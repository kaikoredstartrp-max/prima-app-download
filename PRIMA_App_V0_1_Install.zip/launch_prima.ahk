﻿#Requires AutoHotkey v2.0
; PRIMA local launcher — launches PrimaApp.ahk from this folder.
Run(A_ScriptDir "\PrimaApp.ahk")
