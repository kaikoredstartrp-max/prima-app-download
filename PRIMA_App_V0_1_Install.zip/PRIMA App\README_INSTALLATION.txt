PRIMA App V0.1 — Installation
=============================

PRIMA App est une version locale. Vos profils restent sur votre ordinateur.

Contenu :
- PRIMA App.exe (application Windows avec logo PRIMA)
- Soul / VDA / Shadow
- Questions chirurgicales
- Reprise test sécurisée
- Rester connecté sécurisé
- Ranking corrigé + modification de l'ordre possible
- Choix Univers
- Choix Territoire
- Choix Race / Forme symbolique
- Forces/faiblesses cohérentes par territoire
- Identité PRIMA verrouillée par profil

Important :
Pour cette version, créez un profil neuf.
Les anciens profils de test peuvent contenir des états corrompus.

Installation :
1. Téléchargez le fichier ZIP.
2. Extrayez le dossier « PRIMA App » sur votre PC Windows.
   Ne lancez pas l'application depuis le ZIP non extrait.
3. Double-cliquez sur « PRIMA App.exe ».
4. Créez un profil neuf et un mot de passe local.
5. Utilisez Kit PRIMA pour vérifier l'installation (optionnel).

AutoHotkey v2 n'est pas requis : l'application est fournie en .exe.
