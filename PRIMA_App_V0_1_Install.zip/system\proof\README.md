# system/proof

Espace réservé au module Proof PRIMA.

## V0.1

Non implémenté. Le bouton **Proof** sur Home est visible mais désactivé.

## Référence

Documents officiels attendus (voir `_drive_reference/REQUIRED_DOCS.md`) :

- PRIMA — Validation Inter-Discussions V1
