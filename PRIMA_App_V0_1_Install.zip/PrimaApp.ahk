#Requires AutoHotkey v2.0
#SingleInstance Force

; PRIMA App V0.1 — Clean Spine Foundation
; Local-only. No network. No cloud. No telemetry.

global APP_VERSION := "V0.1"
global APP_TITLE := "PRIMA App V0.1"
global APP_ROOT := A_ScriptDir
global PROFILES_DIR := APP_ROOT "\profiles"
global ARCHIVE_DIR := APP_ROOT "\archive"
global LOGS_DIR := APP_ROOT "\logs"
global REVIEWS_DIR := APP_ROOT "\reviews"
global SETTINGS_DIR := APP_ROOT "\settings"
global SESSION_FILE := SETTINGS_DIR "\session.ini"
global PROFILES_INDEX := PROFILES_DIR "\profiles.ini"
global APP_STATE_FILE := PROFILES_DIR "\app_state.ini"
global CURRENT_PROFILE_ID := ""
global CURRENT_DISPLAY_NAME := ""
global CURRENT_LANG := "fr"
global DRAFT_LANG := "fr"
global DRAFT_NAME := ""
global DRAFT_MODE := "client"
global DRAFT_PASSWORD := ""
global DRAFT_PASSWORD_CONFIRM := ""
global DRAFT_GENDER := "unspecified"
global PENDING_PROFILE_ID := ""
global CREATOR_CODE := "goat"
global REVIEW_SELECTED_DOMAIN_IDX := 1
global GOALS_DOMAIN_IDX := 1
global PRIMA_SOUL_BACK := "home"
global GOALS_BACK_SCREEN := "personal_base"
global REVIEW_BACK_SCREEN := "home"
global KIT_BACK_SCREEN := "home"
global VDA_BACK_SCREEN := "prima_soul_intro"
global SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
global UNIVERSE_BACK_SCREEN := "soul_reading_hub"
global KIT_AI_DDL
global KIT_STATUS_TEXT
global KIT_LAST_CHECKS := ""
global LAUNCHER_FILE := APP_ROOT "\launch_prima.ahk"
global PRIMA_SHORTCUT_FILE := APP_ROOT "\PRIMA App.lnk"
global AUTOHOTKEY_OFFICIAL_URL := "https://www.autohotkey.com/"
global MAIN_GUI := ""
global ACTIVE_HWND := 0
global CURRENT_SCREEN := ""
global IS_DESTROYING := false
global IS_PAUSED := false
global PRIMA_QA_MODE := false
global PRIMA_QA_SKIP_SHOW := false

global CLR_BG := "1a1a2e"
global CLR_PANEL := "2d2d44"
global CLR_TEXT := "E8E8E8"
global CLR_SUBTEXT := "B0B0B0"
global CLR_ACCENT := "E94560"

; ── Grille UI PRIMA (géométrie globale — affichage uniquement) ─────────────────
global WINDOW_W := 1050
global WINDOW_H := 760
global FORM_WINDOW_W := 520
global FORM_WINDOW_H := 680
global FORM_MARGIN_X := 80
global FORM_MARGIN_Y := 10
global FORM_FIELD_W := 360
global FORM_BTN_W := 360
global FORM_BTN_H := 30
global MARGIN_X := 48
global MARGIN_Y := 28
global CONTENT_W := 880
global CARD_W := 880
global CARD_H := 128
global BUTTON_W := 880
global BUTTON_H := 38
global BUTTON_H_BIG := 48
global BUTTON_W_PICK := 880
global GAP_X := 12
global GAP_Y := 10
global GAP_SM := 6
global GAP_MD := 12
global GAP_LG := 18
global GAP_XL := 24
global TITLE_H := 36
global TEXT_H := 24
global INPUT_W := 880
global ANSWER_W := 880
global ANSWER_H := 38
global ANSWER_H_LG := 48
; Grille écrans de questions (Soul / VDA / Shadow)
global TEST_TITLE_Y := 40
global TEST_COUNT_Y := 120
global TEST_PROMPT_Y := 165
global TEST_PROMPT_H := 36
global TEST_HINT_Y := 205
global TEST_HINT_H := 26
global TEST_RULE_Y := 238
global TEST_ANSWERS_Y := 245
global TEST_ANSWER_W := 820
global TEST_ANSWER_H_DEF := 46
global TEST_NAV_GAP_AFTER := 28
global TEST_NAV_MAX_Y := 650
global TEST_NAV_BTN_W := 400
global TEST_NAV_GAP := 20
global GAP_TEST_ANSWER := 10
global TEST_ANSWER_MAX_H := 64
; Grille hub PRIMA Soul (2 colonnes × 2 lignes)
global SOUL_HUB_CARD_W := 420
global SOUL_HUB_CARD_H := 90
global SOUL_HUB_GAP := 24
global SOUL_HUB_TITLE_Y := 45
global SOUL_HUB_INTRO_Y := 95
global SOUL_HUB_GRID_Y := 140
global SOUL_HUB_FOOTER_Y := 620
global SOUL_HUB_FOOTER_BTN_W := 280
global SOUL_HUB_COMPLETE_GRID_Y := 200
global SOUL_HUB_TESTS_STATUS_Y := 430
; Écrans lancement test (Soul / VDA / Shadow)
global LAUNCH_TITLE_Y := 45
global LAUNCH_INTRO_Y := 115
global LAUNCH_INTRO_H := 56
global LAUNCH_ACTION_Y := 300
global LAUNCH_ACTION_W := 420
global LAUNCH_ACTION_H := 48
global LAUNCH_NAV_Y := 650
; Grille hub lecture PRIMA (2 colonnes × 4 lignes)
global READING_HUB_TITLE_Y := 45
global READING_HUB_INTRO_Y := 115
global READING_HUB_INTRO_H := 56
global READING_HUB_GRID_Y := 235
global READING_HUB_BTN_W := 420
global READING_HUB_BTN_H := 42
global READING_HUB_GAP_X := 24
global READING_HUB_GAP_Y := 14
; Grille écrans choix Univers / Territoire (3 cartes visibles, 1050×760)
global CHOICE_TITLE_Y := 45
global CHOICE_INTRO_Y := 120
global CHOICE_INTRO_H := 44
global CHOICE_CARD_X := 85
global CHOICE_CARD_W := 880
global CHOICE_CARD_H := 120
global CHOICE_CARD_GAP := 18
global CHOICE_CARD_START_Y := 220
global CHOICE_PICK_W := 160
global PAGED_CHOICE_PAGE_Y := 185
global PAGED_CHOICE_CARD_Y := 220
global PAGED_CHOICE_CARD_H := 220
global PAGED_CHOICE_NAV_Y := 530
global PAGED_CHOICE_NAV_BTN_W := 200
global PAGED_CHOICE_PICK_W := 260
global CHOICE_NAV_Y := 650
; Zone scrollable (header/footer fixes, contenu central défilable)
global SCROLL_VIEWPORT_Y := 175
global SCROLL_VIEWPORT_H := 472
global SCROLL_FOOTER_Y := 650
global SCROLL_AREA := ""
global PRIMARY_ENTER_ACTION := ""
global PRIMARY_ENTER_HOOKED := false
global PRIMARY_ENTER_BUSY := false

; ── Init ──────────────────────────────────────────────────────────────────────
for arg in A_Args {
    if (arg = "--run-tests") {
        PRIMA_QA_MODE := true
        break
    }
}

if (!PRIMA_QA_MODE) {
    EnsureDirectories()
    WriteLog("app_started")
    SetWorkingDir(APP_ROOT)

    ^!+x::PauseApp()
    ^!+q::EmergencyExit()

    ResetLegacyProfilesIfNeeded()
    if !TryAutoLoginOnStart()
        RenderScreen("profile")
} else {
    EnsureDirectories()
    SetWorkingDir(APP_ROOT)
}

; ── Navigation centrale ───────────────────────────────────────────────────────
CloseCurrentWindow() {
    global MAIN_GUI, ACTIVE_HWND, IS_DESTROYING
    ClearPrimaryEnterAction()
    IS_DESTROYING := true
    DestroyScrollArea()
    hwnd := ACTIVE_HWND
    if (MAIN_GUI != "") {
        try MAIN_GUI.Destroy()
        MAIN_GUI := ""
    }
    if (hwnd && WinExist("ahk_id " hwnd)) {
        try WinClose("ahk_id " hwnd)
    }
    ACTIVE_HWND := 0
    IS_DESTROYING := false
}

RenderScreen(screenName) {
    global CURRENT_SCREEN
    CloseCurrentWindow()
    CURRENT_SCREEN := screenName
    switch screenName {
        case "profile":    BuildProfile()
        case "profile_login": BuildProfileLogin()
        case "archives":   BuildArchives()
        case "create":     BuildCreateProfile()
        case "create_security": BuildCreateProfileSecurity()
        case "privacy":    BuildPrivacy()
        case "start_here": BuildStartHere()
        case "home":       BuildHome()
        case "creator_home": BuildCreatorHome()
        case "creator_soul": BuildCreatorSoul()
        case "kit":          BuildKitPrima()
        case "onboarding":       BuildOnboarding()
        case "personal_base":    BuildPersonalBase()
        case "prima_soul_intro": BuildPrimaSoulIntro()
        case "prima_soul_vda":      BuildPrimaSoulVda()
        case "prima_soul_question": BuildPrimaSoulQuestion()
        case "prima_vda_done":      BuildPrimaVdaDone()
        case "prima_vda_rank":      BuildPrimaVdaRankQuestion()
        case "prima_vda_rank_done": BuildPrimaVdaRankDone()
        case "prima_soul_done":    BuildPrimaSoulDone()
        case "prima_soul_test":     BuildPrimaSoulTest()
        case "prima_soul_shadow":   BuildPrimaSoulShadow()
        case "prima_shadow_question": BuildPrimaShadowQuestion()
        case "prima_shadow_done":     BuildPrimaShadowDone()
        case "soul_reading_hub":      BuildSoulReadingHub()
        case "soul_reading_soul":     BuildSoulReadingSoul()
        case "soul_reading_vda":      BuildSoulReadingVda()
        case "soul_reading_shadow":   BuildSoulReadingShadow()
        case "prima_architecture_locked": BuildPrimaArchitectureLocked()
        case "prima_universe_choice": BuildPrimaUniverseChoice()
        case "prima_universe_detail": BuildPrimaUniverseDetail()
        case "prima_territory_choice": BuildPrimaTerritoryChoice()
        case "prima_territory_detail": BuildPrimaTerritoryDetail()
        case "prima_identity_saved":  BuildPrimaIdentitySaved()
        case "prima_identity_result": BuildPrimaIdentityResult()
        case "prima_soul_settings": BuildPrimaSoulSettings()
        case "prima_soul_choices": BuildPrimaSoulChoices()
        case "onboarding_goals": BuildOnboardingGoals()
        case "settings":         BuildSettings()
        case "review":     BuildReview()
    }
}

HandleGuiClose(*) {
    global IS_DESTROYING
    if (IS_DESTROYING)
        return
    if (!ConfirmExit("x"))
        return true
}

ShowMainGui() {
    global MAIN_GUI, ACTIVE_HWND, WINDOW_W, WINDOW_H
    if (MAIN_GUI = "")
        return
    MAIN_GUI.OnEvent("Close", HandleGuiClose)
    MAIN_GUI.Show("w" WINDOW_W " h" WINDOW_H " Center")
    ACTIVE_HWND := MAIN_GUI.Hwnd
}

; Entrée = action principale (écran unique). Ignorée si champ texte actif ou fenêtre inactive.
ClearPrimaryEnterAction() {
    global PRIMARY_ENTER_ACTION, PRIMARY_ENTER_HOOKED
    PRIMARY_ENTER_ACTION := ""
    if (PRIMARY_ENTER_HOOKED) {
        OnMessage(0x0100, PrimaryEnterKeyDown, 0)
        PRIMARY_ENTER_HOOKED := false
    }
}

SetPrimaryEnterAction(action) {
    global PRIMARY_ENTER_ACTION, PRIMARY_ENTER_HOOKED
    ClearPrimaryEnterAction()
    if (action = "")
        return
    PRIMARY_ENTER_ACTION := action
    if (!PRIMARY_ENTER_HOOKED) {
        OnMessage(0x0100, PrimaryEnterKeyDown, 1)
        PRIMARY_ENTER_HOOKED := true
    }
}

PrimaryEnterFocusIsTextInput() {
    global ACTIVE_HWND
    if (!ACTIVE_HWND)
        return false
    try {
        focused := ControlGetFocus("ahk_id " ACTIVE_HWND)
        if (focused = "")
            return false
        return RegExMatch(focused, "i)^(Edit|ComboBox|DropDownList)")
    } catch
        return false
}

PrimaryEnterKeyDown(wParam, lParam, msg, hwnd) {
    global PRIMARY_ENTER_ACTION, ACTIVE_HWND, IS_DESTROYING, PRIMARY_ENTER_BUSY
    if (IS_DESTROYING || PRIMARY_ENTER_ACTION = "" || PRIMARY_ENTER_BUSY)
        return
    if ((wParam & 0xFF) != 0x0D)
        return
    if (lParam & 0x40000000)
        return
    if (!ACTIVE_HWND || hwnd != ACTIVE_HWND)
        return
    if PrimaryEnterFocusIsTextInput()
        return
    action := PRIMARY_ENTER_ACTION
    if (action = "")
        return
    PRIMARY_ENTER_BUSY := true
    try action.Call()
    catch as e
        WriteLog("primary_enter_failed", e.Message)
    finally
        PRIMARY_ENTER_BUSY := false
    return 0
}

; Affichage unifié écrans PRIMA Soul (1050×760 centré).
ShowScreen() {
    global PRIMA_QA_SKIP_SHOW
    if (PRIMA_QA_SKIP_SHOW)
        return
    FinalizeScrollableContentArea()
    ShowMainGui()
}

; ── Zone scrollable (GUI enfant + barre verticale + molette) ───────────────────
DestroyScrollArea() {
    global SCROLL_AREA
    if !IsObject(SCROLL_AREA)
        return
    try {
        if (SCROLL_AREA.HasProp("onScroll") && SCROLL_AREA.onScroll)
            OnMessage(0x0115, SCROLL_AREA.onScroll, 0)
        if (SCROLL_AREA.HasProp("onWheel") && SCROLL_AREA.onWheel)
            OnMessage(0x020A, SCROLL_AREA.onWheel, 0)
    }
    if (SCROLL_AREA.HasProp("gui") && SCROLL_AREA.gui != "")
        try SCROLL_AREA.gui.Destroy()
    SCROLL_AREA := ""
}

; Crée une zone de contenu défilable dans la fenêtre parente (coords client parent).
CreateScrollableContentArea(parentG, x, y, w, h) {
    global SCROLL_AREA, CLR_BG, CLR_TEXT
    DestroyScrollArea()
    cg := Gui("-Caption +Border +0x200000")
    cg.BackColor := CLR_BG
    cg.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    area := { gui: cg, parent: parentG, x: x, y: y, w: w, h: h, onScroll: "", onWheel: "" }
    area.onScroll := ScrollArea_OnScroll.Bind(area)
    area.onWheel := ScrollArea_OnWheel.Bind(area)
    SCROLL_AREA := area
    return cg
}

FinalizeScrollableContentArea() {
    global SCROLL_AREA, MARGIN_X, CONTENT_W, CLR_BG, CLR_SUBTEXT
    if !IsObject(SCROLL_AREA) || SCROLL_AREA.gui = ""
        return
    parent := SCROLL_AREA.parent
    cg := SCROLL_AREA.gui
    DllCall("SetParent", "Ptr", cg.Hwnd, "Ptr", parent.Hwnd)
    style := DllCall("GetWindowLongPtr", "Ptr", cg.Hwnd, "Int", -16, "Ptr")
    DllCall("SetWindowLongPtr", "Ptr", cg.Hwnd, "Int", -16, "Ptr", style | 0x40000000)
    cg.Show("x" SCROLL_AREA.x " y" SCROLL_AREA.y " w" SCROLL_AREA.w " h" SCROLL_AREA.h)
    ScrollArea_UpdateScrollBars(SCROLL_AREA)
    OnMessage(0x0115, SCROLL_AREA.onScroll)
    OnMessage(0x020A, SCROLL_AREA.onWheel)
}

ScrollArea_ContentExceedsViewport(area) {
    cg := area.gui
    WinGetClientPos(, , , , cg.Hwnd)
    bottom := 0
    for ctrlHwnd in WinGetControlsHwnd(cg.Hwnd) {
        ControlGetPos(, , , &ch, ctrlHwnd)
        if (ctrlHwnd = cg.Hwnd)
            continue
        ControlGetPos(, &cy, , , ctrlHwnd)
        bottom := Max(bottom, cy + ch)
    }
    return bottom > area.h + 4
}

ScrollArea_UpdateScrollBars(area) {
    cg := area.gui
    WinGetClientPos(, , &gw, &gh, cg.Hwnd)
    top := 2147483647
    bottom := -2147483648
    for ctrlHwnd in WinGetControlsHwnd(cg.Hwnd) {
        ControlGetPos(, &cy, , &ch, ctrlHwnd)
        top := Min(cy, top)
        bottom := Max(cy + ch, bottom)
    }
    if (top = 2147483647)
        top := 0
    scrH := bottom - top + 16
    SI := Buffer(28, 0)
    NumPut("UInt", 28, SI, 0)
    NumPut("UInt", 0x1 | 0x2 | 0x8, SI, 4)
    NumPut("Int", 0, SI, 8)
    NumPut("Int", scrH, SI, 12)
    NumPut("Int", gh, SI, 16)
    NumPut("Int", 0, SI, 20)
    DllCall("SetScrollInfo", "Ptr", cg.Hwnd, "Int", 1, "Ptr", SI, "Int", 1)
}

ScrollArea_IsMouseOver(area) {
    pt := Buffer(8, 0)
    DllCall("GetCursorPos", "Ptr", pt)
    NumPut("Int", NumGet(pt, 0, "Int"), pt, 0)
    NumPut("Int", NumGet(pt, 4, "Int"), pt, 4)
    DllCall("ScreenToClient", "Ptr", area.gui.Hwnd, "Ptr", pt)
    cx := NumGet(pt, 0, "Int")
    cy := NumGet(pt, 4, "Int")
    WinGetClientPos(, , &cw, &ch, area.gui.Hwnd)
    return cx >= 0 && cy >= 0 && cx < cw && cy < ch
}

ScrollArea_OnWheel(area, wParam, lParam, msg, hwnd) {
    if !ScrollArea_IsMouseOver(area)
        return
    if (hwnd = area.gui.Hwnd) {
        ht := DllCall("SendMessage", "Ptr", hwnd, "UInt", 0x0084, "Ptr", 0, "Ptr", lParam, "Ptr")
        if (ht = 6 || ht = 7) {
            sb := (wParam & 0x80000000) ? 1 : 0
            ScrollArea_OnScroll(area, sb, 0, (ht = 6) ? 0x0114 : 0x0115, hwnd)
            return 0
        }
    }
    delta := (wParam >> 16) & 0xFFFF
    if (delta >= 0x8000)
        delta -= 0x10000
    steps := (delta < 0) ? 3 : -3
    loop Abs(steps)
        ScrollArea_OnScroll(area, (steps > 0) ? 1 : 0, 0, 0x0115, area.gui.Hwnd)
    return 0
}

ScrollArea_OnScroll(area, wParam, lParam, msg, hwnd) {
    static SCROLL_STEP := 24
    if (hwnd != area.gui.Hwnd)
        return
    if (lParam != 0)
        return
    bar := (msg = 0x0115) ? 1 : 0
    SI := Buffer(28, 0)
    NumPut("UInt", 28, SI, 0)
    NumPut("UInt", 0x17, SI, 4)
    if !DllCall("GetScrollInfo", "Ptr", hwnd, "Int", bar, "Ptr", SI)
        return
    RC := Buffer(16, 0)
    DllCall("GetClientRect", "Ptr", hwnd, "Ptr", RC)
    newPos := NumGet(SI, 20, "Int")
    minPos := NumGet(SI, 8, "Int")
    maxPos := NumGet(SI, 12, "Int")
    switch (wParam & 0xFFFF) {
        case 0: newPos -= SCROLL_STEP
        case 1: newPos += SCROLL_STEP
        case 2: newPos -= NumGet(RC, 12, "Int") - SCROLL_STEP
        case 3: newPos += NumGet(RC, 12, "Int") - SCROLL_STEP
        case 4, 5: newPos := wParam >> 16
        case 6: newPos := minPos
        case 7: newPos := maxPos
        default: return
    }
    maxPos -= NumGet(SI, 16, "Int")
    newPos := Max(minPos, Min(newPos, maxPos))
    oldPos := NumGet(SI, 20, "Int")
    x := (bar = 0) ? oldPos - newPos : 0
    y := (bar = 1) ? oldPos - newPos : 0
    if (x || y) {
        DllCall("ScrollWindow", "Ptr", hwnd, "Int", x, "Int", y, "Ptr", 0, "Ptr", 0)
        NumPut("Int", newPos, SI, 20)
        DllCall("SetScrollInfo", "Ptr", hwnd, "Int", bar, "Ptr", SI, "Int", 1)
    }
}

; En-tête fixe (haut) pour écrans scrollables.
AddScrollPageHeader(g, title, introLine1, introLine2 := "") {
    AddChoiceScreenHeader(g, title, introLine1, introLine2)
}

; Pied fixe Retour (bas) pour écrans scrollables.
AddScrollPageFooterBack(g, backAction) {
    AddChoiceNavBack(g, backAction)
}

; Estime la hauteur d'un texte multiligne dans une zone donnée (wrap mot entier).
ScrollTextHeight(text, width, lineH := 18) {
    if (text = "")
        return 0
    avgCharW := (lineH <= 16) ? 6 : 7
    maxChars := Max(16, width // avgCharW)
    lineLen := 0
    lines := 1
    for word in StrSplit(text, " ") {
        wLen := StrLen(word)
        if (wLen > maxChars) {
            lines += Ceil(wLen / maxChars)
            lineLen := 0
            continue
        }
        need := lineLen = 0 ? wLen : wLen + 1
        if (lineLen + need > maxChars) {
            lines++
            lineLen := wLen
        } else
            lineLen += need
    }
    return lines * lineH + 8
}

; Section résultat dans zone scrollable — retourne le y suivant.
AddScrollResultSection(cg, y, sectionKey, bodyLines*) {
    global CONTENT_W, CLR_ACCENT, CLR_TEXT, GAP_MD
    pad := 12
    w := CONTENT_W - 2 * pad
    x := pad
    cg.SetFont("s12 Bold c" CLR_ACCENT, "Segoe UI")
    cg.Add("Text", "x" x " y" y " w" w " h22 +Wrap BackgroundTrans", TIcon(sectionKey))
    y += 24
    cg.SetFont("s10 c" CLR_TEXT, "Segoe UI")
    for line in bodyLines {
        if (line = "")
            continue
        h := ScrollTextHeight(line, w, 17)
        cg.Add("Text", "x" x " y" y " w" w " h" h " +Wrap BackgroundTrans", line)
        y += h + 4
    }
    y += GAP_MD
    return y
}

; En-tête de section seul (corps ajouté ensuite).
AddScrollResultSectionHeader(cg, y, sectionKey) {
    global CONTENT_W, CLR_ACCENT
    pad := 12
    w := CONTENT_W - 2 * pad
    x := pad
    cg.SetFont("s12 Bold c" CLR_ACCENT, "Segoe UI")
    cg.Add("Text", "x" x " y" y " w" w " h22 +Wrap BackgroundTrans", TIcon(sectionKey))
    return y + 24
}

; Libellé public + nom officiel discret en gris (jamais présenté comme vérité).
FormatPublicWithOfficial(publicLabel, officialLabel) {
    if (officialLabel = "")
        return publicLabel
    return publicLabel "`n" T("lbl_official_small", officialLabel)
}

; Palier V0.1 pour affichage des tendances (1er=100 % … 5e+=0 %).
PrimaTierPercent(rankPosition) {
    switch rankPosition {
        case 1: return 100
        case 2: return 75
        case 3: return 50
        case 4: return 25
        default: return 0
    }
}

; Étiquette de rôle de palier (base ou phase VDA).
PrimaTierRoleLabel(rankPosition, section := "phase") {
    switch rankPosition {
        case 1:
            return T(section = "base" ? "tier_base_main" : "tier_phase_main")
        case 2:
            return T(section = "base" ? "tier_base_secondary" : "tier_phase_secondary")
        case 3:
            return T(section = "base" ? "tier_base_available" : "tier_phase_available")
        case 4:
            return T(section = "base" ? "tier_base_light" : "tier_phase_light")
        default:
            return T(section = "base" ? "tier_base_low" : "tier_phase_low")
    }
}

; Compare deux entrées triées : score → rangs forts → récence → ordre officiel.
StableScoreRankBefore(a, b) {
    if (a.score != b.score)
        return a.score > b.score
    if (a.r1 != b.r1)
        return a.r1 > b.r1
    if (a.r2 != b.r2)
        return a.r2 > b.r2
    if (a.last != b.last)
        return a.last > b.last
    return a.order < b.order
}

; Compte rangs 1-2 et dernière question pour départage stable (session en cours).
ComputeSessionRankTieMeta(session, keys, getKeysFromAnswer) {
    meta := Map()
    ord := 0
    for key in keys {
        ord += 1
        meta[key] := { r1: 0, r2: 0, last: 0, order: ord }
    }
    if (session = "" || !session.HasOwnProp("rankings") || session.rankings.Length = 0)
        return meta
    qById := Map()
    for q in session.questions
        qById[q.id] := q
    qi := 0
    for r in session.rankings {
        qi += 1
        if !qById.Has(r.question_id)
            continue
        q := qById[r.question_id]
        ansById := Map()
        for ans in q.answers
            ansById[ans.id] := ans
        loop Min(2, r.ranks.Length) {
            rank := A_Index
            aid := r.ranks[rank]
            if !ansById.Has(aid)
                continue
            ans := ansById[aid]
            keyList := getKeysFromAnswer(ans)
            if !(keyList is Array)
                keyList := [keyList]
            for key in keyList {
                if !meta.Has(key)
                    continue
                if (rank = 1)
                    meta[key].r1 += 1
                else
                    meta[key].r2 += 1
                if (qi > meta[key].last)
                    meta[key].last := qi
            }
        }
    }
    return meta
}

SoulAnswerScoreKeys(ans) {
    keys := []
    for key, val in ans.scores
        keys.Push(key)
    return keys
}

PcmAnswerKey(ans) {
    return ans.pcm_key
}

ShadowAnswerKey(ans) {
    return ans.shadow_key
}

; Deux premiers scores égaux ou très proches (affichage note utilisateur).
PrimaTopScoresClose(m, keys, tieMeta := "", absMargin := 0) {
    sorted := SortedAllScoreKeys(m, keys, tieMeta)
    if (sorted.Length < 2 || sorted[1].score = 0)
        return false
    if (sorted[1].score = sorted[2].score)
        return true
    if (absMargin > 0 && sorted[1].score - sorted[2].score <= absMargin)
        return true
    return false
}

; Clés triées par score décroissant (scores > 0 uniquement si minScore > 0).
SortedScoreKeys(m, keys, minScore := 0) {
    sorted := []
    for key in keys {
        if (m[key] > minScore)
            sorted.Push({ key: key, score: m[key] })
    }
    loop sorted.Length {
        i := A_Index
        loop sorted.Length - i {
            j := A_Index + i - 1
            if (sorted[j].score < sorted[j + 1].score) {
                tmp := sorted[j]
                sorted[j] := sorted[j + 1]
                sorted[j + 1] := tmp
            }
        }
    }
    return sorted
}

; Toutes les clés triées par score décroissant (y compris score 0), départage stable si égalité.
SortedAllScoreKeys(m, keys, tieMeta := "") {
    sorted := []
    ord := 0
    for key in keys {
        ord += 1
        r1 := 0, r2 := 0, last := 0
        if (tieMeta != "" && tieMeta.Has(key)) {
            r1 := tieMeta[key].r1
            r2 := tieMeta[key].r2
            last := tieMeta[key].last
        }
        sorted.Push({ key: key, score: (m.Has(key) ? m[key] : 0), r1: r1, r2: r2, last: last, order: ord })
    }
    loop sorted.Length {
        i := A_Index
        loop sorted.Length - i {
            j := A_Index + i - 1
            if (StableScoreRankBefore(sorted[j + 1], sorted[j])) {
                tmp := sorted[j]
                sorted[j] := sorted[j + 1]
                sorted[j + 1] := tmp
            }
        }
    }
    return sorted
}

; Convertit scores bruts en liste { key, pct } triée ; si total=0 → tous les axes à 0 %.
BuildTierResultList(m, keys) {
    sum := 0
    for key in keys
        sum += (m.Has(key) ? m[key] : 0)
    list := []
    if (sum = 0) {
        for key in keys
            list.Push({ key: key, pct: 0 })
        return list
    }
    sorted := SortedAllScoreKeys(m, keys)
    loop sorted.Length
        list.Push({ key: sorted[A_Index].key, pct: PrimaTierPercent(A_Index) })
    return list
}

; Ligne résultat : label public — % + nom officiel discret.
AddScrollResultTierRow(cg, y, publicLabel, officialLabel, tierPct) {
    global CONTENT_W, CLR_TEXT, CLR_SUBTEXT, GAP_SM
    pad := 12
    w := CONTENT_W - 2 * pad
    x := pad
    cg.SetFont("s10 c" CLR_TEXT, "Segoe UI")
    mainLine := publicLabel " — " tierPct " %"
    h := ScrollTextHeight(mainLine, w, 17)
    cg.Add("Text", "x" x " y" y " w" w " h" h " +Wrap BackgroundTrans", mainLine)
    y += h + 2
    if (officialLabel != "") {
        cg.SetFont("s9 c" CLR_SUBTEXT, "Segoe UI")
        small := T("lbl_official_small", officialLabel)
        h2 := ScrollTextHeight(small, w, 15)
        cg.Add("Text", "x" x " y" y " w" w " h" h2 " +Wrap BackgroundTrans", small)
        y += h2 + GAP_SM
    } else {
        y += 4
    }
    return y
}

; Ligne résultat VDA avec rôle de palier (ex. dynamique actuelle principale).
AddScrollResultTierRowLabeled(cg, y, roleLabel, publicLabel, officialLabel, tierPct) {
    global CONTENT_W, CLR_TEXT, CLR_SUBTEXT, GAP_SM
    pad := 12
    w := CONTENT_W - 2 * pad
    x := pad
    cg.SetFont("s10 c" CLR_TEXT, "Segoe UI")
    mainLine := roleLabel " : " publicLabel " — " tierPct " %"
    h := ScrollTextHeight(mainLine, w, 17)
    cg.Add("Text", "x" x " y" y " w" w " h" h " +Wrap BackgroundTrans", mainLine)
    y += h + 2
    if (officialLabel != "") {
        cg.SetFont("s9 c" CLR_SUBTEXT, "Segoe UI")
        small := T("lbl_official_small", officialLabel)
        h2 := ScrollTextHeight(small, w, 15)
        cg.Add("Text", "x" x " y" y " w" w " h" h2 " +Wrap BackgroundTrans", small)
        y += h2 + GAP_SM
    } else {
        y += 4
    }
    return y
}

; Note discrète (italique) dans une zone scrollable.
AddScrollResultNote(cg, y, text) {
    global CONTENT_W, CLR_SUBTEXT, GAP_SM
    if (text = "")
        return y
    pad := 12
    w := CONTENT_W - 2 * pad
    cg.SetFont("s9 Italic c" CLR_SUBTEXT, "Segoe UI")
    h := ScrollTextHeight(text, w, 16)
    cg.Add("Text", "x" pad " y" y " w" w " h" h " +Wrap BackgroundTrans", text)
    return y + h + GAP_SM
}

; Bloc scroll : étiquette + public + (petit : officiel) + pourcentage palier optionnel.
AddScrollLabeledOfficial(cg, y, labelText, publicLabel, officialLabel, tierPct := "") {
    global CONTENT_W, CLR_TEXT, CLR_SUBTEXT
    pad := 12
    w := CONTENT_W - 2 * pad
    x := pad
    cg.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    mainLine := labelText " : " publicLabel
    if (tierPct != "")
        mainLine .= " — " tierPct " %"
    h := ScrollTextHeight(mainLine, w, 17)
    cg.Add("Text", "x" x " y" y " w" w " h" h " +Wrap BackgroundTrans", mainLine)
    y += h + 2
    if (officialLabel != "") {
        cg.SetFont("s9 c" CLR_SUBTEXT, "Segoe UI")
        small := T("lbl_official_small", officialLabel)
        h2 := ScrollTextHeight(small, w, 15)
        cg.Add("Text", "x" x " y" y " w" w " h" h2 " +Wrap BackgroundTrans", small)
        y += h2 + 6
    } else {
        y += 4
    }
    return y
}

; Carte choix dans zone scrollable (y relatif, 3 cartes empilées).
AddFixedChoiceCardScroll(cg, row, roleLabel, title, desc, pickAction) {
    global CHOICE_CARD_W, CHOICE_CARD_H, CHOICE_CARD_GAP, CHOICE_PICK_W, BUTTON_H
    global MARGIN_X, CHOICE_CARD_X, CLR_PANEL, CLR_SUBTEXT, CLR_TEXT, CLR_ACCENT, CONTENT_W
    cardX := CHOICE_CARD_X - MARGIN_X
    y := 8 + (row - 1) * (CHOICE_CARD_H + CHOICE_CARD_GAP)
    w := CHOICE_CARD_W
    h := CHOICE_CARD_H
    cg.Add("Text", "x" cardX " y" y " w" w " h" h " Background" CLR_PANEL, "")
    cg.SetFont("s9 c" CLR_SUBTEXT, "Segoe UI")
    cg.Add("Text", "x" (cardX + 16) " y" (y + 8) " w" (w - 32) " h18 BackgroundTrans", roleLabel)
    cg.SetFont("s12 Bold c" CLR_ACCENT, "Segoe UI")
    cg.Add("Text", "x" (cardX + 16) " y" (y + 28) " w" (w - CHOICE_PICK_W - 40) " h24 BackgroundTrans", title)
    cg.SetFont("s10 c" CLR_TEXT, "Segoe UI")
    cg.Add("Text", "x" (cardX + 16) " y" (y + 52) " w" (w - CHOICE_PICK_W - 40) " h44 +0x2000 BackgroundTrans", desc)
    pickX := cardX + w - CHOICE_PICK_W - 16
    pickY := y + h - BUTTON_H - 12
    btn := cg.Add("Button", "x" pickX " y" pickY " w" CHOICE_PICK_W " h" BUTTON_H " Center", TIcon("btn_pick"))
    btn.OnEvent("Click", pickAction)
}

; Bouton hub lecture dans zone scrollable.
AddReadingHubButtonScroll(cg, col, row, label, action) {
    global READING_HUB_BTN_W, READING_HUB_BTN_H, READING_HUB_GAP_X, READING_HUB_GAP_Y, CONTENT_W
    gridW := 2 * READING_HUB_BTN_W + READING_HUB_GAP_X
    startX := (CONTENT_W - gridW) // 2
    x := startX + (col - 1) * (READING_HUB_BTN_W + READING_HUB_GAP_X)
    y := 8 + (row - 1) * (READING_HUB_BTN_H + READING_HUB_GAP_Y)
    btn := cg.Add("Button", "x" x " y" y " w" READING_HUB_BTN_W " h" READING_HUB_BTN_H " Center", label)
    btn.OnEvent("Click", action)
}

ShowFormGui() {
    global MAIN_GUI, ACTIVE_HWND, FORM_WINDOW_W, FORM_WINDOW_H
    if (MAIN_GUI = "")
        return
    MAIN_GUI.OnEvent("Close", HandleGuiClose)
    MAIN_GUI.Show("w" FORM_WINDOW_W " h" FORM_WINDOW_H " Center")
    ACTIVE_HWND := MAIN_GUI.Hwnd
}

ShowCreateProfileGui() {
    ShowFormGui()
}

NewFormGui() {
    global MAIN_GUI, CLR_BG, CLR_TEXT, FORM_WINDOW_W, FORM_WINDOW_H, FORM_MARGIN_X, FORM_MARGIN_Y
    g := Gui("-Resize +MinSize" FORM_WINDOW_W "x" FORM_WINDOW_H, APP_TITLE)
    g.BackColor := CLR_BG
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
    g.MarginX := FORM_MARGIN_X
    g.MarginY := FORM_MARGIN_Y
    MAIN_GUI := g
    return g
}

NewCreateGui() {
    return NewFormGui()
}

NewGui() {
    global MAIN_GUI, CLR_BG, CLR_TEXT, MARGIN_X, MARGIN_Y
    g := Gui("-Resize +MinSize" WINDOW_W "x" WINDOW_H, APP_TITLE)
    g.BackColor := CLR_BG
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
    g.MarginX := MARGIN_X
    g.MarginY := MARGIN_Y
    MAIN_GUI := g
    return g
}

VerifyLocalSaves() {
    global CURRENT_PROFILE_ID, PROFILES_DIR
    if (CURRENT_PROFILE_ID = "")
        return true
    profileDir := PROFILES_DIR "\" CURRENT_PROFILE_ID
    return DirExist(profileDir) && FileExist(profileDir "\profile.ini")
}

ConfirmExit(source := "x") {
    global MAIN_GUI
    if (source = "quit" && IsRememberMeEnabled()) {
        result := MsgBox(T("confirm_quit_remember"), APP_TITLE, "YesNoCancel Icon?")
        if (result = "Cancel")
            return false
        if (result = "No") {
            ClearRememberMeSession()
            AppExit()
            return true
        }
        AppExit()
        return true
    }
    if (source = "quit") {
        prompt := T("confirm_quit")
        if (VerifyLocalSaves())
            prompt .= "`n`n" T("confirm_saved")
        else
            prompt .= "`n`n" T("confirm_missing")
    } else {
        prompt := T("confirm_close")
    }
    result := MsgBox(prompt, APP_TITLE, "YesNo Icon?")
    if (result != "Yes")
        return false
    AppExit()
    return true
}

AppExit() {
    SaveSoulSessionState()
    SaveVdaSessionState()
    SaveShadowSessionState()
    WriteLog("app_closed")
    CloseCurrentWindow()
    ExitApp()
}

; ── Directories ───────────────────────────────────────────────────────────────
EnsureDirectories() {
    for dir in [PROFILES_DIR, ARCHIVE_DIR, LOGS_DIR, REVIEWS_DIR, SETTINGS_DIR] {
        if !DirExist(dir)
            DirCreate(dir)
    }
}

; ── Session locale — rester connecté (sans mot de passe ni données sensibles) ─
IsRememberMeEnabled() {
    EnsureDirectories()
    if !FileExist(SESSION_FILE)
        return false
    return IniRead(SESSION_FILE, "session", "remember_me", "0") = "1"
}

GetRememberedProfileId() {
    if !IsRememberMeEnabled()
        return ""
    pid := IniRead(SESSION_FILE, "session", "last_profile_id", "")
    if (pid = "" || !FileExist(PROFILES_DIR "\" pid "\profile.ini"))
        return ""
    return pid
}

SaveRememberMeSession(profileId, remember := true) {
    EnsureDirectories()
    if !remember {
        ClearRememberMeSession()
        return
    }
    IniWrite("1", SESSION_FILE, "session", "remember_me")
    IniWrite(profileId, SESSION_FILE, "session", "last_profile_id")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm:ss"), SESSION_FILE, "session", "last_login_at")
    IniWrite("1", SESSION_FILE, "session", "resume_on_start")
    WriteLog("session_remember_saved", profileId)
}

ClearRememberMeSession() {
    EnsureDirectories()
    if FileExist(SESSION_FILE)
        try FileDelete(SESSION_FILE)
    WriteLog("session_remember_cleared")
}

LogoutProfile(*) {
    global CURRENT_PROFILE_ID, CURRENT_DISPLAY_NAME, PENDING_PROFILE_ID, SOUL_SESSION
    ClearRememberMeSession()
    CURRENT_PROFILE_ID := ""
    CURRENT_DISPLAY_NAME := ""
    PENDING_PROFILE_ID := ""
    SOUL_SESSION := ""
    WriteLog("profile_logout")
    RenderScreen("profile")
}

TryAutoLoginOnStart() {
    pid := GetRememberedProfileId()
    if (pid = "")
        return false
    LoadProfile(pid)
    WriteLog("session_auto_login", pid)
    RouteAfterProfileLogin(pid)
    return true
}

; ── Kit PRIMA ─────────────────────────────────────────────────────────────────
GetKitAiValues() {
    return ["ChatGPT", "Claude", "Gemini", "Cursor", "Other"]
}

GetKitAiLabels() {
    return ["ChatGPT", "Claude", "Gemini", "Cursor", T("kit_ai_other")]
}

GetKitIniPath(profileId) {
    return PROFILES_DIR "\" profileId "\kit.ini"
}

GetKitCheckKeys() {
    return ["root_folder", "prima_app", "autohotkey_available", "ahk_launcher", "prima_shortcut", "profiles_folder", "logs_folder", "reviews_folder", "profiles_ini"]
}

FindAutoHotkeyExe() {
    if (A_AhkPath != "" && FileExist(A_AhkPath))
        return A_AhkPath
    candidates := [
        A_ProgramFiles "\AutoHotkey\v2\AutoHotkey64.exe",
        A_ProgramFiles "\AutoHotkey\v2\AutoHotkey32.exe",
        A_ProgramFiles "\AutoHotkey\UX\AutoHotkeyUX.exe"
    ]
    localAppData := EnvGet("LOCALAPPDATA")
    if (localAppData != "") {
        candidates.Push(localAppData "\Programs\AutoHotkey\v2\AutoHotkey64.exe")
        candidates.Push(localAppData "\Programs\AutoHotkey\v2\AutoHotkey.exe")
    }
    pf86 := EnvGet("ProgramFiles(x86)")
    if (pf86 != "") {
        candidates.Push(pf86 "\AutoHotkey\v2\AutoHotkey32.exe")
        candidates.Push(pf86 "\AutoHotkey\v2\AutoHotkey64.exe")
    }
    for path in candidates {
        if FileExist(path)
            return path
    }
    return ""
}

IsAutoHotkeyAvailable() {
    return FindAutoHotkeyExe() != ""
}

KitOfferAutoHotkeyDownload() {
    result := MsgBox(T("msg_autohotkey_missing"), APP_TITLE, "YesNo Icon?")
    if (result = "Yes")
        Run(AUTOHOTKEY_OFFICIAL_URL)
}

KitStatusLabel(ok) {
    return ok ? T("status_ok") : T("status_missing")
}

RunKitChecks() {
    return {
        root_folder: DirExist(APP_ROOT),
        prima_app: FileExist(APP_ROOT "\PrimaApp.ahk"),
        autohotkey_available: IsAutoHotkeyAvailable(),
        ahk_launcher: FileExist(LAUNCHER_FILE),
        prima_shortcut: IsKitShortcutValid(),
        profiles_folder: DirExist(PROFILES_DIR),
        logs_folder: DirExist(LOGS_DIR),
        reviews_folder: DirExist(REVIEWS_DIR),
        profiles_ini: FileExist(PROFILES_INDEX)
    }
}

JoinLines(lines) {
    out := ""
    for index, line in lines {
        if (index > 1)
            out .= "`n"
        out .= line
    }
    return out
}

FormatKitStatusText(checks) {
    lines := []
    lines.Push(T("kit_check_root") . ": " . KitStatusLabel(checks.root_folder))
    lines.Push(T("kit_check_prima_app") . ": " . KitStatusLabel(checks.prima_app))
    lines.Push(T("kit_check_autohotkey") . ": " . KitStatusLabel(checks.autohotkey_available))
    lines.Push(T("kit_check_launcher") . ": " . KitStatusLabel(checks.ahk_launcher))
    lines.Push(T("kit_check_shortcut") . ": " . KitStatusLabel(checks.prima_shortcut))
    lines.Push(T("kit_check_profiles") . ": " . KitStatusLabel(checks.profiles_folder))
    lines.Push(T("kit_check_logs") . ": " . KitStatusLabel(checks.logs_folder))
    lines.Push(T("kit_check_reviews") . ": " . KitStatusLabel(checks.reviews_folder))
    lines.Push(T("kit_check_profiles_ini") . ": " . KitStatusLabel(checks.profiles_ini))
    return JoinLines(lines)
}

KitAllChecksOk(checks) {
    for , key in GetKitCheckKeys() {
        if !checks.%key%
            return false
    }
    return true
}

LoadKitSelectedAi(profileId) {
    path := GetKitIniPath(profileId)
    if !FileExist(path)
        return "ChatGPT"
    saved := IniRead(path, "kit", "selected_ai", "ChatGPT")
    values := GetKitAiValues()
    for i, val in values {
        if (val = saved)
            return saved
    }
    return "ChatGPT"
}

KitAiIndexForValue(value) {
    values := GetKitAiValues()
    for i, val in values {
        if (val = value)
            return i
    }
    return 1
}

SaveKitIni(profileId, selectedAi, checks) {
    profileDir := PROFILES_DIR "\" profileId
    if !DirExist(profileDir)
        return false
    path := GetKitIniPath(profileId)
    try {
        now := FormatTime(, "yyyy-MM-dd HH:mm:ss")
        status := KitAllChecksOk(checks) ? "ok" : "missing"
        IniWrite(selectedAi, path, "kit", "selected_ai")
        IniWrite(now, path, "kit", "last_check")
        IniWrite(status, path, "kit", "status")
        for , key in GetKitCheckKeys()
            IniWrite(KitStatusLabel(checks.%key%), path, "checks", key)
        return true
    } catch {
        return false
    }
}

CreateKitLauncher() {
    global APP_ROOT, LAUNCHER_FILE
    if FileExist(LAUNCHER_FILE)
        return true
    if !FileExist(APP_ROOT "\PrimaApp.ahk")
        return false
    content := "#Requires AutoHotkey v2.0`n#SingleInstance Force`n; PRIMA local launcher — launches PrimaApp.ahk from this folder.`nRun(A_ScriptDir `"\PrimaApp.ahk`")`n"
    try {
        FileAppend(content, LAUNCHER_FILE, "UTF-8")
        return true
    } catch {
        return false
    }
}

CreateKitShortcut() {
    global APP_ROOT, LAUNCHER_FILE, PRIMA_SHORTCUT_FILE

    if IsKitShortcutValid()
        return false

    if FileExist(PRIMA_SHORTCUT_FILE) {
        try {
            FileDelete(PRIMA_SHORTCUT_FILE)
        } catch {
            return false
        }
    }

    ahkExe := FindAutoHotkeyExe()
    if (ahkExe = "") {
        MsgBox(T("msg_autohotkey_not_found_shortcut"), APP_TITLE, "Icon!")
        return false
    }
    if !FileExist(LAUNCHER_FILE) && !CreateKitLauncher()
        return false
    try {
        shell := ComObject("WScript.Shell")
        shortcut := shell.CreateShortcut(PRIMA_SHORTCUT_FILE)
        shortcut.TargetPath := ahkExe
        shortcut.Arguments := '"' LAUNCHER_FILE '"'
        shortcut.WorkingDirectory := APP_ROOT
        shortcut.Description := "PRIMA App"
        shortcut.IconLocation := ahkExe . ",0"
        shortcut.Save()
        return true
    } catch {
        return false
    }
}

IsKitShortcutValid() {
    global PRIMA_SHORTCUT_FILE
    if !FileExist(PRIMA_SHORTCUT_FILE)
        return false
    try {
        shell := ComObject("WScript.Shell")
        shortcut := shell.CreateShortcut(PRIMA_SHORTCUT_FILE)
        target := shortcut.TargetPath
        return (target != "" && FileExist(target))
    } catch {
        return false
    }
}

KitCreateMissingItems() {
    created := false
    for dir in [PROFILES_DIR, LOGS_DIR, REVIEWS_DIR] {
        if !DirExist(dir) {
            DirCreate(dir)
            created := true
        }
    }
    if !FileExist(PROFILES_INDEX) {
        try {
            FileAppend("[Index]`n", PROFILES_INDEX, "UTF-8")
            created := true
        }
    }
    if CreateKitLauncher()
        created := true
    if CreateKitShortcut()
        created := true
    return created
}

KitRefreshStatus() {
    global KIT_STATUS_TEXT, KIT_LAST_CHECKS
    KIT_LAST_CHECKS := RunKitChecks()
    if (KIT_STATUS_TEXT != "")
        KIT_STATUS_TEXT.Value := FormatKitStatusText(KIT_LAST_CHECKS)
}

KitVerify(*) {
    global CURRENT_PROFILE_ID
    KitRefreshStatus()
    WriteLog("kit_checked", CURRENT_PROFILE_ID)
    if !IsAutoHotkeyAvailable()
        KitOfferAutoHotkeyDownload()
}

KitCreateMissing(*) {
    global CURRENT_PROFILE_ID
    if KitCreateMissingItems() {
        WriteLog("kit_missing_created", CURRENT_PROFILE_ID)
        WriteProfileLog(CURRENT_PROFILE_ID, "kit_missing_created")
    }
    KitRefreshStatus()
}

KitSave(*) {
    global CURRENT_PROFILE_ID, KIT_AI_DDL, KIT_LAST_CHECKS
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        return
    }
    idx := KIT_AI_DDL.Value
    values := GetKitAiValues()
    selectedAi := values[idx]
    if !IsObject(KIT_LAST_CHECKS)
        KIT_LAST_CHECKS := RunKitChecks()
    if SaveKitIni(CURRENT_PROFILE_ID, selectedAi, KIT_LAST_CHECKS) {
        WriteLog("kit_saved", CURRENT_PROFILE_ID)
        WriteProfileLog(CURRENT_PROFILE_ID, "kit_saved", selectedAi)
        MsgBox(T("msg_kit_saved"), APP_TITLE, "Icon!")
    } else {
        MsgBox(T("msg_kit_save_error"), APP_TITLE, "Icon!")
    }
}

KitBack(*) {
    global KIT_BACK_SCREEN
    RenderScreen(KIT_BACK_SCREEN)
}

OpenKitFromHome(*) {
    global KIT_BACK_SCREEN
    KIT_BACK_SCREEN := "home"
    SetTimer(DeferredRenderKit, -1)
}

OpenKitFromCreator(*) {
    global KIT_BACK_SCREEN
    KIT_BACK_SCREEN := "creator_home"
    SetTimer(DeferredRenderKit, -1)
}

DeferredRenderKit(*) {
    SetTimer(DeferredRenderKit, 0)
    RenderScreen("kit")
}

; Racine projet (correcte même si PrimaApp est #include depuis tests/).
PrimaAppRoot() {
    global APP_ROOT
    if FileExist(APP_ROOT "\PrimaApp.ahk")
        return APP_ROOT
    if FileExist(A_ScriptDir "\PrimaApp.ahk")
        return A_ScriptDir
    if FileExist(A_ScriptDir "\..\PrimaApp.ahk")
        return A_ScriptDir "\.."
    return APP_ROOT
}

; Trace ranking UI (optionnel, ne doit jamais crasher).
SafeTrace(msg) {
    try {
        logDir := PrimaAppRoot() "\tests\logs"
        if !DirExist(logDir)
            DirCreate(logDir)
        FileAppend(FormatTime(, "yyyy-MM-dd HH:mm:ss") " " msg "`n", logDir "\ranking_trace.txt", "UTF-8")
    } catch {
    }
}

; ── Logging ───────────────────────────────────────────────────────────────────
WriteLog(event, extra := "") {
    EnsureDirectories()
    timestamp := FormatTime(, "yyyy-MM-dd HH:mm:ss")
    line := timestamp " | " event
    if (extra != "")
        line .= " | " extra
    line .= "`n"
    logFile := LOGS_DIR "\" FormatTime(, "yyyy-MM-dd") "_prima.log"
    try FileAppend(line, logFile, "UTF-8")
}

WriteProfileLog(profileId, event, extra := "") {
    profileLogDir := PROFILES_DIR "\" profileId "\logs"
    if !DirExist(profileLogDir)
        DirCreate(profileLogDir)
    timestamp := FormatTime(, "yyyy-MM-dd HH:mm:ss")
    line := timestamp " | " event
    if (extra != "")
        line .= " | " extra
    line .= "`n"
    logFile := profileLogDir "\" FormatTime(, "yyyy-MM-dd") "_profile.log"
    try FileAppend(line, logFile, "UTF-8")
}

; ── Profile index ─────────────────────────────────────────────────────────────
GetProfileIds() {
    ids := []
    if !FileExist(PROFILES_INDEX)
        return ids
    loop {
        val := IniRead(PROFILES_INDEX, "Index", "Profile" A_Index, "")
        if (val = "")
            break
        ids.Push(val)
    }
    return ids
}

AddProfileToIndex(profileId) {
    ids := GetProfileIds()
    for id in ids {
        if (id = profileId)
            return
    }
    next := ids.Length + 1
    IniWrite(profileId, PROFILES_INDEX, "Index", "Profile" next)
}

RemoveProfileFromIndex(profileId) {
    ids := GetProfileIds()
    newIds := []
    for id in ids {
        if (id != profileId)
            newIds.Push(id)
    }
    if FileExist(PROFILES_INDEX)
        FileDelete(PROFILES_INDEX)
    for i, id in newIds
        IniWrite(id, PROFILES_INDEX, "Index", "Profile" i)
}

ArchiveProfile(profileId) {
    EnsureDirectories()
    src := PROFILES_DIR "\" profileId
    if !DirExist(src)
        return false
    dest := ARCHIVE_DIR "\" profileId
    if DirExist(dest)
        dest := ARCHIVE_DIR "\" profileId "_" FormatTime(, "yyyyMMdd_HHmmss")
    DirMove(src, dest)
    RemoveProfileFromIndex(profileId)
    WriteLog("profile_archived", profileId)
    return true
}

GetArchiveFolderNames() {
    names := []
    EnsureDirectories()
    if !DirExist(ARCHIVE_DIR)
        return names
    Loop Files, ARCHIVE_DIR "\*", "D" {
        names.Push(A_LoopFileName)
    }
    return names
}

GetArchiveFolderSizeLabel(dirPath) {
    total := 0
    try {
        Loop Files, dirPath "\*", "R" {
            total += A_LoopFileSize
        }
    } catch {
        return "?"
    }
    if (total < 1024)
        return total " B"
    if (total < 1048576)
        return Round(total / 1024, 1) " KB"
    return Round(total / 1048576, 2) " MB"
}

GetArchiveFolderDateLabel(dirPath, folderName) {
    if RegExMatch(folderName, "(\d{8})_(\d{6})", &m) {
        return SubStr(m[1], 1, 4) "-" SubStr(m[1], 5, 2) "-" SubStr(m[1], 7, 2)
            . " " SubStr(m[2], 1, 2) ":" SubStr(m[2], 3, 2)
    }
    try {
        return FormatTime(FileGetTime(dirPath, "C"), "yyyy-MM-dd HH:mm")
    } catch {
        return "—"
    }
}

FormatArchiveListEntry(folderName) {
    dirPath := ARCHIVE_DIR "\" folderName
    return folderName . " | " . GetArchiveFolderSizeLabel(dirPath) . " | " . GetArchiveFolderDateLabel(dirPath, folderName)
}

ResolveArchivePath(folderName) {
    global ARCHIVE_DIR
    if (folderName = "" || InStr(folderName, "\") || InStr(folderName, "/") || InStr(folderName, ".."))
        return ""
    fullPath := ARCHIVE_DIR "\" folderName
    if !DirExist(fullPath)
        return ""
    archiveRoot := RTrim(ARCHIVE_DIR, "\")
    if (StrLower(SubStr(fullPath, 1, StrLen(archiveRoot))) != StrLower(archiveRoot))
        return ""
    if (fullPath = archiveRoot || fullPath = PROFILES_DIR || fullPath = APP_ROOT)
        return ""
    return fullPath
}

IsActiveProfileArchiveName(folderName) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "")
        return false
    return (folderName = CURRENT_PROFILE_ID || InStr(folderName, CURRENT_PROFILE_ID "_") = 1)
}

ArchiveDeletePermanently(*) {
    global ARCHIVE_LIST, ARCHIVE_FOLDER_NAMES, CURRENT_PROFILE_ID
    idx := ARCHIVE_LIST.Value
    if (idx = 0) {
        MsgBox(T("msg_select_archive_delete"), APP_TITLE, "Icon!")
        return
    }
    folderName := ARCHIVE_FOLDER_NAMES[idx]
    if IsActiveProfileArchiveName(folderName) {
        MsgBox(T("msg_active_archive_delete"), APP_TITLE, "Icon!")
        WriteLog("archive_delete_failed", folderName . " | active")
        return
    }
    archivePath := ResolveArchivePath(folderName)
    if (archivePath = "") {
        MsgBox(T("msg_archive_delete_failed"), APP_TITLE, "Icon!")
        WriteLog("archive_delete_failed", folderName . " | invalid_path")
        return
    }
    if (StrLower(SubStr(archivePath, 1, StrLen(ARCHIVE_DIR))) != StrLower(ARCHIVE_DIR)) {
        MsgBox(T("msg_archive_delete_failed"), APP_TITLE, "Icon!")
        WriteLog("archive_delete_failed", folderName . " | outside_archive")
        return
    }
    result1 := MsgBox(T("msg_archive_delete_confirm1", folderName), APP_TITLE, "YesNo Icon?")
    if (result1 != "Yes") {
        WriteLog("archive_delete_cancelled", folderName)
        return
    }
    result2 := MsgBox(T("msg_archive_delete_confirm2"), APP_TITLE, "YesNo Icon?")
    if (result2 != "Yes") {
        WriteLog("archive_delete_cancelled", folderName)
        return
    }
    try {
        if !DirExist(archivePath)
            throw Error("missing")
        DirDelete(archivePath, 1)
        WriteLog("archive_deleted", folderName)
        RenderScreen("archives")
    } catch {
        MsgBox(T("msg_archive_delete_failed"), APP_TITLE, "Icon!")
        WriteLog("archive_delete_failed", folderName)
    }
}

GenerateProfileId(displayName) {
    safe := RegExReplace(displayName, "[^\w\-]", "_")
    if (safe = "")
        safe := "profile"
    return safe "_" FormatTime(, "yyyyMMdd_HHmmss")
}

GetLastProfileId() {
    return IniRead(APP_STATE_FILE, "App", "last_profile_id", "")
}

SetLastProfileId(profileId) {
    IniWrite(profileId, APP_STATE_FILE, "App", "last_profile_id")
}

GetProfileLanguage(profileId) {
    lang := IniRead(PROFILES_DIR "\" profileId "\profile.ini", "Profile", "language", "fr")
    return (lang = "en") ? "en" : "fr"
}

; TODO: Plus tard — adapter certaines formulations de questions selon profile_gender, sans stéréotype ni diagnostic.
GetProfileGender(profileId) {
    if (profileId = "")
        return "unspecified"
    iniPath := PROFILES_DIR "\" profileId "\profile.ini"
    if !FileExist(iniPath)
        return "unspecified"
    g := IniRead(iniPath, "Profile", "profile_gender", "unspecified")
    if (g = "male" || g = "female")
        return g
    return "unspecified"
}

NormalizeProfileGender(gender) {
    if (gender = "male" || gender = "female")
        return gender
    return "unspecified"
}

SaveProfileGender(profileId, gender) {
    if (profileId = "")
        return
    gender := NormalizeProfileGender(gender)
    IniWrite(gender, PROFILES_DIR "\" profileId "\profile.ini", "Profile", "profile_gender")
}

ProfileGenderLabel(gender) {
    switch NormalizeProfileGender(gender) {
        case "male":   return T("gender_male")
        case "female": return T("gender_female")
        default:       return T("gender_unspecified")
    }
}

ProfileGenderChoiceIndex(gender) {
    switch NormalizeProfileGender(gender) {
        case "male":   return 1
        case "female": return 2
        default:       return 3
    }
}

ProfileGenderFromChoiceIndex(index) {
    switch index {
        case 1: return "male"
        case 2: return "female"
        default: return "unspecified"
    }
}

ProfileGenderOptionLabels() {
    return [T("gender_male"), T("gender_female"), T("gender_unspecified_pref")]
}

GetProfileMode(profileId) {
    mode := IniRead(PROFILES_DIR "\" profileId "\profile.ini", "Profile", "mode", "client")
    return (mode = "creator") ? "creator" : "client"
}

IsCreatorProfile(profileId) {
    return GetProfileMode(profileId) = "creator"
}

ProfileHasPassword(profileId) {
    iniPath := PROFILES_DIR "\" profileId "\profile.ini"
    if !FileExist(iniPath)
        return false
    return IniRead(iniPath, "Profile", "password_set", "0") = "1"
}

CollectAllProfileFolderIds() {
    ids := []
    if !DirExist(PROFILES_DIR)
        return ids
    Loop Files, PROFILES_DIR "\*", "D" {
        ids.Push(A_LoopFileName)
    }
    return ids
}

ArchiveResetProfiles(ids) {
    EnsureDirectories()
    stamp := FormatTime(, "yyyyMMdd_HHmmss")
    dest := ARCHIVE_DIR "\reset_profiles_" stamp
    DirCreate(dest)
    for id in ids {
        src := PROFILES_DIR "\" id
        if DirExist(src) {
            try DirMove(src, dest "\" id)
        }
    }
    if FileExist(PROFILES_INDEX)
        FileDelete(PROFILES_INDEX)
    FileAppend("[Index]`n", PROFILES_INDEX, "UTF-8")
    if FileExist(APP_STATE_FILE)
        IniWrite("", APP_STATE_FILE, "App", "last_profile_id")
    WriteLog("profile_reset_archived", dest)
}

ResetLegacyProfilesIfNeeded() {
    ids := CollectAllProfileFolderIds()
    if (ids.Length = 0)
        return
    for id in ids {
        if !ProfileHasPassword(id) {
            ArchiveResetProfiles(ids)
            return
        }
    }
}

GeneratePasswordSalt() {
    salt := ""
    Loop 16
        salt .= Format("{:02x}", Random(0, 255))
    return salt
}

CalcSHA256(text) {
    size := StrPut(text, "UTF-8")
    buf := Buffer(size)
    StrPut(text, buf, "UTF-8")
    dataLen := size - 1
    hProv := 0
    hHash := 0
    hash := Buffer(32, 0)
    hashSize := 32
    if !DllCall("Advapi32\CryptAcquireContext", "Ptr*", &hProv, "Ptr", 0, "Ptr", 0, "UInt", 24, "UInt", 0xF0000000)
        return ""
    if !DllCall("Advapi32\CryptCreateHash", "Ptr", hProv, "UInt", 0x800C, "Ptr", 0, "UInt", 0, "Ptr*", &hHash) {
        DllCall("Advapi32\CryptReleaseContext", "Ptr", hProv, "UInt", 0)
        return ""
    }
    DllCall("Advapi32\CryptHashData", "Ptr", hHash, "Ptr", buf, "UInt", dataLen, "UInt", 0)
    DllCall("Advapi32\CryptGetHashParam", "Ptr", hHash, "UInt", 2, "Ptr", hash, "UInt*", &hashSize, "UInt", 0)
    DllCall("Advapi32\CryptDestroyHash", "Ptr", hHash)
    DllCall("Advapi32\CryptReleaseContext", "Ptr", hProv, "UInt", 0)
    hex := ""
    Loop hashSize
        hex .= Format("{:02x}", NumGet(hash, A_Index - 1, "UChar"))
    return hex
}

BuildPasswordHash(password, salt) {
    return CalcSHA256(salt . password)
}

PasswordHashLogSafe(profileId, salt, hash, event) {
    saltOk := (salt != "") ? "yes" : "no"
    hashLen := StrLen(hash)
    WriteLog(event, profileId . " | salt=" . saltOk . " | hash_len=" . hashLen)
    WriteProfileLog(profileId, event, "salt=" . saltOk . " hash_len=" . hashLen)
}

SetProfilePassword(profileId, password) {
    profileDir := PROFILES_DIR "\" profileId
    password := Trim(password)
    salt := GeneratePasswordSalt()
    hash := BuildPasswordHash(password, salt)
    if (hash = "") {
        PasswordHashLogSafe(profileId, salt, hash, "password_hash_created")
        return false
    }
    IniWrite(salt, profileDir "\profile.ini", "Profile", "password_salt")
    IniWrite(hash, profileDir "\profile.ini", "Profile", "password_hash")
    IniWrite("1", profileDir "\profile.ini", "Profile", "password_set")
    PasswordHashLogSafe(profileId, salt, hash, "password_hash_created")
    WriteLog("profile_password_set", profileId)
    WriteProfileLog(profileId, "profile_password_set")
    return true
}

VerifyProfilePassword(profileId, password) {
    iniPath := PROFILES_DIR "\" profileId "\profile.ini"
    password := Trim(password)
    salt := IniRead(iniPath, "Profile", "password_salt", "")
    hash := IniRead(iniPath, "Profile", "password_hash", "")
    PasswordHashLogSafe(profileId, salt, hash, "password_hash_loaded")
    if (salt = "" || hash = "")
        return false
    computed := BuildPasswordHash(password, salt)
    return (computed != "" && computed = hash)
}

RouteAfterProfileLogin(profileId) {
    global SOUL_TEST_BACK_SCREEN
    LoadProfile(profileId)
    WriteLog("profile_login_success", profileId)
    WriteProfileLog(profileId, "profile_login_success")
    resumeAction := GetNextResumeAction(profileId)
    if (resumeAction = "resume_soul") {
        if (TryResumeSoulSession(profileId)) {
            SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
            RenderScreen("prima_soul_question")
            return
        }
    } else if (resumeAction = "resume_vda") {
        if (TryResumeVdaSession(profileId)) {
            RenderScreen("prima_vda_rank")
            return
        }
    } else if (resumeAction = "resume_shadow") {
        if (TryResumeShadowSession(profileId)) {
            RenderScreen("prima_shadow_question")
            return
        }
    }
    if (IsCreatorProfile(profileId)) {
        RenderScreen("creator_home")
        return
    }
    privacy := IniRead(PROFILES_DIR "\" profileId "\consent.ini", "Consent", "privacy_accepted", "no")
    if (privacy != "yes") {
        RenderScreen("privacy")
        return
    }
    RenderScreen("home")
}

LoadProfile(profileId) {
    global CURRENT_PROFILE_ID, CURRENT_DISPLAY_NAME, CURRENT_LANG
    CURRENT_PROFILE_ID := profileId
    CURRENT_DISPLAY_NAME := IniRead(PROFILES_DIR "\" profileId "\profile.ini", "Profile", "display_name", profileId)
    CURRENT_LANG := GetProfileLanguage(profileId)
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm:ss"), PROFILES_DIR "\" profileId "\profile.ini", "Profile", "last_used_at")
    SetLastProfileId(profileId)
    WriteLog("profile_loaded", profileId " | " CURRENT_DISPLAY_NAME)
}

CanSkipToHome() {
    lastId := GetLastProfileId()
    if (lastId = "")
        return false
    profileDir := PROFILES_DIR "\" lastId
    if !DirExist(profileDir)
        return false
    if (IsCreatorProfile(lastId))
        return true
    privacy := IniRead(profileDir "\consent.ini", "Consent", "privacy_accepted", "no")
    onboarding := IniRead(profileDir "\state.ini", "State", "onboarding_completed", "no")
    return (privacy = "yes" && onboarding = "yes")
}

CreateProfile(displayName, lang := "fr", mode := "client", gender := "unspecified") {
    profileId := GenerateProfileId(displayName)
    profileDir := PROFILES_DIR "\" profileId
    DirCreate(profileDir)
    DirCreate(profileDir "\logs")

    lang := (lang = "en") ? "en" : "fr"
    mode := (mode = "creator") ? "creator" : "client"
    gender := NormalizeProfileGender(gender)
    now := FormatTime(, "yyyy-MM-dd HH:mm:ss")
    IniWrite(profileId, profileDir "\profile.ini", "Profile", "profile_id")
    IniWrite(displayName, profileDir "\profile.ini", "Profile", "display_name")
    IniWrite(lang, profileDir "\profile.ini", "Profile", "language")
    IniWrite(mode, profileDir "\profile.ini", "Profile", "mode")
    IniWrite(gender, profileDir "\profile.ini", "Profile", "profile_gender")
    IniWrite(now, profileDir "\profile.ini", "Profile", "created_at")
    IniWrite(now, profileDir "\profile.ini", "Profile", "last_used_at")
    IniWrite("no", profileDir "\consent.ini", "Consent", "privacy_accepted")
    IniWrite("no", profileDir "\state.ini", "State", "onboarding_completed")

    AddProfileToIndex(profileId)
    LoadProfile(profileId)
    WriteLog("profile_created", profileId . "|" . displayName)
    WriteProfileLog(profileId, "profile_created", displayName)
    return profileId
}

SaveProfileLanguage(profileId, lang) {
    lang := (lang = "en") ? "en" : "fr"
    IniWrite(lang, PROFILES_DIR "\" profileId "\profile.ini", "Profile", "language")
}

RestoreSessionLanguage() {
    global CURRENT_PROFILE_ID, CURRENT_LANG
    if (CURRENT_PROFILE_ID != "")
        CURRENT_LANG := GetProfileLanguage(CURRENT_PROFILE_ID)
    else
        CURRENT_LANG := "fr"
}

SanitizeReviewField(text) {
    return StrReplace(StrReplace(Trim(text), "`r", ""), "`n", " / ")
}

GetMoodLabels() {
    global CURRENT_LANG
    if (CURRENT_LANG = "en")
        return ["Happy", "Sad", "Upset", "Stressed", "Motivated", "Tired", "Calm", "Proud"]
    return ["Heureux", "Triste", "Contrarié", "Stressé", "Motivé", "Fatigué", "Calme", "Fier"]
}

GetMoodCodes() {
    return ["happy", "sad", "upset", "stressed", "motivated", "tired", "calm", "proud"]
}

GetEnergyLabels() {
    global CURRENT_LANG
    if (CURRENT_LANG = "en")
        return ["Energized", "Medium", "Tired", "Exhausted"]
    return ["En forme", "Moyen", "Fatigué", "Épuisé"]
}

GetEnergyCodes() {
    return ["energized", "medium", "tired", "exhausted"]
}

GetDomainCodes() {
    return ["Sport", "Work", "Family", "Health", "Money", "Personal"]
}

GetDomainLabels() {
    global CURRENT_LANG
    if (CURRENT_LANG = "en")
        return ["Sport", "Work", "Family", "Health", "Money", "Personal"]
    return ["Sport", "Travail", "Famille", "Santé", "Argent", "Perso"]
}

GetDomainLabelForCode(code) {
    codes := GetDomainCodes()
    labels := GetDomainLabels()
    loop codes.Length {
        if (codes[A_Index] = code)
            return labels[A_Index]
    }
    return code
}

CodeFromLabel(label) {
    labels := GetDomainLabels()
    codes := GetDomainCodes()
    loop labels.Length {
        if (labels[A_Index] = label)
            return codes[A_Index]
    }
    return ""
}

GoalsIniPath(profileId) {
    return PROFILES_DIR "\" profileId "\goals.ini"
}

; ── PRIMA Soul minimal V0.1 — données locales ─────────────────────────────────
SoulIniPath(profileId) {
    return PROFILES_DIR "\" profileId "\soul.ini"
}

GetSoulChoiceCodes() {
    return Map(
        "tone",   ["soft", "direct", "balanced"],
        "rhythm", ["light", "normal", "sustained"],
        "energy", ["low", "medium", "high"],
        "need",   ["clarity", "motivation", "calm", "structure"],
        "rest",   ["discreet", "guided", "off"]
    )
}

GetSoulChoiceLabels(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "tone":   return ["Soft", "Direct", "Balanced"]
            case "rhythm": return ["Light", "Normal", "Sustained"]
            case "energy": return ["Low", "Medium", "High"]
            case "need":   return ["Clarity", "Motivation", "Calm", "Structure"]
            case "rest":   return ["Discreet", "Guided", "Off"]
        }
    } else {
        switch key {
            case "tone":   return ["Doux", "Direct", "Équilibré"]
            case "rhythm": return ["Léger", "Normal", "Soutenu"]
            case "energy": return ["Basse", "Moyenne", "Haute"]
            case "need":   return ["Clarté", "Motivation", "Calme", "Structure"]
            case "rest":   return ["Discret", "Guidé", "Désactivé"]
        }
    }
    return []
}

LoadSoulChoice(profileId, key) {
    return IniRead(SoulIniPath(profileId), "Soul", key, "")
}

SaveSoulChoices(profileId, tone, rhythm, energy, need, rest) {
    file := SoulIniPath(profileId)
    IniWrite(tone, file, "Soul", "tone")
    IniWrite(rhythm, file, "Soul", "rhythm")
    IniWrite(energy, file, "Soul", "energy")
    IniWrite(need, file, "Soul", "need")
    IniWrite(rest, file, "Soul", "rest")
    IniWrite("yes", file, "Soul", "completed")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm:ss"), file, "Soul", "updated_at")
}

IsSoulCompleted(profileId) {
    return IniRead(SoulIniPath(profileId), "Soul", "completed", "no") = "yes"
}

; ── PRIMA Soul — moteur de parcours (architecture interne) ───────────────────
; Paths : prima_vda | prima_soul | prima_shadow
; Contextes autorisés (internes) : famille | amitie | amour | travail | relation | maintenant
; Catégories neutres autorisées : relation, groupe, choix, pression, changement,
; effort, attente, limite, conflit, imprévu, regard, aide,
; silence, confiance, controle, justice.
; context, category, signal_type et les clés de scores sont internes uniquement
; et ne doivent JAMAIS être affichés à l'utilisateur.

global SOUL_SESSION := ""

; ── Constantes internes (jamais affichées à l'écran) ──────────────────────────
; Clés de scores PRIMA Soul (base PCM interne).
GetSoulPcmKeys() {
    return ["analyseur", "perseverant", "empathique", "imagineur", "energiseur", "promoteur"]
}

; Clés de scores PRIMA VDA (base interne).
GetSoulVdaKeys() {
    return ["rejet", "abandon", "humiliation", "trahison", "injustice"]
}

; Dimensions internes PCM pour catégoriser les futures questions prima_soul.
GetSoulPcmDimensions() {
    return ["perception", "besoin", "stress", "communication", "interaction", "environnement", "force"]
}

; Clés de scores autorisées selon le parcours.
; prima_soul = test 15 situations (axes internes VDA) ; prima_vda = futur PCM.
GetSoulScoreKeys(path) {
    switch path {
        case "prima_soul": return GetSoulVdaKeys()
        case "prima_vda":  return GetSoulPcmKeys()
    }
    return []  ; prima_shadow : rien pour l'instant
}

; signal_type autorisés selon le parcours (champ optionnel des questions).
GetSoulSignalTypes(path) {
    switch path {
        case "prima_soul": return ["emotion", "besoin", "comportement", "contexte", "repetition"]
        case "prima_vda":  return ["perception", "besoin", "stress", "communication", "interaction", "environnement", "force", "phase"]
    }
    return []  ; prima_shadow : rien pour l'instant
}

#Include system\prima_question_bank.ahk
#Include system\prima_question_picker.ahk

GetSoulQuestionBank() {
    return BuildPrimaQuestionBank()
}

GetSoulQuestionsForPath(path) {
    questions := []
    for q in GetSoulQuestionBank() {
        if (q.path = path)
            questions.Push(q)
    }
    return questions
}

ShuffleArray(arr) {
    i := arr.Length
    while (i > 1) {
        j := Random(1, i)
        tmp := arr[i]
        arr[i] := arr[j]
        arr[j] := tmp
        i--
    }
    return arr
}

; Mélange les réponses d'une question : ordre aléatoire, scores attachés.
ShuffleAnswers(question) {
    shuffled := []
    for a in question.answers
        shuffled.Push(a)
    return ShuffleArray(shuffled)
}

; Construit une session de parcours prête à jouer via BuildQuestionSet (banque chirurgicale V0.1).
BuildSoulQuestionRun(path, count) {
    global CURRENT_PROFILE_ID
    testType := PrimaTestTypeFromPath(path)
    if (testType = "")
        return ""
    session := BuildQuestionSet(testType, CURRENT_PROFILE_ID)
    if (session = "" || session.questions.Length != count)
        return ""
    return session
}

; Stocke les choix d'une question dans la session (résultat calculé plus tard).
; selected_1 = réponse priorité 1 (+2) ; selected_2 = priorité 2 (+1), vide si choix unique.
SoulSessionRecordAnswer(session, questionId, selected1, selected2 := "") {
    session.answers.Push({ question_id: questionId, selected_1: selected1, selected_2: selected2 })
    if (session.current_index < session.questions.Length)
        session.current_index += 1
    else
        session.completed := true
}

; ── PRIMA Soul — état global du cycle (verrouillage des tests) ────────────────
SoulResultsPath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\soul_results.ini"
}

; Marque un test comme terminé et verrouillé.
; Tant que le cycle Soul complet n'est pas fini (tests + résultats + univers),
; le verrou reste actif : les champs globaux sont remis à 0 explicitement.
MarkSoulTestCompleted(profileId, path) {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := SoulResultsPath(profileId)
    for key in ["prima_soul_completed", "prima_vda_completed", "prima_shadow_completed"] {
        if (IniRead(file, "tests", key, "") = "")
            IniWrite("0", file, "tests", key)
    }
    IniWrite("0", file, "global", "cycle_complete")
    IniWrite("0", file, "global", "results_generated")
    IniWrite("0", file, "global", "results_read")
    IniWrite("0", file, "global", "universes_proposed")
    IniWrite("0", file, "global", "universe_chosen")
    if (IniRead(file, "global", "chosen_universe", "") = "")
        IniWrite("", file, "global", "chosen_universe")
    IniWrite("0.1", file, "global", "version")
    IniWrite("1", file, "tests", path "_completed")
    WriteLog("soul_test_locked", profileId " | " path)
    WriteLog("soul_test_locked_until_cycle_complete", profileId " | " path)
}

; ── PRIMA Soul — progression / reprise de tests ───────────────────────────────
PrimaPathFromTestType(testType) {
    switch testType {
        case "soul", "prima_soul": return "prima_soul"
        case "vda", "prima_vda": return "prima_vda"
        case "shadow", "prima_shadow": return "prima_shadow"
    }
    return ""
}

TestTypeFromPrimaPath(path) {
    switch path {
        case "prima_soul": return "soul"
        case "prima_vda": return "vda"
        case "prima_shadow": return "shadow"
    }
    return ""
}

GetTestExpectedCount(path) {
    switch path {
        case "prima_soul": return 15
        case "prima_vda": return 20
        case "prima_shadow": return 15
    }
    return 0
}

GetTestStateFile(profileId, path) {
    switch path {
        case "prima_soul": return SoulStatePath(profileId)
        case "prima_vda": return VdaStatePath(profileId)
        case "prima_shadow": return ShadowStatePath(profileId)
    }
    return ""
}

GetDefaultAnswerCountForPath(path) {
    switch path {
        case "prima_soul": return 5
        case "prima_vda": return 6
        case "prima_shadow": return 7
    }
    return 5
}

GetBankQuestionAnswerCount(path, qid) {
    testType := TestTypeFromPrimaPath(path)
    for qb in GetSoulQuestionBank() {
        if (qb.id = qid && qb.test_type = testType) {
            if qb.HasOwnProp("answers")
                return qb.answers.Length
            break
        }
    }
    return GetDefaultAnswerCountForPath(path)
}

IsValidSavedAnswerLine(file, qid, path) {
    val := IniRead(file, "rankings", qid, "")
    if (val != "") {
        parts := StrSplit(val, ",", " ")
        return parts.Length = GetBankQuestionAnswerCount(path, qid)
    }
    val := IniRead(file, "answers", qid, "")
    if (val = "")
        return false
    parts := StrSplit(val, ",", " ")
    return parts.Length >= 1 && parts[1] != ""
}

CountValidAnswersInState(profileId, path) {
    file := GetTestStateFile(profileId, path)
    if !FileExist(file)
        return { answered: 0, ids: [], state_file: "" }
    idsStr := IniRead(file, "questions", "ids", "")
    if (idsStr = "")
        idsStr := IniRead(file, "session", "selected_question_ids", "")
    if (idsStr = "")
        return { answered: 0, ids: [], state_file: file }
    ids := StrSplit(idsStr, ",", " ")
    answered := 0
    for qid in ids {
        if !IsValidSavedAnswerLine(file, qid, path)
            break
        answered++
    }
    return { answered: answered, ids: ids, state_file: file }
}

IsTestMarkedCompletedInResults(profileId, path) {
    if (profileId = "")
        return false
    soulFile := SoulResultsPath(profileId)
    if (FileExist(soulFile) && IniRead(soulFile, "tests", path "_completed", "0") = "1")
        return true
    if (path = "prima_soul") {
        if (FileExist(soulFile) && IniRead(soulFile, "prima_soul", "completed", "0") = "1")
            return true
        return false
    }
    if (path = "prima_vda") {
        vdaFile := VdaResultsPath(profileId)
        return FileExist(vdaFile) && IniRead(vdaFile, "prima_vda", "completed", "0") = "1"
    }
    if (path = "prima_shadow") {
        shadowFile := ShadowResultsPath(profileId)
        return FileExist(shadowFile) && IniRead(shadowFile, "prima_shadow", "completed", "0") = "1"
    }
    return false
}

GetTestProgress(profileId, testType) {
    path := PrimaPathFromTestType(testType)
    total := GetTestExpectedCount(path)
    base := {
        status: "not_started",
        current_index: 1,
        total_questions: total,
        answered_count: 0,
        next_question_index: 1
    }
    if (profileId = "" || path = "" || total = 0)
        return base
    if IsTestMarkedCompletedInResults(profileId, path) {
        base.status := "completed"
        base.current_index := total
        base.answered_count := total
        base.next_question_index := total + 1
        return base
    }
    stateInfo := CountValidAnswersInState(profileId, path)
    answered := stateInfo.answered
    file := stateInfo.state_file
    if (answered >= total && total > 0) {
        base.status := "completed"
        base.current_index := total
        base.answered_count := total
        base.next_question_index := total + 1
        return base
    }
    if FileExist(file) {
        active := IniRead(file, "session", "active", "0")
        fileCompleted := IniRead(file, "session", "completed", "0")
        started := IniRead(file, "session", "started", "")
        hasIds := stateInfo.ids.Length > 0
        if (hasIds && (active = "1" && fileCompleted = "0" || answered > 0 || started = "1")) {
            nextIdx := answered + 1
            curIdx := Integer(IniRead(file, "session", "current_index", String(nextIdx)))
            if (answered > 0 && curIdx != nextIdx) {
                WriteLog("resume_state_fixed", profileId " | " path " | " curIdx " -> " nextIdx)
                curIdx := nextIdx
            }
            if (curIdx < 1 || curIdx > total)
                curIdx := nextIdx
            base.status := "in_progress"
            base.current_index := curIdx
            base.answered_count := answered
            base.next_question_index := nextIdx
            return base
        }
    }
    return base
}

CanGeneratePrimaReading(profileId) {
    if (profileId = "")
        return false
    for testType in ["soul", "vda", "shadow"] {
        if (GetTestProgress(profileId, testType).status != "completed")
            return false
    }
    return true
}

GetNextResumeAction(profileId) {
    if (profileId = "")
        return "start_soul"
    order := [
        { type: "soul", resume: "resume_soul", start: "start_soul" },
        { type: "vda", resume: "resume_vda", start: "start_vda" },
        { type: "shadow", resume: "resume_shadow", start: "start_shadow" }
    ]
    for item in order {
        if (GetTestProgress(profileId, item.type).status = "in_progress")
            return item.resume
    }
    for item in order {
        if (GetTestProgress(profileId, item.type).status = "not_started")
            return item.start
    }
    if CanGeneratePrimaReading(profileId)
        return "generate_reading"
    return "start_soul"
}

WriteTestSessionCommonFlags(file, session) {
    ids := ""
    for q in session.questions
        ids .= (ids = "" ? "" : ",") . q.id
    IniWrite("1", file, "session", "started")
    answered := session.HasOwnProp("rankings") ? session.rankings.Length : 0
    IniWrite(answered > 0 ? "1" : "0", file, "session", "answers_saved")
    IniWrite(ids, file, "session", "selected_question_ids")
}

LoadSavedTestRankings(file, ids, path, answeredCount) {
    rankings := []
    answers := []
    useRankings := false
    if (answeredCount > 0 && IsValidSavedAnswerLine(file, ids[1], path)) {
        testVal := IniRead(file, "rankings", ids[1], "")
        useRankings := (testVal != "")
    }
    loop answeredCount {
        qid := ids[A_Index]
        if (useRankings) {
            val := IniRead(file, "rankings", qid, "")
            parts := StrSplit(val, ",", " ")
            rankings.Push({ question_id: qid, ranks: parts })
        } else {
            val := IniRead(file, "answers", qid, "")
            parts := StrSplit(val, ",", " ")
            answers.Push({
                question_id: qid,
                selected_1: parts[1],
                selected_2: (parts.Length >= 2 ? parts[2] : "")
            })
        }
    }
    return { rankings: rankings, answers: answers }
}

ResumeSoulTestFromHub(*) {
    global CURRENT_PROFILE_ID, SOUL_TEST_BACK_SCREEN
    if (TryResumeSoulSession(CURRENT_PROFILE_ID)) {
        SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
        RenderScreen("prima_soul_question")
    } else {
        MsgBox(T("msg_run_preparing"), APP_TITLE, "Icon!")
    }
}

ResumeVdaTestFromHub(*) {
    global CURRENT_PROFILE_ID
    if (TryResumeVdaSession(CURRENT_PROFILE_ID))
        RenderScreen("prima_vda_rank")
    else
        MsgBox(T("msg_run_preparing"), APP_TITLE, "Icon!")
}

ResumeShadowTestFromHub(*) {
    global CURRENT_PROFILE_ID
    if (TryResumeShadowSession(CURRENT_PROFILE_ID))
        RenderScreen("prima_shadow_question")
    else
        MsgBox(T("msg_run_preparing"), APP_TITLE, "Icon!")
}

ExecuteTestResumeAction(action) {
    global CURRENT_PROFILE_ID, SOUL_TEST_BACK_SCREEN
    switch action {
        case "resume_soul":
            if (TryResumeSoulSession(CURRENT_PROFILE_ID)) {
                SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
                RenderScreen("prima_soul_question")
            }
        case "resume_vda":
            if (TryResumeVdaSession(CURRENT_PROFILE_ID))
                RenderScreen("prima_vda_rank")
        case "resume_shadow":
            if (TryResumeShadowSession(CURRENT_PROFILE_ID))
                RenderScreen("prima_shadow_question")
    }
}

IsSoulTestCompleted(profileId, path) {
    if (profileId = "")
        return false
    return GetTestProgress(profileId, TestTypeFromPrimaPath(path)).status = "completed"
}

IsPrimaSoulCycleComplete(profileId) {
    return CanGeneratePrimaReading(profileId)
}

AreSoulResultsRead(profileId) {
    return IniRead(SoulResultsPath(profileId), "global", "results_read", "0") = "1"
}

; Fichiers du cycle PRIMA Soul archivés puis remis à zéro.
GetSoulCycleResetFileNames() {
    return ["soul_state.ini", "soul_results.ini", "vda_state.ini", "vda_results.ini"
        , "shadow_state.ini", "shadow_results.ini", "prima_identity.ini"]
}

; soul_results.ini vierge après refaire les tests.
WriteSoulResultsAfterReset(profileId) {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := SoulResultsPath(profileId)
    if FileExist(file)
        try FileDelete(file)
    IniWrite("0", file, "tests", "prima_soul_completed")
    IniWrite("0", file, "tests", "prima_vda_completed")
    IniWrite("0", file, "tests", "prima_shadow_completed")
    IniWrite("0", file, "global", "cycle_complete")
    IniWrite("0", file, "global", "results_generated")
    IniWrite("0", file, "global", "results_read")
    IniWrite("0", file, "global", "universes_proposed")
    IniWrite("0", file, "global", "universe_chosen")
    IniWrite("", file, "global", "chosen_universe")
    IniWrite("0.1", file, "global", "version")
}

; Archive horodatée puis suppression des fichiers actifs du cycle.
; Si l'archive échoue, rien n'est supprimé.
ResetSoulCycle(profileId) {
    global SOUL_SESSION, PRIMA_SELECTED_UNIVERSE, PRIMA_SELECTED_TERRITORY
    soulDir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(soulDir)
        DirCreate(soulDir)
    files := GetSoulCycleResetFileNames()
    toArchive := []
    for f in files {
        if FileExist(soulDir "\" f)
            toArchive.Push(f)
    }
    archiveDir := ""
    if (toArchive.Length > 0) {
        archiveDir := soulDir "\archive\" FormatTime(, "yyyyMMdd_HHmmss")
        try DirCreate(archiveDir)
        catch {
            return { ok: false, reason: "mkdir" }
        }
        for f in toArchive {
            src := soulDir "\" f
            dest := archiveDir "\" f
            try FileCopy(src, dest, true)
            catch {
                return { ok: false, reason: "copy " f }
            }
            if !FileExist(dest)
                return { ok: false, reason: "verify " f }
        }
        WriteLog("soul_cycle_archived", profileId " | " archiveDir)
        for f in toArchive {
            src := soulDir "\" f
            if FileExist(src) {
                try FileDelete(src)
                catch {
                    return { ok: false, reason: "delete " f }
                }
            }
        }
    }
    WriteSoulResultsAfterReset(profileId)
    SOUL_SESSION := ""
    PRIMA_SELECTED_UNIVERSE := ""
    PRIMA_SELECTED_TERRITORY := ""
    return { ok: true, archive: archiveDir }
}

SoulRedoTestsClicked(*) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        return
    }
    WriteLog("soul_redo_tests_clicked", CURRENT_PROFILE_ID)
    if (MsgBox(T("msg_redo_tests_confirm"), APP_TITLE, "YesNo Icon?") != "Yes")
        return
    WriteLog("soul_redo_tests_confirmed", CURRENT_PROFILE_ID)
    result := ResetSoulCycle(CURRENT_PROFILE_ID)
    if (result.ok) {
        WriteLog("soul_cycle_reset_done", CURRENT_PROFILE_ID " | " result.archive)
        WriteProfileLog(CURRENT_PROFILE_ID, "soul_cycle_reset_done", result.archive)
        MsgBox(T("msg_redo_tests_done"), APP_TITLE, "Iconi")
        RenderScreen("prima_soul_intro")
        return
    }
    WriteLog("soul_cycle_reset_failed", CURRENT_PROFILE_ID " | " result.reason)
    WriteProfileLog(CURRENT_PROFILE_ID, "soul_cycle_reset_failed", result.reason)
    MsgBox(T("msg_redo_tests_archive_failed"), APP_TITLE, "Icon!")
}

; Alias historique (réglages DEV).
SoulCycleResetClicked(*) {
    SoulRedoTestsClicked()
}

; Règles de lancement d'un test (prima_soul / prima_vda / prima_shadow) :
; - test pas terminé → true
; - test terminé et cycle_complete=0 → false
; - test terminé et results_generated=0 → false
; - test terminé et universe_chosen=0 → false
; - aucun reset possible pour l'instant → false même cycle complet.
CanStartSoulTest(path) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "")
        return false
    if !IsSoulTestCompleted(CURRENT_PROFILE_ID, path)
        return true
    file := SoulResultsPath(CURRENT_PROFILE_ID)
    if (IniRead(file, "global", "cycle_complete", "0") != "1")
        return false
    if (IniRead(file, "global", "results_generated", "0") != "1")
        return false
    if (IniRead(file, "global", "universe_chosen", "0") != "1")
        return false
    return false  ; verrou actif tant que cycle complet non finalisé (reset DEV via Réglages)
}

; ── PRIMA Soul Test — résultat minimal ────────────────────────────────────────
; Calcul interne : classement complet (rang 1 = n pts … rang n = 1 pt)
; ou legacy choix 1-2 (selected_1 = +2, selected_2 = +1).
; Retourne { main, second, totals }.
ComputeSoulMainTendencies(session) {
    totals := Map()
    for key in GetSoulVdaKeys()
        totals[key] := 0
    qById := Map()
    for q in session.questions
        qById[q.id] := q
    if (session.HasOwnProp("rankings") && session.rankings.Length > 0) {
        for r in session.rankings {
            if !qById.Has(r.question_id)
                continue
            q := qById[r.question_id]
            ansById := Map()
            for ans in q.answers
                ansById[ans.id] := ans
            nAns := q.answers.Length
            loop r.ranks.Length {
                rank := A_Index
                if (rank > r.ranks.Length)
                    break
                aid := r.ranks[rank]
                if !ansById.Has(aid)
                    continue
                points := nAns + 1 - rank
                for key, val in ansById[aid].scores {
                    if totals.Has(key)
                        totals[key] += val * points
                }
            }
        }
    }
    if (session.HasOwnProp("answers") && session.answers.Length > 0) {
        for a in session.answers {
            if !qById.Has(a.question_id)
                continue
            q := qById[a.question_id]
            for ans in q.answers {
                mult := 0
                if (ans.id = a.selected_1)
                    mult := 2
                else if (a.selected_2 != "" && ans.id = a.selected_2)
                    mult := 1
                if (mult = 0)
                    continue
                for key, val in ans.scores {
                    if totals.Has(key)
                        totals[key] += val * mult
                }
            }
        }
    }
    main := ""
    second := ""
    tieMeta := ComputeSessionRankTieMeta(session, GetSoulVdaKeys(), SoulAnswerScoreKeys)
    sorted := SortedAllScoreKeys(totals, GetSoulVdaKeys(), tieMeta)
    if (sorted.Length >= 1)
        main := sorted[1].key
    if (sorted.Length >= 2)
        second := sorted[2].key
    return { main: main, second: second, totals: totals }
}

; Mapping public neutre — seuls ces libellés sont affichés.
GetSoulTendencyLabel(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "your place"
            case "abandon":     return "the bond"
            case "humiliation": return "your needs"
            case "trahison":    return "trust"
            case "injustice":   return "fairness"
        }
    } else {
        switch key {
            case "rejet":       return "ta place"
            case "abandon":     return "le lien"
            case "humiliation": return "tes besoins"
            case "trahison":    return "la confiance"
            case "injustice":   return "la justesse"
        }
    }
    return ""
}

; Action simple associée à la tendance principale (texte public).
GetSoulTendencyAction(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "Take a micro-place today."
            case "abandon":     return "Do a small action alone, then ask for specific support if needed."
            case "humiliation": return "Name a need without justifying yourself."
            case "trahison":    return "Check a fact before controlling or accusing."
            case "injustice":   return "Say 'this touches me' first, before correcting."
        }
    } else {
        switch key {
            case "rejet":       return "Prends une micro-place aujourd'hui."
            case "abandon":     return "Fais une petite action seul, puis demande un soutien précis si besoin."
            case "humiliation": return "Nomme un besoin sans te justifier."
            case "trahison":    return "Vérifie un fait avant de contrôler ou d'accuser."
            case "injustice":   return "Dis d'abord « ça me touche » avant de corriger."
        }
    }
    return ""
}

; Sauvegarde le résultat minimal dans soul_results.ini ([latest] + [global] + scores).
SaveSoulTestResult(profileId, mainKey, secondKey, totals := "") {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := SoulResultsPath(profileId)
    IniWrite("prima_soul", file, "latest", "last_test")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm"), file, "latest", "date")
    IniWrite(mainKey, file, "latest", "main_tendency")
    IniWrite(secondKey, file, "latest", "secondary_tendency")
    IniWrite(T("result_line1", GetSoulTendencyLabel(mainKey)), file, "latest", "result_text")
    IniWrite(GetSoulTendencyAction(mainKey), file, "latest", "action_text")
    IniWrite("0.1", file, "latest", "version")
    if (totals != "") {
        for key in GetSoulVdaKeys()
            IniWrite(totals.Has(key) ? totals[key] : 0, file, "scores", key)
    }
    IniWrite("1", file, "global", "results_generated")
    IniWrite("0", file, "global", "results_read")
    IniWrite("0", file, "global", "universes_proposed")
    IniWrite("0", file, "global", "universe_chosen")
    IniWrite("0", file, "global", "cycle_complete")
    WriteLog("soul_result_saved", profileId)
}

; ── PRIMA VDA (PCM) — moteur de classement ────────────────────────────────────
; 6 réponses par question, classées par l'utilisateur.
; rang 1 = +6, rang 2 = +5, rang 3 = +4, rang 4 = +3, rang 5 = +2, rang 6 = +1.
; Tout est interne : aucune clé PCM, aucun score, aucune base/phase affichés.

VdaStatePath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\vda_state.ini"
}

VdaResultsPath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\vda_results.ini"
}

; Construit une session VDA prête à jouer (rankings vides), ou "" si banque insuffisante.
; Les réponses de chaque question sont mélangées par BuildSoulQuestionRun
; (ShuffleAnswers) : aucune clé interne ne reste à une position fixe.
BuildVdaQuestionRun(count) {
    session := BuildSoulQuestionRun("prima_vda", count)
    if (session = "")
        return ""
    session.rankings := []
    WriteLog("vda_answers_shuffled", "prima_vda | " session.questions.Length)
    return session
}

; Session active unique (SOUL_SESSION) — valide selon le parcours attendu.
TestSessionIndex(session) {
    if !IsObject(session) || !session.HasOwnProp("current_index")
        return 0
    idx := Integer(session.current_index)
    return (idx >= 1) ? idx : 0
}

IsValidTestSession(session, expectedPath := "") {
    if !IsObject(session)
        return false
    if !session.HasOwnProp("questions") || !(session.questions is Array) || session.questions.Length = 0
        return false
    idx := TestSessionIndex(session)
    if (idx < 1 || idx > session.questions.Length)
        return false
    if (expectedPath != "" && (!session.HasOwnProp("active_path") || session.active_path != expectedPath))
        return false
    return true
}

GetActiveTestSession(expectedPath := "") {
    global SOUL_SESSION
    path := expectedPath
    if (path = "" && IsObject(SOUL_SESSION) && SOUL_SESSION.HasOwnProp("active_path"))
        path := SOUL_SESSION.active_path
    if !IsValidTestSession(SOUL_SESSION, path)
        return ""
    return SOUL_SESSION
}

GetCurrentQuestion(expectedPath := "") {
    global SOUL_SESSION
    if !IsObject(SOUL_SESSION)
        return ""
    if (expectedPath != "" && (!SOUL_SESSION.HasOwnProp("active_path") || SOUL_SESSION.active_path != expectedPath))
        return ""
    idx := TestSessionIndex(SOUL_SESSION)
    if (idx < 1 || !SOUL_SESSION.HasOwnProp("questions") || idx > SOUL_SESSION.questions.Length)
        return ""
    return SOUL_SESSION.questions[idx]
}

HandleInvalidTestSession(expectedPath, context := "") {
    global SOUL_SESSION, SOUL_TEST_BACK_SCREEN
    WriteLog("test_session_invalid", expectedPath " | " context)
    SOUL_SESSION := ""
    switch expectedPath {
        case "prima_soul":
            RenderScreen(SOUL_TEST_BACK_SCREEN != "" ? SOUL_TEST_BACK_SCREEN : "prima_soul_intro")
        default:
            RenderScreen("prima_soul_intro")
    }
}

; Vérifie un classement complet : tableau de answer_id (index = rang).
; Retourne "" si valide, sinon la clé du message d'erreur.
ValidateAnswerRanking(ranking, expectedCount, msgAllKey := "msg_rank_all") {
    if (!(ranking is Array) || ranking.Length != expectedCount)
        return msgAllKey
    seen := Map()
    for id in ranking {
        if (id = "")
            return msgAllKey
        if seen.Has(id)
            return "msg_rank_unique"
        seen[id] := true
    }
    return ""
}

; Vérifie un classement VDA : 6 réponses.
ValidatePcmRanking(ranking) {
    return ValidateAnswerRanking(ranking, 6, "msg_rank_all")
}

GetRankingExpectedCount(question, testType := "") {
    if (question = "" || !question.HasOwnProp("answers"))
        return 0
    return question.answers.Length
}

GetRankingIncompleteMsgKey(expectedCount) {
    if (expectedCount = 5)
        return "msg_rank_all_5"
    if (expectedCount = 7)
        return "msg_rank_all_7"
    return "msg_rank_all"
}

; picks = answer_id classés par ordre de rang (1 = le plus).
IsRankingComplete(testType, question, picks) {
    expected := GetRankingExpectedCount(question, testType)
    if (expected = 0 || !(picks is Array) || picks.Length != expected)
        return false
    validIds := Map()
    for a in question.answers
        validIds[a.id] := true
    seen := Map()
    for rank, pickId in picks {
        if (pickId = "" || !validIds.Has(pickId))
            return false
        if seen.Has(pickId)
            return false
        seen[pickId] := rank
    }
    return seen.Count = expected
}

BuildRankingFromPicks(question, picks) {
    ranks := []
    for pickId in picks
        ranks.Push(pickId)
    return ranks
}

ToggleRankPickById(picks, question, answerIndex) {
    if (answerIndex < 1 || answerIndex > question.answers.Length)
        return picks
    if !(picks is Array)
        picks := []
    aid := question.answers[answerIndex].id
    for pickId in picks {
        if (pickId = aid)
            return picks
    }
    if (picks.Length >= question.answers.Length)
        return picks
    picks.Push(aid)
    return picks
}

; Stocke le classement d'une question dans la session.
; ranks = tableau de 6 answer_id, index 1 = rang 1 (me définit le plus).
VdaSessionRecordRanking(session, questionId, ranks) {
    if !session.HasOwnProp("rankings")
        session.rankings := []
    session.rankings.Push({ question_id: questionId, ranks: ranks })
    if (session.current_index < session.questions.Length)
        session.current_index += 1
    else
        session.completed := true
}

; Additionne les points par clé PCM interne selon les classements.
; minIdx/maxIdx filtrent par numéro de question (0/0 = toutes).
ComputePcmRankingScores(session, minIdx := 0, maxIdx := 0) {
    totals := Map()
    for key in GetSoulPcmKeys()
        totals[key] := 0
    qById := Map()
    for q in session.questions
        qById[q.id] := q
    for r in session.rankings {
        if (minIdx > 0) {
            n := VdaQuestionIndexFromId(r.question_id, session)
            if (n < minIdx || n > maxIdx)
                continue
        }
        if !qById.Has(r.question_id)
            continue
        q := qById[r.question_id]
        ansById := Map()
        for ans in q.answers
            ansById[ans.id] := ans
        loop 6 {
            rank := A_Index
            if (rank > r.ranks.Length)
                break
            aid := r.ranks[rank]
            if !ansById.Has(aid)
                continue
            key := ansById[aid].pcm_key
            if totals.Has(key)
                totals[key] += (7 - rank)
        }
    }
    return totals
}

; Numéro de question en session (session_index ou legacy vda_pcm_N).
VdaQuestionIndexFromId(qid, session := "") {
    if (session != "") {
        n := PrimaQuestionSessionIndex(session, qid)
        if (n > 0)
            return n
    }
    if RegExMatch(qid, "^vda_pcm_(\d+)$", &m)
        return Integer(m[1])
    return 0
}

; ── Mode court : séparation Base / Phase (internes, jamais affichés) ──────────
; Q1-Q12 = Base probable — max 12 x 6 = 72 points par clé.
ComputeVdaBaseScores(session) {
    return ComputePcmRankingScores(session, 1, 12)
}

; Q13-Q20 = Phase actuelle probable — max 8 x 6 = 48 points par clé.
ComputeVdaPhaseScores(session) {
    return ComputePcmRankingScores(session, 13, 20)
}

; Pourcentages internes : base → maxTotal 72, phase → maxTotal 48.
ComputeVdaPercents(scores, maxTotal) {
    percents := Map()
    for key, val in scores
        percents[key] := Round(val / maxTotal * 100)
    return percents
}

; Sauvegarde l'état de session VDA dans vda_state.ini (même logique que soul_state).
SaveVdaSessionState() {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "" || SOUL_SESSION = "")
        return
    if (SOUL_SESSION.active_path != "prima_vda")
        return
    dir := PROFILES_DIR "\" CURRENT_PROFILE_ID "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := VdaStatePath(CURRENT_PROFILE_ID)
    if FileExist(file)
        try FileDelete(file)
    IniWrite(SOUL_SESSION.completed ? "0" : "1", file, "session", "active")
    IniWrite("prima_vda", file, "session", "path")
    IniWrite(SOUL_SESSION.current_index, file, "session", "current_index")
    IniWrite(SOUL_SESSION.completed ? "1" : "0", file, "session", "completed")
    IniWrite("0.1", file, "session", "version")
    ids := ""
    for q in SOUL_SESSION.questions
        ids .= (ids = "" ? "" : ",") . q.id
    IniWrite(ids, file, "questions", "ids")
    WriteTestSessionCommonFlags(file, SOUL_SESSION)
    if (SOUL_SESSION.HasOwnProp("question_seed"))
        PrimaWriteSessionQuestionMeta(file, SOUL_SESSION)
    for r in SOUL_SESSION.rankings {
        line := ""
        for aid in r.ranks
            line .= (line = "" ? "" : ",") . aid
        IniWrite(line, file, "rankings", r.question_id)
    }
    WriteLog("vda_session_saved", CURRENT_PROFILE_ID " | index " SOUL_SESSION.current_index)
}

; Reprise de session VDA depuis vda_state.ini (jamais de plantage).
TryResumeVdaSession(profileId) {
    global SOUL_SESSION
    prog := GetTestProgress(profileId, "vda")
    if (prog.status != "in_progress")
        return false
    file := VdaStatePath(profileId)
    try {
        idsStr := IniRead(file, "questions", "ids", "")
        if (idsStr = "")
            throw Error("no question ids")
        ids := StrSplit(idsStr, ",", " ")
        questions := PrimaRebuildSessionQuestions("prima_vda", ids, file)
        saved := LoadSavedTestRankings(file, ids, "prima_vda", prog.answered_count)
        currentIndex := prog.next_question_index
        if (currentIndex < 1 || currentIndex > questions.Length)
            throw Error("current_index out of range")
        seed := IniRead(file, "session", "question_seed", "")
        bankVersion := IniRead(file, "session", "bank_version", "")
        SOUL_SESSION := {
            active_path: "prima_vda",
            test_type: "vda",
            question_seed: seed,
            bank_version: bankVersion,
            questions: questions,
            current_index: currentIndex,
            answers: [],
            rankings: saved.rankings,
            completed: false
        }
        WriteLog("vda_session_resumed", profileId " | index " currentIndex)
        return true
    } catch as e {
        WriteLog("vda_resume_failed", profileId " | " e.Message)
        return false
    }
}

; Sauvegarde les totaux internes VDA dans vda_results.ini (jamais affichés).
; baseScores / phaseScores : Maps optionnelles (mode court Q1-12 / Q13-20).
SaveVdaTestResult(profileId, totals, baseScores := "", phaseScores := "") {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := VdaResultsPath(profileId)
    IniWrite("1", file, "prima_vda", "completed")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm"), file, "prima_vda", "last_date")
    IniWrite("0.1", file, "prima_vda", "version")
    for key in GetSoulPcmKeys()
        IniWrite(totals.Has(key) ? totals[key] : 0, file, "scores", key)
    if (baseScores != "") {
        for key in GetSoulPcmKeys()
            IniWrite(baseScores.Has(key) ? baseScores[key] : 0, file, "base", key)
    }
    if (phaseScores != "") {
        for key in GetSoulPcmKeys()
            IniWrite(phaseScores.Has(key) ? phaseScores[key] : 0, file, "phase", key)
    }
    WriteLog("vda_result_saved", profileId)
}

; ── PRIMA Shadow Test — moteur de classement ───────────────────────────────────
; Q1-Q10 = axes symboliques internes ; Q11-Q15 = émotion principale.
; Classement complet : rang 1 = n pts … rang n = 1 pt.
; Clés internes uniquement, jamais affichées.

ShadowStatePath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\shadow_state.ini"
}

ShadowResultsPath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\shadow_results.ini"
}

GetShadowAxisKeys() {
    return ["orgueil", "envie", "colere", "paresse", "avarice", "gourmandise", "luxure"]
}

GetShadowEmotionKeys() {
    return ["peur", "tristesse", "colere", "honte", "joie"]
}

; Numéro de question depuis l'id (shadow_07 → 7), 0 si format inconnu.
ShadowQuestionIndexFromId(qid, session := "") {
    if (session != "") {
        n := PrimaQuestionSessionIndex(session, qid)
        if (n > 0)
            return n
    }
    if RegExMatch(qid, "^shadow_(\d+)$", &m)
        return Integer(m[1])
    return 0
}

; Session Shadow : questions et réponses mélangées (BuildSoulQuestionRun).
BuildShadowQuestionRun(count) {
    session := BuildSoulQuestionRun("prima_shadow", count)
    if (session = "")
        return ""
    session.rankings := []
    WriteLog("shadow_answers_shuffled", "prima_shadow | " session.questions.Length)
    return session
}

; Vérifie les choix : tableau de 1 à 2 answer_id distincts.
; Retourne "" si valide, sinon la clé du message d'erreur.
ValidateShadowChoices(choices) {
    if (!(choices is Array) || choices.Length < 1)
        return "msg_shadow_min"
    if (choices.Length > 2)
        return "msg_shadow_max"
    if (choices.Length = 2 && choices[1] = choices[2])
        return "msg_shadow_max"
    for id in choices {
        if (id = "")
            return "msg_shadow_min"
    }
    return ""
}

; Scoring par classement : rang 1 = n pts … rang n = 1 pt (legacy choix 1-2 supporté).
; Q1-Q10 → totaux axes ; Q11-Q15 → totaux émotions.
ComputeShadowScores(session) {
    axes := Map()
    for key in GetShadowAxisKeys()
        axes[key] := 0
    emotions := Map()
    for key in GetShadowEmotionKeys()
        emotions[key] := 0
    qById := Map()
    for q in session.questions
        qById[q.id] := q
    if (session.HasOwnProp("rankings") && session.rankings.Length > 0) {
        for r in session.rankings {
            if !qById.Has(r.question_id)
                continue
            q := qById[r.question_id]
            n := ShadowQuestionIndexFromId(r.question_id, session)
            ansById := Map()
            for ans in q.answers
                ansById[ans.id] := ans
            nAns := q.answers.Length
            loop r.ranks.Length {
                rank := A_Index
                if (rank > r.ranks.Length)
                    break
                aid := r.ranks[rank]
                if !ansById.Has(aid)
                    continue
                key := ansById[aid].shadow_key
                points := nAns + 1 - rank
                if (n >= 1 && n <= 10) {
                    if axes.Has(key)
                        axes[key] += points
                } else {
                    if emotions.Has(key)
                        emotions[key] += points
                }
            }
        }
    }
    if (session.HasOwnProp("answers") && session.answers.Length > 0) {
        for a in session.answers {
            if !qById.Has(a.question_id)
                continue
            q := qById[a.question_id]
            n := ShadowQuestionIndexFromId(a.question_id, session)
            for ans in q.answers {
                mult := 0
                if (ans.id = a.selected_1)
                    mult := 2
                else if (a.selected_2 != "" && ans.id = a.selected_2)
                    mult := 1
                if (mult = 0)
                    continue
                key := ans.shadow_key
                if (n >= 1 && n <= 10) {
                    if axes.Has(key)
                        axes[key] += mult
                } else {
                    if emotions.Has(key)
                        emotions[key] += mult
                }
            }
        }
    }
    return { axes: axes, emotions: emotions }
}

; État de session Shadow (ordre des questions + classements).
SaveShadowSessionState() {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "" || SOUL_SESSION = "")
        return
    if (SOUL_SESSION.active_path != "prima_shadow")
        return
    dir := PROFILES_DIR "\" CURRENT_PROFILE_ID "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := ShadowStatePath(CURRENT_PROFILE_ID)
    if FileExist(file)
        try FileDelete(file)
    IniWrite(SOUL_SESSION.completed ? "0" : "1", file, "session", "active")
    IniWrite("prima_shadow", file, "session", "path")
    IniWrite(SOUL_SESSION.current_index, file, "session", "current_index")
    IniWrite(SOUL_SESSION.completed ? "1" : "0", file, "session", "completed")
    IniWrite("0.1", file, "session", "version")
    ids := ""
    for q in SOUL_SESSION.questions
        ids .= (ids = "" ? "" : ",") . q.id
    IniWrite(ids, file, "questions", "ids")
    WriteTestSessionCommonFlags(file, SOUL_SESSION)
    if (SOUL_SESSION.HasOwnProp("question_seed"))
        PrimaWriteSessionQuestionMeta(file, SOUL_SESSION)
    if (SOUL_SESSION.HasOwnProp("rankings")) {
        for r in SOUL_SESSION.rankings {
            line := ""
            for aid in r.ranks
                line .= (line = "" ? "" : ",") . aid
            IniWrite(line, file, "rankings", r.question_id)
        }
    }
    WriteLog("shadow_session_saved", CURRENT_PROFILE_ID " | index " SOUL_SESSION.current_index)
}

; Reprise de session Shadow depuis shadow_state.ini (jamais de plantage).
TryResumeShadowSession(profileId) {
    global SOUL_SESSION
    prog := GetTestProgress(profileId, "shadow")
    if (prog.status != "in_progress")
        return false
    file := ShadowStatePath(profileId)
    try {
        idsStr := IniRead(file, "questions", "ids", "")
        if (idsStr = "")
            throw Error("no question ids")
        ids := StrSplit(idsStr, ",", " ")
        questions := PrimaRebuildSessionQuestions("prima_shadow", ids, file)
        saved := LoadSavedTestRankings(file, ids, "prima_shadow", prog.answered_count)
        currentIndex := prog.next_question_index
        if (currentIndex < 1 || currentIndex > questions.Length)
            throw Error("current_index out of range")
        seed := IniRead(file, "session", "question_seed", "")
        bankVersion := IniRead(file, "session", "bank_version", "")
        SOUL_SESSION := {
            active_path: "prima_shadow",
            test_type: "shadow",
            question_seed: seed,
            bank_version: bankVersion,
            questions: questions,
            current_index: currentIndex,
            answers: saved.answers,
            rankings: saved.rankings,
            completed: false
        }
        WriteLog("shadow_session_resumed", profileId " | index " currentIndex)
        return true
    } catch as e {
        WriteLog("shadow_resume_failed", profileId " | " e.Message)
        return false
    }
}

; Résultat Shadow : totaux internes axes + émotion (jamais affichés).
SaveShadowTestResult(profileId, scores) {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := ShadowResultsPath(profileId)
    IniWrite("1", file, "prima_shadow", "completed")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm"), file, "prima_shadow", "last_date")
    IniWrite("0.1", file, "prima_shadow", "version")
    for key in GetShadowAxisKeys()
        IniWrite(scores.axes.Has(key) ? scores.axes[key] : 0, file, "axes", key)
    for key in GetShadowEmotionKeys()
        IniWrite(scores.emotions.Has(key) ? scores.emotions[key] : 0, file, "emotion", key)
    WriteLog("shadow_result_saved", profileId)
}

; ── PRIMA Soul Test — sauvegarde / reprise de session ─────────────────────────
SoulStatePath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\soul_state.ini"
}

; Écrit l'état complet de la session en cours dans soul_state.ini.
; Conserve l'ordre exact des questions tirées et les classements par question.
SaveSoulSessionState() {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "" || SOUL_SESSION = "")
        return
    if (SOUL_SESSION.active_path != "prima_soul")
        return
    dir := PROFILES_DIR "\" CURRENT_PROFILE_ID "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := SoulStatePath(CURRENT_PROFILE_ID)
    if FileExist(file)
        try FileDelete(file)
    IniWrite(SOUL_SESSION.completed ? "0" : "1", file, "session", "active")
    IniWrite("prima_soul", file, "session", "path")
    IniWrite(SOUL_SESSION.current_index, file, "session", "current_index")
    IniWrite(SOUL_SESSION.completed ? "1" : "0", file, "session", "completed")
    IniWrite("0.1", file, "session", "version")
    ids := ""
    for q in SOUL_SESSION.questions
        ids .= (ids = "" ? "" : ",") . q.id
    IniWrite(ids, file, "questions", "ids")
    WriteTestSessionCommonFlags(file, SOUL_SESSION)
    if (SOUL_SESSION.HasOwnProp("question_seed"))
        PrimaWriteSessionQuestionMeta(file, SOUL_SESSION)
    if (SOUL_SESSION.HasOwnProp("rankings")) {
        for r in SOUL_SESSION.rankings {
            line := ""
            for aid in r.ranks
                line .= (line = "" ? "" : ",") . aid
            IniWrite(line, file, "rankings", r.question_id)
        }
    }
    WriteLog("soul_session_saved", CURRENT_PROFILE_ID " | index " SOUL_SESSION.current_index)
}

; Tente de reconstruire SOUL_SESSION depuis soul_state.ini.
; Retourne true si la reprise est prête, false sinon (jamais de plantage).
TryResumeSoulSession(profileId) {
    global SOUL_SESSION
    prog := GetTestProgress(profileId, "soul")
    if (prog.status != "in_progress")
        return false
    file := SoulStatePath(profileId)
    try {
        idsStr := IniRead(file, "questions", "ids", "")
        if (idsStr = "")
            throw Error("no question ids")
        ids := StrSplit(idsStr, ",", " ")
        questions := PrimaRebuildSessionQuestions("prima_soul", ids, file)
        saved := LoadSavedTestRankings(file, ids, "prima_soul", prog.answered_count)
        currentIndex := prog.next_question_index
        if (currentIndex < 1 || currentIndex > questions.Length)
            throw Error("current_index out of range")
        seed := IniRead(file, "session", "question_seed", "")
        bankVersion := IniRead(file, "session", "bank_version", "")
        SOUL_SESSION := {
            active_path: "prima_soul",
            test_type: "soul",
            question_seed: seed,
            bank_version: bankVersion,
            questions: questions,
            current_index: currentIndex,
            answers: saved.answers,
            rankings: saved.rankings,
            completed: false
        }
        WriteLog("soul_session_resumed", profileId " | index " currentIndex)
        return true
    } catch as e {
        WriteLog("soul_resume_failed", profileId " | " e.Message)
        return false
    }
}

LoadDomainGoals(profileId, code) {
    file := GoalsIniPath(profileId)
    return {
        short: IniRead(file, code, "short", ""),
        medium: IniRead(file, code, "medium", ""),
        long: IniRead(file, code, "long", "")
    }
}

SaveDomainGoals(profileId, code, short, medium, long) {
    file := GoalsIniPath(profileId)
    IniWrite(Trim(short), file, code, "short")
    IniWrite(Trim(medium), file, code, "medium")
    IniWrite(Trim(long), file, code, "long")
}

DomainHasGoals(data) {
    return (Trim(data.short) != "" || Trim(data.medium) != "" || Trim(data.long) != "")
}

CountConfiguredDomains(profileId) {
    count := 0
    for code in GetDomainCodes() {
        if DomainHasGoals(LoadDomainGoals(profileId, code))
            count++
    }
    return count
}

HasAnyGoals(profileId) {
    return CountConfiguredDomains(profileId) > 0
}

GetDomainsWithGoals(profileId) {
    domains := []
    for code in GetDomainCodes() {
        if DomainHasGoals(LoadDomainGoals(profileId, code))
            domains.Push(code)
    }
    return domains
}

GetGoalsForDomain(profileId, code) {
    goals := []
    data := LoadDomainGoals(profileId, code)
    if (Trim(data.short) != "")
        goals.Push({ duration: "short", durationLabel: T("dur_short"), title: Trim(data.short) })
    if (Trim(data.medium) != "")
        goals.Push({ duration: "medium", durationLabel: T("dur_medium"), title: Trim(data.medium) })
    if (Trim(data.long) != "")
        goals.Push({ duration: "long", durationLabel: T("dur_long"), title: Trim(data.long) })
    return goals
}

ChooseInList(ddl, labels, value) {
    if (value = "") {
        ddl.Choose(1)
        return
    }
    loop labels.Length {
        if (labels[A_Index] = value) {
            ddl.Choose(A_Index)
            return
        }
    }
    ddl.Choose(1)
}

SaveReview(mood, moodCode, energy, energyCode, whatDid, whatImprove, freeNote, reviewDomain := "", goalTitle := "", goalDuration := "") {
    global REVIEWS_DIR, CURRENT_PROFILE_ID, CURRENT_LANG
    EnsureDirectories()
    dateStr := FormatTime(, "yyyy-MM-dd")
    timestamp := FormatTime(, "yyyy-MM-dd HH:mm:ss")
    file := REVIEWS_DIR "\" dateStr "_" CURRENT_PROFILE_ID "_review.txt"
    content :=
        "date=" timestamp "`n"
        . "profile_id=" CURRENT_PROFILE_ID "`n"
        . "language=" CURRENT_LANG "`n"
        . "mood=" SanitizeReviewField(mood) "`n"
        . "mood_code=" moodCode "`n"
        . "energy=" SanitizeReviewField(energy) "`n"
        . "energy_code=" energyCode "`n"
        . "review_domain=" SanitizeReviewField(reviewDomain) "`n"
        . "what_i_did=" SanitizeReviewField(whatDid) "`n"
        . "what_i_did_goal_title=" SanitizeReviewField(goalTitle) "`n"
        . "what_i_did_goal_duration=" SanitizeReviewField(goalDuration) "`n"
        . "what_i_improve=" SanitizeReviewField(whatImprove) "`n"
        . "free_note=" SanitizeReviewField(freeNote) "`n"
    if FileExist(file)
        FileDelete(file)
    FileAppend(content, file, "UTF-8")
}

T(key, p*) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "profile_title":       s := "Profile"
            case "profile_none":        s := "No local profile"
            case "profile_select":      s := "Select a local profile"
            case "btn_create_profile":  s := "Create profile"
            case "login_title":         s := "Profile login"
            case "create_password":     s := "Password"
            case "create_password_confirm": s := "Confirm password"
            case "msg_empty_password":  s := "Please enter a password."
            case "msg_password_mismatch": s := "Passwords do not match."
            case "msg_wrong_password":  s := "Incorrect password."
            case "msg_password_hash_error": s := "Unable to save password securely. Please try again."
            case "btn_continue":        s := "Continue"
            case "btn_archive":         s := "Archive profile"
            case "btn_archives":        s := "Archives"
            case "archives_title":      s := "Archives"
            case "archives_select":     s := "Select an archived folder"
            case "archives_none":        s := "No archives."
            case "btn_delete_archive":  s := "Delete permanently"
            case "msg_select_archive_delete": s := "Please select an archive to delete."
            case "msg_archive_delete_confirm1": s := "Do you really want to delete this archive?`n`n{}"
            case "msg_archive_delete_confirm2": s := "Permanent deletion. This action cannot be undone. Confirm?"
            case "msg_archive_delete_failed": s := "Failed to delete archive."
            case "msg_active_archive_delete": s := "Cannot delete an archive linked to the active profile."
            case "btn_quit":            s := "Quit"
            case "btn_back":            s := "Back"
            case "btn_save":            s := "Save"
            case "btn_create":          s := "Create"
            case "review_title":        s := "Daily Review"
            case "review_mood":         s := "Mood"
            case "review_energy":       s := "Energy"
            case "review_did":          s := "What I did"
            case "review_improve":      s := "What I improve"
            case "review_note":         s := "Free note"
            case "goals_title":         s := "Goals"
            case "goal_domain":         s := "Domain"
            case "dur_short":           s := "Short term"
            case "dur_medium":          s := "Mid term"
            case "dur_long":            s := "Long term"
            case "dur_short_hint":      s := "~3 months max"
            case "dur_medium_hint":     s := "~6 months to 1 year"
            case "dur_long_hint":       s := "~2 to 5 years"
            case "btn_goals":           s := "Goals"
            case "personal_base_title": s := "Personal Base"
            case "base_kit_prima":      s := "PRIMA Kit"
            case "kit_title":           s := "Kit PRIMA"
            case "kit_body":            s := "Local PRIMA base verification."
            case "kit_ai_label":        s := "Selected AI"
            case "kit_ai_other":        s := "Other"
            case "kit_checks_label":    s := "Local checks"
            case "kit_check_root":      s := "PRIMA root folder"
            case "kit_check_prima_app": s := "PrimaApp.ahk"
            case "kit_check_autohotkey": s := "AutoHotkey available"
            case "kit_check_launcher":  s := "Local AHK launcher"
            case "kit_check_shortcut":  s := "PRIMA App shortcut"
            case "msg_autohotkey_missing": s := "AutoHotkey is missing. Open the official download page?"
            case "msg_autohotkey_not_found_shortcut": s := "AutoHotkey not found. Launch PRIMA with launch_prima.ahk or install AutoHotkey v2."
            case "kit_check_profiles":  s := "profiles folder"
            case "kit_check_logs":      s := "logs folder"
            case "kit_check_reviews":   s := "reviews folder"
            case "kit_check_profiles_ini": s := "profiles.ini file"
            case "status_ok":           s := "OK"
            case "status_missing":      s := "Missing"
            case "btn_kit_verify":      s := "Check"
            case "btn_kit_create":      s := "Create missing"
            case "msg_kit_saved":       s := "PRIMA Kit saved."
            case "msg_kit_save_error":  s := "Error while saving."
            case "base_infos_perso":    s := "Personal info"
            case "base_prima_soul":     s := "PRIMA Soul"
            case "prima_soul_intro_title": s := "PRIMA Soul"
            case "prima_soul_intro_body":  s := "Adapt your PRIMA experience without labeling yourself."
            case "prima_soul_intro_sub":   s := "Choose what helps you most today. You can change these choices later."
            case "prima_soul_guide":       s := "The system guides, it does not confine."
            case "soul_status_available":  s := "Available"
            case "soul_status_in_progress":  s := "In progress"
            case "soul_status_done":       s := "Completed"
            case "soul_status_locked":     s := "Locked"
            case "soul_status_ready":      s := "Ready"
            case "btn_resume_test":         s := "Resume test"
            case "btn_resume_soul":         s := "Resume PRIMA Soul"
            case "btn_resume_vda":          s := "Resume PRIMA VDA"
            case "btn_resume_shadow":       s := "Resume PRIMA Shadow"
            case "soul_resume_banner":      s := "You had a test in progress"
            case "soul_reading_wait":      s := "Available after all 3 tests"
            case "soul_cycle_complete_status": s := "✅ PRIMA Soul cycle completed"
            case "soul_cycle_complete_hint":   s := "You can now generate your reading, choose your PRIMA architecture, or redo the tests."
            case "prima_soul_complete_title":  s := "PRIMA Soul"
            case "msg_test_done_use_reading":  s := "Use Generate my reading or Redo the tests."
            case "prima_soul_no_diag":     s := "PRIMA Soul does not make any diagnosis."
            case "prima_soul_completed":   s := "PRIMA Soul minimal completed."
            case "soul_tone":              s := "Preferred tone"
            case "soul_rhythm":            s := "Support rhythm"
            case "soul_energy":            s := "Current energy"
            case "soul_need":              s := "Main need today"
            case "soul_rest":              s := "Rest mode"
            case "btn_soul_save_goals":    s := "Save and continue to Goals"
            case "vda_line1":              s := "Observe your reactions in simple situations."
            case "vda_line2":              s := "You can choose what feels most like you."
            case "vda_line3":              s := "The result will suggest tendencies to check against your own experience."
            case "vda_count":              s := "15 short situations."
            case "pcm_line1":              s := "Explore how you move forward, react and communicate."
            case "pcm_line2":              s := "The result will offer a simple reading, without labels."
            case "pcm_line3":              s := "You can adjust this later."
            case "pcm_count":              s := "10 situations maximum."
            case "shadow_line1":           s := "This module is coming later."
            case "shadow_line2":           s := "It will explore what takes too much space when you are under pressure."
            case "shadow_line3":           s := "No judgment, no fixed truth."
            case "soul_settings_title":    s := "PRIMA Soul Settings"
            case "soul_settings_later":    s := "PRIMA Soul settings coming soon."
            case "soul_settings_dev_hint": s := "Developer options for this profile."
            case "btn_reset_soul_cycle":   s := "Reset PRIMA Soul cycle"
            case "btn_redo_tests":         s := "Redo the tests"
            case "msg_redo_tests_confirm": s := "You can redo the tests if this reading doesn't fit you.`n`nCurrent results will be archived before starting again.`n`nContinue?"
            case "msg_redo_tests_done":    s := "Cycle reset. You can redo the tests."
            case "msg_redo_tests_archive_failed": s := "Unable to archive previous results. Reset cancelled."
            case "msg_reset_soul_cycle_confirm": s := "This will archive Soul/VDA/Shadow results for this profile and allow redoing the tests. Continue?"
            case "msg_reset_soul_cycle_done":    s := "PRIMA Soul cycle reset. You can retake the tests."
            case "msg_reset_soul_cycle_failed":  s := "Reset failed. Your current files were not removed."
            case "btn_soul_settings":      s := "Settings"
            case "msg_run_preparing":      s := "Journey in preparation."
            case "msg_pick_at_least_one":  s := "Choose at least 1 answer."
            case "msg_pick_only_two":      s := "Choose at most 2 answers."
            case "soul_pick_hint":         s := "Pick 1 to 2 answers."
            case "vda_test_title":         s := "PRIMA VDA Test"
            case "soul_test_title":        s := "PRIMA Soul Test"
            case "vda_later_1":            s := "This test is coming later."
            case "vda_later_2":            s := "It will explore how you communicate, move forward and react."
            case "vda_intro_1":            s := "This test explores how you communicate, move forward and react."
            case "vda_intro_2":            s := "20 situations will be offered."
            case "msg_rank_all":           s := "Rank all 6 answers."
            case "msg_rank_all_5":         s := "Rank all 5 answers."
            case "test_answer_first_instinct": s := "Answer with your moment reaction, not the ideal answer."
            case "soul_test_guidance":     s := "Answer with your moment reaction, not the ideal answer."
            case "vda_test_guidance":      s := "Rank by what fits you most in this context."
            case "shadow_test_guidance":   s := "Answer without judging: choose what comes first."
            case "msg_rank_all_7":         s := "Rank all 7 answers."
            case "msg_rank_unique":        s := "Each place must be used only once."
            case "vda_rank_hint_top":      s := "1 = most like you"
            case "vda_rank_hint_bottom":   s := "6 = least like you"
            case "rank_hint_least":        s := "last = least like you"
            case "btn_vda_test_done":      s := "PRIMA VDA Test completed"
            case "vda_done_reading":       s := "Your reading will be available once the three tests are completed."
            case "shadow_test_title":      s := "PRIMA Shadow Test"
            case "shadow_intro_1":         s := "This test explores your deep reactions, your inner tensions and the emotion that comes back most often."
            case "shadow_intro_2":         s := "This is not a label. It is a reading lead."
            case "shadow_pick_hint":       s := "Pick 1 to 2 answers."
            case "msg_shadow_min":         s := "Pick at least 1 answer."
            case "msg_shadow_max":         s := "Pick 2 answers maximum."
            case "btn_shadow_test_done":   s := "PRIMA Shadow Test completed"
            case "msg_test_locked_cycle":  s := "It will reopen once the full cycle is completed."
            case "btn_generate_reading":   s := "Generate my reading"
            case "msg_reading_preparing":  s := "Reading in preparation."
            case "reading_hub_title":      s := "Your PRIMA reading"
            case "reading_hub_1":          s := "This reading is not a fixed truth."
            case "reading_hub_2":          s := "It gathers your answers to suggest leads about behavior, needs and communication."
            case "btn_result_soul":        s := "PRIMA Soul result"
            case "btn_result_vda":         s := "PRIMA VDA result"
            case "btn_result_shadow":      s := "PRIMA Shadow result"
            case "btn_save_reading":       s := "Save"
            case "btn_restart_cycle":      s := "Restart the cycle later"
            case "btn_choose_universe":    s := "Choose my universe"
            case "btn_create_plan":        s := "Create my PRIMA plan"
            case "msg_reading_saved":      s := "Reading saved."
            case "msg_cycle_reset_later":  s := "Cycle reset planned later."
            case "msg_universe_later":     s := "Universe choice planned later."
            case "msg_plan_later":         s := "PRIMA plan planned later."
            case "sec_suggest":            s := "1. What your answers suggest"
            case "sec_nourish":            s := "2. What can nourish you"
            case "sec_pressure":           s := "3. Under pressure"
            case "sec_comm":               s := "4. Communication / regulation"
            case "sec_soul_touch":         s := "1. What your answer touches"
            case "sec_soul_protection":    s := "2. Your possible protection reaction"
            case "sec_soul_behavior":      s := "3. What this may lead you to do"
            case "sec_soul_need":          s := "4. Inner need"
            case "sec_soul_gentle":        s := "5. Gentle lead"
            case "sec_vda_stable":         s := "1. Likely stable functioning"
            case "sec_vda_energy":         s := "2. Main current energy"
            case "vda_phase_intro":        s := "Your answers suggest a main current dynamic. Other dynamics may also activate depending on context, stress, or energy in the moment."
            case "vda_phase_close_gap":    s := "Small gap between some dynamics: read this as a snapshot of the current cycle, not a fixed label."
            case "tie_note_soul":          s := "Two leads seem close. The first is shown as dominant for this cycle, but the second remains important."
            case "tie_note_vda":           s := "Several dynamics seem close. The first stands out as main in this cycle, but the following may also activate depending on context."
            case "tie_note_shadow":        s := "Two tensions seem close. This reading does not judge: it only helps notice what may need attention."
            case "tier_phase_main":        s := "Main current dynamic"
            case "tier_phase_secondary":   s := "Active secondary dynamic"
            case "tier_phase_available":   s := "Available dynamic"
            case "tier_phase_light":       s := "Light dynamic"
            case "tier_phase_low":         s := "Low-activity dynamics"
            case "tier_base_main":         s := "Main stable tendency"
            case "tier_base_secondary":    s := "Secondary stable tendency"
            case "tier_base_available":    s := "Available tendency"
            case "tier_base_light":        s := "Light tendency"
            case "tier_base_low":          s := "Low-activity tendencies"
            case "sec_vda_nourish":        s := "3. What nourishes you"
            case "sec_vda_comm":           s := "4. Your favorable communication channel"
            case "sec_vda_stress":         s := "5. Under stress"
            case "sec_vda_balance":        s := "6. Return to balance"
            case "sec_shadow_accept":      s := "1. What you may struggle to accept"
            case "sec_shadow_tension":     s := "2. Dominant inner tension"
            case "sec_shadow_emotion":     s := "3. Main emotion"
            case "sec_shadow_hide":        s := "4. What you may hide or compensate"
            case "sec_shadow_pressure":    s := "5. Under pressure"
            case "sec_shadow_integration": s := "6. Integration lead"
            case "shadow_disclaimer":      s := "This reading does not judge. It helps you look at an inner zone with more gentleness."
            case "lbl_official_small":     s := "(small: {})"
            case "btn_view_architecture":  s := "View my PRIMA identity"
            case "btn_view_identity":      s := "View my PRIMA identity"
            case "btn_choose_identity":    s := "Choose my PRIMA identity"
            case "identity_result_title":  s := "Your PRIMA identity"
            case "identity_result_intro":  s := "A symbolic compass for this cycle — not a fixed label."
            case "identity_result_disclaimer": s := "This identity is not a label. It is a symbolic compass for this cycle."
            case "identity_sec_architecture": s := "Your architecture"
            case "identity_sec_climate":   s := "Your inner climate"
            case "identity_sec_form":      s := "Your symbolic form"
            case "identity_sec_reading":   s := "Your personalized reading"
            case "identity_lbl_sub_universe": s := "Inner climate"
            case "identity_lbl_form":      s := "Symbolic form"
            case "identity_lbl_form_link":   s := "Your symbolic form is linked to your main universe and your work territory for this cycle."
            case "identity_lbl_full":      s := "Identity for this cycle"
            case "identity_lbl_universe_tone": s := "Universe tone"
            case "identity_lbl_territory_focus": s := "Territory focus"
            case "identity_lbl_dominant":  s := "Main tendencies"
            case "identity_lbl_summary":   s := "Summary"
            case "arch_locked_title":      s := "Your PRIMA identity"
            case "arch_locked_hint":       s := "This architecture is locked for this cycle."
            case "arch_locked_modify":     s := "To change it, you must redo the tests."
            case "lbl_universe_chosen":    s := "Universe chosen"
            case "lbl_territory_chosen":   s := "Territory chosen"
            case "lbl_dominant":           s := "Dominant tendency"
            case "lbl_secondary":          s := "Secondary tendency"
            case "lbl_influence_tertiary": s := "Third tendency"
            case "lbl_stable_probable":    s := "Probable stable functioning"
            case "lbl_influence_secondary": s := "Probable secondary influence"
            case "lbl_energy_probable":    s := "Probable current energy"
            case "lbl_energy_pending":     s := "Current energy: not enough answers yet to suggest a lead."
            case "lbl_tension_dom":        s := "Dominant inner tension"
            case "lbl_tension_sec":        s := "Secondary tension"
            case "lbl_emotion_main":       s := "Probable main emotion"
            case "lbl_emotion_pending":    s := "Main emotion: not enough answers yet to suggest a lead."
            case "uni_choice_1":           s := "Three leads are offered to you."
            case "uni_choice_2":           s := "Choose your main axis for this cycle. Other leads can be explored later."
            case "uni_role_main":          s := "Main universe"
            case "uni_role_bridge":        s := "Bridge universe"
            case "uni_role_secondary":     s := "Secondary universe"
            case "uni_why_main":           s := "Main lead: it aligns most directly with your Soul and VDA results."
            case "uni_why_bridge":         s := "Bridge lead: it connects your dominant universe to another inner tone."
            case "uni_why_secondary":      s := "Secondary lead: a complementary nuance to explore if it speaks to you."
            case "choice_piste_of":        s := "Lead {} / {}"
            case "choice_why_label":       s := "Why this lead may fit you"
            case "btn_prev_piste":         s := "← Previous"
            case "btn_next_piste":         s := "Next →"
            case "btn_pick_piste":         s := "Choose this lead"
            case "btn_view_detail":        s := "View detail"
            case "btn_pick_universe":      s := "Choose this universe"
            case "btn_pick_territory":     s := "Choose this territory"
            case "btn_back_pistes":        s := "Back to the 3 leads"
            case "uni_detail_title":       s := "Universe detail"
            case "terr_detail_title":      s := "Territory detail"
            case "lbl_theme":              s := "Theme"
            case "lbl_signals":            s := "Dominant signals"
            case "lbl_user_phrase":          s := "A phrase for you"
            case "lbl_inner_question":       s := "Inner question"
            case "lbl_long_desc":            s := "Description"
            case "uni_caution":            s := "This universe is a symbolic lead. It does not define who you are."
            case "terr_caution":           s := "This territory is a symbolic lead. It does not define who you are."
            case "lbl_illustration":       s := "Symbolic illustration"
            case "illustration_pending":   s := "illustration_key={}`nillustration_path="
            case "terr_role_main":         s := "Main territory"
            case "terr_role_bridge":       s := "Bridge territory"
            case "terr_role_secondary":    s := "Secondary territory"
            case "scroll_hint":            s := "Scroll to see more"
            case "terr_choice_title":      s := "Choose my territory"
            case "terr_choice_1":          s := "Three leads are offered to you."
            case "terr_choice_2":          s := "Choose your main axis for this cycle. Other leads can be explored later."
            case "terr_why_main":          s := "Main lead: it reflects the life zone most active for you right now."
            case "terr_why_bridge":        s := "Bridge lead: it links your universe to a complementary territory."
            case "terr_why_secondary":     s := "Secondary lead: an additional angle to consider if it resonates."
            case "btn_pick":               s := "Choose"
            case "identity_saved_title":   s := "PRIMA architecture saved"
            case "identity_saved_1":       s := "Your choice will serve as a symbolic base for the rest of PRIMA App."
            case "identity_saved_2":       s := "This architecture can evolve with your future cycles."
            case "identity_arch_label":    s := "Architecture:"
            case "btn_back_reading":       s := "Back to my reading"
            case "btn_back_prima_home":    s := "Back to PRIMA home"
            case "vda_question_of":        s := "Question {} / {}"
            case "btn_next":               s := "Next"
            case "msg_quit_run":           s := "Leave the current journey?"
            case "msg_finish_or_quit":     s := "Finish the journey or quit the app."
            case "btn_soul_test_done":     s := "PRIMA Soul Test completed"
            case "msg_test_locked_1":      s := "Test already completed."
            case "msg_test_locked_2":      s := "It will reopen once PRIMA VDA, PRIMA Shadow, the results and the universe choice are completed."
            case "vda_done_1":             s := "Journey complete."
            case "vda_done_2":             s := "The full result will be added in a next step."
            case "btn_back_soul":          s := "Back to PRIMA Soul"
            case "result_line1":           s := "Your answers seem to show a possible lead around {}."
            case "result_line2":           s := "This is not an identity. It is a working lead."
            case "result_line3":           s := "A second theme also seems present: {}."
            case "btn_read":               s := "I have read"
            case "btn_start":           s := "Start"
            case "msg_module_later":    s := "Module planned later."
            case "review_domain":       s := "Domain"
            case "review_no_goals":     s := "Add a goal in Personal setup first."
            case "review_no_domain_goals": s := "No goal defined for this domain."
            case "create_title":        s := "New profile"
            case "create_security_title": s := "Profile security"
            case "create_name":         s := "Profile name"
            case "create_lang":         s := "Language"
            case "profile_gender_label": s := "Gender / reading profile"
            case "gender_male":         s := "Man"
            case "gender_female":       s := "Woman"
            case "gender_unspecified_pref": s := "Prefer not to answer"
            case "gender_unspecified":  s := "Not specified"
            case "profile_gender_note": s := "This information is only used to adapt some wording later. It does not define your result."
            case "create_mode":         s := "Profile mode"
            case "mode_client":         s := "Client"
            case "mode_creator":        s := "Creator"
            case "create_code":         s := "Creator code"
            case "msg_wrong_code":      s := "Incorrect code."
            case "privacy_title":       s := "Privacy"
            case "privacy_body":        s := "PRIMA App is local-first.`n`nNo forced cloud.`nNo telemetry.`nNo microphone.`nNo screen capture.`nNo external API."
            case "btn_accept":          s := "I accept"
            case "btn_review":          s := "Review"
            case "btn_proof":           s := "Proof"
            case "btn_settings":        s := "Settings"
            case "settings_title":      s := "Settings"
            case "start_title":         s := "Launch"
            case "start_welcome":       s := "Welcome to PRIMA"
            case "start_profile":       s := "Profile: {}"
            case "btn_launch":          s := "Launch PRIMA"
            case "home_title":          s := "Welcome to PRIMA"
            case "home_active":         s := "Active profile: {}"
            case "home_version":        s := "Version {}"
            case "creator_home_title":  s := "Creator Home"
            case "creator_home_body":   s := "Private PRIMA creator space."
            case "btn_creator_personalization": s := "Personalization"
            case "btn_creator_goal":  s := "Goal"
            case "btn_creator_soul_test": s := "PRIMA Soul Test"
            case "btn_creator_vda_test": s := "PRIMA VDA Test"
            case "btn_creator_shadow_test": s := "PRIMA Shadow Test"
            case "msg_creator_module_later": s := "Creator module planned later."
            case "btn_onboarding":      s := "Personal setup"
            case "btn_change_profile":  s := "Change profile"
            case "onboarding_body":     s := "PRIMA helps you move forward step by step. For now, this version helps you build your base, track your profile, and prepare your personal space."
            case "msg_select_profile":  s := "Please select a profile."
            case "msg_select_archive":  s := "Please select a profile to archive."
            case "msg_active_archive":  s := "This profile is active. Switch profile or log out before archiving it."
            case "msg_archive_confirm": s := "Archive profile « {} » ?`n`nThe profile will be moved to archive/.`nNo permanent deletion."
            case "msg_empty_name":      s := "Please enter a profile name."
            case "msg_no_active":       s := "Error: no active profile."
            case "msg_goals_max_domains": s := "Maximum 5 domains with goals in V0.1."
            case "confirm_close":       s := "Close PRIMA App?"
            case "confirm_quit":        s := "Quit PRIMA App?"
            case "confirm_quit_remember": s := "You can quit the app. Next time you open it, you'll continue where you left off.`nIf you want to switch profile, use Log out.`n`nYes = Quit`nNo = Log out and quit`nCancel = Stay"
            case "login_remember_me":   s := "Stay signed in on this device"
            case "btn_logout":          s := "Log out"
            case "confirm_saved":       s := "Your local data is saved."
            case "confirm_missing":     s := "Warning: active profile not found on disk."
            case "pause_on":            s := "PRIMA App is paused.`n`nCtrl+Alt+Shift+X to resume."
            case "pause_off":           s := "PRIMA App resumed."
            default:                    return key
        }
    } else {
        switch key {
            case "profile_title":       s := "Profil"
            case "profile_none":        s := "Aucun profil local"
            case "profile_select":      s := "Sélectionnez un profil local"
            case "btn_create_profile":  s := "Créer un profil"
            case "login_title":         s := "Connexion profil"
            case "create_password":     s := "Mot de passe"
            case "create_password_confirm": s := "Confirmation mot de passe"
            case "msg_empty_password":  s := "Veuillez entrer un mot de passe."
            case "msg_password_mismatch": s := "Les mots de passe ne correspondent pas."
            case "msg_wrong_password":  s := "Mot de passe incorrect."
            case "msg_password_hash_error": s := "Impossible d'enregistrer le mot de passe. Réessayez."
            case "btn_continue":        s := "Continuer"
            case "btn_archive":         s := "Archiver profil"
            case "btn_archives":        s := "Archives"
            case "archives_title":      s := "Archives"
            case "archives_select":     s := "Sélectionnez une archive"
            case "archives_none":        s := "Aucune archive."
            case "btn_delete_archive":  s := "Supprimer définitivement"
            case "msg_select_archive_delete": s := "Veuillez sélectionner une archive à supprimer."
            case "msg_archive_delete_confirm1": s := "Voulez-vous vraiment supprimer cette archive ?`n`n{}"
            case "msg_archive_delete_confirm2": s := "Suppression définitive. Cette action est irréversible. Confirmer ?"
            case "msg_archive_delete_failed": s := "Échec de la suppression de l'archive."
            case "msg_active_archive_delete": s := "Impossible de supprimer une archive liée au profil actif."
            case "btn_quit":            s := "Quitter"
            case "btn_back":            s := "Retour"
            case "btn_save":            s := "Enregistrer"
            case "btn_create":          s := "Créer"
            case "review_title":        s := "Revue du jour"
            case "review_mood":         s := "Humeur"
            case "review_energy":       s := "Énergie"
            case "review_did":          s := "Ce que j'ai fait"
            case "review_improve":      s := "Ce que j'améliore"
            case "review_note":         s := "Note libre"
            case "goals_title":         s := "Objectifs"
            case "goal_domain":         s := "Domaine"
            case "dur_short":           s := "Court terme"
            case "dur_medium":          s := "Moyen terme"
            case "dur_long":            s := "Long terme"
            case "dur_short_hint":      s := "~3 mois max"
            case "dur_medium_hint":     s := "~6 mois à 1 an"
            case "dur_long_hint":       s := "~2 à 5 ans"
            case "btn_goals":           s := "Objectifs"
            case "personal_base_title": s := "Base personnelle"
            case "base_kit_prima":      s := "Kit PRIMA"
            case "kit_title":           s := "Kit PRIMA"
            case "kit_body":            s := "Vérification de la base locale PRIMA."
            case "kit_ai_label":        s := "IA choisie"
            case "kit_ai_other":        s := "Autre"
            case "kit_checks_label":    s := "Vérifications locales"
            case "kit_check_root":      s := "Dossier racine PRIMA"
            case "kit_check_prima_app": s := "PrimaApp.ahk"
            case "kit_check_autohotkey": s := "AutoHotkey disponible"
            case "kit_check_launcher":  s := "Launcher AHK local"
            case "kit_check_shortcut":  s := "Raccourci PRIMA App"
            case "msg_autohotkey_missing": s := "AutoHotkey est manquant. Voulez-vous ouvrir la page officielle de téléchargement ?"
            case "msg_autohotkey_not_found_shortcut": s := "AutoHotkey est introuvable. Lancez PRIMA avec launch_prima.ahk ou installez AutoHotkey v2."
            case "kit_check_profiles":  s := "Dossier profiles"
            case "kit_check_logs":      s := "Dossier logs"
            case "kit_check_reviews":   s := "Dossier reviews"
            case "kit_check_profiles_ini": s := "Fichier profiles.ini"
            case "status_ok":           s := "OK"
            case "status_missing":      s := "Manquant"
            case "btn_kit_verify":      s := "Vérifier"
            case "btn_kit_create":      s := "Créer ce qui manque"
            case "msg_kit_saved":       s := "Kit PRIMA enregistré."
            case "msg_kit_save_error":  s := "Erreur lors de l'enregistrement."
            case "base_infos_perso":    s := "Infos perso"
            case "base_prima_soul":     s := "PRIMA Soul"
            case "prima_soul_intro_title": s := "PRIMA Soul"
            case "prima_soul_intro_body":  s := "Adapte ton expérience PRIMA sans te coller d'étiquette."
            case "prima_soul_intro_sub":   s := "Choisis ce qui t'aide le plus aujourd'hui. Tu pourras modifier ces choix plus tard."
            case "prima_soul_guide":       s := "Le système guide, il n'enferme pas."
            case "soul_status_available":  s := "Disponible"
            case "soul_status_in_progress":  s := "En cours"
            case "soul_status_done":       s := "Terminé"
            case "soul_status_locked":     s := "Verrouillé"
            case "soul_status_ready":      s := "Prêt"
            case "btn_resume_test":         s := "Reprendre le test"
            case "btn_resume_soul":         s := "Reprendre PRIMA Soul"
            case "btn_resume_vda":          s := "Reprendre PRIMA VDA"
            case "btn_resume_shadow":       s := "Reprendre PRIMA Shadow"
            case "soul_resume_banner":      s := "Tu avais un test en cours"
            case "soul_reading_wait":      s := "Disponible après les 3 tests"
            case "soul_cycle_complete_status": s := "✅ Cycle PRIMA Soul terminé"
            case "soul_cycle_complete_hint":   s := "Tu peux maintenant générer ta lecture, choisir ton architecture PRIMA ou refaire les tests."
            case "prima_soul_complete_title":  s := "PRIMA Soul"
            case "msg_test_done_use_reading":  s := "Utilise Générer ma lecture ou Refaire les tests."
            case "prima_soul_no_diag":     s := "PRIMA Soul ne fait pas de diagnostic."
            case "prima_soul_completed":   s := "PRIMA Soul minimal complété."
            case "soul_tone":              s := "Ton préféré"
            case "soul_rhythm":            s := "Rythme d'accompagnement"
            case "soul_energy":            s := "Énergie du moment"
            case "soul_need":              s := "Besoin principal aujourd'hui"
            case "soul_rest":              s := "Mode repos"
            case "btn_soul_save_goals":    s := "Enregistrer et continuer vers Objectifs"
            case "vda_line1":              s := "Observe tes réactions dans des situations simples."
            case "vda_line2":              s := "Tu pourras choisir ce qui te ressemble le plus."
            case "vda_line3":              s := "Le résultat proposera des tendances à vérifier avec ton vécu."
            case "vda_count":              s := "15 situations courtes."
            case "pcm_line1":              s := "Explore ta manière d'avancer, de réagir et de communiquer."
            case "pcm_line2":              s := "Le résultat proposera une lecture simple, sans étiquette."
            case "pcm_line3":              s := "Tu pourras ajuster ça plus tard."
            case "pcm_count":              s := "10 situations maximum."
            case "shadow_line1":           s := "Ce module arrivera plus tard."
            case "shadow_line2":           s := "Il explorera ce qui prend trop de place quand tu es sous pression."
            case "shadow_line3":           s := "Sans jugement, sans vérité fixe."
            case "soul_settings_title":    s := "Réglages PRIMA Soul"
            case "soul_settings_later":    s := "Réglages PRIMA Soul à venir."
            case "soul_settings_dev_hint": s := "Options développeur pour ce profil."
            case "btn_reset_soul_cycle":   s := "Réinitialiser cycle PRIMA Soul"
            case "btn_redo_tests":         s := "Refaire les tests"
            case "msg_redo_tests_confirm": s := "Tu peux refaire les tests si cette lecture ne te correspond pas.`n`nLes résultats actuels seront archivés avant de recommencer.`n`nContinuer ?"
            case "msg_redo_tests_done":    s := "Cycle réinitialisé. Tu peux refaire les tests."
            case "msg_redo_tests_archive_failed": s := "Impossible d'archiver les anciens résultats. Réinitialisation annulée."
            case "msg_reset_soul_cycle_confirm": s := "Cette action va archiver les résultats Soul/VDA/Shadow de ce profil et permettre de refaire les tests. Continuer ?"
            case "msg_reset_soul_cycle_done":    s := "Cycle PRIMA Soul réinitialisé. Tu peux refaire les tests."
            case "msg_reset_soul_cycle_failed":  s := "Échec de la réinitialisation. Tes fichiers actuels n'ont pas été supprimés."
            case "btn_soul_settings":      s := "Réglages"
            case "msg_run_preparing":      s := "Parcours en préparation."
            case "msg_pick_at_least_one":  s := "Choisis au moins 1 réponse."
            case "msg_pick_only_two":      s := "Choisis maximum 2 réponses."
            case "soul_pick_hint":         s := "Choisis 1 à 2 réponses."
            case "vda_test_title":         s := "PRIMA VDA Test"
            case "soul_test_title":        s := "PRIMA Soul Test"
            case "vda_later_1":            s := "Ce test arrivera plus tard."
            case "vda_later_2":            s := "Il explorera ta manière de communiquer, d'avancer et de réagir."
            case "vda_intro_1":            s := "Ce test explore ta manière de communiquer, d'avancer et de réagir."
            case "vda_intro_2":            s := "20 situations seront proposées."
            case "msg_rank_all":           s := "Classe les 6 réponses."
            case "msg_rank_all_5":         s := "Classe les 5 réponses."
            case "test_answer_first_instinct": s := "Réponds avec ta réaction du moment, pas la réponse idéale."
            case "soul_test_guidance":     s := "Réponds avec ta réaction du moment, pas la réponse idéale."
            case "vda_test_guidance":      s := "Classe selon ce qui te ressemble le plus dans ce contexte."
            case "shadow_test_guidance":   s := "Réponds sans te juger : choisis ce qui part en premier."
            case "msg_rank_all_7":         s := "Classe les 7 réponses."
            case "msg_rank_unique":        s := "Chaque place doit être utilisée une seule fois."
            case "vda_rank_hint_top":      s := "1 = te ressemble le plus"
            case "vda_rank_hint_bottom":   s := "6 = te ressemble le moins"
            case "rank_hint_least":        s := "dernier = te ressemble le moins"
            case "btn_vda_test_done":      s := "PRIMA VDA Test terminé"
            case "vda_done_reading":       s := "Ta lecture sera disponible quand les trois tests seront terminés."
            case "shadow_test_title":      s := "PRIMA Shadow Test"
            case "shadow_intro_1":         s := "Ce test explore tes réactions profondes, tes tensions intérieures et l'émotion qui revient le plus souvent."
            case "shadow_intro_2":         s := "Ce n'est pas une étiquette. C'est une piste de lecture."
            case "shadow_pick_hint":       s := "Choisis 1 à 2 réponses."
            case "msg_shadow_min":         s := "Choisis au moins 1 réponse."
            case "msg_shadow_max":         s := "Choisis maximum 2 réponses."
            case "btn_shadow_test_done":   s := "PRIMA Shadow Test terminé"
            case "msg_test_locked_cycle":  s := "Il sera réouvert quand le cycle complet sera terminé."
            case "btn_generate_reading":   s := "Générer ma lecture"
            case "msg_reading_preparing":  s := "Lecture en préparation."
            case "reading_hub_title":      s := "Ta lecture PRIMA"
            case "reading_hub_1":          s := "Cette lecture n'est pas une vérité fixe."
            case "reading_hub_2":          s := "Elle rassemble tes réponses pour proposer des pistes de comportement, de besoin et de communication."
            case "btn_result_soul":        s := "Résultat PRIMA Soul"
            case "btn_result_vda":         s := "Résultat PRIMA VDA"
            case "btn_result_shadow":      s := "Résultat PRIMA Shadow"
            case "btn_save_reading":       s := "Sauvegarder"
            case "btn_restart_cycle":      s := "Recommencer le cycle plus tard"
            case "btn_choose_universe":    s := "Choisir mon univers"
            case "btn_create_plan":        s := "Créer mon plan PRIMA"
            case "msg_reading_saved":      s := "Lecture sauvegardée."
            case "msg_cycle_reset_later":  s := "Réinitialisation du cycle prévue plus tard."
            case "msg_universe_later":     s := "Choix d'univers prévu plus tard."
            case "msg_plan_later":         s := "Plan PRIMA prévu plus tard."
            case "sec_suggest":            s := "1. Ce que tes réponses suggèrent"
            case "sec_nourish":            s := "2. Ce qui peut te nourrir"
            case "sec_pressure":           s := "3. Sous pression"
            case "sec_comm":               s := "4. Moyen de communication / régulation"
            case "sec_soul_touch":         s := "1. Ce que ta réponse touche"
            case "sec_soul_protection":    s := "2. Ta réaction de protection possible"
            case "sec_soul_behavior":      s := "3. Ce que ça peut te faire faire"
            case "sec_soul_need":          s := "4. Besoin intérieur"
            case "sec_soul_gentle":        s := "5. Piste douce"
            case "sec_vda_stable":         s := "1. Fonctionnement stable probable"
            case "sec_vda_energy":         s := "2. Énergie actuelle principale"
            case "vda_phase_intro":        s := "Tes réponses suggèrent une dynamique actuelle principale. D'autres dynamiques peuvent aussi s'activer selon le contexte, le stress ou l'énergie du moment."
            case "vda_phase_close_gap":    s := "Écart faible entre certaines dynamiques : cette lecture doit être comprise comme une photographie du cycle actuel, pas comme une étiquette fixe."
            case "tie_note_soul":          s := "Deux pistes semblent proches. La première est affichée comme dominante pour ce cycle, mais la seconde reste importante."
            case "tie_note_vda":           s := "Plusieurs dynamiques semblent proches. La première ressort comme principale dans ce cycle, mais les suivantes peuvent aussi s'activer selon le contexte."
            case "tie_note_shadow":        s := "Deux tensions semblent proches. Cette lecture ne juge pas : elle aide seulement à regarder ce qui demande de l'attention."
            case "tier_phase_main":        s := "Dynamique actuelle principale"
            case "tier_phase_secondary":   s := "Dynamique secondaire active"
            case "tier_phase_available":   s := "Dynamique disponible"
            case "tier_phase_light":       s := "Dynamique légère"
            case "tier_phase_low":         s := "Dynamiques peu actives"
            case "tier_base_main":         s := "Tendance stable principale"
            case "tier_base_secondary":    s := "Tendance stable secondaire"
            case "tier_base_available":    s := "Tendance disponible"
            case "tier_base_light":        s := "Tendance légère"
            case "tier_base_low":          s := "Tendances peu actives"
            case "sec_vda_nourish":        s := "3. Ce qui te nourrit"
            case "sec_vda_comm":           s := "4. Ton canal de communication favorable"
            case "sec_vda_stress":         s := "5. Sous stress"
            case "sec_vda_balance":        s := "6. Retour à l'équilibre"
            case "sec_shadow_accept":      s := "1. Ce que tu peux avoir du mal à accepter"
            case "sec_shadow_tension":     s := "2. Tension intérieure dominante"
            case "sec_shadow_emotion":     s := "3. Émotion principale"
            case "sec_shadow_hide":        s := "4. Ce que tu peux cacher ou compenser"
            case "sec_shadow_pressure":    s := "5. Sous pression"
            case "sec_shadow_integration": s := "6. Piste d'intégration"
            case "shadow_disclaimer":      s := "Cette lecture ne juge pas. Elle sert à regarder une zone intérieure avec plus de douceur."
            case "lbl_official_small":     s := "(petit : {})"
            case "btn_view_architecture":  s := "Voir mon identité PRIMA"
            case "btn_view_identity":      s := "Voir mon identité PRIMA"
            case "btn_choose_identity":    s := "Choisir mon identité PRIMA"
            case "identity_result_title":  s := "Ton identité PRIMA"
            case "identity_result_intro":  s := "Une boussole symbolique pour ce cycle — pas une étiquette fixe."
            case "identity_result_disclaimer": s := "Cette identité n'est pas une étiquette. C'est une boussole symbolique pour ce cycle."
            case "identity_sec_architecture": s := "Ton architecture"
            case "identity_sec_climate":   s := "Ton climat intérieur"
            case "identity_sec_form":      s := "Ta forme symbolique"
            case "identity_sec_reading":   s := "Ta lecture personnalisée"
            case "identity_lbl_sub_universe": s := "Climat intérieur"
            case "identity_lbl_form":      s := "Forme symbolique"
            case "identity_lbl_form_link":   s := "Ta forme symbolique est liée à ton univers principal et à ton territoire de travail pour ce cycle."
            case "identity_lbl_full":      s := "Identité pour ce cycle"
            case "identity_lbl_universe_tone": s := "Tonalité univers"
            case "identity_lbl_territory_focus": s := "Focus territoire"
            case "identity_lbl_dominant":  s := "Tendances principales"
            case "identity_lbl_summary":   s := "Synthèse"
            case "arch_locked_title":      s := "Ton identité PRIMA"
            case "arch_locked_hint":       s := "Cette architecture est verrouillée pour ce cycle."
            case "arch_locked_modify":     s := "Pour la modifier, tu dois refaire les tests."
            case "lbl_universe_chosen":    s := "Univers choisi"
            case "lbl_territory_chosen":   s := "Territoire choisi"
            case "lbl_dominant":           s := "Tendance dominante"
            case "lbl_secondary":          s := "Tendance secondaire"
            case "lbl_influence_tertiary": s := "Troisième tendance"
            case "lbl_stable_probable":    s := "Fonctionnement stable probable"
            case "lbl_influence_secondary": s := "Influence secondaire probable"
            case "lbl_energy_probable":    s := "Énergie actuelle probable"
            case "lbl_energy_pending":     s := "Énergie actuelle : pas assez de réponses pour proposer une piste."
            case "lbl_tension_dom":        s := "Tension intérieure dominante"
            case "lbl_tension_sec":        s := "Tension secondaire"
            case "lbl_emotion_main":       s := "Émotion principale probable"
            case "lbl_emotion_pending":    s := "Émotion principale : pas assez de réponses pour proposer une piste."
            case "uni_choice_1":           s := "3 pistes te sont proposées."
            case "uni_choice_2":           s := "Choisis ton axe principal pour ce cycle. Les autres pistes pourront être explorées plus tard."
            case "uni_role_main":          s := "Univers principal"
            case "uni_role_bridge":        s := "Univers pont"
            case "uni_role_secondary":     s := "Univers secondaire"
            case "uni_why_main":           s := "Piste principale : elle correspond le plus directement à tes résultats Soul et VDA."
            case "uni_why_bridge":         s := "Piste pont : elle relie ton univers dominant à une autre tonalité intérieure."
            case "uni_why_secondary":      s := "Piste secondaire : une nuance complémentaire à explorer si elle te parle."
            case "choice_piste_of":        s := "Piste {} / {}"
            case "choice_why_label":       s := "Pourquoi cette piste peut correspondre"
            case "btn_prev_piste":         s := "← Précédent"
            case "btn_next_piste":         s := "Suivant →"
            case "btn_pick_piste":         s := "Choisir cette piste"
            case "btn_view_detail":        s := "Voir détail"
            case "btn_pick_universe":      s := "Choisir cet univers"
            case "btn_pick_territory":     s := "Choisir ce territoire"
            case "btn_back_pistes":        s := "Retour aux 3 pistes"
            case "uni_detail_title":       s := "Détail de l'univers"
            case "terr_detail_title":      s := "Détail du territoire"
            case "lbl_theme":              s := "Thème"
            case "lbl_signals":            s := "Signaux dominants"
            case "lbl_user_phrase":        s := "Phrase pour toi"
            case "lbl_inner_question":     s := "Question intérieure"
            case "lbl_long_desc":          s := "Description"
            case "uni_caution":            s := "Cet univers est une piste symbolique. Il ne définit pas qui tu es."
            case "terr_caution":           s := "Ce territoire est une piste symbolique. Il ne définit pas qui tu es."
            case "lbl_illustration":       s := "Illustration symbolique"
            case "illustration_pending":   s := "illustration_key={}`nillustration_path="
            case "terr_role_main":         s := "Territoire principal"
            case "terr_role_bridge":       s := "Territoire pont"
            case "terr_role_secondary":    s := "Territoire secondaire"
            case "scroll_hint":            s := "Fais défiler pour voir la suite"
            case "terr_choice_title":      s := "Choisir mon territoire"
            case "terr_choice_1":          s := "3 pistes te sont proposées."
            case "terr_choice_2":          s := "Choisis ton axe principal pour ce cycle. Les autres pistes pourront être explorées plus tard."
            case "terr_why_main":          s := "Piste principale : elle reflète la zone de vie la plus active pour toi maintenant."
            case "terr_why_bridge":        s := "Piste pont : elle relie ton univers à un territoire complémentaire."
            case "terr_why_secondary":     s := "Piste secondaire : un angle supplémentaire à considérer s'il résonne."
            case "btn_pick":               s := "Choisir"
            case "identity_saved_title":   s := "Architecture PRIMA sauvegardée"
            case "identity_saved_1":       s := "Ton choix servira de base symbolique pour la suite de PRIMA App."
            case "identity_saved_2":       s := "Cette architecture peut évoluer avec tes futurs cycles."
            case "identity_arch_label":    s := "Architecture :"
            case "btn_back_reading":       s := "Retour à ma lecture"
            case "btn_back_prima_home":    s := "Retour accueil PRIMA"
            case "vda_question_of":        s := "Question {} / {}"
            case "btn_next":               s := "Suivant"
            case "msg_quit_run":           s := "Quitter le parcours en cours ?"
            case "msg_finish_or_quit":     s := "Termine le parcours ou quitte l'application."
            case "btn_soul_test_done":     s := "PRIMA Soul Test terminé"
            case "msg_test_locked_1":      s := "Test déjà terminé."
            case "msg_test_locked_2":      s := "Il sera réouvert quand PRIMA VDA, PRIMA Shadow, les résultats et le choix d'univers seront terminés."
            case "vda_done_1":             s := "Parcours terminé."
            case "vda_done_2":             s := "Le résultat complet sera ajouté dans une prochaine étape."
            case "btn_back_soul":          s := "Retour PRIMA Soul"
            case "result_line1":           s := "Tes réponses semblent montrer une piste possible autour de {}."
            case "result_line2":           s := "Ce n'est pas une identité. C'est une piste de travail."
            case "result_line3":           s := "Un deuxième thème semble aussi présent : {}."
            case "btn_read":               s := "J'ai lu"
            case "btn_start":           s := "Débuter"
            case "msg_module_later":    s := "Module prévu plus tard."
            case "review_domain":       s := "Domaine"
            case "review_no_goals":     s := "Ajoutez d'abord un objectif dans Paramétrage perso."
            case "review_no_domain_goals": s := "Aucun objectif défini pour ce domaine."
            case "create_title":        s := "Nouveau profil"
            case "create_security_title": s := "Sécurité profil"
            case "create_name":         s := "Nom du profil"
            case "create_lang":         s := "Langue"
            case "profile_gender_label": s := "Genre / profil de lecture"
            case "gender_male":         s := "Homme"
            case "gender_female":       s := "Femme"
            case "gender_unspecified_pref": s := "Préfère ne pas répondre"
            case "gender_unspecified":  s := "Non renseigné"
            case "profile_gender_note": s := "Cette information sert uniquement à adapter certaines formulations plus tard. Elle ne définit pas ton résultat."
            case "create_mode":         s := "Mode du profil"
            case "mode_client":         s := "Client"
            case "mode_creator":        s := "Créateur"
            case "create_code":         s := "Code créateur"
            case "msg_wrong_code":      s := "Code incorrect."
            case "privacy_title":       s := "Confidentialité"
            case "privacy_body":        s := "PRIMA App est local-first.`n`nAucun cloud forcé.`nAucune télémétrie.`nAucun micro.`nAucune capture.`nAucune API externe."
            case "btn_accept":          s := "J'accepte"
            case "btn_review":          s := "Revue"
            case "btn_proof":           s := "Preuve"
            case "btn_settings":        s := "Réglages"
            case "settings_title":      s := "Réglages"
            case "start_title":         s := "Lancement"
            case "start_welcome":       s := "Bienvenue dans PRIMA"
            case "start_profile":       s := "Profil : {}"
            case "btn_launch":          s := "Lancer PRIMA"
            case "home_title":          s := "Bienvenue dans PRIMA"
            case "home_active":         s := "Profil actif : {}"
            case "home_version":        s := "Version {}"
            case "creator_home_title":  s := "Creator Home"
            case "creator_home_body":   s := "Espace créateur privé PRIMA."
            case "btn_creator_personalization": s := "Personnalisation"
            case "btn_creator_goal":  s := "Objectif"
            case "btn_creator_soul_test": s := "PRIMA Soul Test"
            case "btn_creator_vda_test": s := "PRIMA VDA Test"
            case "btn_creator_shadow_test": s := "PRIMA Shadow Test"
            case "msg_creator_module_later": s := "Module créateur prévu plus tard."
            case "btn_onboarding":      s := "Paramétrage perso"
            case "btn_change_profile":  s := "Changer de profil"
            case "onboarding_body":     s := "PRIMA t'aide à avancer étape par étape. Pour l'instant, cette version sert à poser ta base, suivre ton profil et préparer ton espace personnel."
            case "msg_select_profile":  s := "Veuillez sélectionner un profil."
            case "msg_select_archive":  s := "Veuillez sélectionner un profil à archiver."
            case "msg_active_archive":  s := "Ce profil est actif. Déconnectez-vous ou choisissez un autre profil avant de l'archiver."
            case "msg_archive_confirm": s := "Archiver le profil « {} » ?`n`nLe profil sera déplacé vers archive/.`nAucune suppression définitive."
            case "msg_empty_name":      s := "Veuillez entrer un nom de profil."
            case "msg_no_active":       s := "Erreur : aucun profil actif."
            case "msg_goals_max_domains": s := "Maximum 5 domaines avec objectifs en V0.1."
            case "confirm_close":       s := "Fermer PRIMA App ?"
            case "confirm_quit":        s := "Quitter PRIMA App ?"
            case "confirm_quit_remember": s := "Tu peux quitter l'app. À la prochaine ouverture, tu reprendras là où tu t'es arrêté.`nSi tu veux changer de profil, utilise Se déconnecter.`n`nOui = Quitter`nNon = Se déconnecter`nAnnuler = Rester"
            case "login_remember_me":   s := "M'enregistrer sur cet appareil"
            case "btn_logout":          s := "Se déconnecter"
            case "confirm_saved":       s := "Vos données locales sont enregistrées."
            case "confirm_missing":     s := "Attention : le profil actif est introuvable sur disque."
            case "pause_on":            s := "PRIMA App est en pause.`n`nCtrl+Alt+Shift+X pour reprendre."
            case "pause_off":           s := "PRIMA App reprend."
            default:                    return key
        }
    }
    return p.Length ? Format(s, p*) : s
}

; ── Icônes UI PRIMA (affichage uniquement — jamais logs / sauvegarde / moteur) ─
PrimaLabelWithIcon(key, label) {
    icon := PrimaIcon(key)
    return (icon != "") ? icon "  " label : label
}

; Traduction + icône pour l'interface uniquement.
TIcon(key, p*) {
    return PrimaLabelWithIcon(key, T(key, p*))
}

PrimaIcon(key) {
    icon := PrimaMainMenuIcon(key)
    if (icon != "")
        return icon
    icon := PrimaSoulHubIcon(key)
    if (icon != "")
        return icon
    icon := PrimaResultSectionIcon(key)
    if (icon != "")
        return icon
    icon := PrimaStateIcon(key)
    if (icon != "")
        return icon
    icon := PrimaUniverseIcon(key)
    if (icon != "")
        return icon
    icon := PrimaTerritoryIcon(key)
    if (icon != "")
        return icon
    icon := SoulPublicIcon(key)
    if (icon != "")
        return icon
    icon := VdaPublicIcon(key)
    if (icon != "")
        return icon
    icon := ShadowPublicIcon(key)
    if (icon != "")
        return icon
    icon := ShadowEmotionIcon(key)
    if (icon != "")
        return icon
    return ""
}

PrimaMainMenuIcon(key) {
    switch key {
        case "home_title", "btn_launch":          return "🏠"
        case "profile_title":                     return "👤"
        case "btn_create_profile", "btn_create":  return "➕"
        case "create_password", "login_title":    return "🔐"
        case "base_kit_prima", "kit_title":       return "🎒"
        case "goals_title", "btn_goals", "btn_creator_goal": return "🎯"
        case "review_title", "btn_review":        return "📝"
        case "base_prima_soul", "prima_soul_intro_title": return "🧭"
        case "prima_soul_complete_title":         return "🎯"
        case "btn_settings", "btn_soul_settings", "settings_title": return "⚙️"
        case "btn_quit":                          return "🚪"
        case "btn_back", "btn_back_reading", "btn_back_prima_home": return "←"
        case "btn_save", "btn_save_reading":      return "💾"
        case "btn_archive":                       return "🗑️"
        case "btn_archives", "archives_title":   return "📦"
        case "btn_delete_archive":              return "❌"
        case "btn_continue":                      return "➡️"
        case "btn_next":                          return "➡️"
        case "btn_pick", "btn_pick_piste", "btn_pick_universe", "btn_pick_territory", "btn_accept", "btn_read": return "✅"
        case "btn_view_detail":                   return "🔍"
        case "btn_back_pistes":                   return "←"
        case "btn_change_profile":                return "👤"
        case "start_title":                       return "🏠"
        case "privacy_title":                     return "🔐"
        case "create_title":                      return "➕"
        case "create_security_title":             return "🔐"
        case "btn_kit_verify":                    return "ℹ️"
        case "btn_kit_create":                    return "➕"
        case "btn_back_soul":                     return "←"
    }
    return ""
}

PrimaSoulHubIcon(key) {
    switch key {
        case "soul_test_soul", "soul_test_title", "btn_result_soul", "btn_creator_soul_test", "btn_soul_test_done": return "🪞"
        case "soul_test_vda", "vda_test_title", "btn_result_vda", "btn_creator_vda_test", "btn_vda_test_done": return "🧠"
        case "soul_test_shadow", "shadow_test_title", "btn_result_shadow", "btn_creator_shadow_test", "btn_shadow_test_done": return "🌘"
        case "btn_generate_reading", "reading_hub_title": return "✨"
        case "btn_choose_universe", "btn_choose_identity", "uni_choice_title": return "🌌"
        case "btn_view_architecture", "btn_view_identity", "arch_locked_title", "identity_result_title": return "🌌"
        case "btn_create_plan":                   return "🛠️"
        case "btn_restart_cycle", "btn_reset_soul_cycle", "btn_redo_tests": return "🔄"
        case "terr_choice_title":                 return "🧭"
        case "identity_saved_title":              return "✅"
        case "identity_arch_label":               return "🌌"
    }
    return ""
}

PrimaResultSectionIcon(key) {
    switch key {
        case "sec_suggest":                       return "🔎"
        case "sec_nourish", "sec_vda_nourish":  return "🌱"
        case "sec_pressure", "sec_vda_stress", "sec_shadow_pressure": return "⚡"
        case "sec_comm", "sec_vda_comm":         return "🗣️"
        case "sec_soul_touch":                    return "💠"
        case "sec_soul_protection":               return "🛡️"
        case "sec_soul_behavior":                 return "👣"
        case "sec_soul_need":                     return "💧"
        case "sec_soul_gentle":                   return "🕊️"
        case "sec_vda_stable":                    return "⚙️"
        case "sec_vda_energy":                    return "🔋"
        case "sec_vda_balance":                   return "🧘"
        case "sec_shadow_accept":                 return "🪞"
        case "sec_shadow_tension":                return "🌀"
        case "sec_shadow_emotion":                return "💫"
        case "sec_shadow_hide":                   return "🌫️"
        case "sec_shadow_integration":            return "🌿"
        case "lbl_dominant", "lbl_stable_probable", "lbl_tension_dom", "lbl_energy_probable": return "⭐"
        case "lbl_secondary", "lbl_influence_secondary", "lbl_influence_tertiary", "lbl_tension_sec": return "✨"
        case "lbl_emotion_main":                  return "💫"
        case "gauge":                             return "📊"
    }
    return ""
}

PrimaStateIcon(key) {
    switch key {
        case "test_available", "btn_start":       return "▶️"
        case "test_done":                         return "✅"
        case "test_locked":                       return "🔒"
        case "msg_reading_preparing":             return "🕯️"
        case "warning":                           return "⚠️"
        case "info":                              return "ℹ️"
        case "no_result":                         return "📭"
        case "vda_question_of":                   return "❓"
        case "msg_rank_all", "msg_rank_all_5", "msg_rank_all_7", "shadow_pick_hint", "soul_pick_hint", "reading_hub_1": return "ℹ️"
    }
    return ""
}

PrimaUniverseIcon(key) {
    switch key {
        case "passe":      return "🕰️"
        case "futur":      return "🚀"
        case "ville":      return "🏙️"
        case "ocean":      return "🌊"
        case "desert":     return "🏜️"
        case "labyrinthe": return "🧩"
        case "jardin":     return "🌿"
    }
    return ""
}

PrimaTerritoryIcon(key) {
    switch key {
        case "lien":       return "🤝"
        case "choix":      return "🧭"
        case "regard":     return "👁️"
        case "controle":   return "🛡️"
        case "silence":    return "🌙"
        case "desir":      return "🔥"
        case "changement": return "🌪️"
    }
    return ""
}

; Icônes noms publics Soul (clé interne → emoji, jamais affichée).
SoulPublicIcon(key) {
    switch key {
        case "rejet":       return "📍"
        case "abandon":     return "🤝"
        case "humiliation": return "🌱"
        case "trahison":    return "🛡️"
        case "injustice":   return "⚖️"
    }
    return ""
}

VdaPublicIcon(key) {
    switch key {
        case "analyseur":   return "🧱"
        case "perseverant": return "🧭"
        case "empathique":  return "🤝"
        case "imagineur":   return "🌌"
        case "energiseur":  return "⚡"
        case "promoteur":   return "🚀"
    }
    return ""
}

ShadowPublicIcon(key) {
    switch key {
        case "orgueil":     return "👑"
        case "envie":       return "👁️"
        case "colere":      return "⚡"
        case "paresse":     return "🌫️"
        case "avarice":     return "🛡️"
        case "gourmandise": return "🍯"
        case "luxure":      return "🔥"
    }
    return ""
}

ShadowEmotionIcon(key) {
    switch key {
        case "peur":      return "⚠️"
        case "tristesse": return "🌧️"
        case "colere":    return "🔥"
        case "honte":     return "🫥"
        case "joie":      return "✨"
    }
    return ""
}

PrimaUniverseDisplayNameWithIcon(key) {
    return PrimaLabelWithIcon(key, PrimaUniverseName(key))
}

PrimaTerritoryDisplayNameWithIcon(key) {
    return PrimaLabelWithIcon(key, PrimaTerritoryName(key))
}

SoulReadingNameWithIcon(key) {
    return PrimaLabelWithIcon(key, SoulReadingName(key))
}

VdaReadingNameWithIcon(key) {
    return PrimaLabelWithIcon(key, VdaReadingName(key))
}

ShadowReadingNameWithIcon(key) {
    return PrimaLabelWithIcon(key, ShadowReadingName(key))
}

ShadowEmotionNameWithIcon(key) {
    return PrimaLabelWithIcon(key, ShadowEmotionName(key))
}

; Préfixe priorité choix 1-2 (Soul / Shadow).
PrimaPriorityPrefix(priority) {
    switch priority {
        case 1: return "① — "
        case 2: return "② — "
    }
    return priority " — "
}

; Préfixe rang VDA 1-6.
PrimaRankPrefix(rank) {
    return rank " — "
}

; ── UI helpers (grille PRIMA) ───────────────────────────────────────────────────
AddSpacer(g, h := "") {
    global GAP_MD
    if (h = "")
        h := GAP_MD
    g.Add("Text", "h" h " Background" CLR_BG, "")
}

AddTitle(g, text, size := 24) {
    global CONTENT_W, TITLE_H, CLR_BG, CLR_ACCENT
    g.SetFont("s" size " Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "w" CONTENT_W " h" TITLE_H " Center Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddSubtitle(g, text) {
    global CONTENT_W, TEXT_H, CLR_BG, CLR_SUBTEXT
    g.SetFont("s11 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "w" CONTENT_W " h" TEXT_H " Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddFormTitle(g, text) {
    global FORM_FIELD_W, CLR_BG, CLR_ACCENT, CLR_TEXT
    g.SetFont("s14 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "w" FORM_FIELD_W " h22 Center Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddFormLabel(g, text) {
    global FORM_FIELD_W, CLR_BG, CLR_SUBTEXT, CLR_TEXT
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "w" FORM_FIELD_W " h16 Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddFormBodyText(g, text) {
    global FORM_FIELD_W, CLR_BG, CLR_TEXT
    g.SetFont("s10 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "w" FORM_FIELD_W " Center Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddFormGap(g, h := 3) {
    global CLR_BG
    g.Add("Text", "h" h " Background" CLR_BG, "")
}

AddFormButton(g, label, action) {
    global FORM_BTN_W, FORM_BTN_H
    btn := g.Add("Button", "w" FORM_BTN_W " h" FORM_BTN_H " Center", label)
    btn.OnEvent("Click", action)
    return btn
}

AddFormNavBackQuit(g, backAction, includeQuit := true) {
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("btn_back"), backAction)
    if (includeQuit) {
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    }
}

AddCreateLabel(g, text) {
    AddFormLabel(g, text)
}

AddCreateGap(g, h := 3) {
    AddFormGap(g, h)
}

AddBodyText(g, text, w := "") {
    global CONTENT_W, CLR_BG, CLR_TEXT
    if (w = "")
        w := CONTENT_W
    g.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "w" w " Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddCardRule(g) {
    global CONTENT_W, CLR_PANEL
    g.Add("Text", "w" CONTENT_W " h1 Background" CLR_PANEL, "")
}

; Carte de choix : titre + description + bouton Choisir (même géométrie partout).
AddChoiceCard(g, title, desc, pickAction) {
    global GAP_LG, GAP_SM, GAP_Y, CARD_H, CARD_W, CLR_BG, CLR_PANEL
    AddSpacer(g, GAP_LG)
    AddCardRule(g)
    AddSpacer(g, GAP_Y)
    AddSubtitle(g, title)
    AddSpacer(g, GAP_SM)
    AddBodyText(g, desc)
    AddSpacer(g, GAP_Y)
    AddButton(g, TIcon("btn_pick"), pickAction)
    AddSpacer(g, GAP_SM)
}

; En-tête fixe écran choix Univers / Territoire.
AddChoiceScreenHeader(g, title, introLine1, introLine2 := "") {
    global MARGIN_X, CONTENT_W, CHOICE_TITLE_Y, CHOICE_INTRO_Y, CHOICE_INTRO_H
    global CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT
    g.SetFont("s20 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" CHOICE_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG, title)
    intro := introLine1
    if (introLine2 != "")
        intro .= "`n" introLine2
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" CHOICE_INTRO_Y " w" CONTENT_W " h" CHOICE_INTRO_H " Center +0x2000 Background" CLR_BG, intro)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

; Carte compacte à position absolue (icône+titre, description, Choisir dans la carte).
AddFixedChoiceCard(g, row, roleLabel, title, desc, pickAction) {
    global CHOICE_CARD_X, CHOICE_CARD_W, CHOICE_CARD_H, CHOICE_CARD_GAP, CHOICE_CARD_START_Y
    global CHOICE_PICK_W, BUTTON_H, CLR_PANEL, CLR_SUBTEXT, CLR_TEXT, CLR_ACCENT
    y := CHOICE_CARD_START_Y + (row - 1) * (CHOICE_CARD_H + CHOICE_CARD_GAP)
    x := CHOICE_CARD_X
    w := CHOICE_CARD_W
    h := CHOICE_CARD_H
    g.Add("Text", "x" x " y" y " w" w " h" h " Background" CLR_PANEL, "")
    g.SetFont("s9 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 8) " w" (w - 32) " h18 BackgroundTrans", roleLabel)
    g.SetFont("s12 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 28) " w" (w - CHOICE_PICK_W - 40) " h24 BackgroundTrans", title)
    g.SetFont("s10 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 52) " w" (w - CHOICE_PICK_W - 40) " h44 +0x2000 BackgroundTrans", desc)
    pickX := x + w - CHOICE_PICK_W - 16
    pickY := y + h - BUTTON_H - 12
    btn := g.Add("Button", "x" pickX " y" pickY " w" CHOICE_PICK_W " h" BUTTON_H " Center", TIcon("btn_pick"))
    btn.OnEvent("Click", pickAction)
}

; Pied écran choix : Retour centré (lecture, hub).
AddChoiceNavBack(g, backAction) {
    global MARGIN_X, CONTENT_W, CHOICE_NAV_Y, TEST_NAV_BTN_W, BUTTON_H
    x := MARGIN_X + (CONTENT_W - TEST_NAV_BTN_W) // 2
    btnBack := g.Add("Button", "x" x " y" CHOICE_NAV_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_back"))
    btnBack.OnEvent("Click", backAction)
}

; Pied Univers / Territoire : Retour à gauche, Choisir à droite.
AddChoiceNavBackPick(g, backAction, pickAction, pickLabel := "") {
    global MARGIN_X, CONTENT_W, CHOICE_NAV_Y, BUTTON_H
    if (pickLabel = "")
        pickLabel := TIcon("btn_pick")
    btnW := 300
    gap := 24
    totalW := 2 * btnW + gap
    startX := MARGIN_X + (CONTENT_W - totalW) // 2
    btnBack := g.Add("Button", "x" startX " y" CHOICE_NAV_Y " w" btnW " h" BUTTON_H " Center", TIcon("btn_back"))
    btnBack.OnEvent("Click", backAction)
    btnPick := g.Add("Button", "x" (startX + btnW + gap) " y" CHOICE_NAV_Y " w" btnW " h" BUTTON_H " Center", pickLabel)
    btnPick.OnEvent("Click", pickAction)
}

; Carte paginée (1 piste visible) : icône, nom, description, Voir détail.
AddPagedChoiceCard(g, icon, name, desc, onDetail) {
    global CHOICE_CARD_X, CHOICE_CARD_W, PAGED_CHOICE_CARD_Y, PAGED_CHOICE_CARD_H
    global BUTTON_H_BIG, CLR_PANEL, CLR_TEXT, CLR_ACCENT
    x := CHOICE_CARD_X
    y := PAGED_CHOICE_CARD_Y
    w := CHOICE_CARD_W
    h := PAGED_CHOICE_CARD_H
    innerW := w - 32
    g.Add("Text", "x" x " y" y " w" w " h" h " Background" CLR_PANEL, "")
    g.SetFont("s36", "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 14) " w" 52 " h48 Center BackgroundTrans", icon)
    g.SetFont("s16 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" (x + 76) " y" (y + 22) " w" (innerW - 60) " h28 BackgroundTrans", name)
    g.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 68) " w" innerW " h72 +0x2000 BackgroundTrans", desc)
    yBtn := y + h - BUTTON_H_BIG - 16
    btnDetail := g.Add("Button", "x" (x + 16) " y" yBtn " w" innerW " h" BUTTON_H_BIG " Center", TIcon("btn_view_detail"))
    btnDetail.OnEvent("Click", onDetail)
}

; Navigation paginée : Précédent | Suivant.
AddPagedChoiceNavRow(g, page, total, onPrev, onNext) {
    global MARGIN_X, CONTENT_W, PAGED_CHOICE_NAV_Y, PAGED_CHOICE_NAV_BTN_W, BUTTON_H
    gap := 24
    totalW := 2 * PAGED_CHOICE_NAV_BTN_W + gap
    startX := MARGIN_X + (CONTENT_W - totalW) // 2
    btnPrev := g.Add("Button", "x" startX " y" PAGED_CHOICE_NAV_Y " w" PAGED_CHOICE_NAV_BTN_W " h" BUTTON_H " Center"
        , T("btn_prev_piste"))
    btnPrev.OnEvent("Click", onPrev)
    btnPrev.Enabled := (page > 1)
    btnNext := g.Add("Button", "x" (startX + PAGED_CHOICE_NAV_BTN_W + gap) " y" PAGED_CHOICE_NAV_Y
        " w" PAGED_CHOICE_NAV_BTN_W " h" BUTTON_H " Center", T("btn_next_piste"))
    btnNext.OnEvent("Click", onNext)
    btnNext.Enabled := (page < total)
}

; Pied écran détail : Retour à gauche, Choisir à droite.
AddChoiceDetailFooter(g, pickLabel, pickAction, backAction) {
    global MARGIN_X, CONTENT_W, BUTTON_H, BUTTON_H_BIG
    btnW := 300
    gap := 24
    yRow := 610
    totalW := 2 * btnW + gap
    startX := MARGIN_X + (CONTENT_W - totalW) // 2
    btnBack := g.Add("Button", "x" startX " y" yRow " w" btnW " h" BUTTON_H " Center"
        , TIcon("btn_back_pistes"))
    btnBack.OnEvent("Click", backAction)
    btnPick := g.Add("Button", "x" (startX + btnW + gap) " y" yRow " w" btnW " h" BUTTON_H_BIG " Center", pickLabel)
    btnPick.OnEvent("Click", pickAction)
}

; Bloc label + texte dans zone scrollable — retourne le y suivant.
AddScrollDetailBlock(cg, y, label, body, width := "") {
    global CONTENT_W, CLR_ACCENT, CLR_TEXT, CLR_SUBTEXT, GAP_SM
    pad := 12
    if (width = "")
        w := CONTENT_W - 2 * pad
    else
        w := width
    x := pad
    cg.SetFont("s11 Bold c" CLR_ACCENT, "Segoe UI")
    cg.Add("Text", "x" x " y" y " w" w " h20 BackgroundTrans", label)
    y += 22
    cg.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    h := ScrollTextHeight(body, w)
    cg.Add("Text", "x" x " y" y " w" w " h" h " +0x2000 BackgroundTrans", body)
    y += h + GAP_SM
    return y
}

; Placeholder illustration (clé + chemin futur).
AddScrollIllustrationPlaceholder(cg, y, illKey, illPath) {
    global CONTENT_W, CLR_PANEL, CLR_SUBTEXT, GAP_SM
    pad := 12
    w := CONTENT_W - 2 * pad
    x := pad
    h := 72
    cg.Add("Text", "x" x " y" y " w" w " h" h " Background" CLR_PANEL, "")
    cg.SetFont("s10 Bold c" CLR_SUBTEXT, "Segoe UI")
    cg.Add("Text", "x" (x + 12) " y" (y + 8) " w" (w - 24) " h18 BackgroundTrans", T("lbl_illustration"))
    cg.SetFont("s9 c" CLR_SUBTEXT, "Segoe UI")
    placeholder := (illPath != "")
        ? illPath
        : Format(T("illustration_pending"), illKey)
    cg.Add("Text", "x" (x + 12) " y" (y + 28) " w" (w - 24) " h36 +0x2000 BackgroundTrans", placeholder)
    return y + h + GAP_SM
}

AddButton(g, label, action, w := "", h := "") {
    global BUTTON_W, BUTTON_H
    if (w = "")
        w := BUTTON_W
    if (h = "")
        h := BUTTON_H
    btn := g.Add("Button", "w" w " h" h " Center", label)
    btn.OnEvent("Click", action)
    return btn
}

AddBigButton(g, label, action) {
    global BUTTON_W, BUTTON_H_BIG
    btn := g.Add("Button", "w" BUTTON_W " h" BUTTON_H_BIG " Center", label)
    btn.SetFont("s12 Bold")
    btn.OnEvent("Click", action)
    return btn
}

; Hauteur réponse selon longueur du texte (wrapping multi-ligne).
AnswerButtonHeight(text, maxH := 64) {
    global ANSWER_H, ANSWER_H_LG
    charsPerLine := 88
    lines := Max(1, Ceil(StrLen(text) / charsPerLine))
    if (lines <= 1)
        h := ANSWER_H
    else if (lines = 2)
        h := ANSWER_H_LG
    else
        h := ANSWER_H_LG + (lines - 2) * 20
    return Min(h, maxH)
}

; Bouton réponse test : largeur grille, multi-ligne, hauteur auto.
AddAnswerButton(g, text, handler, w := "") {
    global ANSWER_W
    if (w = "")
        w := ANSWER_W
    h := AnswerButtonHeight(text)
    btn := g.Add("Button", "w" w " h" h " +0x2000", text)
    btn.OnEvent("Click", handler)
    return btn
}

; Abscisse centrée pour la colonne réponses test (820 px).
TestAnswerX() {
    global MARGIN_X, CONTENT_W, TEST_ANSWER_W
    return MARGIN_X + (CONTENT_W - TEST_ANSWER_W) // 2
}

; En-tête écran question : titre · compteur · prompt · consigne · rang — retourne y des réponses.
AddTestQuestionHeader(g, title, countText, promptText, guidanceText := "", rankHintText := "") {
    global MARGIN_X, CONTENT_W, TEST_TITLE_Y, TEST_COUNT_Y, TEST_PROMPT_Y, TEST_ANSWER_W
    global GAP_SM, GAP_MD, CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT
    ax := TestAnswerX()
    g.SetFont("s20 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" TEST_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG, title)
    g.SetFont("s11 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" TEST_COUNT_Y " w" CONTENT_W " h22 Center Background" CLR_BG, countText)
    y := TEST_PROMPT_Y
    g.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    promptH := ScrollTextHeight(promptText, TEST_ANSWER_W, 18)
    g.Add("Text", "x" ax " y" y " w" TEST_ANSWER_W " h" promptH " +0x2000 Background" CLR_BG, promptText)
    y += promptH + GAP_SM
    if (guidanceText != "") {
        g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
        guidanceH := ScrollTextHeight(guidanceText, TEST_ANSWER_W, 16)
        g.Add("Text", "x" ax " y" y " w" TEST_ANSWER_W " h" guidanceH " +0x2000 Background" CLR_BG, guidanceText)
        y += guidanceH + GAP_SM
    }
    if (rankHintText != "") {
        g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
        rankH := ScrollTextHeight(rankHintText, TEST_ANSWER_W, 16)
        g.Add("Text", "x" ax " y" y " w" TEST_ANSWER_W " h" rankH " +0x2000 Background" CLR_BG, rankHintText)
        y += rankH + GAP_MD
    } else {
        y += GAP_SM
    }
    g.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    return y
}

; Hauteurs + nav adaptative : nav_y = min(WINDOW_H - 110, answers_end + 28).
ComputeTestAnswerLayout(texts, answersY := "") {
    global TEST_ANSWERS_Y, GAP_TEST_ANSWER, TEST_ANSWER_H_DEF, TEST_ANSWER_MAX_H, ANSWER_H
    global TEST_NAV_GAP_AFTER, TEST_NAV_MAX_Y, WINDOW_H
    if (answersY = "")
        answersY := TEST_ANSWERS_Y
    n := texts.Length
    if (n = 0)
        return { heights: [], navY: TEST_NAV_MAX_Y, answersEnd: answersY }
    navCap := Min(TEST_NAV_MAX_Y, WINDOW_H - 110)
    avail := navCap - TEST_NAV_GAP_AFTER - answersY
    heights := []
    for t in texts {
        h := AnswerButtonHeight(t, TEST_ANSWER_MAX_H)
        if (h <= ANSWER_H + 2 && StrLen(t) <= 90)
            h := TEST_ANSWER_H_DEF
        heights.Push(h)
    }
    total := 0
    for h in heights
        total += h
    total += (n - 1) * GAP_TEST_ANSWER
    if (total > avail) {
        cap := Max(38, Min(TEST_ANSWER_MAX_H, Floor((avail - (n - 1) * GAP_TEST_ANSWER) / n)))
        heights := []
        for t in texts {
            h := AnswerButtonHeight(t, cap)
            if (h < cap && StrLen(t) <= 90)
                h := cap
            heights.Push(h)
        }
        total := 0
        for h in heights
            total += h
        total += (n - 1) * GAP_TEST_ANSWER
    }
    answersEnd := answersY + total
    navY := Min(navCap, answersEnd + TEST_NAV_GAP_AFTER)
    return { heights: heights, navY: navY, answersEnd: answersEnd }
}

; Style visuel réponse sélectionnée / non sélectionnée (UI uniquement).
ApplyTestAnswerPickStyle(btn, prefix, answerText, selected) {
    global CLR_TEXT, CLR_ACCENT
    btn.Text := prefix answerText
    if (selected)
        btn.SetFont("s11 Bold c" CLR_ACCENT, "Segoe UI")
    else
        btn.SetFont("s11 c" CLR_TEXT, "Segoe UI")
}

; Boutons réponses sans handler — le caller attache le clic (visible picks).
AddVisibleRankAnswerButtons(g, texts, answersY := "") {
    global TEST_ANSWERS_Y, GAP_TEST_ANSWER, TEST_ANSWER_W, CLR_TEXT
    if (answersY = "")
        answersY := TEST_ANSWERS_Y
    layout := ComputeTestAnswerLayout(texts, answersY)
    btns := []
    y := answersY
    ax := TestAnswerX()
    for i, h in layout.heights {
        btn := g.Add("Button", "x" ax " y" y " w" TEST_ANSWER_W " h" h " +0x2000", "  " texts[i])
        btn.SetFont("s11 c" CLR_TEXT, "Segoe UI")
        btns.Push(btn)
        y += h + GAP_TEST_ANSWER
    }
    return { buttons: btns, navY: layout.navY }
}

; Pile de réponses centrée (820 px) — attache handler.Bind(i) par bouton.
AddTestAnswerButtons(g, texts, clickHandler, answersY := "") {
    answerUi := AddVisibleRankAnswerButtons(g, texts, answersY)
    loop answerUi.buttons.Length {
        i := A_Index
        answerUi.buttons[i].OnEvent("Click", clickHandler.Bind(i))
    }
    return answerUi
}

; Navigation test : Suivant seul (fermeture via croix Windows).
AddFixedTestNav(g, nextAction, navY := "") {
    global MARGIN_X, CONTENT_W, TEST_NAV_BTN_W, TEST_NAV_MAX_Y, BUTTON_H
    if (navY = "")
        navY := TEST_NAV_MAX_Y
    x := MARGIN_X + (CONTENT_W - TEST_NAV_BTN_W) // 2
    btnNext := g.Add("Button", "x" x " y" navY " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_next"))
    btnNext.OnEvent("Click", nextAction)
    SetPrimaryEnterAction(nextAction)
    return btnNext
}

AddDisabledButton(g, label, w := "", h := "") {
    global BUTTON_W, BUTTON_H
    if (w = "")
        w := BUTTON_W
    if (h = "")
        h := BUTTON_H
    btn := g.Add("Button", "w" w " h" h " Center", label)
    btn.Enabled := false
    return btn
}

; En-tête d'écran : titre + texte(s) d'introduction.
AddScreenHeader(g, title, introLines*) {
    global GAP_SM, GAP_LG
    AddTitle(g, title, 20)
    AddSpacer(g, GAP_SM)
    for line in introLines
        AddBodyText(g, line)
    AddSpacer(g, GAP_LG)
}

; Navigation bas d'écran : Retour puis Quitter (ou actions custom).
AddNavBackQuit(g, backAction, quitAction := "") {
    global GAP_XL, GAP_Y
    AddSpacer(g, GAP_XL)
    AddButton(g, TIcon("btn_back"), backAction)
    if (quitAction != "") {
        AddSpacer(g, GAP_Y)
        AddButton(g, TIcon("btn_quit"), quitAction)
    }
}

; Navigation test : Suivant puis Quitter.
AddTestNav(g, nextAction) {
    global GAP_LG, GAP_Y
    AddSpacer(g, GAP_LG)
    AddButton(g, TIcon("btn_next"), nextAction)
    AddSpacer(g, GAP_Y)
    AddButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
}

; Section résultat : sous-titre + contenu (lignes vides ignorées).
AddResultSection(g, sectionKey, bodyLines*) {
    global GAP_LG, GAP_SM
    AddSpacer(g, GAP_LG)
    AddSubtitle(g, TIcon(sectionKey))
    AddSpacer(g, GAP_SM)
    for line in bodyLines {
        if (line != "")
            AddBodyText(g, line)
    }
}

HomeChangeProfile(*) {
    global CURRENT_PROFILE_ID, CURRENT_DISPLAY_NAME, PENDING_PROFILE_ID
    CURRENT_PROFILE_ID := ""
    CURRENT_DISPLAY_NAME := ""
    PENDING_PROFILE_ID := ""
    SetTimer(DeferredRenderProfile, -1)
}

DeferredRenderProfile(*) {
    SetTimer(DeferredRenderProfile, 0)
    RenderScreen("profile")
}

HomeOpenOnboarding(*) {
    SetTimer(DeferredRenderOnboarding, -1)
}

DeferredRenderOnboarding(*) {
    SetTimer(DeferredRenderOnboarding, 0)
    RenderScreen("onboarding")
}

HomeOpenSettings(*) {
    SetTimer(DeferredRenderSettings, -1)
}

DeferredRenderSettings(*) {
    SetTimer(DeferredRenderSettings, 0)
    RenderScreen("settings")
}

HomeOpenReview(*) {
    global REVIEW_BACK_SCREEN
    REVIEW_BACK_SCREEN := "home"
    SetTimer(DeferredRenderReview, -1)
}

CreatorOpenReview(*) {
    global REVIEW_BACK_SCREEN
    REVIEW_BACK_SCREEN := "creator_home"
    SetTimer(DeferredRenderReview, -1)
}

CreatorOpenSoul(*) {
    global PRIMA_SOUL_BACK
    PRIMA_SOUL_BACK := "creator_home"
    SetTimer(DeferredRenderPrimaSoulIntro, -1)
}

DeferredRenderCreatorSoul(*) {
    global PRIMA_SOUL_BACK
    SetTimer(DeferredRenderCreatorSoul, 0)
    PRIMA_SOUL_BACK := "creator_home"
    RenderScreen("prima_soul_intro")
}

CreatorOpenGoals(*) {
    global CURRENT_PROFILE_ID, GOALS_BACK_SCREEN
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        return
    }
    GOALS_BACK_SCREEN := "creator_home"
    RenderScreen("onboarding_goals")
}

DeferredRenderReview(*) {
    SetTimer(DeferredRenderReview, 0)
    RenderScreen("review")
}

HomeOpenPrimaSoulIntro(*) {
    global PRIMA_SOUL_BACK
    PRIMA_SOUL_BACK := "home"
    SetTimer(DeferredRenderPrimaSoulIntro, -1)
}

PersonalBaseOpenPrimaSoulIntro(*) {
    global PRIMA_SOUL_BACK
    PRIMA_SOUL_BACK := "personal_base"
    SetTimer(DeferredRenderPrimaSoulIntro, -1)
}

DeferredRenderPrimaSoulIntro(*) {
    SetTimer(DeferredRenderPrimaSoulIntro, 0)
    RenderScreen("prima_soul_intro")
}

PrimaSoulBackToHome(*) {
    SetTimer(DeferredPrimaSoulBackHome, -1)
}

DeferredPrimaSoulBackHome(*) {
    global PRIMA_SOUL_BACK
    SetTimer(DeferredPrimaSoulBackHome, 0)
    RenderScreen(PRIMA_SOUL_BACK)
}

OpenCreateProfile(*) {
    global DRAFT_LANG, DRAFT_NAME, DRAFT_MODE, DRAFT_PASSWORD, DRAFT_PASSWORD_CONFIRM, DRAFT_GENDER, CURRENT_LANG
    DRAFT_LANG := CURRENT_LANG
    DRAFT_NAME := ""
    DRAFT_MODE := "client"
    DRAFT_PASSWORD := ""
    DRAFT_PASSWORD_CONFIRM := ""
    DRAFT_GENDER := "unspecified"
    CURRENT_LANG := DRAFT_LANG
    RenderScreen("create")
}

TrySaveCreateDrafts() {
    global NAME_INPUT, DRAFT_NAME, GENDER_CHOICE, DRAFT_GENDER
    try DRAFT_NAME := NAME_INPUT.Value
    try DRAFT_GENDER := ProfileGenderFromChoiceIndex(GENDER_CHOICE.Value)
}

TrySaveCreateSecurityDrafts() {
    global PASSWORD_INPUT, PASSWORD_CONFIRM_INPUT
    global DRAFT_PASSWORD, DRAFT_PASSWORD_CONFIRM
    try DRAFT_PASSWORD := PASSWORD_INPUT.Value
    try DRAFT_PASSWORD_CONFIRM := PASSWORD_CONFIRM_INPUT.Value
}

CreateLangChange(*) {
    global LANG_CHOICE, DRAFT_LANG, CURRENT_LANG, MODE_CHOICE, DRAFT_MODE
    TrySaveCreateDrafts()
    DRAFT_MODE := (MODE_CHOICE.Value = 2) ? "creator" : "client"
    DRAFT_LANG := (LANG_CHOICE.Text = "English") ? "en" : "fr"
    CURRENT_LANG := DRAFT_LANG
    RenderScreen("create")
}

CreateModeChange(*) {
    TrySaveCreateDrafts()
    global MODE_CHOICE, DRAFT_MODE
    DRAFT_MODE := (MODE_CHOICE.Value = 2) ? "creator" : "client"
    RenderScreen("create")
}

CreateProfileContinue(*) {
    global NAME_INPUT, LANG_CHOICE, MODE_CHOICE, GENDER_CHOICE
    global DRAFT_NAME, DRAFT_LANG, DRAFT_MODE, DRAFT_GENDER, CURRENT_LANG
    name := Trim(NAME_INPUT.Value)
    if (name = "") {
        MsgBox(T("msg_empty_name"), APP_TITLE, "Icon!")
        return
    }
    DRAFT_NAME := name
    DRAFT_LANG := (LANG_CHOICE.Text = "English") ? "en" : "fr"
    DRAFT_MODE := (MODE_CHOICE.Value = 2) ? "creator" : "client"
    DRAFT_GENDER := ProfileGenderFromChoiceIndex(GENDER_CHOICE.Value)
    CURRENT_LANG := DRAFT_LANG
    RenderScreen("create_security")
}

BackFromCreateSecurity(*) {
    TrySaveCreateSecurityDrafts()
    RenderScreen("create")
}

BackFromCreate(*) {
    RestoreSessionLanguage()
    RenderScreen("profile")
}

; ── Écrans ────────────────────────────────────────────────────────────────────
BuildProfile() {
    ids := GetProfileIds()
    global FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    g := NewFormGui()
    AddFormTitle(g, TIcon("profile_title"))

    if (ids.Length = 0) {
        AddFormGap(g, 8)
        AddFormBodyText(g, T("profile_none"))
        AddFormGap(g, 10)
        AddFormButton(g, TIcon("btn_create_profile"), OpenCreateProfile)
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_archives"), (*) => RenderScreen("archives"))
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    } else {
        AddFormGap(g, 6)
        AddFormBodyText(g, T("profile_select"))
        AddFormGap(g, 4)
        global PROFILE_LIST, PROFILE_IDS
        PROFILE_IDS := ids
        names := []
        for id in ids {
            name := IniRead(PROFILES_DIR "\" id "\profile.ini", "Profile", "display_name", id)
            names.Push(name)
        }
        PROFILE_LIST := g.Add("ListBox", "w" FORM_FIELD_W " h80 Background" CLR_PANEL " c" CLR_TEXT, names)
        if (names.Length > 0) {
            PROFILE_LIST.Choose(1)
            PROFILE_LIST.OnEvent("DoubleClick", ProfileContinue)
        }
        AddFormGap(g, 8)
        AddFormButton(g, TIcon("btn_continue"), ProfileContinue)
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_archive"), ProfileArchive)
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_create_profile"), OpenCreateProfile)
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_archives"), (*) => RenderScreen("archives"))
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    }

    ShowFormGui()
}

BuildArchives() {
    global ARCHIVE_LIST, ARCHIVE_FOLDER_NAMES, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    folderNames := GetArchiveFolderNames()
    g := NewFormGui()
    AddFormTitle(g, TIcon("archives_title"))
    WriteLog("archive_screen_opened")

    if (folderNames.Length = 0) {
        AddFormGap(g, 8)
        AddFormBodyText(g, T("archives_none"))
        AddFormGap(g, 10)
        AddFormNavBackQuit(g, (*) => RenderScreen("profile"))
    } else {
        AddFormGap(g, 6)
        AddFormBodyText(g, T("archives_select"))
        AddFormGap(g, 4)
        ARCHIVE_FOLDER_NAMES := folderNames
        displayLines := []
        for name in folderNames
            displayLines.Push(FormatArchiveListEntry(name))
        ARCHIVE_LIST := g.Add("ListBox", "w" FORM_FIELD_W " h100 Background" CLR_PANEL " c" CLR_TEXT, displayLines)
        AddFormGap(g, 8)
        AddFormButton(g, TIcon("btn_delete_archive"), ArchiveDeletePermanently)
        AddFormNavBackQuit(g, (*) => RenderScreen("profile"))
    }

    ShowFormGui()
}

ProfileArchive(*) {
    global PROFILE_LIST, PROFILE_IDS, CURRENT_PROFILE_ID
    idx := GetProfileListIndex()
    if (idx = 0) {
        MsgBox(T("msg_select_archive"), APP_TITLE, "Icon!")
        return
    }
    profileId := PROFILE_IDS[idx]
    if (CURRENT_PROFILE_ID != "" && profileId = CURRENT_PROFILE_ID) {
        MsgBox(T("msg_active_archive"), APP_TITLE, "Icon!")
        return
    }
    displayName := IniRead(PROFILES_DIR "\" profileId "\profile.ini", "Profile", "display_name", profileId)
    result := MsgBox(T("msg_archive_confirm", displayName), APP_TITLE, "YesNo Icon?")
    if (result != "Yes")
        return
    ArchiveProfile(profileId)
    RenderScreen("profile")
}

; Index ListBox profil (1-based) ; repli sur le seul profil si rien n'est sélectionné.
GetProfileListIndex() {
    global PROFILE_LIST, PROFILE_IDS
    idx := 0
    if IsObject(PROFILE_LIST)
        idx := PROFILE_LIST.Value
    if (idx = 0 && PROFILE_IDS.Length = 1)
        idx := 1
    return idx
}

ProfileContinue(*) {
    global PROFILE_LIST, PROFILE_IDS, PENDING_PROFILE_ID, CURRENT_LANG
    WriteLog("profile_continue_clicked", PROFILE_IDS.Length)
    idx := GetProfileListIndex()
    if (idx = 0) {
        WriteLog("profile_selection_empty", "continue")
        MsgBox(T("msg_select_profile"), APP_TITLE, "Icon!")
        return
    }
    if (idx < 1 || idx > PROFILE_IDS.Length) {
        WriteLog("profile_selection_invalid", idx)
        MsgBox(T("msg_select_profile"), APP_TITLE, "Icon!")
        return
    }
    profileId := PROFILE_IDS[idx]
    PENDING_PROFILE_ID := profileId
    CURRENT_LANG := GetProfileLanguage(profileId)
    WriteLog("profile_selected", profileId)
    RenderScreen("profile_login")
}

BuildProfileLogin() {
    global PENDING_PROFILE_ID, LOGIN_PASSWORD_INPUT, LOGIN_REMEMBER_ME, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    if (PENDING_PROFILE_ID = "") {
        RenderScreen("profile")
        return
    }
    displayName := IniRead(PROFILES_DIR "\" PENDING_PROFILE_ID "\profile.ini", "Profile", "display_name", PENDING_PROFILE_ID)
    g := NewFormGui()
    AddFormTitle(g, TIcon("login_title"))
    AddFormGap(g, 6)
    AddFormBodyText(g, T("start_profile", displayName))
    AddFormGap(g, 6)
    AddFormLabel(g, T("create_password"))
    LOGIN_PASSWORD_INPUT := g.Add("Edit", "w" FORM_FIELD_W " h22 Password Background" CLR_PANEL " c" CLR_TEXT, "")
    AddFormGap(g, 6)
    rememberDefault := IsRememberMeEnabled() && GetRememberedProfileId() = PENDING_PROFILE_ID
    LOGIN_REMEMBER_ME := g.Add("Checkbox", "w" FORM_FIELD_W " Checked" rememberDefault, T("login_remember_me"))
    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_continue"), ProfileLoginSubmit)
    AddFormNavBackQuit(g, (*) => RenderScreen("profile"))
    try LOGIN_PASSWORD_INPUT.Focus()
    ShowFormGui()
}

ProfileLoginSubmit(*) {
    global PENDING_PROFILE_ID, LOGIN_PASSWORD_INPUT, LOGIN_REMEMBER_ME
    if (PENDING_PROFILE_ID = "") {
        RenderScreen("profile")
        return
    }
    password := Trim(LOGIN_PASSWORD_INPUT.Value)
    if (password = "") {
        MsgBox(T("msg_empty_password"), APP_TITLE, "Icon!")
        return
    }
    if VerifyProfilePassword(PENDING_PROFILE_ID, password) {
        profileId := PENDING_PROFILE_ID
        remember := false
        try remember := LOGIN_REMEMBER_ME.Value
        SaveRememberMeSession(profileId, remember)
        PENDING_PROFILE_ID := ""
        RouteAfterProfileLogin(profileId)
        return
    }
    WriteLog("profile_login_failed", PENDING_PROFILE_ID)
    WriteProfileLog(PENDING_PROFILE_ID, "profile_login_failed")
    MsgBox(T("msg_wrong_password"), APP_TITLE, "Icon!")
}

BuildCreateProfile() {
    global DRAFT_NAME, DRAFT_LANG, DRAFT_MODE, DRAFT_GENDER
    global FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    g := NewFormGui()
    AddFormTitle(g, TIcon("create_title"))

    AddFormGap(g, 6)
    AddFormLabel(g, T("create_name"))
    global NAME_INPUT
    NAME_INPUT := g.Add("Edit", "w" FORM_FIELD_W " h22 Background" CLR_PANEL " c" CLR_TEXT, DRAFT_NAME)

    AddFormGap(g, 4)
    AddFormLabel(g, T("create_lang"))
    global LANG_CHOICE
    LANG_CHOICE := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, ["Français", "English"])
    LANG_CHOICE.Choose(DRAFT_LANG = "en" ? 2 : 1)
    LANG_CHOICE.OnEvent("Change", CreateLangChange)

    AddFormGap(g, 4)
    AddFormLabel(g, T("create_mode"))
    global MODE_CHOICE
    MODE_CHOICE := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, [T("mode_client"), T("mode_creator")])
    MODE_CHOICE.Choose(DRAFT_MODE = "creator" ? 2 : 1)
    MODE_CHOICE.OnEvent("Change", CreateModeChange)

    AddFormGap(g, 4)
    AddFormLabel(g, T("profile_gender_label"))
    global GENDER_CHOICE
    GENDER_CHOICE := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, ProfileGenderOptionLabels())
    GENDER_CHOICE.Choose(ProfileGenderChoiceIndex(DRAFT_GENDER))

    AddFormGap(g, 4)
    AddFormBodyText(g, T("profile_gender_note"))

    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_continue"), CreateProfileContinue)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_back"), BackFromCreate)

    ShowFormGui()
}

BuildCreateProfileSecurity() {
    global DRAFT_MODE, DRAFT_PASSWORD, DRAFT_PASSWORD_CONFIRM
    global FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    g := NewFormGui()
    AddFormTitle(g, TIcon("create_security_title"))

    AddFormGap(g, 6)
    if (DRAFT_MODE = "creator") {
        AddFormLabel(g, T("create_code"))
        global CREATOR_CODE_INPUT
        CREATOR_CODE_INPUT := g.Add("Edit", "w" FORM_FIELD_W " h22 Password Background" CLR_PANEL " c" CLR_TEXT, "")
        AddFormGap(g, 4)
    }

    AddFormLabel(g, T("create_password"))
    global PASSWORD_INPUT
    PASSWORD_INPUT := g.Add("Edit", "w" FORM_FIELD_W " h22 Password Background" CLR_PANEL " c" CLR_TEXT, DRAFT_PASSWORD)

    AddFormGap(g, 4)
    AddFormLabel(g, T("create_password_confirm"))
    global PASSWORD_CONFIRM_INPUT
    PASSWORD_CONFIRM_INPUT := g.Add("Edit", "w" FORM_FIELD_W " h22 Password Background" CLR_PANEL " c" CLR_TEXT, DRAFT_PASSWORD_CONFIRM)

    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_create"), CreateProfileSubmit)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_back"), BackFromCreateSecurity)

    ShowFormGui()
}

CreateProfileSubmit(*) {
    global DRAFT_NAME, DRAFT_LANG, DRAFT_MODE, DRAFT_GENDER
    global CREATOR_CODE_INPUT, CREATOR_CODE, PASSWORD_INPUT, PASSWORD_CONFIRM_INPUT
    name := Trim(DRAFT_NAME)
    if (name = "") {
        MsgBox(T("msg_empty_name"), APP_TITLE, "Icon!")
        RenderScreen("create")
        return
    }
    password := Trim(PASSWORD_INPUT.Value)
    confirm := Trim(PASSWORD_CONFIRM_INPUT.Value)
    if (password = "") {
        MsgBox(T("msg_empty_password"), APP_TITLE, "Icon!")
        return
    }
    if (password !== confirm) {
        MsgBox(T("msg_password_mismatch"), APP_TITLE, "Icon!")
        return
    }
    lang := DRAFT_LANG
    mode := DRAFT_MODE
    if (mode = "creator") {
        if (Trim(CREATOR_CODE_INPUT.Value) !== CREATOR_CODE) {
            MsgBox(T("msg_wrong_code"), APP_TITLE, "Icon!")
            return
        }
    }
    profileId := CreateProfile(name, lang, mode, DRAFT_GENDER)
    if !SetProfilePassword(profileId, password) {
        MsgBox(T("msg_password_hash_error"), APP_TITLE, "Icon!")
        return
    }
    if (mode = "creator")
        RenderScreen("creator_home")
    else
        RenderScreen("privacy")
}

BuildPrivacy() {
    g := NewFormGui()
    AddFormTitle(g, TIcon("privacy_title"))
    AddFormGap(g, 6)
    AddFormBodyText(g, T("privacy_body"))
    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_accept"), PrivacyAccept)
    AddFormNavBackQuit(g, (*) => RenderScreen("profile"))
    ShowFormGui()
}

PrivacyAccept(*) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        RenderScreen("profile")
        return
    }
    IniWrite("yes", PROFILES_DIR "\" CURRENT_PROFILE_ID "\consent.ini", "Consent", "privacy_accepted")
    WriteLog("privacy_accepted", CURRENT_PROFILE_ID)
    WriteProfileLog(CURRENT_PROFILE_ID, "privacy_accepted")
    RenderScreen("start_here")
}

BuildStartHere() {
    global CURRENT_DISPLAY_NAME
    g := NewFormGui()
    AddFormTitle(g, TIcon("start_title"))
    AddFormGap(g, 6)
    AddFormBodyText(g, T("start_welcome"))
    AddFormGap(g, 4)
    AddFormBodyText(g, T("start_profile", CURRENT_DISPLAY_NAME))
    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_launch"), StartHereLaunch)
    AddFormNavBackQuit(g, (*) => RenderScreen("profile"))
    ShowFormGui()
}

StartHereLaunch(*) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        RenderScreen("profile")
        return
    }
    IniWrite("yes", PROFILES_DIR "\" CURRENT_PROFILE_ID "\state.ini", "State", "onboarding_completed")
    WriteLog("onboarding_completed", CURRENT_PROFILE_ID)
    WriteProfileLog(CURRENT_PROFILE_ID, "onboarding_completed")
    RenderScreen("home")
}

BuildKitPrima() {
    global CURRENT_PROFILE_ID, KIT_AI_DDL, KIT_STATUS_TEXT, KIT_LAST_CHECKS, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    if (CURRENT_PROFILE_ID = "")
        return
    g := NewFormGui()
    AddFormTitle(g, TIcon("kit_title"))
    AddFormGap(g, 4)
    AddFormBodyText(g, T("kit_body"))
    AddFormGap(g, 6)
    AddFormLabel(g, T("kit_ai_label"))
    KIT_AI_DDL := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, GetKitAiLabels())
    KIT_AI_DDL.Choose(KitAiIndexForValue(LoadKitSelectedAi(CURRENT_PROFILE_ID)))
    AddFormGap(g, 6)
    AddFormLabel(g, T("kit_checks_label"))
    KIT_LAST_CHECKS := RunKitChecks()
    KIT_STATUS_TEXT := g.Add("Edit", "w" FORM_FIELD_W " h92 ReadOnly Multi Background" CLR_PANEL " c" CLR_TEXT, FormatKitStatusText(KIT_LAST_CHECKS))
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("btn_kit_verify"), KitVerify)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_kit_create"), KitCreateMissing)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_save"), KitSave)
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("btn_back"), KitBack)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    WriteLog("kit_opened", CURRENT_PROFILE_ID)
    ShowFormGui()
}

BuildHome() {
    global CURRENT_DISPLAY_NAME, APP_VERSION, CURRENT_PROFILE_ID
    g := NewFormGui()
    AddFormTitle(g, TIcon("home_title"))
    AddFormGap(g, 4)
    AddFormBodyText(g, T("home_active", CURRENT_DISPLAY_NAME))
    AddFormBodyText(g, T("home_version", APP_VERSION))
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("base_kit_prima"), OpenKitFromHome)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("base_prima_soul"), HomeOpenPrimaSoulIntro)
    AddFormGap(g, 4)
    AddFormButton(g, T("btn_proof"), ShowModuleLater)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_review"), HomeOpenReview)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_settings"), HomeOpenSettings)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_logout"), LogoutProfile)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_change_profile"), HomeChangeProfile)
    WriteLog("app_home_opened", CURRENT_PROFILE_ID)
    ShowFormGui()
}

BuildCreatorHome() {
    global CURRENT_PROFILE_ID
    g := NewFormGui()
    AddFormTitle(g, T("creator_home_title"))
    AddFormGap(g, 4)
    AddFormBodyText(g, T("creator_home_body"))
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("base_kit_prima"), OpenKitFromCreator)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("base_prima_soul"), CreatorOpenSoul)
    AddFormGap(g, 4)
    AddFormButton(g, T("btn_creator_personalization"), ShowCreatorModuleLater)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_creator_goal"), CreatorOpenGoals)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_review"), CreatorOpenReview)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_change_profile"), HomeChangeProfile)
    WriteLog("creator_home_opened", CURRENT_PROFILE_ID)
    ShowFormGui()
}

BuildCreatorSoul() {
    global PRIMA_SOUL_BACK
    PRIMA_SOUL_BACK := "creator_home"
    RenderScreen("prima_soul_intro")
}

GoalsDomainChange(*) {
    global GOALS_DOMAIN_DDL, GOALS_DOMAIN_IDX, GOAL_SHORT, GOAL_MEDIUM, GOAL_LONG, CURRENT_PROFILE_ID
    prevCode := GetDomainCodes()[GOALS_DOMAIN_IDX]
    SaveDomainGoals(CURRENT_PROFILE_ID, prevCode, GOAL_SHORT.Value, GOAL_MEDIUM.Value, GOAL_LONG.Value)
    GOALS_DOMAIN_IDX := GOALS_DOMAIN_DDL.Value
    RenderScreen("onboarding_goals")
}

OnboardingDomainSave(*) {
    global CURRENT_PROFILE_ID, GOALS_DOMAIN_DDL, GOAL_SHORT, GOAL_MEDIUM, GOAL_LONG, GOALS_DOMAIN_IDX
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        return
    }
    code := GetDomainCodes()[GOALS_DOMAIN_IDX]
    data := LoadDomainGoals(CURRENT_PROFILE_ID, code)
    wasConfigured := DomainHasGoals(data)
    newData := { short: GOAL_SHORT.Value, medium: GOAL_MEDIUM.Value, long: GOAL_LONG.Value }
    if (!wasConfigured && DomainHasGoals(newData) && CountConfiguredDomains(CURRENT_PROFILE_ID) >= 5) {
        MsgBox(T("msg_goals_max_domains"), APP_TITLE, "Icon!")
        return
    }
    SaveDomainGoals(CURRENT_PROFILE_ID, code, GOAL_SHORT.Value, GOAL_MEDIUM.Value, GOAL_LONG.Value)
}

ShowModuleLater(*) {
    MsgBox(T("msg_module_later"), APP_TITLE, "Icon!")
}

; ── Hub PRIMA Soul — grille 2×2 (position absolue, tient dans 1050×760) ────────
SoulHubGridX(col) {
    global MARGIN_X, CONTENT_W, SOUL_HUB_CARD_W, SOUL_HUB_GAP
    gridW := 2 * SOUL_HUB_CARD_W + SOUL_HUB_GAP
    startX := MARGIN_X + (CONTENT_W - gridW) // 2
    return startX + (col - 1) * (SOUL_HUB_CARD_W + SOUL_HUB_GAP)
}

SoulHubGridY(row) {
    global SOUL_HUB_GRID_Y, SOUL_HUB_CARD_H, SOUL_HUB_GAP
    return SOUL_HUB_GRID_Y + (row - 1) * (SOUL_HUB_CARD_H + SOUL_HUB_GAP)
}

AddSoulHubHeader(g, title, intro) {
    global MARGIN_X, CONTENT_W, SOUL_HUB_TITLE_Y, SOUL_HUB_INTRO_Y, CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT
    g.SetFont("s22 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" SOUL_HUB_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG, title)
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" SOUL_HUB_INTRO_Y " w" CONTENT_W " h44 Center +0x2000 Background" CLR_BG, intro)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

; Carte hub : titre (icône) + statut court, clic sur toute la carte.
AddSoulHubCard(g, col, row, title, status, action, enabled := true) {
    global SOUL_HUB_CARD_W, SOUL_HUB_CARD_H
    x := SoulHubGridX(col)
    y := SoulHubGridY(row)
    if (Trim(title) = "")
        title := "—"
    label := (Trim(status) != "") ? title "`n" status : title
    btn := g.Add("Button", "x" x " y" y " w" SOUL_HUB_CARD_W " h" SOUL_HUB_CARD_H " +0x2000 Center", label)
    btn.SetFont("s11")
    if (action != "")
        btn.OnEvent("Click", action)
    if (!enabled)
        btn.Enabled := false
    return btn
}

; Bouton pleine largeur hub (2 colonnes) — ex. reset cycle.
AddSoulHubWideButton(g, row, label, action) {
    global SOUL_HUB_CARD_W, SOUL_HUB_GAP, SOUL_HUB_CARD_H
    x := SoulHubGridX(1)
    y := SoulHubGridY(row)
    w := 2 * SOUL_HUB_CARD_W + SOUL_HUB_GAP
    if (Trim(label) = "")
        label := "—"
    btn := g.Add("Button", "x" x " y" y " w" w " h" SOUL_HUB_CARD_H " Center", label)
    btn.SetFont("s11")
    btn.OnEvent("Click", action)
    return btn
}

; Carte hub à y absolu (hub cycle terminé).
AddSoulHubCardAt(g, col, y, title, status, action) {
    global SOUL_HUB_CARD_W, SOUL_HUB_CARD_H
    x := SoulHubGridX(col)
    if (Trim(title) = "")
        title := "—"
    label := (Trim(status) != "") ? title "`n" status : title
    btn := g.Add("Button", "x" x " y" y " w" SOUL_HUB_CARD_W " h" SOUL_HUB_CARD_H " +0x2000 Center", label)
    btn.SetFont("s11")
    if (action != "")
        btn.OnEvent("Click", action)
    return btn
}

; Bouton pleine largeur à y absolu.
AddSoulHubWideButtonAt(g, y, label, action) {
    global SOUL_HUB_CARD_W, SOUL_HUB_GAP, SOUL_HUB_CARD_H
    x := SoulHubGridX(1)
    w := 2 * SOUL_HUB_CARD_W + SOUL_HUB_GAP
    if (Trim(label) = "")
        label := "—"
    btn := g.Add("Button", "x" x " y" y " w" w " h" SOUL_HUB_CARD_H " Center", label)
    btn.SetFont("s11")
    btn.OnEvent("Click", action)
    return btn
}

; En-tête écran lancement test (positions fixes).
AddLaunchScreenHeader(g, title, introLine1, introLine2 := "") {
    global MARGIN_X, CONTENT_W, LAUNCH_TITLE_Y, LAUNCH_INTRO_Y, LAUNCH_INTRO_H
    global CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT
    g.SetFont("s20 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" LAUNCH_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG, title)
    intro := introLine1
    if (introLine2 != "")
        intro .= "`n" introLine2
    g.SetFont("s11 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" LAUNCH_INTRO_Y " w" CONTENT_W " h" LAUNCH_INTRO_H " Center +0x2000 Background" CLR_BG, intro)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

; Action principale écran lancement (Débuter / Test terminé).
AddLaunchMainAction(g, label, action, enabled := true) {
    global MARGIN_X, CONTENT_W, LAUNCH_ACTION_Y, LAUNCH_ACTION_W, LAUNCH_ACTION_H
    x := MARGIN_X + (CONTENT_W - LAUNCH_ACTION_W) // 2
    if (Trim(label) = "")
        label := "—"
    btn := g.Add("Button", "x" x " y" LAUNCH_ACTION_Y " w" LAUNCH_ACTION_W " h" LAUNCH_ACTION_H " Center", label)
    btn.SetFont("s12")
    if (action != "")
        btn.OnEvent("Click", action)
    if (!enabled)
        btn.Enabled := false
    else if (action != "")
        SetPrimaryEnterAction(action)
    return btn
}

; Pied lancement test : Retour | Quitter (fixe y=650).
AddLaunchFooter(g, backAction) {
    global MARGIN_X, CONTENT_W, LAUNCH_NAV_Y, TEST_NAV_BTN_W, TEST_NAV_GAP, BUTTON_H
    totalW := 2 * TEST_NAV_BTN_W + TEST_NAV_GAP
    startX := MARGIN_X + (CONTENT_W - totalW) // 2
    btnBack := g.Add("Button", "x" startX " y" LAUNCH_NAV_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_back"))
    btnBack.OnEvent("Click", backAction)
    xQuit := startX + TEST_NAV_BTN_W + TEST_NAV_GAP
    btnQuit := g.Add("Button", "x" xQuit " y" LAUNCH_NAV_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_quit"))
    btnQuit.OnEvent("Click", (*) => ConfirmExit("quit"))
}

ShowTestAlreadyDone(*) {
    MsgBox(SoulTestDoneMessage(), APP_TITLE, "Iconi")
}

ShowReadingNotReady(*) {
    MsgBox(T("soul_reading_wait"), APP_TITLE, "Iconi")
}

; Message clic test terminé — adapté si le cycle est déjà complet.
SoulTestDoneMessage() {
    global CURRENT_PROFILE_ID
    msg := T("msg_test_locked_1")
    if (CURRENT_PROFILE_ID != "" && IsPrimaSoulCycleComplete(CURRENT_PROFILE_ID))
        return msg "`n`n" T("msg_test_done_use_reading")
    return msg "`n`n" T("msg_test_locked_2")
}

; Pied hub cycle terminé : Retour · Quitter (2 boutons).
AddSoulHubFooterBackQuit(g, backAction) {
    global SOUL_HUB_FOOTER_Y, TEST_NAV_BTN_W, TEST_NAV_GAP, BUTTON_H, MARGIN_X, CONTENT_W
    totalW := 2 * TEST_NAV_BTN_W + TEST_NAV_GAP
    startX := MARGIN_X + (CONTENT_W - totalW) // 2
    btnBack := g.Add("Button", "x" startX " y" SOUL_HUB_FOOTER_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_back"))
    btnBack.OnEvent("Click", backAction)
    xQuit := startX + TEST_NAV_BTN_W + TEST_NAV_GAP
    btnQuit := g.Add("Button", "x" xQuit " y" SOUL_HUB_FOOTER_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_quit"))
    btnQuit.OnEvent("Click", (*) => ConfirmExit("quit"))
}

; Pied de page compact : Retour · Réglages · Quitter (3 boutons alignés).
AddSoulHubFooter(g, backAction) {
    global SOUL_HUB_FOOTER_Y, SOUL_HUB_FOOTER_BTN_W, SOUL_HUB_GAP, BUTTON_H, MARGIN_X, CONTENT_W
    gridW := 3 * SOUL_HUB_FOOTER_BTN_W + 2 * SOUL_HUB_GAP
    startX := MARGIN_X + (CONTENT_W - gridW) // 2
    xBack := startX
    xSet := startX + SOUL_HUB_FOOTER_BTN_W + SOUL_HUB_GAP
    xQuit := startX + 2 * (SOUL_HUB_FOOTER_BTN_W + SOUL_HUB_GAP)
    btnBack := g.Add("Button", "x" xBack " y" SOUL_HUB_FOOTER_Y " w" SOUL_HUB_FOOTER_BTN_W " h" BUTTON_H " Center", TIcon("btn_back"))
    btnBack.OnEvent("Click", backAction)
    btnSet := g.Add("Button", "x" xSet " y" SOUL_HUB_FOOTER_Y " w" SOUL_HUB_FOOTER_BTN_W " h" BUTTON_H " Center", TIcon("btn_soul_settings"))
    btnSet.OnEvent("Click", (*) => RenderScreen("prima_soul_settings"))
    btnQuit := g.Add("Button", "x" xQuit " y" SOUL_HUB_FOOTER_Y " w" SOUL_HUB_FOOTER_BTN_W " h" BUTTON_H " Center", TIcon("btn_quit"))
    btnQuit.OnEvent("Click", (*) => ConfirmExit("quit"))
}

; ── Hub lecture PRIMA — grille 2×4 (position absolue, tient dans 1050×760) ─────
ReadingHubGridX(col) {
    global MARGIN_X, CONTENT_W, READING_HUB_BTN_W, READING_HUB_GAP_X
    gridW := 2 * READING_HUB_BTN_W + READING_HUB_GAP_X
    startX := MARGIN_X + (CONTENT_W - gridW) // 2
    return startX + (col - 1) * (READING_HUB_BTN_W + READING_HUB_GAP_X)
}

ReadingHubGridY(row) {
    global READING_HUB_GRID_Y, READING_HUB_BTN_H, READING_HUB_GAP_Y
    return READING_HUB_GRID_Y + (row - 1) * (READING_HUB_BTN_H + READING_HUB_GAP_Y)
}

AddReadingHubHeader(g, title, introLine1, introLine2 := "") {
    global MARGIN_X, CONTENT_W, READING_HUB_TITLE_Y, READING_HUB_INTRO_Y, READING_HUB_INTRO_H
    global READING_HUB_BTN_W, READING_HUB_GAP_X, READING_HUB_GRID_Y
    global CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT, CLR_PANEL
    g.SetFont("s20 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" READING_HUB_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG, title)
    intro := introLine1
    if (introLine2 != "")
        intro .= "`n" introLine2
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" READING_HUB_INTRO_Y " w" CONTENT_W " h" READING_HUB_INTRO_H " Center +0x2000 Background" CLR_BG, intro)
    ax := ReadingHubGridX(1)
    gridW := 2 * READING_HUB_BTN_W + READING_HUB_GAP_X
    g.Add("Text", "x" ax " y" (READING_HUB_GRID_Y - 10) " w" gridW " h1 Background" CLR_PANEL, "")
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddReadingHubButton(g, col, row, label, action) {
    global READING_HUB_BTN_W, READING_HUB_BTN_H
    x := ReadingHubGridX(col)
    y := ReadingHubGridY(row)
    btn := g.Add("Button", "x" x " y" y " w" READING_HUB_BTN_W " h" READING_HUB_BTN_H " Center", label)
    btn.OnEvent("Click", action)
    return btn
}

; Écran fin de test simple — pas de résultat détaillé (lecture via hub global).
BuildPrimaTestDoneScreen(titleKey) {
    global MARGIN_X, CONTENT_W, BUTTON_H, CLR_BG, CLR_ACCENT, CLR_TEXT, CLR_SUBTEXT, CLR_PANEL
    g := NewGui()
    cardW := 680
    cardX := MARGIN_X + (CONTENT_W - cardW) // 2
    cardY := 130
    g.Add("Text", "x" cardX " y" cardY " w" cardW " h200 Background" CLR_PANEL, "")
    g.SetFont("s20 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" cardX " y" (cardY + 24) " w" cardW " h36 Center BackgroundTrans", TIcon(titleKey))
    g.SetFont("s13 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "x" cardX " y" (cardY + 68) " w" cardW " h28 Center BackgroundTrans", T("vda_done_1"))
    g.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "x" (cardX + 36) " y" (cardY + 100) " w" (cardW - 72) " h48 Center +0x2000 BackgroundTrans", T("vda_done_reading"))
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" cardX " y" (cardY + 156) " w" cardW " h22 Center BackgroundTrans", T("prima_soul_guide"))
    btnW := 320
    btnX := MARGIN_X + (CONTENT_W - btnW) // 2
    btnY := cardY + 230
    btnBack := g.Add("Button", "x" btnX " y" btnY " w" btnW " h" BUTTON_H " Center", TIcon("btn_back_soul"))
    btnBack.OnEvent("Click", (*) => RenderScreen("prima_soul_intro"))
    btnQuit := g.Add("Button", "x" btnX " y" (btnY + BUTTON_H + 10) " w" btnW " h" BUTTON_H " Center", TIcon("btn_quit"))
    btnQuit.OnEvent("Click", (*) => ConfirmExit("quit"))
    ShowScreen()
}

ShowCreatorModuleLater(*) {
    MsgBox(T("msg_creator_module_later"), APP_TITLE, "Icon!")
}

; ── PRIMA Soul — hub (1050×760) ───────────────────────────────────────────────
BuildPrimaSoulIntro() {
    global CURRENT_PROFILE_ID
    cycleComplete := (CURRENT_PROFILE_ID != "" && CanGeneratePrimaReading(CURRENT_PROFILE_ID))
    WriteLog("soul_hub_mode", CURRENT_PROFILE_ID " | " (cycleComplete ? "complete" : "in_progress"))
    if (cycleComplete)
        BuildPrimaSoulIntroComplete()
    else
        BuildPrimaSoulIntroInProgress()
}

; Hub cycle terminé : actions de suite (lecture, univers, reset).
BuildPrimaSoulIntroComplete() {
    global CURRENT_PROFILE_ID, MARGIN_X, CONTENT_W, CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT
    global SOUL_HUB_COMPLETE_GRID_Y, SOUL_HUB_CARD_H, SOUL_HUB_GAP, SOUL_HUB_TESTS_STATUS_Y
    g := NewGui()
    g.SetFont("s22 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" SOUL_HUB_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG
        , TIcon("prima_soul_complete_title"))
    g.SetFont("s12 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y88 w" CONTENT_W " h28 Center Background" CLR_BG, T("soul_cycle_complete_status"))
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y118 w" CONTENT_W " h40 Center +0x2000 Background" CLR_BG, T("soul_cycle_complete_hint"))
    yActions := SOUL_HUB_COMPLETE_GRID_Y
    yReset := yActions + SOUL_HUB_CARD_H + SOUL_HUB_GAP
    AddSoulHubCardAt(g, 1, yActions, TIcon("btn_generate_reading"), T("soul_status_ready"), OpenSoulReadingHub)
    if (CURRENT_PROFILE_ID != "" && IsPrimaArchitectureLocked(CURRENT_PROFILE_ID))
        AddSoulHubCardAt(g, 2, yActions, TIcon("btn_view_identity"), "", OpenPrimaIdentityResult)
    else
        AddSoulHubCardAt(g, 2, yActions, TIcon("btn_choose_identity"), "", OpenPrimaUniverseChoice)
    AddSoulHubWideButtonAt(g, yReset, TIcon("btn_redo_tests"), SoulRedoTestsClicked)
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    ty := SOUL_HUB_TESTS_STATUS_Y
    g.Add("Text", "x" MARGIN_X " y" ty " w" CONTENT_W " h22 Center Background" CLR_BG, TIcon("btn_soul_test_done"))
    g.Add("Text", "x" MARGIN_X " y" (ty + 24) " w" CONTENT_W " h22 Center Background" CLR_BG, TIcon("btn_vda_test_done"))
    g.Add("Text", "x" MARGIN_X " y" (ty + 48) " w" CONTENT_W " h22 Center Background" CLR_BG, TIcon("btn_shadow_test_done"))
    AddSoulHubFooterBackQuit(g, PrimaSoulBackToHome)
    WriteLog("soul_global_reading_available", CURRENT_PROFILE_ID)
    ShowScreen()
}

; Hub en cours : grille 2×2 tests + reprise + reset partiel.
BuildPrimaSoulIntroInProgress() {
    global CURRENT_PROFILE_ID, MARGIN_X, CONTENT_W, SOUL_HUB_INTRO_Y, SOUL_HUB_GRID_Y
    global CLR_BG, CLR_ACCENT, CLR_SUBTEXT
    g := NewGui()
    AddSoulHubHeader(g, TIcon("prima_soul_intro_title"), T("prima_soul_guide"))
    resumeAction := (CURRENT_PROFILE_ID != "") ? GetNextResumeAction(CURRENT_PROFILE_ID) : "start_soul"
    if (resumeAction = "resume_soul" || resumeAction = "resume_vda" || resumeAction = "resume_shadow") {
        resumeLabel := T("btn_resume_test")
        switch resumeAction {
            case "resume_soul": resumeLabel := T("btn_resume_soul")
            case "resume_vda": resumeLabel := T("btn_resume_vda")
            case "resume_shadow": resumeLabel := T("btn_resume_shadow")
        }
        g.SetFont("s11 c" CLR_ACCENT, "Segoe UI")
        g.Add("Text", "x" MARGIN_X " y" (SOUL_HUB_INTRO_Y + 52) " w" CONTENT_W " h22 Center Background" CLR_BG, T("soul_resume_banner"))
        btnResume := g.Add("Button", "x" (MARGIN_X + (CONTENT_W - 420) // 2) " y" (SOUL_HUB_INTRO_Y + 78) " w420 h38 Center"
            , resumeLabel)
        btnResume.SetFont("s11 Bold")
        btnResume.OnEvent("Click", ExecuteTestResumeAction.Bind(resumeAction))
    }
    soulProg := (CURRENT_PROFILE_ID != "") ? GetTestProgress(CURRENT_PROFILE_ID, "soul") : { status: "not_started" }
    vdaProg := (CURRENT_PROFILE_ID != "") ? GetTestProgress(CURRENT_PROFILE_ID, "vda") : { status: "not_started" }
    shadowProg := (CURRENT_PROFILE_ID != "") ? GetTestProgress(CURRENT_PROFILE_ID, "shadow") : { status: "not_started" }
    anyDone := soulProg.status = "completed" || vdaProg.status = "completed" || shadowProg.status = "completed"
    if (soulProg.status = "completed") {
        AddSoulHubCard(g, 1, 1, TIcon("btn_soul_test_done"), T("soul_status_done"), ShowTestAlreadyDone)
    } else if (soulProg.status = "in_progress") {
        AddSoulHubCard(g, 1, 1, PrimaLabelWithIcon("soul_test_soul", "PRIMA Soul")
            , T("soul_status_in_progress"), ResumeSoulTestFromHub)
    } else {
        AddSoulHubCard(g, 1, 1, PrimaLabelWithIcon("soul_test_soul", "PRIMA Soul")
            , T("soul_status_available"), OpenSoulTestFromHub)
    }
    if (vdaProg.status = "completed") {
        AddSoulHubCard(g, 2, 1, TIcon("btn_vda_test_done"), T("soul_status_done"), ShowTestAlreadyDone)
    } else if (vdaProg.status = "in_progress") {
        AddSoulHubCard(g, 2, 1, PrimaLabelWithIcon("soul_test_vda", "PRIMA VDA")
            , T("soul_status_in_progress"), ResumeVdaTestFromHub)
    } else {
        AddSoulHubCard(g, 2, 1, PrimaLabelWithIcon("soul_test_vda", "PRIMA VDA")
            , T("soul_status_available"), OpenVdaFromSoulHub)
    }
    if (shadowProg.status = "completed") {
        AddSoulHubCard(g, 1, 2, TIcon("btn_shadow_test_done"), T("soul_status_done"), ShowTestAlreadyDone)
    } else if (shadowProg.status = "in_progress") {
        AddSoulHubCard(g, 1, 2, PrimaLabelWithIcon("soul_test_shadow", "PRIMA Shadow")
            , T("soul_status_in_progress"), ResumeShadowTestFromHub)
    } else {
        AddSoulHubCard(g, 1, 2, PrimaLabelWithIcon("soul_test_shadow", "PRIMA Shadow")
            , T("soul_status_available"), (*) => RenderScreen("prima_soul_shadow"))
    }
    AddSoulHubCard(g, 2, 2, TIcon("btn_generate_reading"), T("soul_reading_wait"), ShowReadingNotReady)
    if (anyDone)
        AddSoulHubWideButton(g, 3, TIcon("btn_redo_tests"), SoulRedoTestsClicked)
    AddSoulHubFooter(g, PrimaSoulBackToHome)
    ShowScreen()
}

; ── Lancement des tests ───────────────────────────────────────────────────────
; Clic sur un test verrouillé : message sobre, pas de relance.
ShowSoulTestLocked(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_test_click_locked", CURRENT_PROFILE_ID)
    MsgBox(SoulTestDoneMessage(), APP_TITLE, "Icon!")
}

; PRIMA Soul Test = test 15 situations (banque prima_soul).
; Verrou technique : aucun lancement, aucune nouvelle session, aucune écriture
; de soul_state.ini / soul_results.ini si le test est verrouillé.
StartSoulTestRun(*) {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (!CanStartSoulTest("prima_soul")) {
        WriteLog("soul_test_start_blocked", CURRENT_PROFILE_ID " | prima_soul")
        ShowSoulTestLocked()
        return
    }
    session := BuildSoulQuestionRun("prima_soul", 15)
    if (session = "") {
        MsgBox(T("msg_run_preparing"), APP_TITLE, "Icon!")
        return
    }
    SOUL_SESSION := session
    SOUL_SESSION.rankings := []
    WriteLog("soul_run_started", "prima_soul | 15")
    WriteLog("soul_answers_shuffled", "prima_soul | " session.questions.Length)
    SaveSoulSessionState()
    RenderScreen("prima_soul_question")
}

; Clic sur un test VDA verrouillé.
ShowVdaTestLocked(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_test_click_locked", CURRENT_PROFILE_ID " | prima_vda")
    MsgBox(SoulTestDoneMessage(), APP_TITLE, "Icon!")
}

; PRIMA VDA Test : lance le test de classement (20 questions).
StartSoulVdaRun(*) {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (!CanStartSoulTest("prima_vda")) {
        WriteLog("soul_test_start_blocked", CURRENT_PROFILE_ID " | prima_vda")
        ShowVdaTestLocked()
        return
    }
    session := BuildVdaQuestionRun(20)
    if (session = "") {
        MsgBox(T("msg_run_preparing"), APP_TITLE, "Icon!")
        return
    }
    SOUL_SESSION := session
    WriteLog("vda_test_started", "prima_vda | 20")
    SaveVdaSessionState()
    RenderScreen("prima_vda_rank")
}

; ── PRIMA VDA — classement visible simple (6 réponses) ───────────────────────
global VDARANK_PICKS := []
global VDA_UI_BTNS := []
global VDA_UI_TEXTS := []
global VDA_UI_PICKS := []
global VDA_UI_ANSWER_IDS := []
; Alias QA / compat
global VDA_VISIBLE_BTNS := []
global VDA_VISIBLE_TEXTS := []
global VDA_VISIBLE_PICKS := []
global VDARANK_ANSWER_BTNS := []

AnswerButtonArrayLength(btns) {
    if !IsObject(btns) || !(btns is Array)
        return 0
    return btns.Length
}

VdaUiSyncAliases() {
    global VDA_UI_BTNS, VDA_UI_TEXTS, VDA_UI_PICKS, VDA_VISIBLE_BTNS, VDA_VISIBLE_TEXTS, VDA_VISIBLE_PICKS, VDARANK_ANSWER_BTNS
    VDA_VISIBLE_BTNS := VDA_UI_BTNS
    VDA_VISIBLE_TEXTS := VDA_UI_TEXTS
    VDA_VISIBLE_PICKS := VDA_UI_PICKS
    VDARANK_ANSWER_BTNS := VDA_UI_BTNS
}

BindVdaButton(btn, idx, answerId := "") {
    btn.rankIdx := idx
    if (answerId != "")
        btn.answerId := answerId
    btn.OnEvent("Click", VdaUiClickEvent)
    SafeTrace("BIND_BTN test=vda idx=" idx " answer_id=" answerId " hwnd=" btn.Hwnd)
}

; Handler unique — idx lu depuis le contrôle cliqué (pas de closure Bind).
VdaUiClickEvent(ctrl, *) {
    idx := 0
    if IsObject(ctrl) && ctrl.HasProp("rankIdx")
        idx := Integer(ctrl.rankIdx)
    SafeTrace("CLICK_HANDLER_ENTER test=vda idx=" idx " ctrl_ok=" (IsObject(ctrl) ? "yes" : "no") " hwnd=" (IsObject(ctrl) ? ctrl.Hwnd : 0))
    VdaButtonClicked(idx, ctrl)
}

VdaButtonClicked(idx, ctrl := "", *) {
    global VDA_UI_TEXTS, VDA_UI_PICKS, VDA_UI_BTNS, VDA_UI_ANSWER_IDS, CLR_ACCENT
    idx := Integer(idx)
    SafeTrace("CLICK_HANDLER_ENTER test=vda idx=" idx " ctrl_ok=" (IsObject(ctrl) ? "yes" : "no") " via=direct hwnd=" (IsObject(ctrl) ? ctrl.Hwnd : 0))
    if (idx < 1 || idx > VDA_UI_TEXTS.Length) {
        SafeTrace("CLICK_ABORT idx_out_of_range idx=" idx " texts_len=" VDA_UI_TEXTS.Length)
        return
    }
    q := GetCurrentQuestion("prima_vda")
    if !IsObject(q) {
        SafeTrace("CLICK_ABORT question_invalid path=prima_vda idx=" idx)
        return
    }
    SafeTrace("QUESTION_OK test=vda qid=" q.id " idx=" idx)
    answerId := (idx <= VDA_UI_ANSWER_IDS.Length) ? VDA_UI_ANSWER_IDS[idx] : q.answers[idx].id
    answerText := VDA_UI_TEXTS[idx]
    SafeTrace("ANSWER_OK idx=" idx " answer_id=" answerId " text=" SubStr(answerText, 1, 60))
    for _, pickedIdx in VDA_UI_PICKS {
        if (pickedIdx = idx) {
            SafeTrace("CLICK_ABORT already_picked idx=" idx)
            return
        }
    }
    if (VDA_UI_PICKS.Length >= VDA_UI_TEXTS.Length) {
        SafeTrace("CLICK_ABORT picks_full count=" VDA_UI_PICKS.Length)
        return
    }
    VDA_UI_PICKS.Push(idx)
    rank := VDA_UI_PICKS.Length
    SafeTrace("PICK_ADDED picks_count=" VDA_UI_PICKS.Length " rank=" rank)
    btn := ""
    if (idx >= 1 && idx <= VDA_UI_BTNS.Length)
        btn := VDA_UI_BTNS[idx]
    if !IsObject(btn) && IsObject(ctrl)
        btn := ctrl
    if IsObject(btn) {
        newText := PrimaRankPrefix(rank) answerText
        btn.Text := newText
        btn.SetFont("s11 Bold c" CLR_ACCENT, "Segoe UI")
        SafeTrace("BUTTON_TEXT_SET idx=" idx " hwnd=" btn.Hwnd " text=" newText)
        try {
            visibleAfter := btn.Text
            SafeTrace("REFRESH_DONE idx=" idx " visible_text=" visibleAfter)
        } catch {
            SafeTrace("REFRESH_DONE idx=" idx " visible_text=<read_err>")
        }
    } else {
        SafeTrace("BUTTON_TEXT_SET idx=" idx " btn_missing=yes")
    }
    VdaUiSyncAliases()
    SyncVdaVisiblePicksToRanking()
}

SyncVdaVisiblePicksToRanking() {
    global VDA_UI_PICKS, VDARANK_PICKS
    q := GetCurrentQuestion("prima_vda")
    VDARANK_PICKS := []
    if !IsObject(q)
        return
    for _, idx in VDA_UI_PICKS {
        if (idx >= 1 && idx <= q.answers.Length)
            VDARANK_PICKS.Push(q.answers[idx].id)
    }
}

VdaRankAnswerClick(idx, ctrl := "", *) {
    global VDA_UI_BTNS
    if IsObject(ctrl)
        VdaButtonClicked(idx, ctrl)
    else if (idx >= 1 && idx <= VDA_UI_BTNS.Length)
        VdaButtonClicked(idx, VDA_UI_BTNS[idx])
}

BuildPrimaVdaRankQuestion() {
    global SOUL_SESSION, VDARANK_PICKS, VDA_UI_BTNS, VDA_UI_TEXTS, VDA_UI_PICKS, VDA_UI_ANSWER_IDS
    session := GetActiveTestSession("prima_vda")
    if (!IsObject(session) || session.completed) {
        HandleInvalidTestSession("prima_vda", "build_vda_rank")
        return
    }
    q := GetCurrentQuestion("prima_vda")
    if !IsObject(q) {
        HandleInvalidTestSession("prima_vda", "build_vda_rank_no_question")
        return
    }
    SafeTrace("BUILD_VDA_START qid=" q.id " q_index=" session.current_index " answers=" q.answers.Length)
    VDARANK_PICKS := []
    VDA_UI_PICKS := []
    VDA_UI_BTNS := []
    VDA_UI_TEXTS := []
    VDA_UI_ANSWER_IDS := []
    g := NewGui()
    rankHint := TIcon("msg_rank_all") " — " T("vda_rank_hint_top") " · " T("vda_rank_hint_bottom")
    guidance := TestGuidanceHint("prima_vda", session.current_index)
    answersY := AddTestQuestionHeader(g, TIcon("vda_test_title")
        , TIcon("vda_question_of", session.current_index, session.questions.Length)
        , q.prompt, guidance, rankHint)
    texts := []
    answerIds := []
    for a in q.answers {
        texts.Push(a.text)
        answerIds.Push(a.id)
    }
    VDA_UI_TEXTS := texts
    VDA_UI_ANSWER_IDS := answerIds
    answerUi := AddVisibleRankAnswerButtons(g, texts, answersY)
    VDA_UI_BTNS := answerUi.buttons
    loop VDA_UI_BTNS.Length {
        i := A_Index
        SafeTrace("CREATE_BTN test=vda idx=" i " answer_id=" answerIds[i] " text=" SubStr(texts[i], 1, 60) " hwnd=" VDA_UI_BTNS[i].Hwnd)
        BindVdaButton(VDA_UI_BTNS[i], i, answerIds[i])
    }
    VdaUiSyncAliases()
    AddFixedTestNav(g, VdaRankNextQuestion, answerUi.navY)
    SafeTrace("BUILD_VDA_DONE btn_count=" VDA_UI_BTNS.Length " gui_hwnd=" g.Hwnd)
    ShowScreen()
}

VdaRankNextQuestion(*) {
    global SOUL_SESSION, VDARANK_PICKS, CURRENT_PROFILE_ID, VDA_UI_PICKS
    SyncVdaVisiblePicksToRanking()
    session := GetActiveTestSession("prima_vda")
    if (!IsObject(session) || session.completed) {
        HandleInvalidTestSession("prima_vda", "vda_next")
        return
    }
    q := GetCurrentQuestion("prima_vda")
    if !IsObject(q) {
        HandleInvalidTestSession("prima_vda", "vda_next_no_question")
        return
    }
    complete := (VDA_UI_PICKS.Length = q.answers.Length) && IsRankingComplete("vda", q, VDARANK_PICKS)
    SafeTrace("NEXT_CLICK picks_count=" VDA_UI_PICKS.Length " vdapicks_count=" VDARANK_PICKS.Length " complete=" (complete ? "yes" : "no"))
    if (VDA_UI_PICKS.Length != q.answers.Length) {
        MsgBox(T(GetRankingIncompleteMsgKey(q.answers.Length)), APP_TITLE, "Icon!")
        return
    }
    if !IsRankingComplete("vda", q, VDARANK_PICKS) {
        MsgBox(T(GetRankingIncompleteMsgKey(q.answers.Length)), APP_TITLE, "Icon!")
        return
    }
    ranks := BuildRankingFromPicks(q, VDARANK_PICKS)
    errKey := ValidateAnswerRanking(ranks, q.answers.Length, GetRankingIncompleteMsgKey(q.answers.Length))
    if (errKey != "") {
        MsgBox(T(errKey), APP_TITLE, "Icon!")
        return
    }
    VdaSessionRecordRanking(SOUL_SESSION, q.id, ranks)
    WriteLog("vda_question_ranked", q.id)
    SaveVdaSessionState()
    if (SOUL_SESSION.completed) {
        WriteLog("vda_test_completed", CURRENT_PROFILE_ID " | " SOUL_SESSION.rankings.Length)
        if (CURRENT_PROFILE_ID != "") {
            MarkSoulTestCompleted(CURRENT_PROFILE_ID, "prima_vda")
            WriteLog("vda_test_locked", CURRENT_PROFILE_ID)
            totals := ComputePcmRankingScores(SOUL_SESSION)
            baseScores := ComputeVdaBaseScores(SOUL_SESSION)
            phaseScores := ComputeVdaPhaseScores(SOUL_SESSION)
            SaveVdaTestResult(CURRENT_PROFILE_ID, totals, baseScores, phaseScores)
        }
        RenderScreen("prima_vda_rank_done")
    } else {
        RenderScreen("prima_vda_rank")
    }
}

; Fin VDA : pas de résultat détaillé immédiat.
BuildPrimaVdaRankDone() {
    BuildPrimaTestDoneScreen("vda_test_title")
}

OpenSoulTestFromHub(*) {
    global SOUL_TEST_BACK_SCREEN
    SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
    RenderScreen("prima_soul_test")
}

CreatorOpenSoulTest(*) {
    global SOUL_TEST_BACK_SCREEN
    SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
    RenderScreen("prima_soul_test")
}

OpenVdaFromSoulHub(*) {
    global VDA_BACK_SCREEN
    VDA_BACK_SCREEN := "prima_soul_intro"
    RenderScreen("prima_soul_vda")
}

CreatorOpenVdaTest(*) {
    global VDA_BACK_SCREEN
    VDA_BACK_SCREEN := "prima_soul_intro"
    RenderScreen("prima_soul_vda")
}

; Écran de lancement PRIMA Soul Test (test 15 situations).
BuildPrimaSoulTest() {
    global CURRENT_PROFILE_ID, SOUL_TEST_BACK_SCREEN
    g := NewGui()
    progress := (CURRENT_PROFILE_ID != "") ? GetTestProgress(CURRENT_PROFILE_ID, "soul") : { status: "not_started" }
    AddLaunchScreenHeader(g, TIcon("soul_test_title"), T("vda_count"), T("vda_line1"))
    if (progress.status = "completed")
        AddLaunchMainAction(g, TIcon("btn_soul_test_done"), ShowTestAlreadyDone)
    else if (progress.status = "in_progress")
        AddLaunchMainAction(g, TIcon("btn_resume_soul"), ResumeSoulTestFromHub)
    else
        AddLaunchMainAction(g, TIcon("btn_start"), StartSoulTestRun)
    AddLaunchFooter(g, (*) => RenderScreen(SOUL_TEST_BACK_SCREEN))
    ShowScreen()
}

; Écran de lancement PRIMA VDA Test.
BuildPrimaSoulVda() {
    global CURRENT_PROFILE_ID, VDA_BACK_SCREEN
    g := NewGui()
    progress := (CURRENT_PROFILE_ID != "") ? GetTestProgress(CURRENT_PROFILE_ID, "vda") : { status: "not_started" }
    AddLaunchScreenHeader(g, TIcon("vda_test_title"), T("vda_intro_1"), T("vda_intro_2"))
    if (progress.status = "completed")
        AddLaunchMainAction(g, TIcon("btn_vda_test_done"), ShowTestAlreadyDone)
    else if (progress.status = "in_progress")
        AddLaunchMainAction(g, TIcon("btn_resume_vda"), ResumeVdaTestFromHub)
    else
        AddLaunchMainAction(g, TIcon("btn_start"), StartSoulVdaRun)
    AddLaunchFooter(g, (*) => RenderScreen(VDA_BACK_SCREEN))
    ShowScreen()
}

; Écran de lancement PRIMA Shadow Test.
BuildPrimaSoulShadow() {
    global CURRENT_PROFILE_ID
    g := NewGui()
    progress := (CURRENT_PROFILE_ID != "") ? GetTestProgress(CURRENT_PROFILE_ID, "shadow") : { status: "not_started" }
    AddLaunchScreenHeader(g, TIcon("shadow_test_title"), T("shadow_intro_1"), T("shadow_intro_2"))
    if (progress.status = "completed")
        AddLaunchMainAction(g, TIcon("btn_shadow_test_done"), ShowTestAlreadyDone)
    else if (progress.status = "in_progress")
        AddLaunchMainAction(g, TIcon("btn_resume_shadow"), ResumeShadowTestFromHub)
    else
        AddLaunchMainAction(g, TIcon("btn_start"), StartShadowTestRun)
    AddLaunchFooter(g, (*) => RenderScreen("prima_soul_intro"))
    ShowScreen()
}

; Clic sur un test Shadow verrouillé.
ShowShadowTestLocked(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_test_click_locked", CURRENT_PROFILE_ID " | prima_shadow")
    MsgBox(SoulTestDoneMessage(), APP_TITLE, "Icon!")
}

StartShadowTestRun(*) {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (!CanStartSoulTest("prima_shadow")) {
        WriteLog("soul_test_start_blocked", CURRENT_PROFILE_ID " | prima_shadow")
        ShowShadowTestLocked()
        return
    }
    session := BuildShadowQuestionRun(15)
    if (session = "") {
        MsgBox(T("msg_run_preparing"), APP_TITLE, "Icon!")
        return
    }
    SOUL_SESSION := session
    WriteLog("shadow_test_started", "prima_shadow | 15")
    SaveShadowSessionState()
    RenderScreen("prima_shadow_question")
}

; ── PRIMA Shadow — classement visible simple (7 réponses) ───────────────────
global SHADOW_PICKS := []
global SHADOW_VISIBLE_BTNS := []
global SHADOW_VISIBLE_TEXTS := []
global SHADOW_VISIBLE_PICKS := []
global SHADOW_ANSWER_BTNS := []

BindShadowButton(btn, idx) {
    btn.OnEvent("Click", ShadowButtonClicked.Bind(idx))
}

ShadowButtonClicked(idx, ctrl, *) {
    global SHADOW_VISIBLE_TEXTS, SHADOW_VISIBLE_PICKS, CLR_ACCENT
    idx := Integer(idx)
    if (idx < 1 || idx > SHADOW_VISIBLE_TEXTS.Length)
        return
    for _, pickedIdx in SHADOW_VISIBLE_PICKS {
        if (pickedIdx = idx)
            return
    }
    if (SHADOW_VISIBLE_PICKS.Length >= SHADOW_VISIBLE_TEXTS.Length)
        return
    SHADOW_VISIBLE_PICKS.Push(idx)
    rank := SHADOW_VISIBLE_PICKS.Length
    if IsObject(ctrl) {
        ctrl.Text := PrimaRankPrefix(rank) SHADOW_VISIBLE_TEXTS[idx]
        ctrl.SetFont("s11 Bold c" CLR_ACCENT, "Segoe UI")
    }
    SyncShadowVisiblePicksToRanking()
}

SyncShadowVisiblePicksToRanking() {
    global SHADOW_VISIBLE_PICKS, SHADOW_PICKS
    q := GetCurrentQuestion("prima_shadow")
    SHADOW_PICKS := []
    if !IsObject(q)
        return
    for _, idx in SHADOW_VISIBLE_PICKS {
        if (idx >= 1 && idx <= q.answers.Length)
            SHADOW_PICKS.Push(q.answers[idx].id)
    }
}

ShadowRankAnswerClick(idx, ctrl := "", *) {
    global SHADOW_VISIBLE_BTNS
    if IsObject(ctrl)
        ShadowButtonClicked(idx, ctrl)
    else if (idx >= 1 && idx <= SHADOW_VISIBLE_BTNS.Length)
        ShadowButtonClicked(idx, SHADOW_VISIBLE_BTNS[idx])
}

BuildPrimaShadowQuestion() {
    global SOUL_SESSION, SHADOW_PICKS, SHADOW_VISIBLE_BTNS, SHADOW_VISIBLE_TEXTS, SHADOW_VISIBLE_PICKS, SHADOW_ANSWER_BTNS
    session := GetActiveTestSession("prima_shadow")
    if (!IsObject(session) || session.completed) {
        HandleInvalidTestSession("prima_shadow", "build_shadow_question")
        return
    }
    q := GetCurrentQuestion("prima_shadow")
    if !IsObject(q) {
        HandleInvalidTestSession("prima_shadow", "build_shadow_no_question")
        return
    }
    SHADOW_PICKS := []
    SHADOW_VISIBLE_PICKS := []
    SHADOW_VISIBLE_BTNS := []
    SHADOW_VISIBLE_TEXTS := []
    g := NewGui()
    rankHint := TIcon("msg_rank_all_7") " — " T("vda_rank_hint_top") " · " T("rank_hint_least")
    guidance := TestGuidanceHint("prima_shadow", session.current_index)
    answersY := AddTestQuestionHeader(g, TIcon("shadow_test_title")
        , TIcon("vda_question_of", session.current_index, session.questions.Length)
        , q.prompt, guidance, rankHint)
    texts := []
    for a in q.answers
        texts.Push(a.text)
    SHADOW_VISIBLE_TEXTS := texts
    answerUi := AddVisibleRankAnswerButtons(g, texts, answersY)
    SHADOW_VISIBLE_BTNS := answerUi.buttons
    loop SHADOW_VISIBLE_BTNS.Length
        BindShadowButton(SHADOW_VISIBLE_BTNS[A_Index], A_Index)
    SHADOW_ANSWER_BTNS := SHADOW_VISIBLE_BTNS
    AddFixedTestNav(g, ShadowRankNextQuestion, answerUi.navY)
    ShowScreen()
}

ShadowRankNextQuestion(*) {
    global SOUL_SESSION, SHADOW_PICKS, CURRENT_PROFILE_ID, SHADOW_VISIBLE_PICKS
    SyncShadowVisiblePicksToRanking()
    session := GetActiveTestSession("prima_shadow")
    if (!IsObject(session) || session.completed) {
        HandleInvalidTestSession("prima_shadow", "shadow_next")
        return
    }
    q := GetCurrentQuestion("prima_shadow")
    if !IsObject(q) {
        HandleInvalidTestSession("prima_shadow", "shadow_next_no_question")
        return
    }
    if (SHADOW_VISIBLE_PICKS.Length != q.answers.Length) {
        MsgBox(T(GetRankingIncompleteMsgKey(q.answers.Length)), APP_TITLE, "Icon!")
        return
    }
    if !IsRankingComplete("shadow", q, SHADOW_PICKS) {
        MsgBox(T(GetRankingIncompleteMsgKey(q.answers.Length)), APP_TITLE, "Icon!")
        return
    }
    ranks := BuildRankingFromPicks(q, SHADOW_PICKS)
    errKey := ValidateAnswerRanking(ranks, q.answers.Length, GetRankingIncompleteMsgKey(q.answers.Length))
    if (errKey != "") {
        MsgBox(T(errKey), APP_TITLE, "Icon!")
        return
    }
    VdaSessionRecordRanking(SOUL_SESSION, q.id, ranks)
    WriteLog("shadow_question_ranked", q.id)
    SaveShadowSessionState()
    if (SOUL_SESSION.completed) {
        WriteLog("shadow_test_completed", CURRENT_PROFILE_ID " | " SOUL_SESSION.rankings.Length)
        if (CURRENT_PROFILE_ID != "") {
            MarkSoulTestCompleted(CURRENT_PROFILE_ID, "prima_shadow")
            WriteLog("shadow_test_locked", CURRENT_PROFILE_ID)
            scores := ComputeShadowScores(SOUL_SESSION)
            SaveShadowTestResult(CURRENT_PROFILE_ID, scores)
        }
        RenderScreen("prima_shadow_done")
    } else {
        RenderScreen("prima_shadow_question")
    }
}

; Fin Shadow : pas de résultat détaillé immédiat.
BuildPrimaShadowDone() {
    BuildPrimaTestDoneScreen("shadow_test_title")
}

; ── Lecture globale PRIMA — hub résultats + écrans détail ─────────────────────
; Tout est formulé en pistes ("tes réponses suggèrent…"), jamais en vérité.
; Les clés internes (blessures, PCM, axes Shadow) ne sont jamais affichées :
; seuls les noms publics neutres apparaissent.

OpenSoulReadingHub(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_global_reading_opened", CURRENT_PROFILE_ID)
    RenderScreen("soul_reading_hub")
}

OpenPrimaUniverseChoice(*) {
    global CURRENT_PROFILE_ID, UNIVERSE_BACK_SCREEN, PRIMA_UNI_PAGE
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    if (IsPrimaArchitectureLocked(CURRENT_PROFILE_ID)) {
        WriteLog("soul_universe_locked", CURRENT_PROFILE_ID)
        OpenPrimaIdentityResult()
        return
    }
    PRIMA_UNI_PAGE := 1
    UNIVERSE_BACK_SCREEN := "prima_soul_intro"
    WriteLog("soul_universe_choice_from_hub", CURRENT_PROFILE_ID)
    RenderScreen("prima_universe_choice")
}

BuildSoulReadingHub() {
    global CURRENT_PROFILE_ID, MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    g := NewGui()
    AddScrollPageHeader(g, TIcon("reading_hub_title"), T("reading_hub_1"), T("reading_hub_2"))
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, SCROLL_VIEWPORT_H)
    AddReadingHubButtonScroll(cg, 1, 1, TIcon("btn_result_soul"), (*) => RenderScreen("soul_reading_soul"))
    AddReadingHubButtonScroll(cg, 2, 1, TIcon("btn_result_vda"), (*) => RenderScreen("soul_reading_vda"))
    AddReadingHubButtonScroll(cg, 1, 2, TIcon("btn_result_shadow"), (*) => RenderScreen("soul_reading_shadow"))
    if (CURRENT_PROFILE_ID != "" && IsPrimaArchitectureLocked(CURRENT_PROFILE_ID))
        AddReadingHubButtonScroll(cg, 2, 2, TIcon("btn_view_identity"), OpenPrimaIdentityResult)
    else
        AddReadingHubButtonScroll(cg, 2, 2, TIcon("btn_choose_identity"), SoulReadingUniverseClicked)
    AddReadingHubButtonScroll(cg, 1, 3, TIcon("btn_save_reading"), SoulReadingSaveClicked)
    AddReadingHubButtonScroll(cg, 2, 3, TIcon("btn_create_plan"), SoulReadingPlanClicked)
    AddReadingHubButtonScroll(cg, 1, 4, TIcon("btn_redo_tests"), SoulRedoTestsClicked)
    AddReadingHubButtonScroll(cg, 2, 4, TIcon("btn_back"), (*) => RenderScreen("prima_soul_intro"))
    ShowScreen()
}

; Boutons préparés : messages seulement, aucune action concrète pour l'instant.
SoulReadingSaveClicked(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_reading_saved_clicked", CURRENT_PROFILE_ID)
    MsgBox(T("msg_reading_saved"), APP_TITLE, "Iconi")
}

SoulReadingUniverseClicked(*) {
    global CURRENT_PROFILE_ID, UNIVERSE_BACK_SCREEN, PRIMA_UNI_PAGE
    if (CURRENT_PROFILE_ID != "" && IsPrimaArchitectureLocked(CURRENT_PROFILE_ID)) {
        WriteLog("soul_universe_locked", CURRENT_PROFILE_ID)
        OpenPrimaIdentityResult()
        return
    }
    WriteLog("soul_universe_choice_clicked", CURRENT_PROFILE_ID)
    PRIMA_UNI_PAGE := 1
    UNIVERSE_BACK_SCREEN := "soul_reading_hub"
    RenderScreen("prima_universe_choice")
}

SoulReadingPlanClicked(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_plan_clicked", CURRENT_PROFILE_ID)
    MsgBox(T("msg_plan_later"), APP_TITLE, "Iconi")
}

; ── Helpers lecture : scores INI, top 2, jauge ─────────────────────────────────

; Lit une section de scores entiers depuis un fichier résultats.
ReadIniScoreMap(file, section, keys) {
    m := Map()
    for key in keys {
        v := IniRead(file, section, key, "0")
        m[key] := (v ~= "^\d+$") ? Integer(v) : 0
    }
    return m
}

; Renvoie les deux clés les plus fortes d'une Map de scores (départage stable).
TopTwoScoreKeys(m, keys, tieMeta := "") {
    sorted := SortedAllScoreKeys(m, keys, tieMeta)
    main := sorted.Length >= 1 ? sorted[1].key : ""
    second := sorted.Length >= 2 ? sorted[2].key : ""
    return { main: main, second: second }
}

; Jauge visuelle simple sur 5 blocs à partir d'un pourcentage 0-100.
SoulGaugeText(pct) {
    filled := Round(pct / 20)
    if (filled < 0)
        filled := 0
    if (filled > 5)
        filled := 5
    bar := ""
    loop 5
        bar .= (A_Index <= filled) ? "■" : "□"
    return bar
}

; ── Mapping public Soul (jamais les mots internes) ─────────────────────────────
; Nom officiel discret (petit, gris) — jamais en titre principal.
SoulOfficialLabel(key) {
    switch key {
        case "rejet":       return "rejet"
        case "abandon":     return "abandon"
        case "humiliation": return "humiliation"
        case "trahison":    return "trahison"
        case "injustice":   return "injustice"
    }
    return ""
}

VdaOfficialLabel(key) {
    switch key {
        case "analyseur":   return "analyseur"
        case "perseverant": return "persévérant"
        case "empathique":  return "empathique"
        case "imagineur":   return "imagineur"
        case "energiseur":  return "énergiseur"
        case "promoteur":   return "promoteur"
    }
    return ""
}

ShadowOfficialLabel(key) {
    switch key {
        case "orgueil":     return "orgueil"
        case "envie":       return "envie"
        case "colere":      return "colère"
        case "paresse":     return "paresse"
        case "avarice":     return "avarice"
        case "gourmandise": return "gourmandise"
        case "luxure":      return "luxure"
    }
    return ""
}

SoulReadingName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "place"
            case "abandon":     return "bond"
            case "humiliation": return "personal need"
            case "trahison":    return "trust"
            case "injustice":   return "fairness"
        }
    } else {
        switch key {
            case "rejet":       return "place"
            case "abandon":     return "lien"
            case "humiliation": return "besoin personnel"
            case "trahison":    return "confiance"
            case "injustice":   return "justesse"
        }
    }
    return ""
}

; Besoin probable (section "Ce qui peut te nourrir").
SoulReadingNeed(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "Your answers suggest a need to feel welcome as you are."
            case "abandon":     return "Your answers suggest a need for a stable bond and presence."
            case "humiliation": return "Your answers suggest a need to express your needs without shame."
            case "trahison":    return "Your answers suggest a need for reliability and trust."
            case "injustice":   return "Your answers suggest a need for fairness and balance."
        }
    } else {
        switch key {
            case "rejet":       return "Tes réponses suggèrent un besoin de te sentir accueilli tel que tu es."
            case "abandon":     return "Tes réponses suggèrent un besoin de lien stable et de présence."
            case "humiliation": return "Tes réponses suggèrent un besoin d'exprimer tes besoins sans honte."
            case "trahison":    return "Tes réponses suggèrent un besoin de fiabilité et de confiance."
            case "injustice":   return "Tes réponses suggèrent un besoin de justesse et d'équilibre."
        }
    }
    return ""
}

; Réaction de protection (Soul — distinct du comportement).
SoulReadingProtection(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "Your answers suggest a protection reaction: stepping back to avoid another rejection."
            case "abandon":     return "Your answers suggest a protection reaction: holding on or checking the bond when it feels fragile."
            case "humiliation": return "Your answers suggest a protection reaction: minimizing yourself so as not to be a burden."
            case "trahison":    return "Your answers suggest a protection reaction: checking or controlling when trust feels uncertain."
            case "injustice":   return "Your answers suggest a protection reaction: stiffening or demanding fairness before feeling."
        }
    } else {
        switch key {
            case "rejet":       return "Tes réponses suggèrent une réaction de protection : te retirer pour éviter un nouveau refus."
            case "abandon":     return "Tes réponses suggèrent une réaction de protection : t'accrocher ou vérifier le lien quand il semble fragile."
            case "humiliation": return "Tes réponses suggèrent une réaction de protection : te minimiser pour ne pas déranger."
            case "trahison":    return "Tes réponses suggèrent une réaction de protection : vérifier ou contrôler quand la confiance semble incertaine."
            case "injustice":   return "Tes réponses suggèrent une réaction de protection : te raidir ou exiger la justesse avant de ressentir."
        }
    }
    return ""
}

; Piste douce (Soul — section dédiée).
SoulReadingGentleLead(key) {
    global CURRENT_LANG
    action := GetSoulTendencyAction(key)
    if (action = "")
        return ""
    if (CURRENT_LANG = "en")
        return "A gentle lead: " action
    return "Piste douce : " action
}

; Comportement possible (formulation prudente).
SoulReadingBehavior(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "A possible lead: stepping back when you doubt being welcome."
            case "abandon":     return "A possible lead: seeking reassurance when the bond feels fragile."
            case "humiliation": return "A possible lead: taking too much on yourself so as not to bother."
            case "trahison":    return "A possible lead: checking or keeping control when doubt sets in."
            case "injustice":   return "A possible lead: aiming for perfect before feeling."
        }
    } else {
        switch key {
            case "rejet":       return "Une piste possible : te mettre en retrait quand tu doutes d'être bienvenu."
            case "abandon":     return "Une piste possible : chercher à être rassuré quand le lien semble fragile."
            case "humiliation": return "Une piste possible : prendre trop sur toi pour ne pas déranger."
            case "trahison":    return "Une piste possible : vérifier ou garder le contrôle quand le doute s'installe."
            case "injustice":   return "Une piste possible : viser le parfait avant de ressentir."
        }
    }
    return ""
}

; Sous pression (jamais de diagnostic).
SoulReadingPressure(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "Under pressure, you may withdraw or isolate more than needed."
            case "abandon":     return "Under pressure, you may hold on to the bond or wait for a sign."
            case "humiliation": return "Under pressure, you may forget yourself and carry for others."
            case "trahison":    return "Under pressure, you may close up or want to control everything."
            case "injustice":   return "Under pressure, you may become cold, hard or very demanding."
        }
    } else {
        switch key {
            case "rejet":       return "Sous pression, tu peux te mettre à l'écart ou t'isoler plus que nécessaire."
            case "abandon":     return "Sous pression, tu peux t'accrocher au lien ou attendre un signe."
            case "humiliation": return "Sous pression, tu peux t'oublier et porter à la place des autres."
            case "trahison":    return "Sous pression, tu peux te fermer ou vouloir tout contrôler."
            case "injustice":   return "Sous pression, tu peux devenir froid, dur ou très exigeant."
        }
    }
    return ""
}

; ── Mapping public VDA (jamais de clé PCM, jamais "base/phase" en vérité) ──────
VdaReadingName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "structure"
            case "perseverant": return "meaning"
            case "empathique":  return "human bond"
            case "imagineur":   return "inner space"
            case "energiseur":  return "living energy"
            case "promoteur":   return "direct action"
        }
    } else {
        switch key {
            case "analyseur":   return "structure"
            case "perseverant": return "sens"
            case "empathique":  return "lien humain"
            case "imagineur":   return "espace intérieur"
            case "energiseur":  return "énergie vivante"
            case "promoteur":   return "action directe"
        }
    }
    return ""
}

; Besoin psychologique probable.
VdaReadingNeed(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "Your answers suggest a need for recognition of your work and clear time frames."
            case "perseverant": return "Your answers suggest a need for your convictions and commitment to be respected."
            case "empathique":  return "Your answers suggest a need to be welcomed as a person, with warmth."
            case "imagineur":   return "Your answers suggest a need for calm, space and clear instructions."
            case "energiseur":  return "Your answers suggest a need for playful contact and lightness."
            case "promoteur":   return "Your answers suggest a need for action, challenge and quick results."
        }
    } else {
        switch key {
            case "analyseur":   return "Tes réponses suggèrent un besoin que ton travail soit reconnu et que le temps soit structuré."
            case "perseverant": return "Tes réponses suggèrent un besoin que tes convictions et ton engagement soient respectés."
            case "empathique":  return "Tes réponses suggèrent un besoin d'être accueilli en tant que personne, avec chaleur."
            case "imagineur":   return "Tes réponses suggèrent un besoin de calme, d'espace et de consignes claires."
            case "energiseur":  return "Tes réponses suggèrent un besoin de contacts ludiques et de légèreté."
            case "promoteur":   return "Tes réponses suggèrent un besoin d'action, de défis et de résultats rapides."
        }
    }
    return ""
}

; Moyen de communication conseillé (piste, pas règle).
VdaReadingComm(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "A possible lead: clear, factual and structured exchanges."
            case "perseverant": return "A possible lead: sincere exchanges that respect your values."
            case "empathique":  return "A possible lead: warm, personal exchanges."
            case "imagineur":   return "A possible lead: simple requests, one thing at a time, without pressure."
            case "energiseur":  return "A possible lead: lively, spontaneous exchanges with humor."
            case "promoteur":   return "A possible lead: direct, short, action-oriented exchanges."
        }
    } else {
        switch key {
            case "analyseur":   return "Une piste possible : des échanges clairs, factuels et structurés."
            case "perseverant": return "Une piste possible : des échanges sincères qui respectent tes valeurs."
            case "empathique":  return "Une piste possible : des échanges chaleureux et personnels."
            case "imagineur":   return "Une piste possible : des demandes simples, une chose à la fois, sans pression."
            case "energiseur":  return "Une piste possible : des échanges vivants, spontanés, avec de l'humour."
            case "promoteur":   return "Une piste possible : des échanges directs, courts, orientés action."
        }
    }
    return ""
}

; Environnement qui peut nourrir.
VdaReadingEnv(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "An ordered setting where work is recognized can nourish you."
            case "perseverant": return "An environment consistent with your values can nourish you."
            case "empathique":  return "A warm, welcoming environment can nourish you."
            case "imagineur":   return "A calm space with time for yourself can nourish you."
            case "energiseur":  return "A stimulating, creative environment can nourish you."
            case "promoteur":   return "Movement, challenges and room to act can nourish you."
        }
    } else {
        switch key {
            case "analyseur":   return "Un cadre ordonné où le travail est reconnu peut te nourrir."
            case "perseverant": return "Un environnement cohérent avec tes valeurs peut te nourrir."
            case "empathique":  return "Un environnement chaleureux et accueillant peut te nourrir."
            case "imagineur":   return "Un espace calme avec du temps pour toi peut te nourrir."
            case "energiseur":  return "Un environnement stimulant et créatif peut te nourrir."
            case "promoteur":   return "Du mouvement, des défis et de la place pour agir peuvent te nourrir."
        }
    }
    return ""
}

; Retour à l'équilibre (VDA — section dédiée).
VdaReadingBalance(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "A possible lead: one small ordered step, then pause before taking on more."
            case "perseverant": return "A possible lead: reconnect with one value that matters, without convincing anyone."
            case "empathique":  return "A possible lead: one warm contact, then a moment for yourself."
            case "imagineur":   return "A possible lead: ten quiet minutes before deciding anything."
            case "energiseur":  return "A possible lead: move your body lightly, then choose one simple next step."
            case "promoteur":   return "A possible lead: one concrete micro-action, then breathe before forcing the pace."
        }
    } else {
        switch key {
            case "analyseur":   return "Une piste possible : un petit pas ordonné, puis une pause avant d'en prendre plus."
            case "perseverant": return "Une piste possible : reconnecte-toi à une valeur qui compte, sans convaincre."
            case "empathique":  return "Une piste possible : un contact chaleureux, puis un moment pour toi."
            case "imagineur":   return "Une piste possible : dix minutes au calme avant de décider quoi que ce soit."
            case "energiseur":  return "Une piste possible : bouger le corps légèrement, puis choisir une prochaine étape simple."
            case "promoteur":   return "Une piste possible : une micro-action concrète, puis respirer avant de forcer le rythme."
        }
    }
    return ""
}

; Sous pression (piste possible, jamais certitude).
VdaReadingPressure(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "Under pressure, you may over-control, over-detail or exhaust yourself in perfection."
            case "perseverant": return "Under pressure, you may judge, stiffen or want to convince at all costs."
            case "empathique":  return "Under pressure, you may over-adapt and forget yourself to be accepted."
            case "imagineur":   return "Under pressure, you may withdraw, disappear or postpone decisions."
            case "energiseur":  return "Under pressure, you may complain, provoke or shift the blame."
            case "promoteur":   return "Under pressure, you may force things, take risks or bend the frame."
        }
    } else {
        switch key {
            case "analyseur":   return "Sous pression, tu peux sur-contrôler, sur-détailler ou t'épuiser dans le parfait."
            case "perseverant": return "Sous pression, tu peux juger, te raidir ou vouloir convaincre à tout prix."
            case "empathique":  return "Sous pression, tu peux trop t'adapter et t'oublier pour être accepté."
            case "imagineur":   return "Sous pression, tu peux te couper, disparaître ou repousser les décisions."
            case "energiseur":  return "Sous pression, tu peux râler, provoquer ou rejeter la faute."
            case "promoteur":   return "Sous pression, tu peux forcer, prendre des risques ou contourner le cadre."
        }
    }
    return ""
}

; ── Mapping public Shadow (jamais péché, défaut, diagnostic, score brut) ───────
ShadowReadingName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "orgueil":     return "need for worth"
            case "envie":       return "comparison"
            case "colere":      return "tension"
            case "paresse":     return "avoidance"
            case "avarice":     return "control"
            case "gourmandise": return "compensation"
            case "luxure":      return "intensity"
        }
    } else {
        switch key {
            case "orgueil":     return "besoin de valeur"
            case "envie":       return "comparaison"
            case "colere":      return "tension"
            case "paresse":     return "évitement"
            case "avarice":     return "contrôle"
            case "gourmandise": return "compensation"
            case "luxure":      return "intensité"
        }
    }
    return ""
}

; Besoin caché probable.
ShadowReadingHiddenNeed(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "orgueil":     return "This may indicate a hidden need to be valued without having to prove it."
            case "envie":       return "This may indicate a hidden need to feel your own path has worth, without comparison."
            case "colere":      return "This may indicate a hidden need for your limits to be heard earlier."
            case "paresse":     return "This may indicate a hidden need for safety before effort, step by step."
            case "avarice":     return "This may indicate a hidden need for stability before letting go."
            case "gourmandise": return "This may indicate a hidden need for real comfort rather than quick fixes."
            case "luxure":      return "This may indicate a hidden need for living intensity without danger."
        }
    } else {
        switch key {
            case "orgueil":     return "Cela peut indiquer un besoin caché d'être reconnu à ta juste valeur sans devoir le prouver."
            case "envie":       return "Cela peut indiquer un besoin caché de sentir que ta route a de la valeur, sans comparaison."
            case "colere":      return "Cela peut indiquer un besoin caché que tes limites soient entendues plus tôt."
            case "paresse":     return "Cela peut indiquer un besoin caché de sécurité avant l'effort, pas à pas."
            case "avarice":     return "Cela peut indiquer un besoin caché de stabilité avant de lâcher du lest."
            case "gourmandise": return "Cela peut indiquer un besoin caché de réconfort réel plutôt que de compensations rapides."
            case "luxure":      return "Cela peut indiquer un besoin caché d'intensité vivante sans te mettre en danger."
        }
    }
    return ""
}

; Zone difficile à accepter (Shadow — section 1).
ShadowReadingAcceptHard(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "orgueil":     return "This may indicate a part of you that struggles to accept not being seen at your worth."
            case "envie":       return "This may indicate a part of you that struggles to accept your own path without comparing."
            case "colere":      return "This may indicate a part of you that struggles to accept anger without judging it."
            case "paresse":     return "This may indicate a part of you that struggles to accept slowness or necessary rest."
            case "avarice":     return "This may indicate a part of you that struggles to accept letting go or sharing."
            case "gourmandise": return "This may indicate a part of you that struggles to accept discomfort without quick comfort."
            case "luxure":      return "This may indicate a part of you that struggles to accept intensity without excess."
        }
    } else {
        switch key {
            case "orgueil":     return "Cela peut indiquer une partie de toi qui peine à accepter de ne pas être vue à ta juste valeur."
            case "envie":       return "Cela peut indiquer une partie de toi qui peine à accepter ta route sans te comparer."
            case "colere":      return "Cela peut indiquer une partie de toi qui peine à accepter la colère sans la juger."
            case "paresse":     return "Cela peut indiquer une partie de toi qui peine à accepter la lenteur ou le repos nécessaire."
            case "avarice":     return "Cela peut indiquer une partie de toi qui peine à accepter de lâcher ou de partager."
            case "gourmandise": return "Cela peut indiquer une partie de toi qui peine à accepter l'inconfort sans réconfort rapide."
            case "luxure":      return "Cela peut indiquer une partie de toi qui peine à accepter l'intensité sans excès."
        }
    }
    return ""
}

; Compensation / dissimulation (Shadow — section 4).
ShadowReadingCompensation(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "orgueil":     return "You may tend to hide fatigue behind performance or proof."
            case "envie":       return "You may tend to compensate by comparing yourself or putting yourself down."
            case "colere":      return "You may tend to hide tension until it overflows."
            case "paresse":     return "You may tend to avoid, postpone or cut yourself off to stay safe."
            case "avarice":     return "You may tend to hold back, control or close up to keep stability."
            case "gourmandise": return "You may tend to compensate with quick pleasures rather than real comfort."
            case "luxure":      return "You may tend to seek intensity at the wrong moment to feel alive."
        }
    } else {
        switch key {
            case "orgueil":     return "Tu pourrais avoir tendance à cacher la fatigue derrière la performance ou la preuve."
            case "envie":       return "Tu pourrais avoir tendance à compenser en te comparant ou en te dévalorisant."
            case "colere":      return "Tu pourrais avoir tendance à cacher la tension jusqu'à ce qu'elle déborde."
            case "paresse":     return "Tu pourrais avoir tendance à éviter, repousser ou te couper pour rester en sécurité."
            case "avarice":     return "Tu pourrais avoir tendance à retenir, contrôler ou te fermer pour garder la stabilité."
            case "gourmandise": return "Tu pourrais avoir tendance à compenser par des plaisirs rapides plutôt qu'un vrai réconfort."
            case "luxure":      return "Tu pourrais avoir tendance à chercher l'intensité au mauvais moment pour te sentir vivant."
        }
    }
    return ""
}

; Sous pression (piste possible).
ShadowReadingPressure(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "orgueil":     return "Under pressure, you may want to prove and carry everything alone."
            case "envie":       return "Under pressure, you may compare yourself and put yourself down."
            case "colere":      return "Under pressure, you may react too fast and too strong."
            case "paresse":     return "Under pressure, you may avoid, postpone or cut yourself off."
            case "avarice":     return "Under pressure, you may hold back, control or close up."
            case "gourmandise": return "Under pressure, you may compensate with quick pleasures."
            case "luxure":      return "Under pressure, you may seek thrill at the wrong moment."
        }
    } else {
        switch key {
            case "orgueil":     return "Sous pression, tu peux vouloir prouver et tout porter seul."
            case "envie":       return "Sous pression, tu peux te comparer et te dévaloriser."
            case "colere":      return "Sous pression, tu peux réagir trop vite et trop fort."
            case "paresse":     return "Sous pression, tu peux éviter, repousser ou te couper."
            case "avarice":     return "Sous pression, tu peux retenir, contrôler ou te fermer."
            case "gourmandise": return "Sous pression, tu peux compenser par des plaisirs rapides."
            case "luxure":      return "Sous pression, tu peux chercher le frisson au mauvais moment."
        }
    }
    return ""
}

; Piste de régulation douce.
ShadowReadingRegulation(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "orgueil":     return "A gentle lead: note one real success without showing it to anyone."
            case "envie":       return "A gentle lead: turn one comparison into one concrete action for yourself."
            case "colere":      return "A gentle lead: name the tension as soon as it rises, before it overflows."
            case "paresse":     return "A gentle lead: cut the next step into one tiny step."
            case "avarice":     return "A gentle lead: give or delegate one small thing today."
            case "gourmandise": return "A gentle lead: offer yourself one real chosen comfort, not an automatic one."
            case "luxure":      return "A gentle lead: choose a healthy intensity - sport, creation, a framed challenge."
        }
    } else {
        switch key {
            case "orgueil":     return "Piste douce : note une réussite réelle sans la montrer à personne."
            case "envie":       return "Piste douce : transforme une comparaison en une action concrète pour toi."
            case "colere":      return "Piste douce : nomme la tension dès qu'elle monte, avant qu'elle déborde."
            case "paresse":     return "Piste douce : découpe la prochaine étape en un pas minuscule."
            case "avarice":     return "Piste douce : donne ou délègue une petite chose aujourd'hui."
            case "gourmandise": return "Piste douce : offre-toi un vrai moment de réconfort choisi, pas automatique."
            case "luxure":      return "Piste douce : choisis une intensité saine — sport, création, défi cadré."
        }
    }
    return ""
}

; Émotion publique (libellés simples uniquement).
ShadowEmotionName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "peur":      return "fear"
            case "tristesse": return "sadness"
            case "colere":    return "anger"
            case "honte":     return "shame"
            case "joie":      return "joy"
        }
    } else {
        switch key {
            case "peur":      return "peur"
            case "tristesse": return "tristesse"
            case "colere":    return "colère"
            case "honte":     return "honte"
            case "joie":      return "joie"
        }
    }
    return ""
}

; Nom officiel discret pour émotions Shadow (petit gris).
ShadowEmotionOfficialLabel(key) {
    switch key {
        case "peur":      return "peur"
        case "tristesse": return "tristesse"
        case "colere":    return "colère"
        case "honte":     return "honte"
        case "joie":      return "joie"
    }
    return ""
}

; ── Écran détail : Résultat PRIMA Soul ─────────────────────────────────────────
; Blessures / réactions émotionnelles / protection — structure dédiée Soul.
BuildSoulReadingSoul() {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    file := SoulResultsPath(CURRENT_PROFILE_ID)
    mainKey := IniRead(file, "latest", "main_tendency", "")
    secondKey := IniRead(file, "latest", "secondary_tendency", "")
    if (mainKey = "" || SoulReadingName(mainKey) = "") {
        RenderScreen("soul_reading_hub")
        return
    }
    soulKeys := GetSoulVdaKeys()
    scores := ReadIniScoreMap(file, "scores", soulKeys)
    scoreSum := 0
    for , v in scores
        scoreSum += v
    if (scoreSum = 0) {
        for key in soulKeys
            scores[key] := 0
        scores[mainKey] := 10
        if (secondKey != "")
            scores[secondKey] := 5
    }
    soulTiers := BuildTierResultList(scores, soulKeys)
    WriteLog("soul_result_detail_opened", CURRENT_PROFILE_ID)
    global MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H, GAP_LG
    g := NewGui()
    AddScrollPageHeader(g, TIcon("btn_result_soul"), TIcon("reading_hub_1"))
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, SCROLL_VIEWPORT_H)
    contentY := 8
    contentY := AddScrollResultSectionHeader(cg, contentY, "sec_soul_touch")
    for item in soulTiers {
        pub := SoulReadingName(item.key)
        if (pub = "")
            continue
        contentY := AddScrollResultTierRow(cg, contentY, pub, SoulOfficialLabel(item.key), item.pct)
    }
    if (PrimaTopScoresClose(scores, soulKeys))
        contentY := AddScrollResultNote(cg, contentY, T("tie_note_soul"))
    contentY := AddScrollResultSection(cg, contentY, "sec_soul_protection", SoulReadingProtection(mainKey))
    contentY := AddScrollResultSection(cg, contentY, "sec_soul_behavior", SoulReadingBehavior(mainKey))
    contentY := AddScrollResultSection(cg, contentY, "sec_soul_need", SoulReadingNeed(mainKey))
    contentY := AddScrollResultSection(cg, contentY, "sec_soul_gentle", SoulReadingGentleLead(mainKey))
    AddScrollPageFooterBack(g, (*) => RenderScreen("soul_reading_hub"))
    ShowScreen()
}

; ── Écran détail : Résultat PRIMA VDA ──────────────────────────────────────────
; Besoins, communication, énergie relationnelle — structure dédiée VDA.
BuildSoulReadingVda() {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    file := VdaResultsPath(CURRENT_PROFILE_ID)
    if (IniRead(file, "prima_vda", "completed", "0") != "1") {
        RenderScreen("soul_reading_hub")
        return
    }
    keys := GetSoulPcmKeys()
    base := ReadIniScoreMap(file, "base", keys)
    phase := ReadIniScoreMap(file, "phase", keys)
    baseSum := 0
    for , v in base
        baseSum += v
    if (baseSum = 0) {
        base := ReadIniScoreMap(file, "scores", keys)
        baseSum := 0
        for , v in base
            baseSum += v
    }
    if (baseSum = 0) {
        RenderScreen("soul_reading_hub")
        return
    }
    top := TopTwoScoreKeys(base, keys)
    baseTiers := BuildTierResultList(base, keys)
    phaseTiers := BuildTierResultList(phase, keys)
    phaseClose := PrimaTopScoresClose(phase, keys, "", 5)
    vdaTieNote := PrimaTopScoresClose(base, keys) || PrimaTopScoresClose(phase, keys, "", 5)
    WriteLog("vda_result_detail_opened", CURRENT_PROFILE_ID)
    global MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H, GAP_LG
    g := NewGui()
    AddScrollPageHeader(g, TIcon("btn_result_vda"), TIcon("reading_hub_1"))
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, SCROLL_VIEWPORT_H)
    contentY := 8
    contentY := AddScrollResultSectionHeader(cg, contentY, "sec_vda_stable")
    rankPos := 0
    for item in baseTiers {
        rankPos += 1
        pub := VdaReadingName(item.key)
        if (pub = "")
            continue
        contentY := AddScrollResultTierRowLabeled(cg, contentY, PrimaTierRoleLabel(rankPos, "base")
            , pub, VdaOfficialLabel(item.key), item.pct)
    }
    contentY := AddScrollResultSectionHeader(cg, contentY, "sec_vda_energy")
    contentY := AddScrollResultNote(cg, contentY, T("vda_phase_intro"))
    rankPos := 0
    for item in phaseTiers {
        rankPos += 1
        pub := VdaReadingName(item.key)
        if (pub = "")
            continue
        contentY := AddScrollResultTierRowLabeled(cg, contentY, PrimaTierRoleLabel(rankPos, "phase")
            , pub, VdaOfficialLabel(item.key), item.pct)
    }
    if (phaseClose)
        contentY := AddScrollResultNote(cg, contentY, T("vda_phase_close_gap"))
    if (vdaTieNote)
        contentY := AddScrollResultNote(cg, contentY, T("tie_note_vda"))
    contentY := AddScrollResultSection(cg, contentY, "sec_vda_nourish", VdaReadingNeed(top.main), VdaReadingEnv(top.main))
    contentY := AddScrollResultSection(cg, contentY, "sec_vda_comm", VdaReadingComm(top.main))
    contentY := AddScrollResultSection(cg, contentY, "sec_vda_stress", VdaReadingPressure(top.main))
    contentY := AddScrollResultSection(cg, contentY, "sec_vda_balance", VdaReadingBalance(top.main))
    AddScrollPageFooterBack(g, (*) => RenderScreen("soul_reading_hub"))
    ShowScreen()
}

; ── Écran détail : Résultat PRIMA Shadow ───────────────────────────────────────
; Tension cachée / intégration sans jugement — structure dédiée Shadow.
BuildSoulReadingShadow() {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    file := ShadowResultsPath(CURRENT_PROFILE_ID)
    if (IniRead(file, "prima_shadow", "completed", "0") != "1") {
        RenderScreen("soul_reading_hub")
        return
    }
    axisKeys := GetShadowAxisKeys()
    axes := ReadIniScoreMap(file, "axes", axisKeys)
    axSum := 0
    for , v in axes
        axSum += v
    if (axSum = 0) {
        RenderScreen("soul_reading_hub")
        return
    }
    top := TopTwoScoreKeys(axes, axisKeys)
    shadowTiers := BuildTierResultList(axes, axisKeys)
    emoKeys := GetShadowEmotionKeys()
    emotions := ReadIniScoreMap(file, "emotion", emoKeys)
    emoTiers := BuildTierResultList(emotions, emoKeys)
    WriteLog("shadow_result_detail_opened", CURRENT_PROFILE_ID)
    global MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H, CLR_SUBTEXT, GAP_LG
    g := NewGui()
    AddScrollPageHeader(g, TIcon("btn_result_shadow"), TIcon("reading_hub_1"))
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, SCROLL_VIEWPORT_H)
    contentY := 8
    cg.SetFont("s10 Italic c" CLR_SUBTEXT, "Segoe UI")
    pad := 12
    w := CONTENT_W - 2 * pad
    disclaimer := T("shadow_disclaimer")
    hDisc := ScrollTextHeight(disclaimer, w, 17)
    cg.Add("Text", "x" pad " y" contentY " w" w " h" hDisc " +Wrap BackgroundTrans", disclaimer)
    contentY += hDisc + GAP_LG
    contentY := AddScrollResultSection(cg, contentY, "sec_shadow_accept", ShadowReadingAcceptHard(top.main))
    contentY := AddScrollResultSectionHeader(cg, contentY, "sec_shadow_tension")
    for item in shadowTiers {
        pub := ShadowReadingName(item.key)
        if (pub = "")
            continue
        contentY := AddScrollResultTierRow(cg, contentY, pub, ShadowOfficialLabel(item.key), item.pct)
    }
    if (PrimaTopScoresClose(axes, axisKeys))
        contentY := AddScrollResultNote(cg, contentY, T("tie_note_shadow"))
    contentY := AddScrollResultSectionHeader(cg, contentY, "sec_shadow_emotion")
    for item in emoTiers {
        pub := ShadowEmotionName(item.key)
        if (pub = "")
            continue
        contentY := AddScrollResultTierRow(cg, contentY, pub, ShadowEmotionOfficialLabel(item.key), item.pct)
    }
    contentY := AddScrollResultSection(cg, contentY, "sec_shadow_hide", ShadowReadingCompensation(top.main))
    contentY := AddScrollResultSection(cg, contentY, "sec_shadow_pressure", ShadowReadingPressure(top.main))
    contentY := AddScrollResultSection(cg, contentY, "sec_shadow_integration", ShadowReadingRegulation(top.main))
    AddScrollPageFooterBack(g, (*) => RenderScreen("soul_reading_hub"))
    ShowScreen()
}

; ── PRIMA Univers + Territoire — Master Architecture v2 ───────────────────────
; Visible : 7 Univers × 7 Territoires = 49 architectures PRIMA.
; Moteur caché : Base VDA × blessure principale (30) et Phase VDA × blessure
; secondaire (30) = 900 combinaisons internes. Aucune clé interne affichée :
; ni PCM, ni blessure, ni diagnostic. Tout est proposé en pistes.

global PRIMA_SELECTED_UNIVERSE := ""
global PRIMA_SELECTED_TERRITORY := ""
global PRIMA_UNI_SUGGESTED := ""
global PRIMA_TERR_SUGGESTED := ""
global PRIMA_UNI_PAGE := 1
global PRIMA_TERR_PAGE := 1
global PRIMA_DETAIL_UNI_KEY := ""
global PRIMA_DETAIL_TERR_KEY := ""

GetPrimaUniverseKeys() {
    return ["passe", "futur", "ville", "ocean", "desert", "labyrinthe", "jardin"]
}

GetPrimaTerritoryKeys() {
    return ["lien", "choix", "regard", "controle", "silence", "desir", "changement"]
}

; Noms publics des univers (seuls libellés affichés).
PrimaUniverseName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "passe":      return "Universe of the Past"
            case "futur":      return "Universe of the Future"
            case "ville":      return "Universe of the City"
            case "ocean":      return "Universe of the Ocean"
            case "desert":     return "Universe of the Desert"
            case "labyrinthe": return "Universe of the Labyrinth"
            case "jardin":     return "Universe of the Garden"
        }
    } else {
        switch key {
            case "passe":      return "Univers du Passé"
            case "futur":      return "Univers du Futur"
            case "ville":      return "Univers de la Ville"
            case "ocean":      return "Univers de l'Océan"
            case "desert":     return "Univers du Désert"
            case "labyrinthe": return "Univers du Labyrinthe"
            case "jardin":     return "Univers du Jardin"
        }
    }
    return ""
}

; Descriptions courtes des univers (pistes officielles).
PrimaUniverseDesc(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "passe":      return "Memory, nostalgia, loyalty and traces of what remains in you."
            case "futur":      return "Projection, ambition, control and anticipation of what comes next."
            case "ville":      return "Movement, social role, adaptation and image in the world."
            case "ocean":      return "Deep emotions, sensitivity, attachment and intuition."
            case "desert":     return "Solitude, distance, inner survival and silence."
            case "labyrinthe": return "Analysis, doubt, mental control and inner complexity."
            case "jardin":     return "Growth, repair, gentleness and reconstruction."
        }
    } else {
        switch key {
            case "passe":      return "Mémoire, traces anciennes, fidélité, choses non digérées."
            case "futur":      return "Projection, ambition, anticipation, volonté de maîtriser ce qui vient."
            case "ville":      return "Adaptation, rôle social, mouvement, image, rythme extérieur."
            case "ocean":      return "Émotions profondes, sensibilité, intuition, attachement."
            case "desert":     return "Silence, solitude, distance, résistance intérieure, survie calme."
            case "labyrinthe": return "Analyse, doute, complexité mentale, recherche de sens."
            case "jardin":     return "Réparation, croissance, douceur, reconstruction, apaisement."
        }
    }
    return ""
}

PrimaUniverseDescLong(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "passe":
                return "The Universe of the Past speaks of what still lives in memory: old bonds, loyalty, nostalgia and traces that ask to be understood rather than erased."
            case "futur":
                return "The Universe of the Future turns toward what is being built: ambition, projection, the need to anticipate and to keep a grip on what comes next."
            case "ville":
                return "The Universe of the City is social and in motion: roles, adaptation, image and the way you take your place among others."
            case "ocean":
                return "The Universe of the Ocean is deep and sensitive: emotions, attachment, intuition and what moves beneath the surface."
            case "desert":
                return "The Universe of the Desert protects through distance: solitude, silence, inner survival and the space needed to breathe."
            case "labyrinthe":
                return "The Universe of the Labyrinth is mental and complex: analysis, doubt, inner control and the search for the right path."
            case "jardin":
                return "The Universe of the Garden is a place of repair: growth, gentleness, gradual reconstruction and what can bloom again."
        }
    } else {
        switch key {
            case "passe":
                return "L'Univers du Passé parle de ce qui vit encore dans la mémoire : anciens liens, fidélité, nostalgie et traces qui demandent à être comprises plutôt qu'effacées."
            case "futur":
                return "L'Univers du Futur se tourne vers ce qui se construit : ambition, projection, besoin d'anticiper et de garder une prise sur la suite."
            case "ville":
                return "L'Univers de la Ville est social et en mouvement : rôles, adaptation, image et façon de prendre sa place parmi les autres."
            case "ocean":
                return "L'Univers de l'Océan est profond et sensible : émotions, attachement, intuition et ce qui bouge sous la surface."
            case "desert":
                return "L'Univers du Désert protège par la distance : solitude, silence, survie intérieure et espace nécessaire pour respirer."
            case "labyrinthe":
                return "L'Univers du Labyrinthe est mental et complexe : analyse, doute, contrôle intérieur et recherche du bon chemin."
            case "jardin":
                return "L'Univers du Jardin est un lieu de réparation : croissance, douceur, reconstruction progressive et ce qui peut refleurir."
        }
    }
    return ""
}

PrimaUniverseTheme(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "passe":      return "Memory, nostalgia, loyalty and old traces"
            case "futur":      return "Projection, ambition, control and anticipation"
            case "ville":      return "Movement, social role, adaptation and image"
            case "ocean":      return "Deep emotions, sensitivity, attachment and intuition"
            case "desert":     return "Solitude, distance, inner survival and silence"
            case "labyrinthe": return "Analysis, doubt, mental control and inner complexity"
            case "jardin":     return "Growth, repair, gentleness and reconstruction"
        }
    } else {
        switch key {
            case "passe":      return "Mémoire, nostalgie, fidélité, traces anciennes"
            case "futur":      return "Projection, ambition, contrôle, anticipation"
            case "ville":      return "Mouvement, rôle social, adaptation, image"
            case "ocean":      return "Émotions profondes, sensibilité, attachement, intuition"
            case "desert":     return "Solitude, distance, survie intérieure, silence"
            case "labyrinthe": return "Analyse, doute, contrôle mental, complexité intérieure"
            case "jardin":     return "Croissance, réparation, douceur, reconstruction"
        }
    }
    return ""
}

PrimaUniverseSignals(key) {
    return PrimaUniverseTheme(key)
}

PrimaUniverseUserPhrase(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "passe":      return "You sometimes revisit what was, as if it still asked for a place inside you."
            case "futur":      return "You often look ahead, as if the next step needed to be prepared and secured."
            case "ville":      return "You feel how much your place, role and image matter in daily life."
            case "ocean":      return "You sense deep currents — emotions, bonds and intuition — that guide you quietly."
            case "desert":     return "You sometimes need distance and silence to protect what is fragile inside."
            case "labyrinthe": return "You think a lot, analyze and seek the right path before moving forward."
            case "jardin":     return "You look for gentleness, repair and what can grow again at your own pace."
        }
    } else {
        switch key {
            case "passe":      return "Tu revis parfois ce qui a été, comme si cela demandait encore une place en toi."
            case "futur":      return "Tu regardes souvent devant toi, comme si la suite devait être préparée et sécurisée."
            case "ville":      return "Tu sens combien ta place, ton rôle et ton image comptent dans le quotidien."
            case "ocean":      return "Tu perçois des courants profonds — émotions, liens et intuition — qui te guident en silence."
            case "desert":     return "Tu as parfois besoin de distance et de silence pour protéger ce qui est fragile en toi."
            case "labyrinthe": return "Tu réfléchis beaucoup, analyses et cherches le bon chemin avant d'avancer."
            case "jardin":     return "Tu cherches la douceur, la réparation et ce qui peut repousser à ton rythme."
        }
    }
    return ""
}

GetPrimaUniverseIllustration(key) {
    return Map("illustration_key", key, "illustration_path", "")
}

; Noms publics des territoires.
PrimaTerritoryName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "lien":       return "Territory of the Bond"
            case "choix":      return "Territory of Choice"
            case "regard":     return "Territory of the Gaze"
            case "controle":   return "Territory of Control"
            case "silence":    return "Territory of Silence"
            case "desir":      return "Territory of Desire"
            case "changement": return "Territory of Change"
        }
    } else {
        switch key {
            case "lien":       return "Territoire du Lien"
            case "choix":      return "Territoire du Choix"
            case "regard":     return "Territoire du Regard"
            case "controle":   return "Territoire du Contrôle"
            case "silence":    return "Territoire du Silence"
            case "desir":      return "Territoire du Désir"
            case "changement": return "Territoire du Changement"
        }
    }
    return ""
}

; Descriptions courtes des territoires.
PrimaTerritoryDesc(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "lien":       return "Presence, attachment and relational safety."
            case "choix":      return "Decision, direction and responsibility."
            case "regard":     return "Image, judgment and social place."
            case "controle":   return "Structure, checking, trust and mastery."
            case "silence":    return "Withdrawal, rest, distance and inner protection."
            case "desir":      return "Wanting, pleasure, the body and the right to want."
            case "changement": return "Transition, rupture, movement and starting over."
        }
    } else {
        switch key {
            case "lien":       return "Ce qui se joue dans l'attachement, la proximité, la relation."
            case "choix":      return "Ce qui se joue dans les décisions, les bifurcations, les renoncements."
            case "regard":     return "Ce qui se joue dans l'image, la reconnaissance, la peur d'être vu."
            case "controle":   return "Ce qui se joue dans la maîtrise, la sécurité, la peur de perdre prise."
            case "silence":    return "Ce qui se joue dans le retrait, le non-dit, l'espace intérieur."
            case "desir":      return "Ce qui se joue dans l'envie, l'intensité, l'élan vital."
            case "changement": return "Ce qui se joue dans les passages, les transformations, les nouveaux cycles."
        }
    }
    return ""
}

PrimaTerritoryDescLong(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "lien":
                return "The Territory of the Bond is where presence, attachment and relational safety are most active right now."
            case "choix":
                return "The Territory of Choice is where decisions, direction and responsibility take center stage."
            case "regard":
                return "The Territory of the Gaze is tied to image, judgment and your place in others' eyes."
            case "controle":
                return "The Territory of Control is where structure, checking and mastery help you feel secure."
            case "silence":
                return "The Territory of Silence is a zone of withdrawal, rest and inner protection."
            case "desir":
                return "The Territory of Desire speaks of wanting, pleasure, the body and the right to want."
            case "changement":
                return "The Territory of Change is a zone of transition, rupture and movement toward something new."
        }
    } else {
        switch key {
            case "lien":
                return "Le Territoire du Lien est là où la présence, l'attachement et la sécurité relationnelle sont les plus actifs maintenant."
            case "choix":
                return "Le Territoire du Choix est là où la décision, la direction et la responsabilité prennent le devant."
            case "regard":
                return "Le Territoire du Regard est lié à l'image, au jugement et à ta place dans le regard des autres."
            case "controle":
                return "Le Territoire du Contrôle est là où la structure, la vérification et la maîtrise t'aident à te sentir en sécurité."
            case "silence":
                return "Le Territoire du Silence est une zone de retrait, de repos et de protection intérieure."
            case "desir":
                return "Le Territoire du Désir parle de l'envie, du plaisir, du corps et du droit de vouloir."
            case "changement":
                return "Le Territoire du Changement est une zone de transition, de rupture et de mouvement vers du nouveau."
        }
    }
    return ""
}

PrimaTerritoryTheme(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "lien":       return "Presence, attachment, relational safety"
            case "choix":      return "Decision, direction, responsibility"
            case "regard":     return "Image, judgment, social place"
            case "controle":   return "Structure, checking, trust, mastery"
            case "silence":    return "Withdrawal, rest, distance, protection"
            case "desir":      return "Wanting, pleasure, body, right to want"
            case "changement": return "Transition, rupture, movement, renewal"
        }
    } else {
        switch key {
            case "lien":       return "Présence, attachement, sécurité relationnelle"
            case "choix":      return "Décision, direction, responsabilité"
            case "regard":     return "Image, jugement, place sociale"
            case "controle":   return "Structure, vérification, confiance, maîtrise"
            case "silence":    return "Retrait, repos, distance, protection"
            case "desir":      return "Envie, plaisir, corps, droit de vouloir"
            case "changement": return "Transition, rupture, mouvement, renouveau"
        }
    }
    return ""
}

PrimaTerritoryInnerQuestion(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "lien":       return "Where do you need to feel that you truly matter?"
            case "choix":      return "Which direction is asking for your commitment right now?"
            case "regard":     return "How much does others' gaze weigh on your place?"
            case "controle":   return "Where are you trying to structure things to feel safe?"
            case "silence":    return "What inner space do you need to recharge?"
            case "desir":      return "What is calling you to live more fully?"
            case "changement": return "What is asking to move or transform inside you?"
        }
    } else {
        switch key {
            case "lien":       return "Où as-tu besoin de sentir que tu comptes vraiment ?"
            case "choix":      return "Quelle direction te demande ton engagement en ce moment ?"
            case "regard":     return "Combien le regard des autres pèse-t-il sur ta place ?"
            case "controle":   return "Où cherches-tu à structurer pour te sentir en sécurité ?"
            case "silence":    return "De quel espace intérieur as-tu besoin pour te ressourcer ?"
            case "desir":      return "Qu'est-ce qui appelle ton envie de vivre plus pleinement ?"
            case "changement": return "Qu'est-ce qui demande à bouger ou à se transformer en toi ?"
        }
    }
    return ""
}

GetPrimaTerritoryIllustration(key) {
    return Map("illustration_key", key, "illustration_path", "")
}

; ── Sous-univers et formes symboliques (couche identité minimale) ─────────────

GetPrimaSubUniverseKeys(universe) {
    switch universe {
        case "passe":      return ["passe_memoire", "passe_ruines", "passe_heritage"]
        case "futur":      return ["futur_horizon", "futur_machine", "futur_etoile"]
        case "ville":      return ["ville_neon", "ville_haute", "ville_souterraine"]
        case "ocean":      return ["ocean_calme", "ocean_tempete", "ocean_abyssal"]
        case "desert":     return ["desert_solaire", "desert_nocturne", "desert_mirage"]
        case "labyrinthe": return ["labyrinthe_miroir", "labyrinthe_mental", "labyrinthe_ancien"]
        case "jardin":     return ["jardin_secret", "jardin_sauvage", "jardin_reparation"]
    }
    return []
}

PrimaSubUniverseName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "passe_memoire":       return "Ancient memory"
            case "passe_ruines":        return "Inner ruins"
            case "passe_heritage":      return "Silent heritage"
            case "futur_horizon":       return "Distant horizon"
            case "futur_machine":       return "Anticipation machine"
            case "futur_etoile":        return "Guiding star"
            case "ville_neon":          return "Neon city"
            case "ville_haute":         return "High city"
            case "ville_souterraine":   return "Underground city"
            case "ocean_calme":         return "Calm ocean"
            case "ocean_tempete":       return "Storm ocean"
            case "ocean_abyssal":       return "Abyssal ocean"
            case "desert_solaire":      return "Solar desert"
            case "desert_nocturne":     return "Night desert"
            case "desert_mirage":       return "Desert of mirages"
            case "labyrinthe_miroir":   return "Mirror labyrinth"
            case "labyrinthe_mental":   return "Mental labyrinth"
            case "labyrinthe_ancien":   return "Ancient labyrinth"
            case "jardin_secret":       return "Secret garden"
            case "jardin_sauvage":      return "Wild garden"
            case "jardin_reparation":   return "Garden of repair"
        }
    } else {
        switch key {
            case "passe_memoire":       return "Mémoire ancienne"
            case "passe_ruines":        return "Ruines intérieures"
            case "passe_heritage":      return "Héritage silencieux"
            case "futur_horizon":       return "Horizon lointain"
            case "futur_machine":       return "Machine d'anticipation"
            case "futur_etoile":        return "Étoile directrice"
            case "ville_neon":          return "Ville néon"
            case "ville_haute":         return "Ville haute"
            case "ville_souterraine":   return "Ville souterraine"
            case "ocean_calme":         return "Océan calme"
            case "ocean_tempete":       return "Océan tempête"
            case "ocean_abyssal":       return "Océan abyssal"
            case "desert_solaire":      return "Désert solaire"
            case "desert_nocturne":     return "Désert nocturne"
            case "desert_mirage":       return "Désert des mirages"
            case "labyrinthe_miroir":   return "Labyrinthe miroir"
            case "labyrinthe_mental":   return "Labyrinthe mental"
            case "labyrinthe_ancien":   return "Labyrinthe ancien"
            case "jardin_secret":       return "Jardin secret"
            case "jardin_sauvage":      return "Jardin sauvage"
            case "jardin_reparation":   return "Jardin de réparation"
        }
    }
    return ""
}

; 3 formes par univers : humaine, noble, mythique (index 1..3).
GetPrimaFormsForUniverse(universe) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch universe {
            case "passe":      return ["Memory Keeper", "Knight of Ruins", "Heritage Specter"]
            case "futur":      return ["Horizon Watcher", "Mechanical Oracle", "Stellar Dragon"]
            case "ville":      return ["Masked Citizen", "Urban Strategist", "Neon Chimera"]
            case "ocean":      return ["Tide Human", "Abyssal Guardian", "Depth Dragon"]
            case "desert":     return ["Sand Nomad", "Solar Titan", "Ancient Scorpion"]
            case "labyrinthe": return ["Mirror Human", "Knight of Doubt", "Mental Minotaur"]
            case "jardin":     return ["Garden Child", "Root Guardian", "Ancient Stag"]
        }
    } else {
        switch universe {
            case "passe":      return ["Gardien des Souvenirs", "Chevalier des Ruines", "Spectre d'Héritage"]
            case "futur":      return ["Veilleur d'Horizon", "Oracle Mécanique", "Dragon Stellaire"]
            case "ville":      return ["Citadin Masqué", "Stratège Urbain", "Chimère Néon"]
            case "ocean":      return ["Humain des Marées", "Gardien Abyssal", "Dragon des Profondeurs"]
            case "desert":     return ["Nomade du Sable", "Titan Solaire", "Scorpion Ancien"]
            case "labyrinthe": return ["Humain des Miroirs", "Chevalier du Doute", "Minotaure Mental"]
            case "jardin":     return ["Enfant du Jardin", "Gardien des Racines", "Cerf Ancien"]
        }
    }
    return []
}

; Sources de résultats pour le moteur identité (lecture seule, jamais affichées telles quelles).
ReadPrimaResultSources(profileId) {
    soulFile := SoulResultsPath(profileId)
    vdaFile := VdaResultsPath(profileId)
    shadowFile := ShadowResultsPath(profileId)
    soulMain := IniRead(soulFile, "latest", "main_tendency", "")
    soulSecond := IniRead(soulFile, "latest", "secondary_tendency", "")
    pcmKeys := GetSoulPcmKeys()
    base := ReadIniScoreMap(vdaFile, "base", pcmKeys)
    if (PrimaScoreSum(base) = 0)
        base := ReadIniScoreMap(vdaFile, "scores", pcmKeys)
    phase := ReadIniScoreMap(vdaFile, "phase", pcmKeys)
    baseTop := TopTwoScoreKeys(base, pcmKeys)
    phaseTop := TopTwoScoreKeys(phase, pcmKeys)
    axisKeys := GetShadowAxisKeys()
    axes := ReadIniScoreMap(shadowFile, "axes", axisKeys)
    shadowTop := TopTwoScoreKeys(axes, axisKeys)
    emoKeys := GetShadowEmotionKeys()
    emotions := ReadIniScoreMap(shadowFile, "emotion", emoKeys)
    emoTop := TopTwoScoreKeys(emotions, emoKeys)
    return {
        soul_main: soulMain,
        soul_secondary: soulSecond,
        vda_base: baseTop.main,
        vda_base_second: baseTop.second,
        vda_phase: phaseTop.main,
        vda_phase_second: phaseTop.second,
        shadow_main: shadowTop.main,
        shadow_second: shadowTop.second,
        shadow_emotion: emoTop.main,
        profile_gender: GetProfileGender(profileId)
    }
}

ComputeSubUniverse(universe, soulDominant, shadowDominant, emotionDominant) {
    keys := GetPrimaSubUniverseKeys(universe)
    if (keys.Length = 0)
        return ""
    fallback := keys[1]
    if (emotionDominant != "") {
        switch emotionDominant {
            case "peur":
                switch universe {
                    case "passe":      return "passe_heritage"
                    case "futur":      return "futur_horizon"
                    case "ville":      return "ville_souterraine"
                    case "ocean":      return "ocean_abyssal"
                    case "desert":     return "desert_nocturne"
                    case "labyrinthe": return "labyrinthe_miroir"
                    case "jardin":     return "jardin_secret"
                }
            case "tristesse":
                switch universe {
                    case "ocean":  return "ocean_calme"
                    case "passe":  return "passe_memoire"
                    case "jardin": return "jardin_reparation"
                    case "desert": return "desert_nocturne"
                }
            case "colere":
                switch universe {
                    case "ocean":  return "ocean_tempete"
                    case "desert": return "desert_solaire"
                    case "ville":  return "ville_neon"
                    case "jardin": return "jardin_sauvage"
                }
            case "honte":
                switch universe {
                    case "passe":  return "passe_ruines"
                    case "jardin": return "jardin_secret"
                    case "ville":  return "ville_souterraine"
                }
            case "joie":
                switch universe {
                    case "futur":  return "futur_etoile"
                    case "ville":  return "ville_haute"
                    case "jardin": return "jardin_sauvage"
                }
        }
    }
    switch shadowDominant {
        case "envie":
            if (universe = "desert")
                return "desert_mirage"
        case "colere":
            if (universe = "ocean")
                return "ocean_tempete"
        case "paresse":
            if (universe = "desert")
                return "desert_nocturne"
        case "luxure":
            if (universe = "ocean")
                return "ocean_abyssal"
        case "orgueil":
            if (universe = "desert")
                return "desert_solaire"
        case "gourmandise":
            if (universe = "jardin")
                return "jardin_sauvage"
    }
    switch soulDominant {
        case "rejet":
            if (universe = "desert")
                return "desert_nocturne"
        case "abandon":
            if (universe = "ocean")
                return "ocean_calme"
        case "humiliation":
            if (universe = "jardin")
                return "jardin_reparation"
        case "trahison":
            if (universe = "ville")
                return "ville_neon"
        case "injustice":
            if (universe = "labyrinthe")
                return "labyrinthe_mental"
    }
    return fallback
}

; Score de tier forme : 1=humaine, 2=noble/gardienne, 3=mythique (uniquement dans l'univers).
PrimaSubKeyEndsWith(subKey, suffix) {
    return (subKey != "" && StrLen(subKey) >= StrLen(suffix) && SubStr(subKey, -StrLen(suffix)) = suffix)
}

PrimaFormTierFromSignals(subUniverse, territory, vdaBase, shadowDominant, soulDominant) {
    tier := 2
    switch territory {
        case "lien":       tier := 1
        case "choix":      tier := 2
        case "regard":     tier := 1
        case "controle":   tier := 3
        case "silence":    tier := 1
        case "desir":      tier := 3
        case "changement": tier := 3
    }
    if (PrimaSubKeyEndsWith(subUniverse, "_abyssal") || PrimaSubKeyEndsWith(subUniverse, "_souterraine")
        || PrimaSubKeyEndsWith(subUniverse, "_nocturne") || PrimaSubKeyEndsWith(subUniverse, "_miroir"))
        tier := Max(tier, 3)
    if (PrimaSubKeyEndsWith(subUniverse, "_calme") || PrimaSubKeyEndsWith(subUniverse, "_memoire")
        || PrimaSubKeyEndsWith(subUniverse, "_reparation"))
        tier := Min(tier, 2)
    mythicShadow := ["orgueil", "colere", "luxure", "envie"]
    for k in mythicShadow {
        if (k = shadowDominant)
            tier := 3
    }
    if (shadowDominant = "paresse")
        tier := Min(tier, 1)
    if (shadowDominant = "avarice" || shadowDominant = "orgueil")
        tier := Max(tier, 2)
    if (vdaBase = "promoteur" || vdaBase = "energiseur")
        tier := Max(tier, 3)
    else if (vdaBase = "analyseur" || vdaBase = "perseverant")
        tier := Max(tier, 2)
    else if (vdaBase = "empathique" || vdaBase = "imagineur")
        tier := Min(tier, 2)
    if (soulDominant = "abandon" || soulDominant = "humiliation" || soulDominant = "rejet")
        tier := Min(tier, 2)
    else if (soulDominant = "injustice" || soulDominant = "trahison")
        tier := Max(tier, 2)
    if (territory = "desir")
        tier := 3
    else if (territory = "controle")
        tier := Max(tier, 2)
    if (tier < 1)
        tier := 1
    if (tier > 3)
        tier := 3
    return tier
}

; Index 1..3 prioritaire selon territoire + univers (forme toujours dans GetPrimaFormsForUniverse).
PrimaTerritoryFormIndex(universe, territory, subUniverse, tier, shadowDominant) {
    switch territory {
        case "lien":
            return 1
        case "regard":
            switch universe {
                case "ville":      return 1
                case "passe":      return 3
                case "labyrinthe": return 1
            }
            return 1
        case "choix":
            switch universe {
                case "futur":      return 1
                case "passe":      return 2
                case "ville":      return 2
                case "labyrinthe": return 2
            }
            return 2
        case "controle":
            switch universe {
                case "desert":     return 2
                case "futur":      return 2
                case "ocean":      return 2
            }
            return 2
        case "silence":
            switch universe {
                case "ocean":      return PrimaSubKeyEndsWith(subUniverse, "_abyssal") ? 3 : 2
                case "desert":     return 1
                case "passe":      return 3
                case "labyrinthe": return 1
            }
            return 1
        case "desir":
            switch universe {
                case "ocean":  return 3
                case "ville":  return 3
                case "desert": return 3
            }
            return 3
        case "changement":
            return 3
    }
    if (shadowDominant = "paresse" || shadowDominant = "avarice")
        return 1
    return tier
}

; Forme symbolique : famille fixée par l'Univers ; rôle par Territoire/Sous-univers ; tier par Shadow/VDA/Soul.
ComputePrimaForm(universe, subUniverse, territory, vdaBase, shadowDominant, soulDominant) {
    forms := GetPrimaFormsForUniverse(universe)
    if (forms.Length = 0)
        return ""
    tier := PrimaFormTierFromSignals(subUniverse, territory, vdaBase, shadowDominant, soulDominant)
    idx := PrimaTerritoryFormIndex(universe, territory, subUniverse, tier, shadowDominant)
    if (idx < 1)
        idx := tier
    if (idx > forms.Length)
        idx := forms.Length
    return forms[idx]
}

PrimaFormBelongsToUniverse(universe, formName) {
    if (formName = "")
        return false
    for f in GetPrimaFormsForUniverse(universe) {
        if (f = formName)
            return true
    }
    return false
}

PrimaSubUniverseBelongsToUniverse(universe, subKey) {
    if (subKey = "")
        return false
    for k in GetPrimaSubUniverseKeys(universe) {
        if (k = subKey)
            return true
    }
    return false
}

PrimaTerritoryIsValid(territory) {
    for k in GetPrimaTerritoryKeys() {
        if (k = territory)
            return true
    }
    return false
}

; Vérifie et corrige l'identité (fallback cohérent, jamais de crash).
ValidatePrimaIdentityCoherence(identity) {
    fixed := false
    uni := identity.universe
    if (uni = "" || GetPrimaSubUniverseKeys(uni).Length = 0) {
        uni := GetPrimaUniverseKeys()[1]
        fixed := true
    }
    terr := identity.territory
    if !PrimaTerritoryIsValid(terr) {
        terr := PrimaTerritoryForUniverse(uni)
        fixed := true
    }
    sub := identity.sub_universe
    if !PrimaSubUniverseBelongsToUniverse(uni, sub) {
        subKeys := GetPrimaSubUniverseKeys(uni)
        sub := subKeys.Length > 0 ? subKeys[1] : ""
        fixed := true
    }
    form := identity.form
    if !PrimaFormBelongsToUniverse(uni, form) {
        forms := GetPrimaFormsForUniverse(uni)
        form := forms.Length > 0 ? forms[1] : ""
        fixed := true
    }
    subName := PrimaSubUniverseName(sub)
    archLabel := PrimaUniverseName(uni) " / " PrimaTerritoryName(terr)
    idLabel := form " — " subName
    if (form = "" || subName = "")
        idLabel := identity.identity_label
    return {
        universe: uni,
        territory: terr,
        sub_universe: sub,
        sub_universe_name: subName,
        form: form,
        architecture_label: archLabel,
        identity_label: idLabel,
        fixed: fixed
    }
}

; Valide, corrige et réécrit prima_identity.ini si nécessaire.
ValidateAndFixPrimaIdentityFile(profileId) {
    if (profileId = "" || !FileExist(PrimaIdentityPath(profileId)))
        return false
    id := ReadPrimaIdentity(profileId)
    if (id.universe = "" || id.territory = "")
        return false
    coh := ValidatePrimaIdentityCoherence(id)
    if !coh.fixed
        return false
    sources := ReadPrimaResultSources(profileId)
    SavePrimaIdentityComplete(profileId, coh.universe, coh.territory, sources, coh.sub_universe, coh.form)
    WriteLog("prima_identity_coherence_fixed", profileId " | 1")
    return true
}

GetUniverseLanguageTone(universe) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch universe {
            case "passe":
                return "Your profile seems to move with old traces that ask to be recognized without holding you back."
            case "futur":
                return "Your profile seems to seek a clear direction so as not to get lost in anticipation."
            case "ville":
                return "Your profile seems to build itself in movement, between what you show and what you keep inside."
            case "ocean":
                return "Your profile seems to carry an emotional depth that needs to be welcomed without overflowing."
            case "desert":
                return "Your profile seems to have learned to stand in silence, sometimes keeping too much alone."
            case "labyrinthe":
                return "Your profile seems to seek the right inner exit, not by forcing, but by understanding its paths."
            case "jardin":
                return "Your profile seems to ask for a space of reconstruction, where what is fragile can grow again."
        }
    } else {
        switch universe {
            case "passe":
                return "Ton profil semble avancer avec des traces anciennes qui demandent à être reconnues sans te retenir."
            case "futur":
                return "Ton profil semble chercher un cap clair pour ne pas se perdre dans l'anticipation."
            case "ville":
                return "Ton profil semble se construire dans le mouvement, entre ce que tu montres et ce que tu gardes pour toi."
            case "ocean":
                return "Ton profil semble porter une profondeur émotionnelle qui a besoin d'être accueillie sans débordement."
            case "desert":
                return "Ton profil semble avoir appris à tenir debout dans le silence, parfois en gardant trop de choses seul."
            case "labyrinthe":
                return "Ton profil semble chercher la bonne sortie intérieure, non pas en forçant, mais en comprenant mieux ses propres chemins."
            case "jardin":
                return "Ton profil semble demander un espace de reconstruction, où ce qui est fragile peut repousser sans pression."
        }
    }
    return ""
}

GetTerritoryLanguageFocus(territory) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch territory {
            case "lien":       return "The heart of the work seems to pass through relationship and feeling connected without losing yourself."
            case "choix":      return "The heart of the work seems to pass through decisions, directions and what you accept to leave behind."
            case "regard":     return "The heart of the work seems to touch image, recognition and fear of being seen wrongly."
            case "controle":   return "The heart of the work seems to touch safety, mastery and accepting what escapes control."
            case "silence":    return "The heart of the work seems to pass through what is unsaid, kept inside, waiting for a safe space."
            case "desir":      return "The heart of the work seems to pass through intensity, wanting and what you dare to recognize in yourself."
            case "changement": return "The heart of the work seems to pass through passages, endings and transformation."
        }
    } else {
        switch territory {
            case "lien":       return "Le cœur du travail semble passer par la relation et la manière de te sentir relié sans te perdre."
            case "choix":      return "Le cœur du travail semble passer par les décisions, les directions et ce que tu acceptes de laisser derrière."
            case "regard":     return "Le cœur du travail semble toucher l'image, la reconnaissance et la peur d'être mal vu."
            case "controle":   return "Le cœur du travail semble toucher la sécurité, la maîtrise et l'acceptation de ce qui échappe."
            case "silence":    return "Le cœur du travail semble passer par ce qui n'est pas dit, ce qui se garde, ce qui attend un espace sûr."
            case "desir":      return "Le cœur du travail semble passer par l'intensité, l'envie et ce que tu oses reconnaître en toi."
            case "changement": return "Le cœur du travail semble passer par les passages, les fins de cycle et la transformation."
        }
    }
    return ""
}

BuildPrimaDominantReadingLine(sources) {
    global CURRENT_LANG
    parts := []
    if (sources.soul_main != "" && SoulReadingName(sources.soul_main) != "")
        parts.Push(SoulReadingName(sources.soul_main))
    if (sources.vda_base != "" && VdaReadingName(sources.vda_base) != "")
        parts.Push(VdaReadingName(sources.vda_base))
    if (sources.shadow_main != "" && ShadowReadingName(sources.shadow_main) != "")
        parts.Push(ShadowReadingName(sources.shadow_main))
    if (parts.Length = 0)
        return ""
    joined := parts[1]
    loop parts.Length - 1
        joined .= ", " parts[A_Index + 1]
    if (CURRENT_LANG = "en")
        return "Your answers suggest possible sensitivity around " joined " — a lead for this cycle, not a fixed label."
    return "Tes réponses suggèrent une sensibilité possible autour de " joined " — une piste pour ce cycle, pas une étiquette fixe."
}

BuildPrimaIdentitySummary(sources, universe, territory) {
    global CURRENT_LANG
    u := PrimaUniverseName(universe)
    t := PrimaTerritoryName(territory)
    if (CURRENT_LANG = "en")
        return "For this cycle, this may represent a symbolic path between " u " and " t ", built from your Soul, VDA and Shadow answers."
    return "Pour ce cycle, cela peut représenter une piste symbolique entre " u " et " t ", construite à partir de tes réponses Soul, VDA et Shadow."
}

; ── Moteur Univers / Territoire V0.1 (interne, jamais affiché) ─────────────────

; Univers fin = clé VDA (base) × blessure Soul. Règles beta puis fallback blessure.
MapPrimaUniverse(pcmKey, soulKey) {
    switch pcmKey {
        case "empathique":
            if (soulKey = "abandon" || soulKey = "rejet")
                return "ocean"
            if (soulKey = "humiliation")
                return "jardin"
        case "analyseur":
            if (soulKey = "injustice")
                return "labyrinthe"
            if (soulKey = "trahison")
                return "futur"
        case "perseverant":
            if (soulKey = "injustice" || soulKey = "trahison")
                return "labyrinthe"
        case "imagineur":
            if (soulKey = "rejet" || soulKey = "abandon")
                return "desert"
        case "energiseur":
            if (soulKey = "rejet" || soulKey = "humiliation")
                return "ville"
        case "promoteur":
            if (soulKey = "trahison" || soulKey = "injustice")
                return "futur"
    }
    switch soulKey {
        case "abandon":     return "ocean"
        case "rejet":       return "desert"
        case "humiliation": return "jardin"
        case "trahison":    return "futur"
        case "injustice":   return "labyrinthe"
    }
    return ""
}

; Pont entre deux univers identiques (table fixe).
PrimaUniverseBridge(key) {
    switch key {
        case "ocean":      return "jardin"
        case "jardin":     return "ocean"
        case "labyrinthe": return "futur"
        case "futur":      return "ville"
        case "ville":      return "labyrinthe"
        case "desert":     return "passe"
        case "passe":      return "ocean"
    }
    return ""
}

; Territoire fin = clé VDA (phase) × blessure secondaire Soul.
MapPrimaTerritory(pcmKey, soulKey) {
    switch pcmKey {
        case "empathique":
            if (soulKey = "abandon" || soulKey = "rejet")
                return "lien"
        case "analyseur":
            if (soulKey = "injustice" || soulKey = "trahison")
                return "controle"
        case "perseverant":
            if (soulKey = "injustice" || soulKey = "trahison")
                return "regard"
        case "imagineur":
            if (soulKey = "rejet" || soulKey = "abandon")
                return "silence"
        case "energiseur":
            if (soulKey = "rejet" || soulKey = "humiliation")
                return "regard"
        case "promoteur":
            if (soulKey = "trahison" || soulKey = "injustice")
                return "choix"
    }
    ; Toute phase + humiliation forte → désir.
    if (soulKey = "humiliation")
        return "desir"
    switch soulKey {
        case "abandon":   return "lien"
        case "rejet":     return "silence"
        case "trahison":  return "controle"
        case "injustice": return "regard"
    }
    return ""
}

; Pont territoire selon l'univers choisi.
PrimaTerritoryForUniverse(universeKey) {
    switch universeKey {
        case "ocean":      return "lien"
        case "passe":      return "lien"
        case "futur":      return "choix"
        case "ville":      return "regard"
        case "desert":     return "silence"
        case "labyrinthe": return "controle"
        case "jardin":     return "changement"
    }
    return "lien"
}

; Garantit exactement 3 clés distinctes (ordre conservé, complète via canon puis fallback).
EnsureExactlyThreePrimaKeys(list, canonKeys, fallbackKeys) {
    out := []
    for k in list {
        if (k = "")
            continue
        found := false
        for o in out {
            if (o = k)
                found := true
        }
        if !found
            out.Push(k)
    }
    for k in canonKeys {
        if (out.Length >= 3)
            break
        found := false
        for o in out {
            if (o = k)
                found := true
        }
        if !found
            out.Push(k)
    }
    for k in fallbackKeys {
        if (out.Length >= 3)
            break
        found := false
        for o in out {
            if (o = k)
                found := true
        }
        if !found
            out.Push(k)
    }
    result := []
    loop Min(3, out.Length)
        result.Push(out[A_Index])
    return result
}

; Alias historique.
DedupePrimaKeys(list, allKeys) {
    return EnsureExactlyThreePrimaKeys(list, allKeys, allKeys)
}

; Somme des valeurs d'une Map de scores.
PrimaScoreSum(m) {
    total := 0
    for , v in m
        total += v
    return total
}

; Propose 3 univers : principal, pont, secondaire. Fallback si calcul impossible.
ComputeSuggestedPrimaUniverses(profileId) {
    canon := GetPrimaUniverseKeys()
    fallback := ["ocean", "labyrinthe", "jardin"]
    if (profileId = "")
        return EnsureExactlyThreePrimaKeys([], canon, fallback)
    soulFile := SoulResultsPath(profileId)
    soulMain := IniRead(soulFile, "latest", "main_tendency", "")
    soulSecond := IniRead(soulFile, "latest", "secondary_tendency", "")
    if (soulSecond = "")
        soulSecond := soulMain
    keys := GetSoulPcmKeys()
    vdaFile := VdaResultsPath(profileId)
    base := ReadIniScoreMap(vdaFile, "base", keys)
    if (PrimaScoreSum(base) = 0)
        base := ReadIniScoreMap(vdaFile, "scores", keys)
    if (soulMain = "" || PrimaScoreSum(base) = 0)
        return EnsureExactlyThreePrimaKeys([], canon, fallback)
    top := TopTwoScoreKeys(base, keys)
    mainUni := MapPrimaUniverse(top.main, soulMain)
    secUni := MapPrimaUniverse(top.second, soulSecond)
    if (mainUni = "" || secUni = "")
        return EnsureExactlyThreePrimaKeys([], canon, fallback)
    bridge := PrimaUniverseBridge(mainUni)
    if (bridge = "")
        bridge := fallback[2]
    return EnsureExactlyThreePrimaKeys([mainUni, bridge, secUni], canon, fallback)
}

; Propose 3 territoires : principal, pont avec l'univers choisi, secondaire.
ComputeSuggestedPrimaTerritories(profileId, selectedUniverse) {
    canon := GetPrimaTerritoryKeys()
    fallback := ["lien", "controle", "changement"]
    bridge := PrimaTerritoryForUniverse(selectedUniverse)
    if (profileId = "" || selectedUniverse = "")
        return EnsureExactlyThreePrimaKeys([bridge], canon, fallback)
    soulFile := SoulResultsPath(profileId)
    soulSecond := IniRead(soulFile, "latest", "secondary_tendency", "")
    if (soulSecond = "")
        soulSecond := IniRead(soulFile, "latest", "main_tendency", "")
    keys := GetSoulPcmKeys()
    phase := ReadIniScoreMap(VdaResultsPath(profileId), "phase", keys)
    if (soulSecond = "" || PrimaScoreSum(phase) = 0)
        return EnsureExactlyThreePrimaKeys([bridge], canon, fallback)
    top := TopTwoScoreKeys(phase, keys)
    t1 := MapPrimaTerritory(top.main, soulSecond)
    t3 := MapPrimaTerritory(top.second, soulSecond)
    if (t1 = "" || t3 = "")
        return EnsureExactlyThreePrimaKeys([bridge], canon, fallback)
    return EnsureExactlyThreePrimaKeys([t1, bridge, t3], canon, fallback)
}

; ── Sauvegarde prima_identity.ini ──────────────────────────────────────────────
PrimaIdentityPath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\prima_identity.ini"
}

; Architecture et identité PRIMA verrouillées pour le cycle en cours.
IsPrimaArchitectureLocked(profileId) {
    if (profileId = "")
        return false
    file := PrimaIdentityPath(profileId)
    if !FileExist(file)
        return false
    u := IniRead(file, "identity", "selected_universe", "")
    t := IniRead(file, "identity", "selected_territory", "")
    if (u = "" || t = "")
        return false
    locked := IniRead(file, "identity", "locked", "0")
    if (locked = "1")
        return true
    l := IniRead(file, "identity", "architecture_label", "")
    return (l != "")
}

ReadPrimaArchitecture(profileId) {
    id := ReadPrimaIdentity(profileId)
    return {
        universe: id.universe,
        territory: id.territory,
        label: id.architecture_label
    }
}

; Lit l'identité complète depuis prima_identity.ini (fallbacks si champs manquants).
ReadPrimaIdentity(profileId) {
    file := PrimaIdentityPath(profileId)
    universe := IniRead(file, "identity", "selected_universe", "")
    territory := IniRead(file, "identity", "selected_territory", "")
    subKey := IniRead(file, "identity", "selected_sub_universe", "")
    form := IniRead(file, "identity", "selected_form", "")
    archLabel := IniRead(file, "identity", "architecture_label", "")
    if (archLabel = "" && universe != "" && territory != "")
        archLabel := PrimaUniverseName(universe) " / " PrimaTerritoryName(territory)
    idLabel := IniRead(file, "identity", "identity_label", "")
    if (idLabel = "" && form != "" && subKey != "")
        idLabel := form " — " PrimaSubUniverseName(subKey)
    return {
        universe: universe,
        territory: territory,
        sub_universe: subKey,
        sub_universe_name: PrimaSubUniverseName(subKey),
        form: form,
        architecture_label: archLabel,
        identity_label: idLabel,
        identity_summary: IniRead(file, "identity", "identity_summary", ""),
        language_tone: IniRead(file, "language", "universe_tone", ""),
        territory_focus: IniRead(file, "language", "territory_focus", ""),
        locked: IniRead(file, "identity", "locked", "0"),
        date: IniRead(file, "identity", "date", ""),
        sources: {
            soul_main: IniRead(file, "sources", "soul_main", ""),
            soul_secondary: IniRead(file, "sources", "soul_secondary", ""),
            vda_base: IniRead(file, "sources", "vda_base", ""),
            vda_phase: IniRead(file, "sources", "vda_phase", ""),
            shadow_main: IniRead(file, "sources", "shadow_main", ""),
            shadow_emotion: IniRead(file, "sources", "shadow_emotion", "")
        }
    }
}

; Construit ou retourne l'identité PRIMA (ne recalcule pas si verrouillée complète).
BuildPrimaIdentity(profileId) {
    if (profileId = "")
        return ""
    file := PrimaIdentityPath(profileId)
    if FileExist(file) {
        u := IniRead(file, "identity", "selected_universe", "")
        t := IniRead(file, "identity", "selected_territory", "")
        sub := IniRead(file, "identity", "selected_sub_universe", "")
        form := IniRead(file, "identity", "selected_form", "")
        locked := IniRead(file, "identity", "locked", "0")
        if (locked = "1" && u != "" && t != "" && sub != "" && form != "")
            return ReadPrimaIdentity(profileId)
    }
    sources := ReadPrimaResultSources(profileId)
    if (sources.soul_main = "" || sources.vda_base = "")
        return ""
    universe := MapPrimaUniverse(sources.vda_base, sources.soul_main)
    if (universe = "")
        universe := GetPrimaUniverseKeys()[1]
    territory := MapPrimaTerritory(sources.vda_phase, sources.soul_secondary)
    if (territory = "")
        territory := PrimaTerritoryForUniverse(universe)
    SavePrimaIdentityComplete(profileId, universe, territory, sources)
    return ReadPrimaIdentity(profileId)
}

; Complète sous-univers / forme pour anciens prima_identity.ini (sans crash).
CompletePrimaIdentityIfMissing(profileId) {
    if (profileId = "" || !IsPrimaArchitectureLocked(profileId))
        return false
    file := PrimaIdentityPath(profileId)
    sub := IniRead(file, "identity", "selected_sub_universe", "")
    form := IniRead(file, "identity", "selected_form", "")
    if (sub != "" && form != "")
        return false
    universe := IniRead(file, "identity", "selected_universe", "")
    territory := IniRead(file, "identity", "selected_territory", "")
    if (universe = "" || territory = "")
        return false
    sources := ReadPrimaResultSources(profileId)
    if (sub = "")
        sub := ComputeSubUniverse(universe, sources.soul_main, sources.shadow_main, sources.shadow_emotion)
    if (form = "")
        form := ComputePrimaForm(universe, sub, territory, sources.vda_base, sources.shadow_main, sources.soul_main)
    SavePrimaIdentityComplete(profileId, universe, territory, sources, sub, form)
    WriteLog("prima_identity_completed", profileId)
    return true
}

MarkSoulCycleIdentityChosen(profileId) {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := SoulResultsPath(profileId)
    IniWrite("1", file, "global", "universe_chosen")
    IniWrite("1", file, "global", "cycle_complete")
    IniWrite("1", file, "global", "results_read")
}

; Écran architecture verrouillée — redirige vers identité PRIMA complète.
BuildPrimaArchitectureLocked() {
    BuildPrimaIdentityResult()
}

OpenPrimaIdentityResult(*) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    if !IsPrimaArchitectureLocked(CURRENT_PROFILE_ID) {
        SoulReadingUniverseClicked()
        return
    }
    CompletePrimaIdentityIfMissing(CURRENT_PROFILE_ID)
    ValidateAndFixPrimaIdentityFile(CURRENT_PROFILE_ID)
    WriteLog("prima_identity_result_opened", CURRENT_PROFILE_ID)
    RenderScreen("prima_identity_result")
}

; Alias historique — même écran identité PRIMA.
OpenPrimaArchitectureView(*) {
    OpenPrimaIdentityResult()
}

BuildPrimaIdentityResult() {
    global CURRENT_PROFILE_ID, MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H
    global CLR_ACCENT, CLR_TEXT, CLR_SUBTEXT, GAP_LG
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    if !IsPrimaArchitectureLocked(CURRENT_PROFILE_ID) {
        RenderScreen("soul_reading_hub")
        return
    }
    CompletePrimaIdentityIfMissing(CURRENT_PROFILE_ID)
    ValidateAndFixPrimaIdentityFile(CURRENT_PROFILE_ID)
    id := ReadPrimaIdentity(CURRENT_PROFILE_ID)
    sources := id.sources
    if (sources.soul_main = "")
        sources := ReadPrimaResultSources(CURRENT_PROFILE_ID)
    g := NewGui()
    AddScrollPageHeader(g, TIcon("identity_result_title"), T("identity_result_intro"), "")
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, SCROLL_VIEWPORT_H)
    contentY := 8
    contentY := AddScrollResultSectionHeader(cg, contentY, "identity_sec_architecture")
    contentY := AddScrollResultSection(cg, contentY, "lbl_universe_chosen"
        , PrimaUniverseDisplayNameWithIcon(id.universe))
    contentY := AddScrollResultSection(cg, contentY, "lbl_territory_chosen"
        , PrimaTerritoryDisplayNameWithIcon(id.territory))
    if (id.architecture_label != "")
        contentY := AddScrollResultSection(cg, contentY, "identity_arch_label", id.architecture_label)
    contentY := AddScrollResultSectionHeader(cg, contentY, "identity_sec_climate")
    if (id.sub_universe_name != "")
        contentY := AddScrollResultSection(cg, contentY, "identity_lbl_sub_universe", id.sub_universe_name)
    contentY := AddScrollResultSectionHeader(cg, contentY, "identity_sec_form")
    if (id.form != "")
        contentY := AddScrollResultSection(cg, contentY, "identity_lbl_form", id.form)
    contentY := AddScrollResultSection(cg, contentY, "identity_lbl_form_link", T("identity_form_link"))
    if (id.identity_label != "")
        contentY := AddScrollResultSection(cg, contentY, "identity_lbl_full", id.identity_label)
    contentY := AddScrollResultSectionHeader(cg, contentY, "identity_sec_reading")
    tone := (id.language_tone != "") ? id.language_tone : GetUniverseLanguageTone(id.universe)
    if (tone != "")
        contentY := AddScrollResultSection(cg, contentY, "identity_lbl_universe_tone", tone)
    focus := (id.territory_focus != "") ? id.territory_focus : GetTerritoryLanguageFocus(id.territory)
    if (focus != "")
        contentY := AddScrollResultSection(cg, contentY, "identity_lbl_territory_focus", focus)
    domLine := BuildPrimaDominantReadingLine(sources)
    if (domLine != "")
        contentY := AddScrollResultSection(cg, contentY, "identity_lbl_dominant", domLine)
    summary := (id.identity_summary != "") ? id.identity_summary
        : BuildPrimaIdentitySummary(sources, id.universe, id.territory)
    if (summary != "")
        contentY := AddScrollResultSection(cg, contentY, "identity_lbl_summary", summary)
    cg.SetFont("s10 Italic c" CLR_SUBTEXT, "Segoe UI")
    pad := 12
    w := CONTENT_W - 2 * pad
    disclaimer := T("identity_result_disclaimer")
    hDisc := ScrollTextHeight(disclaimer, w)
    cg.Add("Text", "x" pad " y" contentY " w" w " h" hDisc " +0x2000 BackgroundTrans", disclaimer)
    AddArchitectureLockedFooter(g, IdentityResultBack, SoulRedoTestsClicked)
    ShowScreen()
}

IdentityResultBack(*) {
    global UNIVERSE_BACK_SCREEN
    if (UNIVERSE_BACK_SCREEN = "prima_soul_intro")
        RenderScreen("prima_soul_intro")
    else
        RenderScreen("soul_reading_hub")
}

AddArchitectureLockedFooter(g, backAction, redoAction) {
    global SCROLL_FOOTER_Y, TEST_NAV_BTN_W, TEST_NAV_GAP, BUTTON_H, MARGIN_X, CONTENT_W
    totalW := 2 * TEST_NAV_BTN_W + TEST_NAV_GAP
    startX := MARGIN_X + (CONTENT_W - totalW) // 2
    btnBack := g.Add("Button", "x" startX " y" SCROLL_FOOTER_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_back"))
    btnBack.OnEvent("Click", backAction)
    xRedo := startX + TEST_NAV_BTN_W + TEST_NAV_GAP
    btnRedo := g.Add("Button", "x" xRedo " y" SCROLL_FOOTER_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_redo_tests"))
    btnRedo.OnEvent("Click", redoAction)
}

ArchitectureLockedBack(*) {
    IdentityResultBack()
}

JoinPrimaKeys(arr) {
    if !IsObject(arr)
        return ""
    s := ""
    for k in arr
        s .= (s = "" ? "" : ",") k
    return s
}

SavePrimaIdentity(profileId, universe, territory) {
    SavePrimaIdentityComplete(profileId, universe, territory)
}

; Sauvegarde identité PRIMA complète dans prima_identity.ini (compatible ancien format).
SavePrimaIdentityComplete(profileId, universe, territory, sources := "", subKey := "", form := "") {
    global PRIMA_UNI_SUGGESTED, PRIMA_TERR_SUGGESTED
    if (profileId = "" || universe = "" || territory = "")
        return
    if (sources = "")
        sources := ReadPrimaResultSources(profileId)
    if (subKey = "")
        subKey := ComputeSubUniverse(universe, sources.soul_main, sources.shadow_main, sources.shadow_emotion)
    if (form = "")
        form := ComputePrimaForm(universe, subKey, territory, sources.vda_base, sources.shadow_main, sources.soul_main)
    coh := ValidatePrimaIdentityCoherence({
        universe: universe, territory: territory, sub_universe: subKey, form: form, identity_label: ""
    })
    if (coh.fixed) {
        universe := coh.universe
        territory := coh.territory
        subKey := coh.sub_universe
        form := coh.form
        WriteLog("prima_identity_coherence_fixed", profileId " | on_save")
    }
    subName := PrimaSubUniverseName(subKey)
    archLabel := PrimaUniverseName(universe) " / " PrimaTerritoryName(territory)
    idLabel := form " — " subName
    uniTone := GetUniverseLanguageTone(universe)
    terrFocus := GetTerritoryLanguageFocus(territory)
    idSummary := BuildPrimaIdentitySummary(sources, universe, territory)
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := PrimaIdentityPath(profileId)
    IniWrite(universe, file, "identity", "selected_universe")
    IniWrite(territory, file, "identity", "selected_territory")
    IniWrite(subKey, file, "identity", "selected_sub_universe")
    IniWrite(form, file, "identity", "selected_form")
    IniWrite(archLabel, file, "identity", "architecture_label")
    IniWrite(idLabel, file, "identity", "identity_label")
    IniWrite(idSummary, file, "identity", "identity_summary")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm"), file, "identity", "date")
    IniWrite("0.1", file, "identity", "version")
    IniWrite("1", file, "identity", "locked")
    IniWrite(uniTone, file, "language", "universe_tone")
    IniWrite(terrFocus, file, "language", "territory_focus")
    IniWrite("7408800", file, "engine", "visible_total")
    IniWrite("22226400", file, "engine", "fine_total")
    IniWrite("66679200", file, "engine", "narrative_total")
    IniWrite("76814438400000", file, "engine", "internal_total_49")
    IniWrite("230443315200000", file, "engine", "internal_total_147")
    IniWrite("691329945600000", file, "engine", "internal_total_441")
    IniWrite(sources.soul_main, file, "sources", "soul_main")
    IniWrite(sources.soul_secondary, file, "sources", "soul_secondary")
    IniWrite(sources.vda_base, file, "sources", "vda_base")
    IniWrite(sources.vda_phase, file, "sources", "vda_phase")
    IniWrite(sources.shadow_main, file, "sources", "shadow_main")
    IniWrite(sources.shadow_emotion, file, "sources", "shadow_emotion")
    IniWrite(JoinPrimaKeys(PRIMA_UNI_SUGGESTED), file, "suggestions", "universes")
    IniWrite(JoinPrimaKeys(PRIMA_TERR_SUGGESTED), file, "suggestions", "territories")
    MarkSoulCycleIdentityChosen(profileId)
    WriteLog("prima_identity_saved", profileId " | " universe "/" territory " | " subKey " | " form)
}

; ── Écran choix Univers ────────────────────────────────────────────────────────
BuildPrimaUniverseChoice() {
    BuildPrimaPagedChoiceScreen("universe")
}

UniversePrevPage(*) {
    global PRIMA_UNI_PAGE
    if (PRIMA_UNI_PAGE > 1) {
        PRIMA_UNI_PAGE -= 1
        RenderScreen("prima_universe_choice")
    }
}

UniverseNextPage(*) {
    global PRIMA_UNI_PAGE
    if (PRIMA_UNI_PAGE < 3) {
        PRIMA_UNI_PAGE += 1
        RenderScreen("prima_universe_choice")
    }
}

UniverseChoiceBack(backScreen, *) {
    RenderScreen(backScreen)
}

SelectPrimaUniverse(key, *) {
    global CURRENT_PROFILE_ID, PRIMA_SELECTED_UNIVERSE, PRIMA_TERR_PAGE
    if (CURRENT_PROFILE_ID != "" && IsPrimaArchitectureLocked(CURRENT_PROFILE_ID)) {
        OpenPrimaIdentityResult()
        return
    }
    PRIMA_SELECTED_UNIVERSE := key
    PRIMA_TERR_PAGE := 1
    WriteLog("prima_universe_selected", CURRENT_PROFILE_ID " | " key)
    RenderScreen("prima_territory_choice")
}

; ── Écran choix Territoire ─────────────────────────────────────────────────────
BuildPrimaTerritoryChoice() {
    BuildPrimaPagedChoiceScreen("territory")
}

TerritoryPrevPage(*) {
    global PRIMA_TERR_PAGE
    if (PRIMA_TERR_PAGE > 1) {
        PRIMA_TERR_PAGE -= 1
        RenderScreen("prima_territory_choice")
    }
}

TerritoryNextPage(*) {
    global PRIMA_TERR_PAGE
    if (PRIMA_TERR_PAGE < 3) {
        PRIMA_TERR_PAGE += 1
        RenderScreen("prima_territory_choice")
    }
}

TerritoryChoiceBack(*) {
    global PRIMA_UNI_PAGE
    PRIMA_UNI_PAGE := 1
    RenderScreen("prima_universe_choice")
}

BuildPrimaPagedChoiceScreen(mode) {
    global CURRENT_PROFILE_ID, PRIMA_UNI_SUGGESTED, PRIMA_TERR_SUGGESTED
    global PRIMA_UNI_PAGE, PRIMA_TERR_PAGE, PRIMA_SELECTED_UNIVERSE, UNIVERSE_BACK_SCREEN
    global MARGIN_X, CONTENT_W, PAGED_CHOICE_PAGE_Y, CLR_BG, CLR_ACCENT

    if (CURRENT_PROFILE_ID != "" && IsPrimaArchitectureLocked(CURRENT_PROFILE_ID)) {
        RenderScreen("prima_architecture_locked")
        return
    }

    total := 3
    if (mode = "universe") {
        if (CURRENT_PROFILE_ID = "") {
            RenderScreen("prima_soul_intro")
            return
        }
        PRIMA_UNI_SUGGESTED := ComputeSuggestedPrimaUniverses(CURRENT_PROFILE_ID)
        WriteLog("prima_universe_suggestions", JoinPrimaKeys(PRIMA_UNI_SUGGESTED))
        WriteLog("prima_universe_choice_opened", CURRENT_PROFILE_ID)
        page := Max(1, Min(total, PRIMA_UNI_PAGE))
        PRIMA_UNI_PAGE := page
        roles := ["uni_role_main", "uni_role_bridge", "uni_role_secondary"]
        key := PRIMA_UNI_SUGGESTED[page]
        screenTitle := TIcon("btn_choose_universe")
        guide1 := T("uni_choice_1")
        guide2 := T("uni_choice_2")
        onPick := SelectPrimaUniverse.Bind(key)
        onDetail := OpenUniverseDetail.Bind(key)
        onPrev := UniversePrevPage
        onNext := UniverseNextPage
        backScreen := (UNIVERSE_BACK_SCREEN != "") ? UNIVERSE_BACK_SCREEN : "soul_reading_hub"
        onBack := UniverseChoiceBack.Bind(backScreen)
        cardIcon := PrimaUniverseIcon(key)
        cardName := PrimaUniverseName(key)
        cardDesc := PrimaUniverseDesc(key)
    } else {
        if (CURRENT_PROFILE_ID = "" || PRIMA_SELECTED_UNIVERSE = "") {
            RenderScreen("soul_reading_hub")
            return
        }
        PRIMA_TERR_SUGGESTED := ComputeSuggestedPrimaTerritories(CURRENT_PROFILE_ID, PRIMA_SELECTED_UNIVERSE)
        WriteLog("prima_territory_suggestions", JoinPrimaKeys(PRIMA_TERR_SUGGESTED))
        WriteLog("prima_territory_choice_opened", CURRENT_PROFILE_ID)
        page := Max(1, Min(total, PRIMA_TERR_PAGE))
        PRIMA_TERR_PAGE := page
        roles := ["terr_role_main", "terr_role_bridge", "terr_role_secondary"]
        key := PRIMA_TERR_SUGGESTED[page]
        screenTitle := TIcon("terr_choice_title")
        guide1 := T("terr_choice_1")
        guide2 := T("terr_choice_2")
        onPick := SelectPrimaTerritory.Bind(key)
        onDetail := OpenTerritoryDetail.Bind(key)
        onPrev := TerritoryPrevPage
        onNext := TerritoryNextPage
        onBack := TerritoryChoiceBack
        cardIcon := PrimaTerritoryIcon(key)
        cardName := PrimaTerritoryName(key)
        cardDesc := PrimaTerritoryDesc(key)
    }

    g := NewGui()
    AddChoiceScreenHeader(g, screenTitle, guide1, guide2)
    g.SetFont("s12 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" PAGED_CHOICE_PAGE_Y " w" CONTENT_W " h24 Center Background" CLR_BG
        , T("choice_piste_of", page, total) " — " T(roles[page]))
    AddPagedChoiceCard(g, cardIcon, cardName, cardDesc, onDetail)
    AddPagedChoiceNavRow(g, page, total, onPrev, onNext)
    pickLabel := (mode = "universe") ? TIcon("btn_pick_universe") : TIcon("btn_pick_territory")
    AddChoiceNavBackPick(g, onBack, onPick, pickLabel)
    ShowScreen()
}

OpenUniverseDetail(key, *) {
    global PRIMA_DETAIL_UNI_KEY
    PRIMA_DETAIL_UNI_KEY := key
    RenderScreen("prima_universe_detail")
}

OpenTerritoryDetail(key, *) {
    global PRIMA_DETAIL_TERR_KEY
    PRIMA_DETAIL_TERR_KEY := key
    RenderScreen("prima_territory_detail")
}

BuildPrimaUniverseDetail() {
    global PRIMA_DETAIL_UNI_KEY, MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H
    global CLR_ACCENT, CLR_TEXT, CLR_SUBTEXT
    key := PRIMA_DETAIL_UNI_KEY
    if (key = "") {
        RenderScreen("prima_universe_choice")
        return
    }
    ill := GetPrimaUniverseIllustration(key)
    g := NewGui()
    AddScrollPageHeader(g, T("uni_detail_title"), "", "")
    detailScrollH := SCROLL_VIEWPORT_H - 55
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, detailScrollH)
    y := 8
    cg.SetFont("s48", "Segoe UI")
    cg.Add("Text", "x12 y" y " w" (CONTENT_W - 24) " h56 Center BackgroundTrans", PrimaUniverseIcon(key))
    y += 60
    cg.SetFont("s18 Bold c" CLR_ACCENT, "Segoe UI")
    cg.Add("Text", "x12 y" y " w" (CONTENT_W - 24) " h28 Center BackgroundTrans", PrimaUniverseName(key))
    y += 36
    y := AddScrollDetailBlock(cg, y, T("lbl_long_desc"), PrimaUniverseDescLong(key))
    y := AddScrollDetailBlock(cg, y, T("lbl_theme"), PrimaUniverseTheme(key))
    y := AddScrollDetailBlock(cg, y, T("lbl_signals"), PrimaUniverseSignals(key))
    y := AddScrollDetailBlock(cg, y, T("lbl_user_phrase"), PrimaUniverseUserPhrase(key))
    y := AddScrollIllustrationPlaceholder(cg, y, ill["illustration_key"], ill["illustration_path"])
    cg.SetFont("s10 Italic c" CLR_SUBTEXT, "Segoe UI")
    hCaution := ScrollTextHeight(T("uni_caution"), CONTENT_W - 24)
    cg.Add("Text", "x12 y" y " w" (CONTENT_W - 24) " h" hCaution " +0x2000 BackgroundTrans", T("uni_caution"))
    AddChoiceDetailFooter(g, TIcon("btn_pick_universe"), SelectPrimaUniverse.Bind(key), UniverseDetailBack)
    ShowScreen()
}

UniverseDetailBack(*) {
    RenderScreen("prima_universe_choice")
}

BuildPrimaTerritoryDetail() {
    global PRIMA_DETAIL_TERR_KEY, MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H
    global CLR_ACCENT, CLR_SUBTEXT
    key := PRIMA_DETAIL_TERR_KEY
    if (key = "") {
        RenderScreen("prima_territory_choice")
        return
    }
    ill := GetPrimaTerritoryIllustration(key)
    g := NewGui()
    AddScrollPageHeader(g, T("terr_detail_title"), "", "")
    detailScrollH := SCROLL_VIEWPORT_H - 55
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, detailScrollH)
    y := 8
    cg.SetFont("s48", "Segoe UI")
    cg.Add("Text", "x12 y" y " w" (CONTENT_W - 24) " h56 Center BackgroundTrans", PrimaTerritoryIcon(key))
    y += 60
    cg.SetFont("s18 Bold c" CLR_ACCENT, "Segoe UI")
    cg.Add("Text", "x12 y" y " w" (CONTENT_W - 24) " h28 Center BackgroundTrans", PrimaTerritoryName(key))
    y += 36
    y := AddScrollDetailBlock(cg, y, T("lbl_long_desc"), PrimaTerritoryDescLong(key))
    y := AddScrollDetailBlock(cg, y, T("lbl_theme"), PrimaTerritoryTheme(key))
    y := AddScrollDetailBlock(cg, y, T("lbl_inner_question"), PrimaTerritoryInnerQuestion(key))
    y := AddScrollIllustrationPlaceholder(cg, y, ill["illustration_key"], ill["illustration_path"])
    cg.SetFont("s10 Italic c" CLR_SUBTEXT, "Segoe UI")
    hCaution := ScrollTextHeight(T("terr_caution"), CONTENT_W - 24)
    cg.Add("Text", "x12 y" y " w" (CONTENT_W - 24) " h" hCaution " +0x2000 BackgroundTrans", T("terr_caution"))
    AddChoiceDetailFooter(g, TIcon("btn_pick_territory"), SelectPrimaTerritory.Bind(key), TerritoryDetailBack)
    ShowScreen()
}

TerritoryDetailBack(*) {
    RenderScreen("prima_territory_choice")
}

SelectPrimaTerritory(key, *) {
    global CURRENT_PROFILE_ID, PRIMA_SELECTED_UNIVERSE, PRIMA_SELECTED_TERRITORY
    if (CURRENT_PROFILE_ID != "" && IsPrimaArchitectureLocked(CURRENT_PROFILE_ID)) {
        OpenPrimaIdentityResult()
        return
    }
    PRIMA_SELECTED_TERRITORY := key
    WriteLog("prima_territory_selected", CURRENT_PROFILE_ID " | " key)
    SavePrimaIdentity(CURRENT_PROFILE_ID, PRIMA_SELECTED_UNIVERSE, key)
    RenderScreen("prima_identity_result")
}

; ── Écran confirmation architecture ────────────────────────────────────────────
BuildPrimaIdentitySaved() {
    OpenPrimaIdentityResult()
}

BuildPrimaSoulSettings() {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    g := NewGui()
    AddScreenHeader(g, TIcon("soul_settings_title"), T("soul_settings_dev_hint"))
    AddSpacer(g, GAP_LG)
    AddButton(g, TIcon("btn_redo_tests"), SoulRedoTestsClicked)
    AddNavBackQuit(g, (*) => RenderScreen("prima_soul_intro"), (*) => ConfirmExit("quit"))
    ShowScreen()
}

; ── PRIMA Soul — classement visible simple (5 réponses) ─────────────────────
; TODO futur : questions contextualisées par environnement relationnel.
global SOUL_PICKS := []
global SOUL_VISIBLE_BTNS := []
global SOUL_VISIBLE_TEXTS := []
global SOUL_VISIBLE_PICKS := []
global SOUL_ANSWER_BTNS := []

BindSoulButton(btn, idx) {
    btn.OnEvent("Click", SoulButtonClicked.Bind(idx))
}

SoulButtonClicked(idx, ctrl, *) {
    global SOUL_VISIBLE_TEXTS, SOUL_VISIBLE_PICKS, CLR_ACCENT
    idx := Integer(idx)
    if (idx < 1 || idx > SOUL_VISIBLE_TEXTS.Length)
        return
    for _, pickedIdx in SOUL_VISIBLE_PICKS {
        if (pickedIdx = idx)
            return
    }
    if (SOUL_VISIBLE_PICKS.Length >= SOUL_VISIBLE_TEXTS.Length)
        return
    SOUL_VISIBLE_PICKS.Push(idx)
    rank := SOUL_VISIBLE_PICKS.Length
    if IsObject(ctrl) {
        ctrl.Text := PrimaRankPrefix(rank) SOUL_VISIBLE_TEXTS[idx]
        ctrl.SetFont("s11 Bold c" CLR_ACCENT, "Segoe UI")
    }
    SyncSoulVisiblePicksToRanking()
}

SyncSoulVisiblePicksToRanking() {
    global SOUL_VISIBLE_PICKS, SOUL_PICKS
    q := GetCurrentQuestion("prima_soul")
    SOUL_PICKS := []
    if !IsObject(q)
        return
    for _, idx in SOUL_VISIBLE_PICKS {
        if (idx >= 1 && idx <= q.answers.Length)
            SOUL_PICKS.Push(q.answers[idx].id)
    }
}

BuildPrimaSoulQuestion() {
    global SOUL_SESSION, SOUL_PICKS, SOUL_VISIBLE_BTNS, SOUL_VISIBLE_TEXTS, SOUL_VISIBLE_PICKS, SOUL_ANSWER_BTNS
    session := GetActiveTestSession("prima_soul")
    if (!IsObject(session) || session.completed) {
        HandleInvalidTestSession("prima_soul", "build_soul_question")
        return
    }
    q := GetCurrentQuestion("prima_soul")
    if !IsObject(q) {
        HandleInvalidTestSession("prima_soul", "build_soul_no_question")
        return
    }
    SOUL_PICKS := []
    SOUL_VISIBLE_PICKS := []
    SOUL_VISIBLE_BTNS := []
    SOUL_VISIBLE_TEXTS := []
    g := NewGui()
    rankHint := TIcon("msg_rank_all_5") " — " T("vda_rank_hint_top") " · " T("rank_hint_least")
    guidance := TestGuidanceHint("prima_soul", session.current_index)
    answersY := AddTestQuestionHeader(g, TIcon("soul_test_title")
        , TIcon("vda_question_of", session.current_index, session.questions.Length)
        , q.prompt, guidance, rankHint)
    texts := []
    for a in q.answers
        texts.Push(a.text)
    SOUL_VISIBLE_TEXTS := texts
    answerUi := AddVisibleRankAnswerButtons(g, texts, answersY)
    SOUL_VISIBLE_BTNS := answerUi.buttons
    loop SOUL_VISIBLE_BTNS.Length
        BindSoulButton(SOUL_VISIBLE_BTNS[A_Index], A_Index)
    SOUL_ANSWER_BTNS := SOUL_VISIBLE_BTNS
    AddFixedTestNav(g, SoulRankNextQuestion, answerUi.navY)
    ShowScreen()
}

; Pendant un test actif, aucun retour au hub n'est autorisé.
SoulBackFromQuestion(*) {
    MsgBox(T("msg_finish_or_quit"), APP_TITLE, "Icon!")
}

SoulRankAnswerClick(idx, ctrl := "", *) {
    global SOUL_VISIBLE_BTNS
    if IsObject(ctrl)
        SoulButtonClicked(idx, ctrl)
    else if (idx >= 1 && idx <= SOUL_VISIBLE_BTNS.Length)
        SoulButtonClicked(idx, SOUL_VISIBLE_BTNS[idx])
}

SoulRankNextQuestion(*) {
    global SOUL_SESSION, SOUL_PICKS, CURRENT_PROFILE_ID, SOUL_VISIBLE_PICKS
    SyncSoulVisiblePicksToRanking()
    session := GetActiveTestSession("prima_soul")
    if (!IsObject(session) || session.completed) {
        HandleInvalidTestSession("prima_soul", "soul_next")
        return
    }
    q := GetCurrentQuestion("prima_soul")
    if !IsObject(q) {
        HandleInvalidTestSession("prima_soul", "soul_next_no_question")
        return
    }
    if (SOUL_VISIBLE_PICKS.Length != q.answers.Length) {
        MsgBox(T(GetRankingIncompleteMsgKey(q.answers.Length)), APP_TITLE, "Icon!")
        return
    }
    if !IsRankingComplete("soul", q, SOUL_PICKS) {
        MsgBox(T(GetRankingIncompleteMsgKey(q.answers.Length)), APP_TITLE, "Icon!")
        return
    }
    ranks := BuildRankingFromPicks(q, SOUL_PICKS)
    errKey := ValidateAnswerRanking(ranks, q.answers.Length, GetRankingIncompleteMsgKey(q.answers.Length))
    if (errKey != "") {
        MsgBox(T(errKey), APP_TITLE, "Icon!")
        return
    }
    VdaSessionRecordRanking(SOUL_SESSION, q.id, ranks)
    WriteLog("soul_question_ranked", q.id)
    SaveSoulSessionState()
    if (SOUL_SESSION.completed) {
        WriteLog("soul_run_completed", "prima_soul | " SOUL_SESSION.rankings.Length)
        if (CURRENT_PROFILE_ID != "") {
            MarkSoulTestCompleted(CURRENT_PROFILE_ID, "prima_soul")
            result := ComputeSoulMainTendencies(SOUL_SESSION)
            WriteLog("soul_result_built", CURRENT_PROFILE_ID)
            SaveSoulTestResult(CURRENT_PROFILE_ID, result.main, result.second, result.totals)
        }
        RenderScreen("prima_soul_done")
    } else {
        RenderScreen("prima_soul_question")
    }
}

; Fin Soul : pas de résultat détaillé immédiat.
BuildPrimaSoulDone() {
    BuildPrimaTestDoneScreen("soul_test_title")
}

BuildPrimaVdaDone() {
    BuildPrimaTestDoneScreen("vda_test_title")
}

SoulChooseByCode(ddl, codes, savedCode) {
    if (savedCode != "") {
        loop codes.Length {
            if (codes[A_Index] = savedCode) {
                ddl.Choose(A_Index)
                return
            }
        }
    }
    ddl.Choose(1)
}

AddSoulChoice(g, key, savedCode) {
    AddSubtitle(g, T("soul_" key))
    AddSpacer(g, 3)
    ddl := g.Add("DropDownList", "w880 Background" CLR_PANEL " c" CLR_TEXT, GetSoulChoiceLabels(key))
    SoulChooseByCode(ddl, GetSoulChoiceCodes()[key], savedCode)
    return ddl
}

BuildPrimaSoulChoices() {
    global CURRENT_PROFILE_ID
    global SOUL_TONE, SOUL_RHYTHM, SOUL_ENERGY, SOUL_NEED, SOUL_REST
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        RenderScreen("profile")
        return
    }
    g := NewGui()
    AddTitle(g, T("prima_soul_intro_title"), 20)
    AddSpacer(g, 4)
    AddSubtitle(g, T("prima_soul_guide"))
    AddSpacer(g, 8)
    SOUL_TONE := AddSoulChoice(g, "tone", LoadSoulChoice(CURRENT_PROFILE_ID, "tone"))
    AddSpacer(g, 6)
    SOUL_RHYTHM := AddSoulChoice(g, "rhythm", LoadSoulChoice(CURRENT_PROFILE_ID, "rhythm"))
    AddSpacer(g, 6)
    SOUL_ENERGY := AddSoulChoice(g, "energy", LoadSoulChoice(CURRENT_PROFILE_ID, "energy"))
    AddSpacer(g, 6)
    SOUL_NEED := AddSoulChoice(g, "need", LoadSoulChoice(CURRENT_PROFILE_ID, "need"))
    AddSpacer(g, 6)
    SOUL_REST := AddSoulChoice(g, "rest", LoadSoulChoice(CURRENT_PROFILE_ID, "rest"))
    AddSpacer(g, 10)
    AddButton(g, TIcon("btn_soul_save_goals"), PrimaSoulSave)
    AddSpacer(g, 4)
    AddButton(g, TIcon("btn_back"), (*) => RenderScreen("prima_soul_intro"))
    AddSpacer(g, 4)
    AddButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    ShowScreen()
}

PrimaSoulSave(*) {
    global CURRENT_PROFILE_ID, SOUL_TONE, SOUL_RHYTHM, SOUL_ENERGY, SOUL_NEED, SOUL_REST
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        RenderScreen("profile")
        return
    }
    codes := GetSoulChoiceCodes()
    tone := codes["tone"][SOUL_TONE.Value ? SOUL_TONE.Value : 1]
    rhythm := codes["rhythm"][SOUL_RHYTHM.Value ? SOUL_RHYTHM.Value : 1]
    energy := codes["energy"][SOUL_ENERGY.Value ? SOUL_ENERGY.Value : 1]
    need := codes["need"][SOUL_NEED.Value ? SOUL_NEED.Value : 1]
    rest := codes["rest"][SOUL_REST.Value ? SOUL_REST.Value : 1]
    SaveSoulChoices(CURRENT_PROFILE_ID, tone, rhythm, energy, need, rest)
    WriteLog("prima_soul_saved", CURRENT_PROFILE_ID)
    WriteProfileLog(CURRENT_PROFILE_ID, "prima_soul_saved")
    RenderScreen("onboarding_goals")
}

BuildOnboarding() {
    g := NewFormGui()
    AddFormTitle(g, TIcon("btn_onboarding"))
    AddFormGap(g, 6)
    AddFormBodyText(g, T("onboarding_body"))
    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_continue"), (*) => RenderScreen("personal_base"))
    AddFormNavBackQuit(g, (*) => RenderScreen("home"))
    ShowFormGui()
}

BuildPersonalBase() {
    g := NewFormGui()
    AddFormTitle(g, T("personal_base_title"))
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("base_kit_prima"), ShowModuleLater)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("base_prima_soul"), PersonalBaseOpenPrimaSoulIntro)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_goals"), OpenGoalsFromPersonalBase)
    AddFormGap(g, 4)
    AddFormButton(g, T("btn_proof"), ShowModuleLater)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_review"), HomeOpenReview)
    AddFormNavBackQuit(g, (*) => RenderScreen("onboarding"))
    ShowFormGui()
}

BuildOnboardingGoals() {
    global CURRENT_PROFILE_ID, GOALS_DOMAIN_IDX, GOALS_DOMAIN_DDL, GOAL_SHORT, GOAL_MEDIUM, GOAL_LONG, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    if (CURRENT_PROFILE_ID = "")
        return
    if (GOALS_DOMAIN_IDX < 1)
        GOALS_DOMAIN_IDX := 1
    code := GetDomainCodes()[GOALS_DOMAIN_IDX]
    data := LoadDomainGoals(CURRENT_PROFILE_ID, code)
    g := NewFormGui()
    AddFormTitle(g, TIcon("goals_title"))
    AddFormGap(g, 4)
    AddFormLabel(g, T("goal_domain"))
    GOALS_DOMAIN_DDL := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, GetDomainLabels())
    GOALS_DOMAIN_DDL.Choose(GOALS_DOMAIN_IDX)
    GOALS_DOMAIN_DDL.OnEvent("Change", GoalsDomainChange)
    AddFormGap(g, 4)
    AddFormLabel(g, T("dur_short") . " — " T("dur_short_hint"))
    GOAL_SHORT := g.Add("Edit", "w" FORM_FIELD_W " h22 Background" CLR_PANEL " c" CLR_TEXT, data.short)
    AddFormGap(g, 3)
    AddFormLabel(g, T("dur_medium") . " — " T("dur_medium_hint"))
    GOAL_MEDIUM := g.Add("Edit", "w" FORM_FIELD_W " h22 Background" CLR_PANEL " c" CLR_TEXT, data.medium)
    AddFormGap(g, 3)
    AddFormLabel(g, T("dur_long") . " — " T("dur_long_hint"))
    GOAL_LONG := g.Add("Edit", "w" FORM_FIELD_W " h22 Background" CLR_PANEL " c" CLR_TEXT, data.long)
    AddFormGap(g, 10)
    AddFormButton(g, TIcon("btn_save"), OnboardingDomainSave)
    AddFormNavBackQuit(g, GoalsBack)
    ShowFormGui()
}

OpenGoalsFromPersonalBase(*) {
    global GOALS_BACK_SCREEN
    GOALS_BACK_SCREEN := "personal_base"
    RenderScreen("onboarding_goals")
}

GoalsBack(*) {
    global GOALS_BACK_SCREEN
    RenderScreen(GOALS_BACK_SCREEN)
}

ReviewBack(*) {
    global REVIEW_BACK_SCREEN
    RenderScreen(REVIEW_BACK_SCREEN)
}

BuildReviewBlocked() {
    g := NewFormGui()
    AddFormTitle(g, TIcon("review_title"))
    AddFormGap(g, 8)
    AddFormBodyText(g, PrimaLabelWithIcon("no_result", T("review_no_goals")))
    AddFormNavBackQuit(g, ReviewBack)
    ShowFormGui()
}

ReviewDomainChange(*) {
    global REVIEW_DOMAIN, REVIEW_SELECTED_DOMAIN_IDX
    REVIEW_SELECTED_DOMAIN_IDX := REVIEW_DOMAIN.Value
    RenderScreen("review")
}

BuildReview() {
    global CURRENT_PROFILE_ID, REVIEW_SELECTED_DOMAIN_IDX, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    domainsWithGoals := GetDomainsWithGoals(CURRENT_PROFILE_ID)
    if (domainsWithGoals.Length = 0) {
        BuildReviewBlocked()
        return
    }
    if (REVIEW_SELECTED_DOMAIN_IDX > domainsWithGoals.Length)
        REVIEW_SELECTED_DOMAIN_IDX := 1
    selectedCode := domainsWithGoals[REVIEW_SELECTED_DOMAIN_IDX]
    domainGoals := GetGoalsForDomain(CURRENT_PROFILE_ID, selectedCode)

    g := NewFormGui()
    AddFormTitle(g, TIcon("review_title"))
    AddFormGap(g, 4)
    AddFormLabel(g, T("review_mood"))
    global REVIEW_MOOD
    REVIEW_MOOD := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, GetMoodLabels())
    REVIEW_MOOD.Choose(1)
    AddFormGap(g, 3)
    AddFormLabel(g, T("review_energy"))
    global REVIEW_ENERGY
    REVIEW_ENERGY := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, GetEnergyLabels())
    REVIEW_ENERGY.Choose(1)
    AddFormGap(g, 3)
    AddFormLabel(g, T("review_domain"))
    global REVIEW_DOMAIN, REVIEW_DOMAIN_GOALS
    domainLabels := []
    for code in domainsWithGoals
        domainLabels.Push(GetDomainLabelForCode(code))
    REVIEW_DOMAIN := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, domainLabels)
    REVIEW_DOMAIN.Choose(REVIEW_SELECTED_DOMAIN_IDX)
    REVIEW_DOMAIN.OnEvent("Change", ReviewDomainChange)
    AddFormGap(g, 3)
    AddFormLabel(g, T("review_did"))
    global REVIEW_DID
    REVIEW_DOMAIN_GOALS := domainGoals
    if (domainGoals.Length = 0) {
        REVIEW_DID := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, [T("review_no_domain_goals")])
        REVIEW_DID.Choose(1)
    } else {
        didLabels := []
        for goal in domainGoals
            didLabels.Push(goal.durationLabel . " — " . goal.title)
        REVIEW_DID := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, didLabels)
        REVIEW_DID.Choose(1)
    }
    AddFormGap(g, 3)
    AddFormLabel(g, T("review_improve"))
    global REVIEW_IMPROVE
    REVIEW_IMPROVE := g.Add("Edit", "w" FORM_FIELD_W " h22 Multi Background" CLR_PANEL " c" CLR_TEXT, "")
    AddFormGap(g, 3)
    AddFormLabel(g, T("review_note"))
    global REVIEW_NOTE
    REVIEW_NOTE := g.Add("Edit", "w" FORM_FIELD_W " h22 Multi Background" CLR_PANEL " c" CLR_TEXT, "")
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("btn_save"), ReviewSave)
    AddFormNavBackQuit(g, ReviewBack)
    ShowFormGui()
}

ReviewSave(*) {
    global CURRENT_PROFILE_ID, REVIEW_MOOD, REVIEW_ENERGY, REVIEW_DID, REVIEW_IMPROVE, REVIEW_NOTE
    global REVIEW_DOMAIN, REVIEW_SELECTED_DOMAIN_IDX, REVIEW_DOMAIN_GOALS
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        RenderScreen("home")
        return
    }
    moodIdx := REVIEW_MOOD.Value
    energyIdx := REVIEW_ENERGY.Value
    moodLabels := GetMoodLabels()
    moodCodes := GetMoodCodes()
    energyLabels := GetEnergyLabels()
    energyCodes := GetEnergyCodes()
    moodLabel := moodIdx ? moodLabels[moodIdx] : ""
    moodCode := moodIdx ? moodCodes[moodIdx] : ""
    energyLabel := energyIdx ? energyLabels[energyIdx] : ""
    energyCode := energyIdx ? energyCodes[energyIdx] : ""
    domainsWithGoals := GetDomainsWithGoals(CURRENT_PROFILE_ID)
    reviewDomain := ""
    whatDid := ""
    goalTitle := ""
    goalDuration := ""
    if (domainsWithGoals.Length > 0 && REVIEW_DOMAIN_GOALS.Length > 0) {
        selectedCode := domainsWithGoals[REVIEW_SELECTED_DOMAIN_IDX]
        reviewDomain := GetDomainLabelForCode(selectedCode)
        didIdx := REVIEW_DID.Value
        if (didIdx > 0) {
            goal := REVIEW_DOMAIN_GOALS[didIdx]
            whatDid := goal.title
            goalTitle := goal.title
            goalDuration := goal.duration
        }
    }
    SaveReview(moodLabel, moodCode, energyLabel, energyCode, whatDid, REVIEW_IMPROVE.Value, REVIEW_NOTE.Value, reviewDomain, goalTitle, goalDuration)
    WriteLog("review_saved", CURRENT_PROFILE_ID)
}

BuildSettings() {
    global CURRENT_PROFILE_ID, CURRENT_LANG, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    g := NewFormGui()
    AddFormTitle(g, TIcon("settings_title"))
    AddFormGap(g, 6)
    AddFormLabel(g, T("create_lang"))
    global SETTINGS_LANG
    SETTINGS_LANG := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, ["Français", "English"])
    SETTINGS_LANG.Choose(CURRENT_LANG = "en" ? 2 : 1)
    SETTINGS_LANG.OnEvent("Change", SettingsLangChange)
    AddFormGap(g, 4)
    AddFormLabel(g, T("profile_gender_label"))
    gender := (CURRENT_PROFILE_ID != "") ? GetProfileGender(CURRENT_PROFILE_ID) : "unspecified"
    global SETTINGS_GENDER
    SETTINGS_GENDER := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, ProfileGenderOptionLabels())
    SETTINGS_GENDER.Choose(ProfileGenderChoiceIndex(gender))
    SETTINGS_GENDER.OnEvent("Change", SettingsGenderChange)
    AddFormGap(g, 4)
    AddFormBodyText(g, T("profile_gender_note"))
    AddFormNavBackQuit(g, (*) => RenderScreen("home"), false)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    ShowFormGui()
}

SettingsLangChange(*) {
    global SETTINGS_LANG, CURRENT_PROFILE_ID, CURRENT_LANG
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("home")
        return
    }
    lang := (SETTINGS_LANG.Text = "English") ? "en" : "fr"
    SaveProfileLanguage(CURRENT_PROFILE_ID, lang)
    CURRENT_LANG := lang
    RenderScreen("settings")
}

SettingsGenderChange(*) {
    global SETTINGS_GENDER, CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("home")
        return
    }
    gender := ProfileGenderFromChoiceIndex(SETTINGS_GENDER.Value)
    SaveProfileGender(CURRENT_PROFILE_ID, gender)
    WriteLog("profile_gender_changed", CURRENT_PROFILE_ID " | " gender)
    RenderScreen("settings")
}

; ── Hotkeys ───────────────────────────────────────────────────────────────────
PauseApp() {
    global IS_PAUSED
    IS_PAUSED := !IS_PAUSED
    if (IS_PAUSED)
        MsgBox(T("pause_on"), APP_TITLE, "Icon!")
    else
        MsgBox(T("pause_off"), APP_TITLE, "Icon!")
    WriteLog(IS_PAUSED ? "app_paused" : "app_resumed")
}

EmergencyExit() {
    SaveSoulSessionState()
    SaveVdaSessionState()
    SaveShadowSessionState()
    WriteLog("app_emergency_exit")
    CloseCurrentWindow()
    ExitApp()
}

