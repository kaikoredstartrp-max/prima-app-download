#Requires AutoHotkey v2.0
#SingleInstance Force

; PRIMA App V0.1 — Clean Spine Foundation
; Local-only. No network. No cloud. No telemetry.

global APP_VERSION := "V0.1"
global APP_TITLE := "PRIMA App V0.1"
global APP_ROOT := A_ScriptDir
global PROFILES_DIR := APP_ROOT "\profiles"
global ARCHIVE_DIR := APP_ROOT "\archive"
global LOGS_DIR := APP_ROOT "\logs"
global REVIEWS_DIR := APP_ROOT "\reviews"
global PROFILES_INDEX := PROFILES_DIR "\profiles.ini"
global APP_STATE_FILE := PROFILES_DIR "\app_state.ini"
global CURRENT_PROFILE_ID := ""
global CURRENT_DISPLAY_NAME := ""
global CURRENT_LANG := "fr"
global DRAFT_LANG := "fr"
global DRAFT_NAME := ""
global DRAFT_MODE := "client"
global DRAFT_PASSWORD := ""
global DRAFT_PASSWORD_CONFIRM := ""
global PENDING_PROFILE_ID := ""
global CREATOR_CODE := "goat"
global REVIEW_SELECTED_DOMAIN_IDX := 1
global GOALS_DOMAIN_IDX := 1
global PRIMA_SOUL_BACK := "home"
global GOALS_BACK_SCREEN := "personal_base"
global REVIEW_BACK_SCREEN := "home"
global KIT_BACK_SCREEN := "home"
global VDA_BACK_SCREEN := "prima_soul_intro"
global SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
global UNIVERSE_BACK_SCREEN := "soul_reading_hub"
global KIT_AI_DDL
global KIT_STATUS_TEXT
global KIT_LAST_CHECKS := ""
global LAUNCHER_FILE := APP_ROOT "\launch_prima.ahk"
global PRIMA_SHORTCUT_FILE := APP_ROOT "\PRIMA App.lnk"
global AUTOHOTKEY_OFFICIAL_URL := "https://www.autohotkey.com/"
global MAIN_GUI := ""
global ACTIVE_HWND := 0
global CURRENT_SCREEN := ""
global IS_DESTROYING := false
global IS_PAUSED := false

global CLR_BG := "1a1a2e"
global CLR_PANEL := "2d2d44"
global CLR_TEXT := "E8E8E8"
global CLR_SUBTEXT := "B0B0B0"
global CLR_ACCENT := "E94560"

; ── Grille UI PRIMA (géométrie globale — affichage uniquement) ─────────────────
global WINDOW_W := 1050
global WINDOW_H := 760
global FORM_WINDOW_W := 520
global FORM_WINDOW_H := 680
global FORM_MARGIN_X := 80
global FORM_MARGIN_Y := 10
global FORM_FIELD_W := 360
global FORM_BTN_W := 360
global FORM_BTN_H := 30
global MARGIN_X := 48
global MARGIN_Y := 28
global CONTENT_W := 880
global CARD_W := 880
global CARD_H := 128
global BUTTON_W := 880
global BUTTON_H := 38
global BUTTON_H_BIG := 48
global BUTTON_W_PICK := 880
global GAP_X := 12
global GAP_Y := 10
global GAP_SM := 6
global GAP_MD := 12
global GAP_LG := 18
global GAP_XL := 24
global TITLE_H := 36
global TEXT_H := 24
global INPUT_W := 880
global ANSWER_W := 880
global ANSWER_H := 38
global ANSWER_H_LG := 48
; Grille écrans de questions (Soul / VDA / Shadow)
global TEST_TITLE_Y := 40
global TEST_COUNT_Y := 120
global TEST_PROMPT_Y := 165
global TEST_PROMPT_H := 36
global TEST_HINT_Y := 205
global TEST_HINT_H := 26
global TEST_RULE_Y := 238
global TEST_ANSWERS_Y := 245
global TEST_ANSWER_W := 820
global TEST_ANSWER_H_DEF := 46
global TEST_NAV_GAP_AFTER := 28
global TEST_NAV_MAX_Y := 650
global TEST_NAV_BTN_W := 400
global TEST_NAV_GAP := 20
global GAP_TEST_ANSWER := 10
global TEST_ANSWER_MAX_H := 64
; Grille hub PRIMA Soul (2 colonnes × 2 lignes)
global SOUL_HUB_CARD_W := 420
global SOUL_HUB_CARD_H := 90
global SOUL_HUB_GAP := 24
global SOUL_HUB_TITLE_Y := 45
global SOUL_HUB_INTRO_Y := 95
global SOUL_HUB_GRID_Y := 140
global SOUL_HUB_FOOTER_Y := 620
global SOUL_HUB_FOOTER_BTN_W := 280
global SOUL_HUB_COMPLETE_GRID_Y := 200
global SOUL_HUB_TESTS_STATUS_Y := 430
; Écrans lancement test (Soul / VDA / Shadow)
global LAUNCH_TITLE_Y := 45
global LAUNCH_INTRO_Y := 115
global LAUNCH_INTRO_H := 56
global LAUNCH_ACTION_Y := 300
global LAUNCH_ACTION_W := 420
global LAUNCH_ACTION_H := 48
global LAUNCH_NAV_Y := 650
; Grille hub lecture PRIMA (2 colonnes × 4 lignes)
global READING_HUB_TITLE_Y := 45
global READING_HUB_INTRO_Y := 115
global READING_HUB_INTRO_H := 56
global READING_HUB_GRID_Y := 235
global READING_HUB_BTN_W := 420
global READING_HUB_BTN_H := 42
global READING_HUB_GAP_X := 24
global READING_HUB_GAP_Y := 14
; Grille écrans choix Univers / Territoire (3 cartes visibles, 1050×760)
global CHOICE_TITLE_Y := 45
global CHOICE_INTRO_Y := 120
global CHOICE_INTRO_H := 44
global CHOICE_CARD_X := 85
global CHOICE_CARD_W := 880
global CHOICE_CARD_H := 120
global CHOICE_CARD_GAP := 18
global CHOICE_CARD_START_Y := 220
global CHOICE_PICK_W := 160
global PAGED_CHOICE_PAGE_Y := 185
global PAGED_CHOICE_CARD_Y := 220
global PAGED_CHOICE_CARD_H := 280
global PAGED_CHOICE_NAV_Y := 530
global PAGED_CHOICE_NAV_BTN_W := 200
global PAGED_CHOICE_PICK_W := 260
global CHOICE_NAV_Y := 650
; Zone scrollable (header/footer fixes, contenu central défilable)
global SCROLL_VIEWPORT_Y := 175
global SCROLL_VIEWPORT_H := 465
global SCROLL_FOOTER_Y := 650
global SCROLL_AREA := ""

; ── Init ──────────────────────────────────────────────────────────────────────
EnsureDirectories()
WriteLog("app_started")
SetWorkingDir(APP_ROOT)

^!+x::PauseApp()
^!+q::EmergencyExit()

; Démarrage direct — profil + mot de passe requis
ResetLegacyProfilesIfNeeded()
RenderScreen("profile")

; ── Navigation centrale ───────────────────────────────────────────────────────
CloseCurrentWindow() {
    global MAIN_GUI, ACTIVE_HWND, IS_DESTROYING
    IS_DESTROYING := true
    DestroyScrollArea()
    hwnd := ACTIVE_HWND
    if (MAIN_GUI != "") {
        try MAIN_GUI.Destroy()
        MAIN_GUI := ""
    }
    if (hwnd && WinExist("ahk_id " hwnd)) {
        try WinClose("ahk_id " hwnd)
    }
    ACTIVE_HWND := 0
    IS_DESTROYING := false
}

RenderScreen(screenName) {
    global CURRENT_SCREEN
    CloseCurrentWindow()
    CURRENT_SCREEN := screenName
    switch screenName {
        case "profile":    BuildProfile()
        case "profile_login": BuildProfileLogin()
        case "archives":   BuildArchives()
        case "create":     BuildCreateProfile()
        case "create_security": BuildCreateProfileSecurity()
        case "privacy":    BuildPrivacy()
        case "start_here": BuildStartHere()
        case "home":       BuildHome()
        case "creator_home": BuildCreatorHome()
        case "creator_soul": BuildCreatorSoul()
        case "kit":          BuildKitPrima()
        case "onboarding":       BuildOnboarding()
        case "personal_base":    BuildPersonalBase()
        case "prima_soul_intro": BuildPrimaSoulIntro()
        case "prima_soul_vda":      BuildPrimaSoulVda()
        case "prima_soul_question": BuildPrimaSoulQuestion()
        case "prima_vda_done":      BuildPrimaVdaDone()
        case "prima_vda_rank":      BuildPrimaVdaRankQuestion()
        case "prima_vda_rank_done": BuildPrimaVdaRankDone()
        case "prima_soul_done":    BuildPrimaSoulDone()
        case "prima_soul_test":     BuildPrimaSoulTest()
        case "prima_soul_shadow":   BuildPrimaSoulShadow()
        case "prima_shadow_question": BuildPrimaShadowQuestion()
        case "prima_shadow_done":     BuildPrimaShadowDone()
        case "soul_reading_hub":      BuildSoulReadingHub()
        case "soul_reading_soul":     BuildSoulReadingSoul()
        case "soul_reading_vda":      BuildSoulReadingVda()
        case "soul_reading_shadow":   BuildSoulReadingShadow()
        case "prima_universe_choice": BuildPrimaUniverseChoice()
        case "prima_territory_choice": BuildPrimaTerritoryChoice()
        case "prima_identity_saved":  BuildPrimaIdentitySaved()
        case "prima_soul_settings": BuildPrimaSoulSettings()
        case "prima_soul_choices": BuildPrimaSoulChoices()
        case "onboarding_goals": BuildOnboardingGoals()
        case "settings":         BuildSettings()
        case "review":     BuildReview()
    }
}

HandleGuiClose(*) {
    global IS_DESTROYING
    if (IS_DESTROYING)
        return
    if (!ConfirmExit("x"))
        return true
}

ShowMainGui() {
    global MAIN_GUI, ACTIVE_HWND, WINDOW_W, WINDOW_H
    if (MAIN_GUI = "")
        return
    MAIN_GUI.OnEvent("Close", HandleGuiClose)
    MAIN_GUI.Show("w" WINDOW_W " h" WINDOW_H " Center")
    ACTIVE_HWND := MAIN_GUI.Hwnd
}

; Affichage unifié écrans PRIMA Soul (1050×760 centré).
ShowScreen() {
    FinalizeScrollableContentArea()
    ShowMainGui()
}

; ── Zone scrollable (GUI enfant + barre verticale + molette) ───────────────────
DestroyScrollArea() {
    global SCROLL_AREA
    if !IsObject(SCROLL_AREA)
        return
    try {
        if (SCROLL_AREA.HasProp("onScroll") && SCROLL_AREA.onScroll)
            OnMessage(0x0115, SCROLL_AREA.onScroll, 0)
        if (SCROLL_AREA.HasProp("onWheel") && SCROLL_AREA.onWheel)
            OnMessage(0x020A, SCROLL_AREA.onWheel, 0)
    }
    if (SCROLL_AREA.HasProp("gui") && SCROLL_AREA.gui != "")
        try SCROLL_AREA.gui.Destroy()
    SCROLL_AREA := ""
}

; Crée une zone de contenu défilable dans la fenêtre parente (coords client parent).
CreateScrollableContentArea(parentG, x, y, w, h) {
    global SCROLL_AREA, CLR_BG, CLR_TEXT
    DestroyScrollArea()
    cg := Gui("-Caption +Border +0x200000")
    cg.BackColor := CLR_BG
    cg.SetFont("s12 c" CLR_TEXT, "Segoe UI")
    area := { gui: cg, parent: parentG, x: x, y: y, w: w, h: h, onScroll: "", onWheel: "" }
    area.onScroll := ScrollArea_OnScroll.Bind(area)
    area.onWheel := ScrollArea_OnWheel.Bind(area)
    SCROLL_AREA := area
    return cg
}

FinalizeScrollableContentArea() {
    global SCROLL_AREA, MARGIN_X, CONTENT_W, CLR_BG, CLR_SUBTEXT
    if !IsObject(SCROLL_AREA) || SCROLL_AREA.gui = ""
        return
    parent := SCROLL_AREA.parent
    cg := SCROLL_AREA.gui
    DllCall("SetParent", "Ptr", cg.Hwnd, "Ptr", parent.Hwnd)
    style := DllCall("GetWindowLongPtr", "Ptr", cg.Hwnd, "Int", -16, "Ptr")
    DllCall("SetWindowLongPtr", "Ptr", cg.Hwnd, "Int", -16, "Ptr", style | 0x40000000)
    cg.Show("x" SCROLL_AREA.x " y" SCROLL_AREA.y " w" SCROLL_AREA.w " h" SCROLL_AREA.h)
    ScrollArea_UpdateScrollBars(SCROLL_AREA)
    OnMessage(0x0115, SCROLL_AREA.onScroll)
    OnMessage(0x020A, SCROLL_AREA.onWheel)
    if (ScrollArea_ContentExceedsViewport(SCROLL_AREA)) {
        parent.SetFont("s9 c" CLR_SUBTEXT, "Segoe UI")
        hy := SCROLL_AREA.y + SCROLL_AREA.h - 20
        parent.Add("Text", "x" MARGIN_X " y" hy " w" CONTENT_W " h16 Center Background" CLR_BG, T("scroll_hint"))
    }
}

ScrollArea_ContentExceedsViewport(area) {
    cg := area.gui
    WinGetClientPos(, , , , cg.Hwnd)
    bottom := 0
    for ctrlHwnd in WinGetControlsHwnd(cg.Hwnd) {
        ControlGetPos(, , , &ch, ctrlHwnd)
        if (ctrlHwnd = cg.Hwnd)
            continue
        ControlGetPos(, &cy, , , ctrlHwnd)
        bottom := Max(bottom, cy + ch)
    }
    return bottom > area.h + 4
}

ScrollArea_UpdateScrollBars(area) {
    cg := area.gui
    WinGetClientPos(, , &gw, &gh, cg.Hwnd)
    top := 2147483647
    bottom := -2147483648
    for ctrlHwnd in WinGetControlsHwnd(cg.Hwnd) {
        ControlGetPos(, &cy, , &ch, ctrlHwnd)
        top := Min(cy, top)
        bottom := Max(cy + ch, bottom)
    }
    if (top = 2147483647)
        top := 0
    scrH := bottom - top + 16
    SI := Buffer(28, 0)
    NumPut("UInt", 28, SI, 0)
    NumPut("UInt", 0x1 | 0x2 | 0x8, SI, 4)
    NumPut("Int", 0, SI, 8)
    NumPut("Int", scrH, SI, 12)
    NumPut("Int", gh, SI, 16)
    NumPut("Int", 0, SI, 20)
    DllCall("SetScrollInfo", "Ptr", cg.Hwnd, "Int", 1, "Ptr", SI, "Int", 1)
}

ScrollArea_IsMouseOver(area) {
    pt := Buffer(8, 0)
    DllCall("GetCursorPos", "Ptr", pt)
    NumPut("Int", NumGet(pt, 0, "Int"), pt, 0)
    NumPut("Int", NumGet(pt, 4, "Int"), pt, 4)
    DllCall("ScreenToClient", "Ptr", area.gui.Hwnd, "Ptr", pt)
    cx := NumGet(pt, 0, "Int")
    cy := NumGet(pt, 4, "Int")
    WinGetClientPos(, , &cw, &ch, area.gui.Hwnd)
    return cx >= 0 && cy >= 0 && cx < cw && cy < ch
}

ScrollArea_OnWheel(area, wParam, lParam, msg, hwnd) {
    if !ScrollArea_IsMouseOver(area)
        return
    if (hwnd = area.gui.Hwnd) {
        ht := DllCall("SendMessage", "Ptr", hwnd, "UInt", 0x0084, "Ptr", 0, "Ptr", lParam, "Ptr")
        if (ht = 6 || ht = 7) {
            sb := (wParam & 0x80000000) ? 1 : 0
            ScrollArea_OnScroll(area, sb, 0, (ht = 6) ? 0x0114 : 0x0115, hwnd)
            return 0
        }
    }
    delta := (wParam >> 16) & 0xFFFF
    if (delta >= 0x8000)
        delta -= 0x10000
    steps := (delta < 0) ? 3 : -3
    loop Abs(steps)
        ScrollArea_OnScroll(area, (steps > 0) ? 1 : 0, 0, 0x0115, area.gui.Hwnd)
    return 0
}

ScrollArea_OnScroll(area, wParam, lParam, msg, hwnd) {
    static SCROLL_STEP := 24
    if (hwnd != area.gui.Hwnd)
        return
    if (lParam != 0)
        return
    bar := (msg = 0x0115) ? 1 : 0
    SI := Buffer(28, 0)
    NumPut("UInt", 28, SI, 0)
    NumPut("UInt", 0x17, SI, 4)
    if !DllCall("GetScrollInfo", "Ptr", hwnd, "Int", bar, "Ptr", SI)
        return
    RC := Buffer(16, 0)
    DllCall("GetClientRect", "Ptr", hwnd, "Ptr", RC)
    newPos := NumGet(SI, 20, "Int")
    minPos := NumGet(SI, 8, "Int")
    maxPos := NumGet(SI, 12, "Int")
    switch (wParam & 0xFFFF) {
        case 0: newPos -= SCROLL_STEP
        case 1: newPos += SCROLL_STEP
        case 2: newPos -= NumGet(RC, 12, "Int") - SCROLL_STEP
        case 3: newPos += NumGet(RC, 12, "Int") - SCROLL_STEP
        case 4, 5: newPos := wParam >> 16
        case 6: newPos := minPos
        case 7: newPos := maxPos
        default: return
    }
    maxPos -= NumGet(SI, 16, "Int")
    newPos := Max(minPos, Min(newPos, maxPos))
    oldPos := NumGet(SI, 20, "Int")
    x := (bar = 0) ? oldPos - newPos : 0
    y := (bar = 1) ? oldPos - newPos : 0
    if (x || y) {
        DllCall("ScrollWindow", "Ptr", hwnd, "Int", x, "Int", y, "Ptr", 0, "Ptr", 0)
        NumPut("Int", newPos, SI, 20)
        DllCall("SetScrollInfo", "Ptr", hwnd, "Int", bar, "Ptr", SI, "Int", 1)
    }
}

; En-tête fixe (haut) pour écrans scrollables.
AddScrollPageHeader(g, title, introLine1, introLine2 := "") {
    AddChoiceScreenHeader(g, title, introLine1, introLine2)
}

; Pied fixe Retour (bas) pour écrans scrollables.
AddScrollPageFooterBack(g, backAction) {
    AddChoiceNavBack(g, backAction)
}

; Estime la hauteur d'un texte multiligne dans une zone donnée.
ScrollTextHeight(text, width, lineH := 18) {
    if (text = "")
        return 0
    charsPerLine := Max(24, width // 9)
    lines := Max(1, Ceil(StrLen(text) / charsPerLine))
    return lines * lineH + 4
}

; Section résultat dans zone scrollable — retourne le y suivant.
AddScrollResultSection(cg, y, sectionKey, bodyLines*) {
    global CONTENT_W, CLR_ACCENT, CLR_TEXT, GAP_LG
    pad := 12
    w := CONTENT_W - 2 * pad
    x := pad
    cg.SetFont("s13 Bold c" CLR_ACCENT, "Segoe UI")
    cg.Add("Text", "x" x " y" y " w" w " h24 BackgroundTrans", TIcon(sectionKey))
    y += 28
    cg.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    for line in bodyLines {
        if (line = "")
            continue
        h := ScrollTextHeight(line, w)
        cg.Add("Text", "x" x " y" y " w" w " h" h " +0x2000 BackgroundTrans", line)
        y += h + 6
    }
    y += GAP_LG
    return y
}

; Carte choix dans zone scrollable (y relatif, 3 cartes empilées).
AddFixedChoiceCardScroll(cg, row, roleLabel, title, desc, pickAction) {
    global CHOICE_CARD_W, CHOICE_CARD_H, CHOICE_CARD_GAP, CHOICE_PICK_W, BUTTON_H
    global MARGIN_X, CHOICE_CARD_X, CLR_PANEL, CLR_SUBTEXT, CLR_TEXT, CLR_ACCENT, CONTENT_W
    cardX := CHOICE_CARD_X - MARGIN_X
    y := 8 + (row - 1) * (CHOICE_CARD_H + CHOICE_CARD_GAP)
    w := CHOICE_CARD_W
    h := CHOICE_CARD_H
    cg.Add("Text", "x" cardX " y" y " w" w " h" h " Background" CLR_PANEL, "")
    cg.SetFont("s9 c" CLR_SUBTEXT, "Segoe UI")
    cg.Add("Text", "x" (cardX + 16) " y" (y + 8) " w" (w - 32) " h18 BackgroundTrans", roleLabel)
    cg.SetFont("s12 Bold c" CLR_ACCENT, "Segoe UI")
    cg.Add("Text", "x" (cardX + 16) " y" (y + 28) " w" (w - CHOICE_PICK_W - 40) " h24 BackgroundTrans", title)
    cg.SetFont("s10 c" CLR_TEXT, "Segoe UI")
    cg.Add("Text", "x" (cardX + 16) " y" (y + 52) " w" (w - CHOICE_PICK_W - 40) " h44 +0x2000 BackgroundTrans", desc)
    pickX := cardX + w - CHOICE_PICK_W - 16
    pickY := y + h - BUTTON_H - 12
    btn := cg.Add("Button", "x" pickX " y" pickY " w" CHOICE_PICK_W " h" BUTTON_H " Center", TIcon("btn_pick"))
    btn.OnEvent("Click", pickAction)
}

; Bouton hub lecture dans zone scrollable.
AddReadingHubButtonScroll(cg, col, row, label, action) {
    global READING_HUB_BTN_W, READING_HUB_BTN_H, READING_HUB_GAP_X, READING_HUB_GAP_Y, CONTENT_W
    gridW := 2 * READING_HUB_BTN_W + READING_HUB_GAP_X
    startX := (CONTENT_W - gridW) // 2
    x := startX + (col - 1) * (READING_HUB_BTN_W + READING_HUB_GAP_X)
    y := 8 + (row - 1) * (READING_HUB_BTN_H + READING_HUB_GAP_Y)
    btn := cg.Add("Button", "x" x " y" y " w" READING_HUB_BTN_W " h" READING_HUB_BTN_H " Center", label)
    btn.OnEvent("Click", action)
}

ShowFormGui() {
    global MAIN_GUI, ACTIVE_HWND, FORM_WINDOW_W, FORM_WINDOW_H
    if (MAIN_GUI = "")
        return
    MAIN_GUI.OnEvent("Close", HandleGuiClose)
    MAIN_GUI.Show("w" FORM_WINDOW_W " h" FORM_WINDOW_H " Center")
    ACTIVE_HWND := MAIN_GUI.Hwnd
}

ShowCreateProfileGui() {
    ShowFormGui()
}

NewFormGui() {
    global MAIN_GUI, CLR_BG, CLR_TEXT, FORM_WINDOW_W, FORM_WINDOW_H, FORM_MARGIN_X, FORM_MARGIN_Y
    g := Gui("-Resize +MinSize" FORM_WINDOW_W "x" FORM_WINDOW_H, APP_TITLE)
    g.BackColor := CLR_BG
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
    g.MarginX := FORM_MARGIN_X
    g.MarginY := FORM_MARGIN_Y
    MAIN_GUI := g
    return g
}

NewCreateGui() {
    return NewFormGui()
}

NewGui() {
    global MAIN_GUI, CLR_BG, CLR_TEXT, MARGIN_X, MARGIN_Y
    g := Gui("-Resize +MinSize" WINDOW_W "x" WINDOW_H, APP_TITLE)
    g.BackColor := CLR_BG
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
    g.MarginX := MARGIN_X
    g.MarginY := MARGIN_Y
    MAIN_GUI := g
    return g
}

VerifyLocalSaves() {
    global CURRENT_PROFILE_ID, PROFILES_DIR
    if (CURRENT_PROFILE_ID = "")
        return true
    profileDir := PROFILES_DIR "\" CURRENT_PROFILE_ID
    return DirExist(profileDir) && FileExist(profileDir "\profile.ini")
}

ConfirmExit(source := "x") {
    global MAIN_GUI
    if (source = "quit") {
        prompt := T("confirm_quit")
        if (VerifyLocalSaves())
            prompt .= "`n`n" T("confirm_saved")
        else
            prompt .= "`n`n" T("confirm_missing")
    } else {
        prompt := T("confirm_close")
    }
    result := MsgBox(prompt, APP_TITLE, "YesNo Icon?")
    if (result != "Yes")
        return false
    AppExit()
    return true
}

AppExit() {
    SaveSoulSessionState()
    SaveVdaSessionState()
    SaveShadowSessionState()
    WriteLog("app_closed")
    CloseCurrentWindow()
    ExitApp()
}

; ── Directories ───────────────────────────────────────────────────────────────
EnsureDirectories() {
    for dir in [PROFILES_DIR, ARCHIVE_DIR, LOGS_DIR, REVIEWS_DIR] {
        if !DirExist(dir)
            DirCreate(dir)
    }
}

; ── Kit PRIMA ─────────────────────────────────────────────────────────────────
GetKitAiValues() {
    return ["ChatGPT", "Claude", "Gemini", "Cursor", "Other"]
}

GetKitAiLabels() {
    return ["ChatGPT", "Claude", "Gemini", "Cursor", T("kit_ai_other")]
}

GetKitIniPath(profileId) {
    return PROFILES_DIR "\" profileId "\kit.ini"
}

GetKitCheckKeys() {
    return ["root_folder", "prima_app", "autohotkey_available", "ahk_launcher", "prima_shortcut", "profiles_folder", "logs_folder", "reviews_folder", "profiles_ini"]
}

FindAutoHotkeyExe() {
    if (A_AhkPath != "" && FileExist(A_AhkPath))
        return A_AhkPath
    candidates := [
        A_ProgramFiles "\AutoHotkey\v2\AutoHotkey64.exe",
        A_ProgramFiles "\AutoHotkey\v2\AutoHotkey32.exe",
        A_ProgramFiles "\AutoHotkey\UX\AutoHotkeyUX.exe"
    ]
    localAppData := EnvGet("LOCALAPPDATA")
    if (localAppData != "") {
        candidates.Push(localAppData "\Programs\AutoHotkey\v2\AutoHotkey64.exe")
        candidates.Push(localAppData "\Programs\AutoHotkey\v2\AutoHotkey.exe")
    }
    pf86 := EnvGet("ProgramFiles(x86)")
    if (pf86 != "") {
        candidates.Push(pf86 "\AutoHotkey\v2\AutoHotkey32.exe")
        candidates.Push(pf86 "\AutoHotkey\v2\AutoHotkey64.exe")
    }
    for path in candidates {
        if FileExist(path)
            return path
    }
    return ""
}

IsAutoHotkeyAvailable() {
    return FindAutoHotkeyExe() != ""
}

KitOfferAutoHotkeyDownload() {
    result := MsgBox(T("msg_autohotkey_missing"), APP_TITLE, "YesNo Icon?")
    if (result = "Yes")
        Run(AUTOHOTKEY_OFFICIAL_URL)
}

KitStatusLabel(ok) {
    return ok ? T("status_ok") : T("status_missing")
}

RunKitChecks() {
    return {
        root_folder: DirExist(APP_ROOT),
        prima_app: FileExist(APP_ROOT "\PrimaApp.ahk"),
        autohotkey_available: IsAutoHotkeyAvailable(),
        ahk_launcher: FileExist(LAUNCHER_FILE),
        prima_shortcut: IsKitShortcutValid(),
        profiles_folder: DirExist(PROFILES_DIR),
        logs_folder: DirExist(LOGS_DIR),
        reviews_folder: DirExist(REVIEWS_DIR),
        profiles_ini: FileExist(PROFILES_INDEX)
    }
}

JoinLines(lines) {
    out := ""
    for index, line in lines {
        if (index > 1)
            out .= "`n"
        out .= line
    }
    return out
}

FormatKitStatusText(checks) {
    lines := []
    lines.Push(T("kit_check_root") . ": " . KitStatusLabel(checks.root_folder))
    lines.Push(T("kit_check_prima_app") . ": " . KitStatusLabel(checks.prima_app))
    lines.Push(T("kit_check_autohotkey") . ": " . KitStatusLabel(checks.autohotkey_available))
    lines.Push(T("kit_check_launcher") . ": " . KitStatusLabel(checks.ahk_launcher))
    lines.Push(T("kit_check_shortcut") . ": " . KitStatusLabel(checks.prima_shortcut))
    lines.Push(T("kit_check_profiles") . ": " . KitStatusLabel(checks.profiles_folder))
    lines.Push(T("kit_check_logs") . ": " . KitStatusLabel(checks.logs_folder))
    lines.Push(T("kit_check_reviews") . ": " . KitStatusLabel(checks.reviews_folder))
    lines.Push(T("kit_check_profiles_ini") . ": " . KitStatusLabel(checks.profiles_ini))
    return JoinLines(lines)
}

KitAllChecksOk(checks) {
    for , key in GetKitCheckKeys() {
        if !checks.%key%
            return false
    }
    return true
}

LoadKitSelectedAi(profileId) {
    path := GetKitIniPath(profileId)
    if !FileExist(path)
        return "ChatGPT"
    saved := IniRead(path, "kit", "selected_ai", "ChatGPT")
    values := GetKitAiValues()
    for i, val in values {
        if (val = saved)
            return saved
    }
    return "ChatGPT"
}

KitAiIndexForValue(value) {
    values := GetKitAiValues()
    for i, val in values {
        if (val = value)
            return i
    }
    return 1
}

SaveKitIni(profileId, selectedAi, checks) {
    profileDir := PROFILES_DIR "\" profileId
    if !DirExist(profileDir)
        return false
    path := GetKitIniPath(profileId)
    try {
        now := FormatTime(, "yyyy-MM-dd HH:mm:ss")
        status := KitAllChecksOk(checks) ? "ok" : "missing"
        IniWrite(selectedAi, path, "kit", "selected_ai")
        IniWrite(now, path, "kit", "last_check")
        IniWrite(status, path, "kit", "status")
        for , key in GetKitCheckKeys()
            IniWrite(KitStatusLabel(checks.%key%), path, "checks", key)
        return true
    } catch {
        return false
    }
}

CreateKitLauncher() {
    global APP_ROOT, LAUNCHER_FILE
    if FileExist(LAUNCHER_FILE)
        return true
    if !FileExist(APP_ROOT "\PrimaApp.ahk")
        return false
    content := "#Requires AutoHotkey v2.0`n#SingleInstance Force`n; PRIMA local launcher — launches PrimaApp.ahk from this folder.`nRun(A_ScriptDir `"\PrimaApp.ahk`")`n"
    try {
        FileAppend(content, LAUNCHER_FILE, "UTF-8")
        return true
    } catch {
        return false
    }
}

CreateKitShortcut() {
    global APP_ROOT, LAUNCHER_FILE, PRIMA_SHORTCUT_FILE

    if IsKitShortcutValid()
        return false

    if FileExist(PRIMA_SHORTCUT_FILE) {
        try {
            FileDelete(PRIMA_SHORTCUT_FILE)
        } catch {
            return false
        }
    }

    ahkExe := FindAutoHotkeyExe()
    if (ahkExe = "") {
        MsgBox(T("msg_autohotkey_not_found_shortcut"), APP_TITLE, "Icon!")
        return false
    }
    if !FileExist(LAUNCHER_FILE) && !CreateKitLauncher()
        return false
    try {
        shell := ComObject("WScript.Shell")
        shortcut := shell.CreateShortcut(PRIMA_SHORTCUT_FILE)
        shortcut.TargetPath := ahkExe
        shortcut.Arguments := '"' LAUNCHER_FILE '"'
        shortcut.WorkingDirectory := APP_ROOT
        shortcut.Description := "PRIMA App"
        shortcut.IconLocation := ahkExe . ",0"
        shortcut.Save()
        return true
    } catch {
        return false
    }
}

IsKitShortcutValid() {
    global PRIMA_SHORTCUT_FILE
    if !FileExist(PRIMA_SHORTCUT_FILE)
        return false
    try {
        shell := ComObject("WScript.Shell")
        shortcut := shell.CreateShortcut(PRIMA_SHORTCUT_FILE)
        target := shortcut.TargetPath
        return (target != "" && FileExist(target))
    } catch {
        return false
    }
}

KitCreateMissingItems() {
    created := false
    for dir in [PROFILES_DIR, LOGS_DIR, REVIEWS_DIR] {
        if !DirExist(dir) {
            DirCreate(dir)
            created := true
        }
    }
    if !FileExist(PROFILES_INDEX) {
        try {
            FileAppend("[Index]`n", PROFILES_INDEX, "UTF-8")
            created := true
        }
    }
    if CreateKitLauncher()
        created := true
    if CreateKitShortcut()
        created := true
    return created
}

KitRefreshStatus() {
    global KIT_STATUS_TEXT, KIT_LAST_CHECKS
    KIT_LAST_CHECKS := RunKitChecks()
    if (KIT_STATUS_TEXT != "")
        KIT_STATUS_TEXT.Value := FormatKitStatusText(KIT_LAST_CHECKS)
}

KitVerify(*) {
    global CURRENT_PROFILE_ID
    KitRefreshStatus()
    WriteLog("kit_checked", CURRENT_PROFILE_ID)
    if !IsAutoHotkeyAvailable()
        KitOfferAutoHotkeyDownload()
}

KitCreateMissing(*) {
    global CURRENT_PROFILE_ID
    if KitCreateMissingItems() {
        WriteLog("kit_missing_created", CURRENT_PROFILE_ID)
        WriteProfileLog(CURRENT_PROFILE_ID, "kit_missing_created")
    }
    KitRefreshStatus()
}

KitSave(*) {
    global CURRENT_PROFILE_ID, KIT_AI_DDL, KIT_LAST_CHECKS
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        return
    }
    idx := KIT_AI_DDL.Value
    values := GetKitAiValues()
    selectedAi := values[idx]
    if !IsObject(KIT_LAST_CHECKS)
        KIT_LAST_CHECKS := RunKitChecks()
    if SaveKitIni(CURRENT_PROFILE_ID, selectedAi, KIT_LAST_CHECKS) {
        WriteLog("kit_saved", CURRENT_PROFILE_ID)
        WriteProfileLog(CURRENT_PROFILE_ID, "kit_saved", selectedAi)
        MsgBox(T("msg_kit_saved"), APP_TITLE, "Icon!")
    } else {
        MsgBox(T("msg_kit_save_error"), APP_TITLE, "Icon!")
    }
}

KitBack(*) {
    global KIT_BACK_SCREEN
    RenderScreen(KIT_BACK_SCREEN)
}

OpenKitFromHome(*) {
    global KIT_BACK_SCREEN
    KIT_BACK_SCREEN := "home"
    SetTimer(DeferredRenderKit, -1)
}

OpenKitFromCreator(*) {
    global KIT_BACK_SCREEN
    KIT_BACK_SCREEN := "creator_home"
    SetTimer(DeferredRenderKit, -1)
}

DeferredRenderKit(*) {
    SetTimer(DeferredRenderKit, 0)
    RenderScreen("kit")
}

; ── Logging ───────────────────────────────────────────────────────────────────
WriteLog(event, extra := "") {
    EnsureDirectories()
    timestamp := FormatTime(, "yyyy-MM-dd HH:mm:ss")
    line := timestamp " | " event
    if (extra != "")
        line .= " | " extra
    line .= "`n"
    logFile := LOGS_DIR "\" FormatTime(, "yyyy-MM-dd") "_prima.log"
    try FileAppend(line, logFile, "UTF-8")
}

WriteProfileLog(profileId, event, extra := "") {
    profileLogDir := PROFILES_DIR "\" profileId "\logs"
    if !DirExist(profileLogDir)
        DirCreate(profileLogDir)
    timestamp := FormatTime(, "yyyy-MM-dd HH:mm:ss")
    line := timestamp " | " event
    if (extra != "")
        line .= " | " extra
    line .= "`n"
    logFile := profileLogDir "\" FormatTime(, "yyyy-MM-dd") "_profile.log"
    try FileAppend(line, logFile, "UTF-8")
}

; ── Profile index ─────────────────────────────────────────────────────────────
GetProfileIds() {
    ids := []
    if !FileExist(PROFILES_INDEX)
        return ids
    loop {
        val := IniRead(PROFILES_INDEX, "Index", "Profile" A_Index, "")
        if (val = "")
            break
        ids.Push(val)
    }
    return ids
}

AddProfileToIndex(profileId) {
    ids := GetProfileIds()
    for id in ids {
        if (id = profileId)
            return
    }
    next := ids.Length + 1
    IniWrite(profileId, PROFILES_INDEX, "Index", "Profile" next)
}

RemoveProfileFromIndex(profileId) {
    ids := GetProfileIds()
    newIds := []
    for id in ids {
        if (id != profileId)
            newIds.Push(id)
    }
    if FileExist(PROFILES_INDEX)
        FileDelete(PROFILES_INDEX)
    for i, id in newIds
        IniWrite(id, PROFILES_INDEX, "Index", "Profile" i)
}

ArchiveProfile(profileId) {
    EnsureDirectories()
    src := PROFILES_DIR "\" profileId
    if !DirExist(src)
        return false
    dest := ARCHIVE_DIR "\" profileId
    if DirExist(dest)
        dest := ARCHIVE_DIR "\" profileId "_" FormatTime(, "yyyyMMdd_HHmmss")
    DirMove(src, dest)
    RemoveProfileFromIndex(profileId)
    WriteLog("profile_archived", profileId)
    return true
}

GetArchiveFolderNames() {
    names := []
    EnsureDirectories()
    if !DirExist(ARCHIVE_DIR)
        return names
    Loop Files, ARCHIVE_DIR "\*", "D" {
        names.Push(A_LoopFileName)
    }
    return names
}

GetArchiveFolderSizeLabel(dirPath) {
    total := 0
    try {
        Loop Files, dirPath "\*", "R" {
            total += A_LoopFileSize
        }
    } catch {
        return "?"
    }
    if (total < 1024)
        return total " B"
    if (total < 1048576)
        return Round(total / 1024, 1) " KB"
    return Round(total / 1048576, 2) " MB"
}

GetArchiveFolderDateLabel(dirPath, folderName) {
    if RegExMatch(folderName, "(\d{8})_(\d{6})", &m) {
        return SubStr(m[1], 1, 4) "-" SubStr(m[1], 5, 2) "-" SubStr(m[1], 7, 2)
            . " " SubStr(m[2], 1, 2) ":" SubStr(m[2], 3, 2)
    }
    try {
        return FormatTime(FileGetTime(dirPath, "C"), "yyyy-MM-dd HH:mm")
    } catch {
        return "—"
    }
}

FormatArchiveListEntry(folderName) {
    dirPath := ARCHIVE_DIR "\" folderName
    return folderName . " | " . GetArchiveFolderSizeLabel(dirPath) . " | " . GetArchiveFolderDateLabel(dirPath, folderName)
}

ResolveArchivePath(folderName) {
    global ARCHIVE_DIR
    if (folderName = "" || InStr(folderName, "\") || InStr(folderName, "/") || InStr(folderName, ".."))
        return ""
    fullPath := ARCHIVE_DIR "\" folderName
    if !DirExist(fullPath)
        return ""
    archiveRoot := RTrim(ARCHIVE_DIR, "\")
    if (StrLower(SubStr(fullPath, 1, StrLen(archiveRoot))) != StrLower(archiveRoot))
        return ""
    if (fullPath = archiveRoot || fullPath = PROFILES_DIR || fullPath = APP_ROOT)
        return ""
    return fullPath
}

IsActiveProfileArchiveName(folderName) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "")
        return false
    return (folderName = CURRENT_PROFILE_ID || InStr(folderName, CURRENT_PROFILE_ID "_") = 1)
}

ArchiveDeletePermanently(*) {
    global ARCHIVE_LIST, ARCHIVE_FOLDER_NAMES, CURRENT_PROFILE_ID
    idx := ARCHIVE_LIST.Value
    if (idx = 0) {
        MsgBox(T("msg_select_archive_delete"), APP_TITLE, "Icon!")
        return
    }
    folderName := ARCHIVE_FOLDER_NAMES[idx]
    if IsActiveProfileArchiveName(folderName) {
        MsgBox(T("msg_active_archive_delete"), APP_TITLE, "Icon!")
        WriteLog("archive_delete_failed", folderName . " | active")
        return
    }
    archivePath := ResolveArchivePath(folderName)
    if (archivePath = "") {
        MsgBox(T("msg_archive_delete_failed"), APP_TITLE, "Icon!")
        WriteLog("archive_delete_failed", folderName . " | invalid_path")
        return
    }
    if (StrLower(SubStr(archivePath, 1, StrLen(ARCHIVE_DIR))) != StrLower(ARCHIVE_DIR)) {
        MsgBox(T("msg_archive_delete_failed"), APP_TITLE, "Icon!")
        WriteLog("archive_delete_failed", folderName . " | outside_archive")
        return
    }
    result1 := MsgBox(T("msg_archive_delete_confirm1", folderName), APP_TITLE, "YesNo Icon?")
    if (result1 != "Yes") {
        WriteLog("archive_delete_cancelled", folderName)
        return
    }
    result2 := MsgBox(T("msg_archive_delete_confirm2"), APP_TITLE, "YesNo Icon?")
    if (result2 != "Yes") {
        WriteLog("archive_delete_cancelled", folderName)
        return
    }
    try {
        if !DirExist(archivePath)
            throw Error("missing")
        DirDelete(archivePath, 1)
        WriteLog("archive_deleted", folderName)
        RenderScreen("archives")
    } catch {
        MsgBox(T("msg_archive_delete_failed"), APP_TITLE, "Icon!")
        WriteLog("archive_delete_failed", folderName)
    }
}

GenerateProfileId(displayName) {
    safe := RegExReplace(displayName, "[^\w\-]", "_")
    if (safe = "")
        safe := "profile"
    return safe "_" FormatTime(, "yyyyMMdd_HHmmss")
}

GetLastProfileId() {
    return IniRead(APP_STATE_FILE, "App", "last_profile_id", "")
}

SetLastProfileId(profileId) {
    IniWrite(profileId, APP_STATE_FILE, "App", "last_profile_id")
}

GetProfileLanguage(profileId) {
    lang := IniRead(PROFILES_DIR "\" profileId "\profile.ini", "Profile", "language", "fr")
    return (lang = "en") ? "en" : "fr"
}

GetProfileMode(profileId) {
    mode := IniRead(PROFILES_DIR "\" profileId "\profile.ini", "Profile", "mode", "client")
    return (mode = "creator") ? "creator" : "client"
}

IsCreatorProfile(profileId) {
    return GetProfileMode(profileId) = "creator"
}

ProfileHasPassword(profileId) {
    iniPath := PROFILES_DIR "\" profileId "\profile.ini"
    if !FileExist(iniPath)
        return false
    return IniRead(iniPath, "Profile", "password_set", "0") = "1"
}

CollectAllProfileFolderIds() {
    ids := []
    if !DirExist(PROFILES_DIR)
        return ids
    Loop Files, PROFILES_DIR "\*", "D" {
        ids.Push(A_LoopFileName)
    }
    return ids
}

ArchiveResetProfiles(ids) {
    EnsureDirectories()
    stamp := FormatTime(, "yyyyMMdd_HHmmss")
    dest := ARCHIVE_DIR "\reset_profiles_" stamp
    DirCreate(dest)
    for id in ids {
        src := PROFILES_DIR "\" id
        if DirExist(src) {
            try DirMove(src, dest "\" id)
        }
    }
    if FileExist(PROFILES_INDEX)
        FileDelete(PROFILES_INDEX)
    FileAppend("[Index]`n", PROFILES_INDEX, "UTF-8")
    if FileExist(APP_STATE_FILE)
        IniWrite("", APP_STATE_FILE, "App", "last_profile_id")
    WriteLog("profile_reset_archived", dest)
}

ResetLegacyProfilesIfNeeded() {
    ids := CollectAllProfileFolderIds()
    if (ids.Length = 0)
        return
    for id in ids {
        if !ProfileHasPassword(id) {
            ArchiveResetProfiles(ids)
            return
        }
    }
}

GeneratePasswordSalt() {
    salt := ""
    Loop 16
        salt .= Format("{:02x}", Random(0, 255))
    return salt
}

CalcSHA256(text) {
    size := StrPut(text, "UTF-8")
    buf := Buffer(size)
    StrPut(text, buf, "UTF-8")
    dataLen := size - 1
    hProv := 0
    hHash := 0
    hash := Buffer(32, 0)
    hashSize := 32
    if !DllCall("Advapi32\CryptAcquireContext", "Ptr*", &hProv, "Ptr", 0, "Ptr", 0, "UInt", 24, "UInt", 0xF0000000)
        return ""
    if !DllCall("Advapi32\CryptCreateHash", "Ptr", hProv, "UInt", 0x800C, "Ptr", 0, "UInt", 0, "Ptr*", &hHash) {
        DllCall("Advapi32\CryptReleaseContext", "Ptr", hProv, "UInt", 0)
        return ""
    }
    DllCall("Advapi32\CryptHashData", "Ptr", hHash, "Ptr", buf, "UInt", dataLen, "UInt", 0)
    DllCall("Advapi32\CryptGetHashParam", "Ptr", hHash, "UInt", 2, "Ptr", hash, "UInt*", &hashSize, "UInt", 0)
    DllCall("Advapi32\CryptDestroyHash", "Ptr", hHash)
    DllCall("Advapi32\CryptReleaseContext", "Ptr", hProv, "UInt", 0)
    hex := ""
    Loop hashSize
        hex .= Format("{:02x}", NumGet(hash, A_Index - 1, "UChar"))
    return hex
}

BuildPasswordHash(password, salt) {
    return CalcSHA256(salt . password)
}

PasswordHashLogSafe(profileId, salt, hash, event) {
    saltOk := (salt != "") ? "yes" : "no"
    hashLen := StrLen(hash)
    WriteLog(event, profileId . " | salt=" . saltOk . " | hash_len=" . hashLen)
    WriteProfileLog(profileId, event, "salt=" . saltOk . " hash_len=" . hashLen)
}

SetProfilePassword(profileId, password) {
    profileDir := PROFILES_DIR "\" profileId
    password := Trim(password)
    salt := GeneratePasswordSalt()
    hash := BuildPasswordHash(password, salt)
    if (hash = "") {
        PasswordHashLogSafe(profileId, salt, hash, "password_hash_created")
        return false
    }
    IniWrite(salt, profileDir "\profile.ini", "Profile", "password_salt")
    IniWrite(hash, profileDir "\profile.ini", "Profile", "password_hash")
    IniWrite("1", profileDir "\profile.ini", "Profile", "password_set")
    PasswordHashLogSafe(profileId, salt, hash, "password_hash_created")
    WriteLog("profile_password_set", profileId)
    WriteProfileLog(profileId, "profile_password_set")
    return true
}

VerifyProfilePassword(profileId, password) {
    iniPath := PROFILES_DIR "\" profileId "\profile.ini"
    password := Trim(password)
    salt := IniRead(iniPath, "Profile", "password_salt", "")
    hash := IniRead(iniPath, "Profile", "password_hash", "")
    PasswordHashLogSafe(profileId, salt, hash, "password_hash_loaded")
    if (salt = "" || hash = "")
        return false
    computed := BuildPasswordHash(password, salt)
    return (computed != "" && computed = hash)
}

RouteAfterProfileLogin(profileId) {
    global SOUL_TEST_BACK_SCREEN
    LoadProfile(profileId)
    WriteLog("profile_login_success", profileId)
    WriteProfileLog(profileId, "profile_login_success")
    if (IsCreatorProfile(profileId)) {
        if (TryResumeSoulSession(profileId)) {
            SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
            RenderScreen("prima_soul_question")
            return
        }
        if (TryResumeVdaSession(profileId)) {
            RenderScreen("prima_vda_rank")
            return
        }
        if (TryResumeShadowSession(profileId)) {
            RenderScreen("prima_shadow_question")
            return
        }
        RenderScreen("creator_home")
        return
    }
    privacy := IniRead(PROFILES_DIR "\" profileId "\consent.ini", "Consent", "privacy_accepted", "no")
    if (privacy != "yes") {
        RenderScreen("privacy")
        return
    }
    if (TryResumeSoulSession(profileId)) {
        SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
        RenderScreen("prima_soul_question")
        return
    }
    if (TryResumeVdaSession(profileId)) {
        RenderScreen("prima_vda_rank")
        return
    }
    if (TryResumeShadowSession(profileId)) {
        RenderScreen("prima_shadow_question")
        return
    }
    RenderScreen("home")
}

LoadProfile(profileId) {
    global CURRENT_PROFILE_ID, CURRENT_DISPLAY_NAME, CURRENT_LANG
    CURRENT_PROFILE_ID := profileId
    CURRENT_DISPLAY_NAME := IniRead(PROFILES_DIR "\" profileId "\profile.ini", "Profile", "display_name", profileId)
    CURRENT_LANG := GetProfileLanguage(profileId)
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm:ss"), PROFILES_DIR "\" profileId "\profile.ini", "Profile", "last_used_at")
    SetLastProfileId(profileId)
    WriteLog("profile_loaded", profileId " | " CURRENT_DISPLAY_NAME)
}

CanSkipToHome() {
    lastId := GetLastProfileId()
    if (lastId = "")
        return false
    profileDir := PROFILES_DIR "\" lastId
    if !DirExist(profileDir)
        return false
    if (IsCreatorProfile(lastId))
        return true
    privacy := IniRead(profileDir "\consent.ini", "Consent", "privacy_accepted", "no")
    onboarding := IniRead(profileDir "\state.ini", "State", "onboarding_completed", "no")
    return (privacy = "yes" && onboarding = "yes")
}

CreateProfile(displayName, lang := "fr", mode := "client") {
    profileId := GenerateProfileId(displayName)
    profileDir := PROFILES_DIR "\" profileId
    DirCreate(profileDir)
    DirCreate(profileDir "\logs")

    lang := (lang = "en") ? "en" : "fr"
    mode := (mode = "creator") ? "creator" : "client"
    now := FormatTime(, "yyyy-MM-dd HH:mm:ss")
    IniWrite(profileId, profileDir "\profile.ini", "Profile", "profile_id")
    IniWrite(displayName, profileDir "\profile.ini", "Profile", "display_name")
    IniWrite(lang, profileDir "\profile.ini", "Profile", "language")
    IniWrite(mode, profileDir "\profile.ini", "Profile", "mode")
    IniWrite(now, profileDir "\profile.ini", "Profile", "created_at")
    IniWrite(now, profileDir "\profile.ini", "Profile", "last_used_at")
    IniWrite("no", profileDir "\consent.ini", "Consent", "privacy_accepted")
    IniWrite("no", profileDir "\state.ini", "State", "onboarding_completed")

    AddProfileToIndex(profileId)
    LoadProfile(profileId)
    WriteLog("profile_created", profileId . "|" . displayName)
    WriteProfileLog(profileId, "profile_created", displayName)
    return profileId
}

SaveProfileLanguage(profileId, lang) {
    lang := (lang = "en") ? "en" : "fr"
    IniWrite(lang, PROFILES_DIR "\" profileId "\profile.ini", "Profile", "language")
}

RestoreSessionLanguage() {
    global CURRENT_PROFILE_ID, CURRENT_LANG
    if (CURRENT_PROFILE_ID != "")
        CURRENT_LANG := GetProfileLanguage(CURRENT_PROFILE_ID)
    else
        CURRENT_LANG := "fr"
}

SanitizeReviewField(text) {
    return StrReplace(StrReplace(Trim(text), "`r", ""), "`n", " / ")
}

GetMoodLabels() {
    global CURRENT_LANG
    if (CURRENT_LANG = "en")
        return ["Happy", "Sad", "Upset", "Stressed", "Motivated", "Tired", "Calm", "Proud"]
    return ["Heureux", "Triste", "Contrarié", "Stressé", "Motivé", "Fatigué", "Calme", "Fier"]
}

GetMoodCodes() {
    return ["happy", "sad", "upset", "stressed", "motivated", "tired", "calm", "proud"]
}

GetEnergyLabels() {
    global CURRENT_LANG
    if (CURRENT_LANG = "en")
        return ["Energized", "Medium", "Tired", "Exhausted"]
    return ["En forme", "Moyen", "Fatigué", "Épuisé"]
}

GetEnergyCodes() {
    return ["energized", "medium", "tired", "exhausted"]
}

GetDomainCodes() {
    return ["Sport", "Work", "Family", "Health", "Money", "Personal"]
}

GetDomainLabels() {
    global CURRENT_LANG
    if (CURRENT_LANG = "en")
        return ["Sport", "Work", "Family", "Health", "Money", "Personal"]
    return ["Sport", "Travail", "Famille", "Santé", "Argent", "Perso"]
}

GetDomainLabelForCode(code) {
    codes := GetDomainCodes()
    labels := GetDomainLabels()
    loop codes.Length {
        if (codes[A_Index] = code)
            return labels[A_Index]
    }
    return code
}

CodeFromLabel(label) {
    labels := GetDomainLabels()
    codes := GetDomainCodes()
    loop labels.Length {
        if (labels[A_Index] = label)
            return codes[A_Index]
    }
    return ""
}

GoalsIniPath(profileId) {
    return PROFILES_DIR "\" profileId "\goals.ini"
}

; ── PRIMA Soul minimal V0.1 — données locales ─────────────────────────────────
SoulIniPath(profileId) {
    return PROFILES_DIR "\" profileId "\soul.ini"
}

GetSoulChoiceCodes() {
    return Map(
        "tone",   ["soft", "direct", "balanced"],
        "rhythm", ["light", "normal", "sustained"],
        "energy", ["low", "medium", "high"],
        "need",   ["clarity", "motivation", "calm", "structure"],
        "rest",   ["discreet", "guided", "off"]
    )
}

GetSoulChoiceLabels(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "tone":   return ["Soft", "Direct", "Balanced"]
            case "rhythm": return ["Light", "Normal", "Sustained"]
            case "energy": return ["Low", "Medium", "High"]
            case "need":   return ["Clarity", "Motivation", "Calm", "Structure"]
            case "rest":   return ["Discreet", "Guided", "Off"]
        }
    } else {
        switch key {
            case "tone":   return ["Doux", "Direct", "Équilibré"]
            case "rhythm": return ["Léger", "Normal", "Soutenu"]
            case "energy": return ["Basse", "Moyenne", "Haute"]
            case "need":   return ["Clarté", "Motivation", "Calme", "Structure"]
            case "rest":   return ["Discret", "Guidé", "Désactivé"]
        }
    }
    return []
}

LoadSoulChoice(profileId, key) {
    return IniRead(SoulIniPath(profileId), "Soul", key, "")
}

SaveSoulChoices(profileId, tone, rhythm, energy, need, rest) {
    file := SoulIniPath(profileId)
    IniWrite(tone, file, "Soul", "tone")
    IniWrite(rhythm, file, "Soul", "rhythm")
    IniWrite(energy, file, "Soul", "energy")
    IniWrite(need, file, "Soul", "need")
    IniWrite(rest, file, "Soul", "rest")
    IniWrite("yes", file, "Soul", "completed")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm:ss"), file, "Soul", "updated_at")
}

IsSoulCompleted(profileId) {
    return IniRead(SoulIniPath(profileId), "Soul", "completed", "no") = "yes"
}

; ── PRIMA Soul — moteur de parcours (architecture interne) ───────────────────
; Paths : prima_vda | prima_soul | prima_shadow
; Contextes autorisés (internes) : famille | amitie | amour | travail | relation | maintenant
; Catégories neutres autorisées : relation, groupe, choix, pression, changement,
; effort, attente, limite, conflit, imprévu, regard, aide,
; silence, confiance, controle, justice.
; context, category, signal_type et les clés de scores sont internes uniquement
; et ne doivent JAMAIS être affichés à l'utilisateur.

global SOUL_SESSION := ""

; ── Constantes internes (jamais affichées à l'écran) ──────────────────────────
; Clés de scores PRIMA Soul (base PCM interne).
GetSoulPcmKeys() {
    return ["analyseur", "perseverant", "empathique", "imagineur", "energiseur", "promoteur"]
}

; Clés de scores PRIMA VDA (base interne).
GetSoulVdaKeys() {
    return ["rejet", "abandon", "humiliation", "trahison", "injustice"]
}

; Dimensions internes PCM pour catégoriser les futures questions prima_soul.
GetSoulPcmDimensions() {
    return ["perception", "besoin", "stress", "communication", "interaction", "environnement", "force"]
}

; Clés de scores autorisées selon le parcours.
; prima_soul = test 15 situations (axes internes VDA) ; prima_vda = futur PCM.
GetSoulScoreKeys(path) {
    switch path {
        case "prima_soul": return GetSoulVdaKeys()
        case "prima_vda":  return GetSoulPcmKeys()
    }
    return []  ; prima_shadow : rien pour l'instant
}

; signal_type autorisés selon le parcours (champ optionnel des questions).
GetSoulSignalTypes(path) {
    switch path {
        case "prima_soul": return ["emotion", "besoin", "comportement", "contexte", "repetition"]
        case "prima_vda":  return ["perception", "besoin", "stress", "communication", "interaction", "environnement", "force", "phase"]
    }
    return []  ; prima_shadow : rien pour l'instant
}

GetSoulQuestionBank() {
    ; ============================================================
    ; prima_soul : banque V0.1 réelle — 15 questions × 5 réponses (1 par axe interne).
    ;              Lancée par PRIMA Soul Test.
    ; prima_vda : PLACEHOLDERS PCM non utilisés (futur PRIMA VDA Test).
    ; Scores internes, jamais affichés. Choix 1 à 2 ; priorité 1 = +2, priorité 2 = +1.
    ; ============================================================
    bank := []

    ; ── prima_soul — banque V0.1 (15 questions) ──
    bank.Push({
        id: "vda_01", path: "prima_soul", context: "amitie", category: "groupe", signal_type: "emotion",
        prompt: "Quand tu arrives avec des gens, tu fais quoi d'abord ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je regarde si je peux venir avec eux.", scores: Map("rejet", 1) },
            { id: "a2", text: "Je vais vite vers quelqu'un que je connais.", scores: Map("abandon", 1) },
            { id: "a3", text: "Je fais attention à ne pas gêner.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je vérifie si les gens sont corrects avec moi.", scores: Map("trahison", 1) },
            { id: "a5", text: "Je regarde si tout le monde est traité pareil.", scores: Map("injustice", 1) }
        ]
    })

    bank.Push({
        id: "vda_02", path: "prima_soul", context: "famille", category: "regard", signal_type: "comportement",
        prompt: "Quand on te regarde trop, tu ressens quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "J'ai envie de me cacher.", scores: Map("rejet", 1) },
            { id: "a2", text: "J'ai besoin qu'on me rassure.", scores: Map("abandon", 1) },
            { id: "a3", text: "J'ai peur d'avoir l'air ridicule.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je me tiens droit et je contrôle.", scores: Map("injustice", 1) },
            { id: "a5", text: "Je me méfie de ce qu'on pense vraiment.", scores: Map("trahison", 1) }
        ]
    })

    bank.Push({
        id: "vda_03", path: "prima_soul", context: "travail", category: "aide", signal_type: "besoin",
        prompt: "Quand tu dois demander quelque chose, tu penses quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je vais peut-être déranger.", scores: Map("rejet", 1) },
            { id: "a2", text: "J'espère qu'on va m'aider.", scores: Map("abandon", 1) },
            { id: "a3", text: "J'ai honte de demander.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je veux être sûr que ce sera bien fait.", scores: Map("trahison", 1) },
            { id: "a5", text: "Je veux que ce soit équitable pour tout le monde.", scores: Map("injustice", 1) }
        ]
    })

    bank.Push({
        id: "vda_04", path: "prima_soul", context: "amour", category: "attente", signal_type: "emotion",
        prompt: "Quand quelqu'un répond moins vite, tu fais quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je me dis que je ne compte pas trop.", scores: Map("rejet", 1) },
            { id: "a2", text: "J'attends un signe qu'il est encore là.", scores: Map("abandon", 1) },
            { id: "a3", text: "Je garde pour moi pour ne pas faire lourd.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je me demande s'il cache quelque chose.", scores: Map("trahison", 1) },
            { id: "a5", text: "Je trouve ça injuste qu'on ne réponde pas pareil.", scores: Map("injustice", 1) }
        ]
    })

    bank.Push({
        id: "vda_05", path: "prima_soul", context: "famille", category: "relation", signal_type: "besoin",
        prompt: "Quand une personne part longtemps, tu ressens quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je fais comme si ça ne me touchait pas.", scores: Map("rejet", 1) },
            { id: "a2", text: "J'ai peur qu'elle m'oublie.", scores: Map("abandon", 1) },
            { id: "a3", text: "Je prends sur moi pour ne pas embêter.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je veux savoir quand elle revient.", scores: Map("trahison", 1) },
            { id: "a5", text: "Je veux que les choses restent justes entre nous.", scores: Map("injustice", 1) }
        ]
    })

    bank.Push({
        id: "vda_06", path: "prima_soul", context: "amitie", category: "silence", signal_type: "repetition",
        prompt: "Quand il y a un silence, tu penses quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Peut-être qu'on ne veut pas de moi.", scores: Map("rejet", 1) },
            { id: "a2", text: "Peut-être qu'on m'oublie.", scores: Map("abandon", 1) },
            { id: "a3", text: "J'ai honte de mon silence.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je cherche ce qui a changé.", scores: Map("trahison", 1) },
            { id: "a5", text: "Ce silence me semble injuste.", scores: Map("injustice", 1) }
        ]
    })

    bank.Push({
        id: "vda_07", path: "prima_soul", context: "famille", category: "limite", signal_type: "comportement",
        prompt: "Quand tu veux dire non, c'est quoi le plus dur ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Peur qu'on ne m'aime plus.", scores: Map("abandon", 1) },
            { id: "a2", text: "Peur qu'on se moque de moi.", scores: Map("humiliation", 1) },
            { id: "a3", text: "Peur qu'on me mette de côté.", scores: Map("rejet", 1) },
            { id: "a4", text: "Peur que ce soit injuste pour quelqu'un.", scores: Map("injustice", 1) },
            { id: "a5", text: "Peur qu'on trahisse ma confiance.", scores: Map("trahison", 1) }
        ]
    })

    bank.Push({
        id: "vda_08", path: "prima_soul", context: "travail", category: "effort", signal_type: "comportement",
        prompt: "Quand il y a trop à faire, tu fais quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je reste discret et je fais mon coin.", scores: Map("rejet", 1) },
            { id: "a2", text: "Je cherche quelqu'un pour m'aider.", scores: Map("abandon", 1) },
            { id: "a3", text: "Je prends trop sur moi.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je veux tout rendre parfait.", scores: Map("injustice", 1) },
            { id: "a5", text: "Je ne peux pas faire confiance aux autres pour le faire.", scores: Map("trahison", 1) }
        ]
    })

    bank.Push({
        id: "vda_09", path: "prima_soul", context: "amitie", category: "aide", signal_type: "repetition",
        prompt: "Quand quelqu'un a un problème, tu fais quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je reste loin si je ne sais pas ma place.", scores: Map("rejet", 1) },
            { id: "a2", text: "Je reste proche pour garder le lien.", scores: Map("abandon", 1) },
            { id: "a3", text: "J'aide même si je suis fatigué.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je vérifie qui a fait quoi.", scores: Map("trahison", 1) },
            { id: "a5", text: "Je veux que chacun assume sa part.", scores: Map("injustice", 1) }
        ]
    })

    bank.Push({
        id: "vda_10", path: "prima_soul", context: "amour", category: "confiance", signal_type: "emotion",
        prompt: "Quand quelqu'un ne tient pas parole, tu ressens quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je me ferme et je disparais un peu.", scores: Map("rejet", 1) },
            { id: "a2", text: "J'ai peur que le lien casse.", scores: Map("abandon", 1) },
            { id: "a3", text: "Je me sens bête d'y avoir cru.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je ne veux plus faire confiance.", scores: Map("trahison", 1) },
            { id: "a5", text: "Ce n'était pas juste envers moi.", scores: Map("injustice", 1) }
        ]
    })

    bank.Push({
        id: "vda_11", path: "prima_soul", context: "travail", category: "controle", signal_type: "comportement",
        prompt: "Quand tu dois faire confiance, c'est quoi le plus dur ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Laisser ma place à quelqu'un.", scores: Map("rejet", 1) },
            { id: "a2", text: "Ne pas chercher de soutien.", scores: Map("abandon", 1) },
            { id: "a3", text: "Ne pas porter à la place des autres.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Ne pas vérifier tout le temps.", scores: Map("trahison", 1) },
            { id: "a5", text: "Accepter que ce ne soit pas toujours équitable.", scores: Map("injustice", 1) }
        ]
    })

    bank.Push({
        id: "vda_12", path: "prima_soul", context: "famille", category: "changement", signal_type: "repetition",
        prompt: "Quand les choses changent sans prévenir, tu fais quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je me mets en retrait.", scores: Map("rejet", 1) },
            { id: "a2", text: "Je demande si tout va bien.", scores: Map("abandon", 1) },
            { id: "a3", text: "Je m'adapte même si ça me gêne.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je veux reprendre le contrôle.", scores: Map("trahison", 1) },
            { id: "a5", text: "Je veux que ce soit juste pour tout le monde.", scores: Map("injustice", 1) }
        ]
    })

    bank.Push({
        id: "vda_13", path: "prima_soul", context: "travail", category: "pression", signal_type: "emotion",
        prompt: "Quand tu fais une erreur, tu ressens quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je voudrais disparaître.", scores: Map("rejet", 1) },
            { id: "a2", text: "J'ai besoin qu'on me dise que ça va.", scores: Map("abandon", 1) },
            { id: "a3", text: "J'ai honte.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je veux vite corriger parfaitement.", scores: Map("injustice", 1) },
            { id: "a5", text: "Je crains qu'on ne me fasse plus confiance.", scores: Map("trahison", 1) }
        ]
    })

    bank.Push({
        id: "vda_14", path: "prima_soul", context: "amitie", category: "regard", signal_type: "besoin",
        prompt: "Quand on te critique, tu veux quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Qu'on me laisse tranquille.", scores: Map("rejet", 1) },
            { id: "a2", text: "Qu'on me rassure.", scores: Map("abandon", 1) },
            { id: "a3", text: "Qu'on ne me rabaisse pas.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Qu'on soit juste et précis.", scores: Map("injustice", 1) },
            { id: "a5", text: "Je me demande si je peux encore faire confiance.", scores: Map("trahison", 1) }
        ]
    })

    bank.Push({
        id: "vda_15", path: "prima_soul", context: "famille", category: "justice", signal_type: "repetition",
        prompt: "Quand ce n'est pas juste, tu fais quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je me coupe un peu des autres.", scores: Map("rejet", 1) },
            { id: "a2", text: "Je cherche quelqu'un de mon côté.", scores: Map("abandon", 1) },
            { id: "a3", text: "Je prends sur moi trop longtemps.", scores: Map("humiliation", 1) },
            { id: "a4", text: "Je deviens froid ou dur.", scores: Map("injustice", 1) },
            { id: "a5", text: "Je me méfie de ceux qui en profitent.", scores: Map("trahison", 1) }
        ]
    })

    ; ── prima_vda — banque V0.1, MODE COURT (20 questions, classement 6 réponses) ──
    ; Source officielle : PRIMA_Questionnaire_PCM_Univers_Max (96 questions, 16 univers).
    ; Mode court = Q1-Q12 Base probable (max 72 pts) / Q13-Q20 Phase actuelle probable (max 48 pts).
    ; Modes profond (48 questions) et expert (96 questions) prévus plus tard.
    ; pcm_key interne uniquement, jamais affiché.
    bank.Push({
        id: "vda_pcm_01", path: "prima_vda", context: "amitie", category: "groupe", signal_type: "perception",
        prompt: "Quand tu arrives dans un nouveau groupe, qu'est-ce qui te met le plus à l'aise ?",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Sentir que les gens sont chaleureux, bienveillants et accueillants.", pcm_key: "empathique" },
            { id: "a2", text: "Comprendre rapidement les règles, le fonctionnement et l'organisation.", pcm_key: "analyseur" },
            { id: "a3", text: "Voir que les valeurs, les intentions et le sérieux du groupe sont clairs.", pcm_key: "perseverant" },
            { id: "a4", text: "Pouvoir observer tranquillement avant de participer.", pcm_key: "imagineur" },
            { id: "a5", text: "Sentir qu'il y a de l'énergie, de l'humour et de la spontanéité.", pcm_key: "energiseur" },
            { id: "a6", text: "Voir qu'il y a du challenge, du mouvement et des opportunités à saisir.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_02", path: "prima_vda", context: "travail", category: "effort", signal_type: "besoin",
        prompt: "Quand tu travailles sur un projet important, tu as surtout besoin de…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Te sentir soutenu humainement et apprécié.", pcm_key: "empathique" },
            { id: "a2", text: "Avoir un plan clair, logique et structuré.", pcm_key: "analyseur" },
            { id: "a3", text: "Savoir que le projet a du sens et respecte tes valeurs.", pcm_key: "perseverant" },
            { id: "a4", text: "Avoir de l'espace, du calme et peu d'interruptions.", pcm_key: "imagineur" },
            { id: "a5", text: "Pouvoir t'amuser un peu, tester, réagir, improviser.", pcm_key: "energiseur" },
            { id: "a6", text: "Avoir un objectif concret, rapide et stimulant.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_03", path: "prima_vda", context: "famille", category: "besoin", signal_type: "besoin",
        prompt: "Quelle phrase te ressemble le plus ?",
        max_choices: 6,
        answers: [
            { id: "a1", text: "J'ai besoin de sentir que je compte pour les autres.", pcm_key: "empathique" },
            { id: "a2", text: "J'aime comprendre, organiser et faire les choses correctement.", pcm_key: "analyseur" },
            { id: "a3", text: "J'ai besoin d'être aligné avec ce que je fais.", pcm_key: "perseverant" },
            { id: "a4", text: "J'ai besoin de temps seul pour réfléchir et me recentrer.", pcm_key: "imagineur" },
            { id: "a5", text: "J'ai besoin que ça bouge, que ce soit vivant.", pcm_key: "energiseur" },
            { id: "a6", text: "J'aime agir, tenter, gagner, provoquer le destin.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_04", path: "prima_vda", context: "relation", category: "critique", signal_type: "stress",
        prompt: "Quand quelqu'un te critique, ce qui te touche le plus c'est…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Le ton froid, dur ou blessant.", pcm_key: "empathique" },
            { id: "a2", text: "Le manque de précision ou de logique dans ce qu'on te reproche.", pcm_key: "analyseur" },
            { id: "a3", text: "Le sentiment qu'on remet en cause ton intégrité ou tes valeurs.", pcm_key: "perseverant" },
            { id: "a4", text: "Le fait qu'on t'envahisse ou qu'on te force à réagir vite.", pcm_key: "imagineur" },
            { id: "a5", text: "Le fait qu'on te juge au lieu de te laisser être toi-même.", pcm_key: "energiseur" },
            { id: "a6", text: "Le fait qu'on te bloque, te contrôle ou te ralentisse.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_05", path: "prima_vda", context: "amour", category: "relation", signal_type: "besoin",
        prompt: "Dans une relation forte, tu recherches surtout…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "De la tendresse, de l'écoute et de l'attention.", pcm_key: "empathique" },
            { id: "a2", text: "De la stabilité, de la fiabilité et de la clarté.", pcm_key: "analyseur" },
            { id: "a3", text: "De la loyauté, du respect et des convictions partagées.", pcm_key: "perseverant" },
            { id: "a4", text: "De l'espace, de la confiance et peu de pression.", pcm_key: "imagineur" },
            { id: "a5", text: "De la complicité, du jeu et de la spontanéité.", pcm_key: "energiseur" },
            { id: "a6", text: "De l'intensité, du désir, du challenge et de l'action.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_06", path: "prima_vda", context: "travail", category: "choix", signal_type: "perception",
        prompt: "Quand tu dois prendre une décision, tu te bases d'abord sur…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Ce que tu ressens et l'impact humain.", pcm_key: "empathique" },
            { id: "a2", text: "Les faits, les données et la logique.", pcm_key: "analyseur" },
            { id: "a3", text: "Tes convictions, tes principes et ce qui est juste.", pcm_key: "perseverant" },
            { id: "a4", text: "Ton intuition intérieure après un temps de recul.", pcm_key: "imagineur" },
            { id: "a5", text: "Ton envie du moment, ton ressenti immédiat.", pcm_key: "energiseur" },
            { id: "a6", text: "Le résultat possible et l'opportunité concrète.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_07", path: "prima_vda", context: "travail", category: "reconnaissance", signal_type: "besoin",
        prompt: "Quel type de reconnaissance te nourrit le plus ?",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Tu es important pour moi.", pcm_key: "empathique" },
            { id: "a2", text: "Ton travail est propre, sérieux et utile.", pcm_key: "analyseur" },
            { id: "a3", text: "Ton engagement et tes valeurs sont respectables.", pcm_key: "perseverant" },
            { id: "a4", text: "Je respecte ton rythme et ton espace.", pcm_key: "imagineur" },
            { id: "a5", text: "J'adore ton énergie, tu me fais rire.", pcm_key: "energiseur" },
            { id: "a6", text: "Tu as assuré, tu as pris le risque et tu as gagné.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_08", path: "prima_vda", context: "famille", category: "pression", signal_type: "stress",
        prompt: "Quand tu es fatigué mentalement, tu as tendance à…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Te sentir blessé, oublié ou pas assez aimé.", pcm_key: "empathique" },
            { id: "a2", text: "Devenir perfectionniste, contrôlant ou surchargé.", pcm_key: "analyseur" },
            { id: "a3", text: "Juger plus vite, te raidir ou vouloir convaincre.", pcm_key: "perseverant" },
            { id: "a4", text: "Te couper, disparaître ou te mettre en retrait.", pcm_key: "imagineur" },
            { id: "a5", text: "Provoquer, râler, t'agiter ou chercher une réaction.", pcm_key: "energiseur" },
            { id: "a6", text: "Forcer, prendre des risques ou vouloir reprendre le contrôle.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_09", path: "prima_vda", context: "amitie", category: "groupe", signal_type: "force",
        prompt: "Dans un groupe, tu apportes naturellement…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Du lien, de la douceur et de l'attention aux autres.", pcm_key: "empathique" },
            { id: "a2", text: "De l'organisation, de la méthode et de la fiabilité.", pcm_key: "analyseur" },
            { id: "a3", text: "De la vision, des valeurs et du sérieux.", pcm_key: "perseverant" },
            { id: "a4", text: "Du recul, de l'observation et de la profondeur silencieuse.", pcm_key: "imagineur" },
            { id: "a5", text: "De l'énergie, de l'humour et de la créativité spontanée.", pcm_key: "energiseur" },
            { id: "a6", text: "De l'audace, du mouvement et une capacité à décider vite.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_10", path: "prima_vda", context: "travail", category: "environnement", signal_type: "environnement",
        prompt: "Ce qui t'épuise le plus dans ton environnement…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Le manque de chaleur humaine.", pcm_key: "empathique" },
            { id: "a2", text: "Le désordre, l'imprévu permanent ou l'inefficacité.", pcm_key: "analyseur" },
            { id: "a3", text: "L'hypocrisie, l'injustice ou l'absence de valeurs.", pcm_key: "perseverant" },
            { id: "a4", text: "Le bruit, la pression sociale ou les sollicitations constantes.", pcm_key: "imagineur" },
            { id: "a5", text: "L'ennui, la rigidité ou les ambiances trop sérieuses.", pcm_key: "energiseur" },
            { id: "a6", text: "La lenteur, la passivité ou le manque d'action.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_11", path: "prima_vda", context: "travail", category: "probleme", signal_type: "interaction",
        prompt: "Face à un problème, ton premier réflexe est plutôt de…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Voir comment chacun se sent et préserver le lien.", pcm_key: "empathique" },
            { id: "a2", text: "Analyser la situation et chercher une solution logique.", pcm_key: "analyseur" },
            { id: "a3", text: "Identifier ce qui est juste, vrai ou acceptable.", pcm_key: "perseverant" },
            { id: "a4", text: "Prendre du recul et réfléchir seul avant d'agir.", pcm_key: "imagineur" },
            { id: "a5", text: "Dédramatiser, réagir vite ou changer l'énergie.", pcm_key: "energiseur" },
            { id: "a6", text: "Agir directement, tester une solution et ajuster après.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_12", path: "prima_vda", context: "famille", category: "confiance", signal_type: "force",
        prompt: "Quelle situation te donne le plus confiance en toi ?",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Quand tu te sens aimé, accepté et important.", pcm_key: "empathique" },
            { id: "a2", text: "Quand tu maîtrises ton sujet et que ton travail est reconnu.", pcm_key: "analyseur" },
            { id: "a3", text: "Quand tu défends quelque chose qui a du sens.", pcm_key: "perseverant" },
            { id: "a4", text: "Quand on te laisse avancer à ton rythme.", pcm_key: "imagineur" },
            { id: "a5", text: "Quand tu peux être libre, drôle et spontané.", pcm_key: "energiseur" },
            { id: "a6", text: "Quand tu réussis un défi concret.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_13", path: "prima_vda", context: "maintenant", category: "manque", signal_type: "phase",
        prompt: "En ce moment, ce qui te manque le plus, c'est…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "De l'affection, de la douceur ou de la présence.", pcm_key: "empathique" },
            { id: "a2", text: "De la structure, de la clarté ou du contrôle.", pcm_key: "analyseur" },
            { id: "a3", text: "Du sens, de la reconnaissance ou du respect.", pcm_key: "perseverant" },
            { id: "a4", text: "Du calme, du silence ou de la solitude.", pcm_key: "imagineur" },
            { id: "a5", text: "Du fun, de la légèreté ou de la stimulation.", pcm_key: "energiseur" },
            { id: "a6", text: "De l'action, de l'intensité ou des résultats rapides.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_14", path: "prima_vda", context: "maintenant", category: "frustration", signal_type: "phase",
        prompt: "En ce moment, tu te sens le plus frustré quand…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Les autres ne voient pas tes besoins émotionnels.", pcm_key: "empathique" },
            { id: "a2", text: "Les choses sont floues, mal organisées ou incomplètes.", pcm_key: "analyseur" },
            { id: "a3", text: "Les gens manquent de respect, d'engagement ou de valeurs.", pcm_key: "perseverant" },
            { id: "a4", text: "On te demande trop, trop vite, trop souvent.", pcm_key: "imagineur" },
            { id: "a5", text: "Tout est trop sérieux, prévisible ou ennuyeux.", pcm_key: "energiseur" },
            { id: "a6", text: "Tu te sens bloqué, dépendant ou privé de liberté d'action.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_15", path: "prima_vda", context: "maintenant", category: "pression", signal_type: "phase",
        prompt: "Quand tu es sous pression actuellement, tu cherches surtout à…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Être rassuré affectivement.", pcm_key: "empathique" },
            { id: "a2", text: "Reprendre le contrôle par l'organisation.", pcm_key: "analyseur" },
            { id: "a3", text: "Défendre ton point de vue ou tes principes.", pcm_key: "perseverant" },
            { id: "a4", text: "Te retirer pour respirer.", pcm_key: "imagineur" },
            { id: "a5", text: "Faire redescendre la pression avec humour ou agitation.", pcm_key: "energiseur" },
            { id: "a6", text: "Passer à l'action immédiatement.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_16", path: "prima_vda", context: "maintenant", category: "besoin", signal_type: "phase",
        prompt: "Ce qui te ferait le plus de bien cette semaine…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Un moment tendre avec quelqu'un qui compte.", pcm_key: "empathique" },
            { id: "a2", text: "Une journée productive où tout avance clairement.", pcm_key: "analyseur" },
            { id: "a3", text: "Une discussion profonde où tu te sens respecté.", pcm_key: "perseverant" },
            { id: "a4", text: "Un vrai moment seul sans culpabilité.", pcm_key: "imagineur" },
            { id: "a5", text: "Une activité drôle, créative ou imprévue.", pcm_key: "energiseur" },
            { id: "a6", text: "Un défi, une victoire ou une prise de risque réussie.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_17", path: "prima_vda", context: "maintenant", category: "danger", signal_type: "phase",
        prompt: "En ce moment, ton danger principal serait plutôt…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Trop attendre des autres affectivement.", pcm_key: "empathique" },
            { id: "a2", text: "Trop vouloir tout contrôler ou tout perfectionner.", pcm_key: "analyseur" },
            { id: "a3", text: "Trop juger, te raidir ou vouloir convaincre.", pcm_key: "perseverant" },
            { id: "a4", text: "Trop t'isoler ou disparaître.", pcm_key: "imagineur" },
            { id: "a5", text: "Trop provoquer ou saboter par réaction.", pcm_key: "energiseur" },
            { id: "a6", text: "Trop foncer ou prendre des risques inutiles.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_18", path: "prima_vda", context: "maintenant", category: "ideal", signal_type: "phase",
        prompt: "Quand tu imagines une bonne journée idéale maintenant, il y a surtout…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "De l'amour, du lien, de la douceur.", pcm_key: "empathique" },
            { id: "a2", text: "Des tâches finies, une progression claire, de l'ordre.", pcm_key: "analyseur" },
            { id: "a3", text: "Du sens, de la loyauté, des échanges profonds.", pcm_key: "perseverant" },
            { id: "a4", text: "Du calme, de l'espace, peu de sollicitations.", pcm_key: "imagineur" },
            { id: "a5", text: "Du rire, de la créativité, des surprises.", pcm_key: "energiseur" },
            { id: "a6", text: "De l'action, de l'argent, du mouvement ou une victoire.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_19", path: "prima_vda", context: "maintenant", category: "attente", signal_type: "phase",
        prompt: "Ce que tu attends le plus des autres actuellement…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Qu'ils soient plus attentifs à toi.", pcm_key: "empathique" },
            { id: "a2", text: "Qu'ils soient plus fiables et organisés.", pcm_key: "analyseur" },
            { id: "a3", text: "Qu'ils soient plus honnêtes, respectueux et cohérents.", pcm_key: "perseverant" },
            { id: "a4", text: "Qu'ils te laissent respirer.", pcm_key: "imagineur" },
            { id: "a5", text: "Qu'ils soient plus simples, drôles et spontanés.", pcm_key: "energiseur" },
            { id: "a6", text: "Qu'ils soient plus rapides, directs et efficaces.", pcm_key: "promoteur" }
        ]
    })

    bank.Push({
        id: "vda_pcm_20", path: "prima_vda", context: "maintenant", category: "priorite", signal_type: "phase",
        prompt: "Si tu devais régler une seule chose en priorité dans ta vie maintenant, ce serait…",
        max_choices: 6,
        answers: [
            { id: "a1", text: "Te sentir plus aimé et émotionnellement nourri.", pcm_key: "empathique" },
            { id: "a2", text: "Retrouver une structure solide et maîtrisée.", pcm_key: "analyseur" },
            { id: "a3", text: "Retrouver du sens, du respect et de l'alignement.", pcm_key: "perseverant" },
            { id: "a4", text: "Retrouver du calme intérieur et de l'espace personnel.", pcm_key: "imagineur" },
            { id: "a5", text: "Retrouver de la joie, de l'énergie et du jeu.", pcm_key: "energiseur" },
            { id: "a6", text: "Retrouver de la puissance d'action et des résultats.", pcm_key: "promoteur" }
        ]
    })

    ; ── prima_shadow — banque beta V0.1 (15 questions, choix 1-2) ──
    ; Q1-Q10 = axes symboliques internes (7 clés) ;
    ; Q11-Q15 = émotion principale (5 clés internes).
    ; shadow_key interne uniquement, jamais affiché.
    bank.Push({
        id: "shadow_01", path: "prima_shadow", context: "travail", category: "pression", signal_type: "stress",
        prompt: "Quand tu es sous pression, qu'est-ce qui monte en premier ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je veux montrer que je suis à la hauteur.", shadow_key: "orgueil" },
            { id: "a2", text: "Je regarde où en sont les autres.", shadow_key: "envie" },
            { id: "a3", text: "Je sens l'agacement monter vite.", shadow_key: "colere" },
            { id: "a4", text: "J'ai envie de tout reporter à plus tard.", shadow_key: "paresse" },
            { id: "a5", text: "Je resserre tout : temps, argent, énergie.", shadow_key: "avarice" },
            { id: "a6", text: "Je compense avec quelque chose qui fait du bien.", shadow_key: "gourmandise" },
            { id: "a7", text: "Je cherche une sensation forte pour me sentir vivant.", shadow_key: "luxure" }
        ]
    })

    bank.Push({
        id: "shadow_02", path: "prima_shadow", context: "famille", category: "attente", signal_type: "besoin",
        prompt: "Quand on ne te donne pas ce que tu attends, tu fais quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je n'en montre rien, je gère seul.", shadow_key: "orgueil" },
            { id: "a2", text: "Je pense à ceux qui l'ont déjà.", shadow_key: "envie" },
            { id: "a3", text: "Je le fais sentir directement.", shadow_key: "colere" },
            { id: "a4", text: "Je laisse tomber la demande.", shadow_key: "paresse" },
            { id: "a5", text: "Je garde ce que j'ai et je ne donne plus.", shadow_key: "avarice" },
            { id: "a6", text: "Je me console autrement.", shadow_key: "gourmandise" },
            { id: "a7", text: "Je vais chercher l'intensité ailleurs.", shadow_key: "luxure" }
        ]
    })

    bank.Push({
        id: "shadow_03", path: "prima_shadow", context: "amitie", category: "regard", signal_type: "perception",
        prompt: "Quand quelqu'un brille devant tout le monde, tu ressens quoi ?",
        max_choices: 2,
        answers: [
            { id: "a1", text: "J'aimerais qu'on me voie aussi.", shadow_key: "orgueil" },
            { id: "a2", text: "Je compare avec ce que j'ai fait.", shadow_key: "envie" },
            { id: "a3", text: "Ça m'agace si c'est immérité.", shadow_key: "colere" },
            { id: "a4", text: "Ça ne me donne pas envie d'en faire plus.", shadow_key: "paresse" },
            { id: "a5", text: "Je calcule ce que ça lui rapporte.", shadow_key: "avarice" },
            { id: "a6", text: "Je profite de l'ambiance sans me prendre la tête.", shadow_key: "gourmandise" },
            { id: "a7", text: "Ça me donne envie de vivre quelque chose de fort.", shadow_key: "luxure" }
        ]
    })

    bank.Push({
        id: "shadow_04", path: "prima_shadow", context: "travail", category: "effort", signal_type: "comportement",
        prompt: "Quand un travail devient long et répétitif…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je tiens pour prouver que je peux.", shadow_key: "orgueil" },
            { id: "a2", text: "Je pense à ceux qui font plus intéressant.", shadow_key: "envie" },
            { id: "a3", text: "Je m'irrite contre tout le monde.", shadow_key: "colere" },
            { id: "a4", text: "Je ralentis et j'évite.", shadow_key: "paresse" },
            { id: "a5", text: "Je donne le minimum nécessaire.", shadow_key: "avarice" },
            { id: "a6", text: "Je multiplie les pauses plaisir.", shadow_key: "gourmandise" },
            { id: "a7", text: "Je cherche du frisson ailleurs.", shadow_key: "luxure" }
        ]
    })

    bank.Push({
        id: "shadow_05", path: "prima_shadow", context: "amour", category: "relation", signal_type: "besoin",
        prompt: "Dans une relation proche, ta tentation serait plutôt de…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Vouloir avoir raison.", shadow_key: "orgueil" },
            { id: "a2", text: "Comparer avec d'autres couples.", shadow_key: "envie" },
            { id: "a3", text: "Exploser quand ça déborde.", shadow_key: "colere" },
            { id: "a4", text: "Éviter les discussions difficiles.", shadow_key: "paresse" },
            { id: "a5", text: "Garder le contrôle sur tout.", shadow_key: "avarice" },
            { id: "a6", text: "Combler les manques par des plaisirs.", shadow_key: "gourmandise" },
            { id: "a7", text: "Chercher l'intensité avant tout.", shadow_key: "luxure" }
        ]
    })

    bank.Push({
        id: "shadow_06", path: "prima_shadow", context: "maintenant", category: "manque", signal_type: "besoin",
        prompt: "Quand tu te sens vide, tu remplis avec…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Des réussites à montrer.", shadow_key: "orgueil" },
            { id: "a2", text: "Ce que les autres ont l'air d'avoir.", shadow_key: "envie" },
            { id: "a3", text: "De la tension, des débats.", shadow_key: "colere" },
            { id: "a4", text: "Du rien, je coupe tout.", shadow_key: "paresse" },
            { id: "a5", text: "De l'accumulation, je stocke.", shadow_key: "avarice" },
            { id: "a6", text: "De la nourriture ou des plaisirs rapides.", shadow_key: "gourmandise" },
            { id: "a7", text: "Des sensations fortes.", shadow_key: "luxure" }
        ]
    })

    bank.Push({
        id: "shadow_07", path: "prima_shadow", context: "famille", category: "conflit", signal_type: "interaction",
        prompt: "En cas de conflit familial, ton premier mouvement…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Ne pas perdre la face.", shadow_key: "orgueil" },
            { id: "a2", text: "Pointer ce que les autres reçoivent de plus.", shadow_key: "envie" },
            { id: "a3", text: "Monter le ton.", shadow_key: "colere" },
            { id: "a4", text: "Fuir la pièce ou le sujet.", shadow_key: "paresse" },
            { id: "a5", text: "Compter ce que chacun doit.", shadow_key: "avarice" },
            { id: "a6", text: "Apaiser avec quelque chose d'agréable.", shadow_key: "gourmandise" },
            { id: "a7", text: "Dramatiser pour faire réagir fort.", shadow_key: "luxure" }
        ]
    })

    bank.Push({
        id: "shadow_08", path: "prima_shadow", context: "travail", category: "regard", signal_type: "perception",
        prompt: "Quand on ne reconnaît pas ton travail…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je me dis qu'ils ne sont pas au niveau.", shadow_key: "orgueil" },
            { id: "a2", text: "Je regarde qui est reconnu à ma place.", shadow_key: "envie" },
            { id: "a3", text: "Je rumine fort.", shadow_key: "colere" },
            { id: "a4", text: "Je me démotive.", shadow_key: "paresse" },
            { id: "a5", text: "Je ne donne plus rien gratuitement.", shadow_key: "avarice" },
            { id: "a6", text: "Je me récompense moi-même.", shadow_key: "gourmandise" },
            { id: "a7", text: "Je cherche un projet plus excitant.", shadow_key: "luxure" }
        ]
    })

    bank.Push({
        id: "shadow_09", path: "prima_shadow", context: "amitie", category: "limite", signal_type: "comportement",
        prompt: "Quand un ami dépasse une limite…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Je le remets à sa place.", shadow_key: "orgueil" },
            { id: "a2", text: "Je note ce qu'il se permet, lui.", shadow_key: "envie" },
            { id: "a3", text: "Je réponds au quart de tour.", shadow_key: "colere" },
            { id: "a4", text: "Je laisse couler.", shadow_key: "paresse" },
            { id: "a5", text: "Je retire ma confiance et mon temps.", shadow_key: "avarice" },
            { id: "a6", text: "Je passe à autre chose de plus agréable.", shadow_key: "gourmandise" },
            { id: "a7", text: "J'en fais un moment intense, quitte à marquer.", shadow_key: "luxure" }
        ]
    })

    bank.Push({
        id: "shadow_10", path: "prima_shadow", context: "maintenant", category: "controle", signal_type: "stress",
        prompt: "Ces derniers temps, ton excès le plus probable…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Trop vouloir prouver.", shadow_key: "orgueil" },
            { id: "a2", text: "Trop comparer.", shadow_key: "envie" },
            { id: "a3", text: "Trop réagir.", shadow_key: "colere" },
            { id: "a4", text: "Trop éviter.", shadow_key: "paresse" },
            { id: "a5", text: "Trop retenir.", shadow_key: "avarice" },
            { id: "a6", text: "Trop compenser.", shadow_key: "gourmandise" },
            { id: "a7", text: "Trop chercher l'intensité.", shadow_key: "luxure" }
        ]
    })

    bank.Push({
        id: "shadow_11", path: "prima_shadow", context: "maintenant", category: "pression", signal_type: "emotion",
        prompt: "Quand tu te réveilles avec une boule au ventre, c'est plutôt…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "La peur que quelque chose tourne mal.", shadow_key: "peur" },
            { id: "a2", text: "Le trac avant ce qui m'attend.", shadow_key: "peur" },
            { id: "a3", text: "Un fond de tristesse sans raison claire.", shadow_key: "tristesse" },
            { id: "a4", text: "De l'agacement déjà prêt à sortir.", shadow_key: "colere" },
            { id: "a5", text: "Le sentiment de ne pas être à la hauteur.", shadow_key: "honte" },
            { id: "a6", text: "La gêne d'être vu tel que je suis.", shadow_key: "honte" },
            { id: "a7", text: "Une excitation positive malgré tout.", shadow_key: "joie" }
        ]
    })

    bank.Push({
        id: "shadow_12", path: "prima_shadow", context: "relation", category: "conflit", signal_type: "emotion",
        prompt: "Après une dispute, ce qui reste le plus longtemps…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "La crainte que ça recommence.", shadow_key: "peur" },
            { id: "a2", text: "Une tristesse qui s'installe.", shadow_key: "tristesse" },
            { id: "a3", text: "Le sentiment d'avoir perdu quelque chose.", shadow_key: "tristesse" },
            { id: "a4", text: "Une colère qui tourne en boucle.", shadow_key: "colere" },
            { id: "a5", text: "La gêne de ce que j'ai dit ou fait.", shadow_key: "honte" },
            { id: "a6", text: "Le soulagement d'avoir dit les choses.", shadow_key: "joie" },
            { id: "a7", text: "La peur d'être moins aimé.", shadow_key: "peur" }
        ]
    })

    bank.Push({
        id: "shadow_13", path: "prima_shadow", context: "travail", category: "attente", signal_type: "emotion",
        prompt: "Avant un moment important, tu ressens surtout…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "La peur de rater.", shadow_key: "peur" },
            { id: "a2", text: "De l'irritation contre la pression.", shadow_key: "colere" },
            { id: "a3", text: "Une lassitude d'avance.", shadow_key: "tristesse" },
            { id: "a4", text: "La peur d'être jugé.", shadow_key: "honte" },
            { id: "a5", text: "De l'enthousiasme.", shadow_key: "joie" },
            { id: "a6", text: "L'envie que ça commence.", shadow_key: "joie" },
            { id: "a7", text: "Des scénarios catastrophes en tête.", shadow_key: "peur" }
        ]
    })

    bank.Push({
        id: "shadow_14", path: "prima_shadow", context: "famille", category: "regard", signal_type: "emotion",
        prompt: "Quand tu repenses à ton passé, l'émotion la plus fréquente…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "Une nostalgie qui serre.", shadow_key: "tristesse" },
            { id: "a2", text: "Des regrets.", shadow_key: "tristesse" },
            { id: "a3", text: "De la colère contre ce qui s'est passé.", shadow_key: "colere" },
            { id: "a4", text: "De la gêne sur certains souvenirs.", shadow_key: "honte" },
            { id: "a5", text: "De la gratitude pour ce qui a été.", shadow_key: "joie" },
            { id: "a6", text: "La peur que ça se répète.", shadow_key: "peur" },
            { id: "a7", text: "Le sourire en repensant aux bons moments.", shadow_key: "joie" }
        ]
    })

    bank.Push({
        id: "shadow_15", path: "prima_shadow", context: "maintenant", category: "priorite", signal_type: "emotion",
        prompt: "Cette semaine, l'émotion qui est revenue le plus…",
        max_choices: 2,
        answers: [
            { id: "a1", text: "L'inquiétude.", shadow_key: "peur" },
            { id: "a2", text: "Le cafard.", shadow_key: "tristesse" },
            { id: "a3", text: "L'irritabilité.", shadow_key: "colere" },
            { id: "a4", text: "Le doute sur ma valeur.", shadow_key: "honte" },
            { id: "a5", text: "Des moments de joie simple.", shadow_key: "joie" },
            { id: "a6", text: "L'impatience qui monte.", shadow_key: "colere" },
            { id: "a7", text: "La tension de l'anticipation.", shadow_key: "peur" }
        ]
    })

    return bank
}

GetSoulQuestionsForPath(path) {
    questions := []
    for q in GetSoulQuestionBank() {
        if (q.path = path)
            questions.Push(q)
    }
    return questions
}

ShuffleArray(arr) {
    i := arr.Length
    while (i > 1) {
        j := Random(1, i)
        tmp := arr[i]
        arr[i] := arr[j]
        arr[j] := tmp
        i--
    }
    return arr
}

; Mélange les réponses d'une question : ordre aléatoire, scores attachés.
ShuffleAnswers(question) {
    shuffled := []
    for a in question.answers
        shuffled.Push(a)
    return ShuffleArray(shuffled)
}

; Construit une session de parcours prête à jouer, ou "" si pas assez de questions.
; Tirage équilibré : à chaque pas, on choisit la question dont le context et la
; category sont les moins représentés dans le tirage en cours (glouton).
; Le pool est mélangé avant tirage pour que les égalités restent aléatoires,
; puis l'ordre final des questions est mélangé.
BuildSoulQuestionRun(path, count) {
    pool := GetSoulQuestionsForPath(path)
    if (pool.Length < count)
        return ""

    ShuffleArray(pool)
    picked := []
    ctxCount := Map()
    catCount := Map()
    while (picked.Length < count && pool.Length > 0) {
        bestIdx := 1
        bestLoad := ""
        for i, q in pool {
            load := (ctxCount.Has(q.context) ? ctxCount[q.context] : 0)
                  + (catCount.Has(q.category) ? catCount[q.category] : 0)
            if (bestLoad = "" || load < bestLoad) {
                bestLoad := load
                bestIdx := i
            }
        }
        q := pool.RemoveAt(bestIdx)
        picked.Push(q)
        ctxCount[q.context] := (ctxCount.Has(q.context) ? ctxCount[q.context] : 0) + 1
        catCount[q.category] := (catCount.Has(q.category) ? catCount[q.category] : 0) + 1
    }
    if (picked.Length < count)
        return ""
    ShuffleArray(picked)

    questions := []
    for q in picked {
        questions.Push({
            id: q.id, path: q.path, context: q.context, category: q.category,
            signal_type: (q.HasOwnProp("signal_type") ? q.signal_type : ""),
            prompt: q.prompt, max_choices: q.max_choices,
            answers: ShuffleAnswers(q)
        })
    }
    return {
        active_path: path,
        questions: questions,
        current_index: 1,
        answers: [],
        completed: false
    }
}

; Stocke les choix d'une question dans la session (résultat calculé plus tard).
; selected_1 = réponse priorité 1 (+2) ; selected_2 = priorité 2 (+1), vide si choix unique.
SoulSessionRecordAnswer(session, questionId, selected1, selected2 := "") {
    session.answers.Push({ question_id: questionId, selected_1: selected1, selected_2: selected2 })
    if (session.current_index < session.questions.Length)
        session.current_index += 1
    else
        session.completed := true
}

; ── PRIMA Soul — état global du cycle (verrouillage des tests) ────────────────
SoulResultsPath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\soul_results.ini"
}

; Marque un test comme terminé et verrouillé.
; Tant que le cycle Soul complet n'est pas fini (tests + résultats + univers),
; le verrou reste actif : les champs globaux sont remis à 0 explicitement.
MarkSoulTestCompleted(profileId, path) {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := SoulResultsPath(profileId)
    for key in ["prima_soul_completed", "prima_vda_completed", "prima_shadow_completed"] {
        if (IniRead(file, "tests", key, "") = "")
            IniWrite("0", file, "tests", key)
    }
    IniWrite("0", file, "global", "cycle_complete")
    IniWrite("0", file, "global", "results_generated")
    IniWrite("0", file, "global", "results_read")
    IniWrite("0", file, "global", "universes_proposed")
    IniWrite("0", file, "global", "universe_chosen")
    if (IniRead(file, "global", "chosen_universe", "") = "")
        IniWrite("", file, "global", "chosen_universe")
    IniWrite("0.1", file, "global", "version")
    IniWrite("1", file, "tests", path "_completed")
    WriteLog("soul_test_locked", profileId " | " path)
    WriteLog("soul_test_locked_until_cycle_complete", profileId " | " path)
}

IsSoulTestCompleted(profileId, path) {
    if (profileId = "")
        return false
    soulFile := SoulResultsPath(profileId)
    if (FileExist(soulFile) && IniRead(soulFile, "tests", path "_completed", "0") = "1")
        return true
    if (path = "prima_soul") {
        stateFile := SoulStatePath(profileId)
        if (FileExist(stateFile)
            && IniRead(stateFile, "session", "path", "") = "prima_soul"
            && IniRead(stateFile, "session", "completed", "0") = "1")
            return true
        if (FileExist(soulFile)) {
            if (IniRead(soulFile, "prima_soul", "completed", "0") = "1")
                return true
            if (IniRead(soulFile, "latest", "main_tendency", "") != "")
                return true
        }
        return false
    }
    if (path = "prima_vda") {
        vdaFile := VdaResultsPath(profileId)
        if (FileExist(vdaFile) && IniRead(vdaFile, "prima_vda", "completed", "0") = "1")
            return true
        stateFile := VdaStatePath(profileId)
        if (FileExist(stateFile)
            && IniRead(stateFile, "session", "path", "") = "prima_vda"
            && IniRead(stateFile, "session", "completed", "0") = "1")
            return true
        return false
    }
    if (path = "prima_shadow") {
        shadowFile := ShadowResultsPath(profileId)
        if (FileExist(shadowFile) && IniRead(shadowFile, "prima_shadow", "completed", "0") = "1")
            return true
        stateFile := ShadowStatePath(profileId)
        if (FileExist(stateFile)
            && IniRead(stateFile, "session", "path", "") = "prima_shadow"
            && IniRead(stateFile, "session", "completed", "0") = "1")
            return true
        return false
    }
    return false
}

IsSoulCycleComplete(profileId) {
    return IniRead(SoulResultsPath(profileId), "global", "cycle_complete", "0") = "1"
}

; Cycle utilisateur terminé : les 3 tests Soul / VDA / Shadow sont verrouillés.
IsPrimaSoulCycleComplete(profileId) {
    if (profileId = "")
        return false
    return IsSoulTestCompleted(profileId, "prima_soul")
        && IsSoulTestCompleted(profileId, "prima_vda")
        && IsSoulTestCompleted(profileId, "prima_shadow")
}

AreSoulResultsRead(profileId) {
    return IniRead(SoulResultsPath(profileId), "global", "results_read", "0") = "1"
}

; Fichiers du cycle PRIMA Soul archivés puis remis à zéro.
GetSoulCycleResetFileNames() {
    return ["soul_state.ini", "soul_results.ini", "vda_state.ini", "vda_results.ini"
        , "shadow_state.ini", "shadow_results.ini", "prima_identity.ini"]
}

; soul_results.ini vierge après refaire les tests.
WriteSoulResultsAfterReset(profileId) {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := SoulResultsPath(profileId)
    if FileExist(file)
        try FileDelete(file)
    IniWrite("0", file, "tests", "prima_soul_completed")
    IniWrite("0", file, "tests", "prima_vda_completed")
    IniWrite("0", file, "tests", "prima_shadow_completed")
    IniWrite("0", file, "global", "cycle_complete")
    IniWrite("0", file, "global", "results_generated")
    IniWrite("0", file, "global", "results_read")
    IniWrite("0", file, "global", "universes_proposed")
    IniWrite("0", file, "global", "universe_chosen")
    IniWrite("", file, "global", "chosen_universe")
    IniWrite("0.1", file, "global", "version")
}

; Archive horodatée puis suppression des fichiers actifs du cycle.
; Si l'archive échoue, rien n'est supprimé.
ResetSoulCycle(profileId) {
    global SOUL_SESSION, PRIMA_SELECTED_UNIVERSE, PRIMA_SELECTED_TERRITORY
    soulDir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(soulDir)
        DirCreate(soulDir)
    files := GetSoulCycleResetFileNames()
    toArchive := []
    for f in files {
        if FileExist(soulDir "\" f)
            toArchive.Push(f)
    }
    archiveDir := ""
    if (toArchive.Length > 0) {
        archiveDir := soulDir "\archive\" FormatTime(, "yyyyMMdd_HHmmss")
        try DirCreate(archiveDir)
        catch {
            return { ok: false, reason: "mkdir" }
        }
        for f in toArchive {
            src := soulDir "\" f
            dest := archiveDir "\" f
            try FileCopy(src, dest, true)
            catch {
                return { ok: false, reason: "copy " f }
            }
            if !FileExist(dest)
                return { ok: false, reason: "verify " f }
        }
        WriteLog("soul_cycle_archived", profileId " | " archiveDir)
        for f in toArchive {
            src := soulDir "\" f
            if FileExist(src) {
                try FileDelete(src)
                catch {
                    return { ok: false, reason: "delete " f }
                }
            }
        }
    }
    WriteSoulResultsAfterReset(profileId)
    SOUL_SESSION := ""
    PRIMA_SELECTED_UNIVERSE := ""
    PRIMA_SELECTED_TERRITORY := ""
    return { ok: true, archive: archiveDir }
}

SoulRedoTestsClicked(*) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        return
    }
    WriteLog("soul_redo_tests_clicked", CURRENT_PROFILE_ID)
    if (MsgBox(T("msg_redo_tests_confirm"), APP_TITLE, "YesNo Icon?") != "Yes")
        return
    WriteLog("soul_redo_tests_confirmed", CURRENT_PROFILE_ID)
    result := ResetSoulCycle(CURRENT_PROFILE_ID)
    if (result.ok) {
        WriteLog("soul_cycle_reset_done", CURRENT_PROFILE_ID " | " result.archive)
        WriteProfileLog(CURRENT_PROFILE_ID, "soul_cycle_reset_done", result.archive)
        MsgBox(T("msg_redo_tests_done"), APP_TITLE, "Iconi")
        RenderScreen("prima_soul_intro")
        return
    }
    WriteLog("soul_cycle_reset_failed", CURRENT_PROFILE_ID " | " result.reason)
    WriteProfileLog(CURRENT_PROFILE_ID, "soul_cycle_reset_failed", result.reason)
    MsgBox(T("msg_redo_tests_archive_failed"), APP_TITLE, "Icon!")
}

; Alias historique (réglages DEV).
SoulCycleResetClicked(*) {
    SoulRedoTestsClicked()
}

; Règles de lancement d'un test (prima_soul / prima_vda / prima_shadow) :
; - test pas terminé → true
; - test terminé et cycle_complete=0 → false
; - test terminé et results_generated=0 → false
; - test terminé et universe_chosen=0 → false
; - aucun reset possible pour l'instant → false même cycle complet.
CanStartSoulTest(path) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "")
        return false
    if !IsSoulTestCompleted(CURRENT_PROFILE_ID, path)
        return true
    file := SoulResultsPath(CURRENT_PROFILE_ID)
    if (IniRead(file, "global", "cycle_complete", "0") != "1")
        return false
    if (IniRead(file, "global", "results_generated", "0") != "1")
        return false
    if (IniRead(file, "global", "universe_chosen", "0") != "1")
        return false
    return false  ; verrou actif tant que cycle complet non finalisé (reset DEV via Réglages)
}

; ── PRIMA Soul Test — résultat minimal ────────────────────────────────────────
; Calcul interne : selected_1 = +2 ; selected_2 = +1 (choix unique = +2 sur selected_1).
; Retourne { main, second } (clés internes, jamais affichées telles quelles).
ComputeSoulMainTendencies(session) {
    totals := Map()
    for key in GetSoulVdaKeys()
        totals[key] := 0
    qById := Map()
    for q in session.questions
        qById[q.id] := q
    for a in session.answers {
        if !qById.Has(a.question_id)
            continue
        q := qById[a.question_id]
        for ans in q.answers {
            mult := 0
            if (ans.id = a.selected_1)
                mult := 2
            else if (a.selected_2 != "" && ans.id = a.selected_2)
                mult := 1
            if (mult = 0)
                continue
            for key, val in ans.scores {
                if totals.Has(key)
                    totals[key] += val * mult
            }
        }
    }
    main := ""
    for key in GetSoulVdaKeys() {
        if (main = "" || totals[key] > totals[main])
            main := key
    }
    second := ""
    for key in GetSoulVdaKeys() {
        if (key = main)
            continue
        if (second = "" || totals[key] > totals[second])
            second := key
    }
    return { main: main, second: second }
}

; Mapping public neutre — seuls ces libellés sont affichés.
GetSoulTendencyLabel(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "your place"
            case "abandon":     return "the bond"
            case "humiliation": return "your needs"
            case "trahison":    return "trust"
            case "injustice":   return "fairness"
        }
    } else {
        switch key {
            case "rejet":       return "ta place"
            case "abandon":     return "le lien"
            case "humiliation": return "tes besoins"
            case "trahison":    return "la confiance"
            case "injustice":   return "la justesse"
        }
    }
    return ""
}

; Action simple associée à la tendance principale (texte public).
GetSoulTendencyAction(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "Take a micro-place today."
            case "abandon":     return "Do a small action alone, then ask for specific support if needed."
            case "humiliation": return "Name a need without justifying yourself."
            case "trahison":    return "Check a fact before controlling or accusing."
            case "injustice":   return "Say 'this touches me' first, before correcting."
        }
    } else {
        switch key {
            case "rejet":       return "Prends une micro-place aujourd'hui."
            case "abandon":     return "Fais une petite action seul, puis demande un soutien précis si besoin."
            case "humiliation": return "Nomme un besoin sans te justifier."
            case "trahison":    return "Vérifie un fait avant de contrôler ou d'accuser."
            case "injustice":   return "Dis d'abord « ça me touche » avant de corriger."
        }
    }
    return ""
}

; Sauvegarde le résultat minimal dans soul_results.ini ([latest] + [global]).
SaveSoulTestResult(profileId, mainKey, secondKey) {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := SoulResultsPath(profileId)
    IniWrite("prima_soul", file, "latest", "last_test")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm"), file, "latest", "date")
    IniWrite(mainKey, file, "latest", "main_tendency")
    IniWrite(secondKey, file, "latest", "secondary_tendency")
    IniWrite(T("result_line1", GetSoulTendencyLabel(mainKey)), file, "latest", "result_text")
    IniWrite(GetSoulTendencyAction(mainKey), file, "latest", "action_text")
    IniWrite("0.1", file, "latest", "version")
    IniWrite("1", file, "global", "results_generated")
    IniWrite("0", file, "global", "results_read")
    IniWrite("0", file, "global", "universes_proposed")
    IniWrite("0", file, "global", "universe_chosen")
    IniWrite("0", file, "global", "cycle_complete")
    WriteLog("soul_result_saved", profileId)
}

; ── PRIMA VDA (PCM) — moteur de classement ────────────────────────────────────
; 6 réponses par question, classées par l'utilisateur.
; rang 1 = +6, rang 2 = +5, rang 3 = +4, rang 4 = +3, rang 5 = +2, rang 6 = +1.
; Tout est interne : aucune clé PCM, aucun score, aucune base/phase affichés.

VdaStatePath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\vda_state.ini"
}

VdaResultsPath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\vda_results.ini"
}

; Construit une session VDA prête à jouer (rankings vides), ou "" si banque insuffisante.
; Les réponses de chaque question sont mélangées par BuildSoulQuestionRun
; (ShuffleAnswers) : aucune clé interne ne reste à une position fixe.
BuildVdaQuestionRun(count) {
    session := BuildSoulQuestionRun("prima_vda", count)
    if (session = "")
        return ""
    session.rankings := []
    WriteLog("vda_answers_shuffled", "prima_vda | " session.questions.Length)
    return session
}

; Vérifie un classement : tableau de 6 answer_id (index = rang).
; Retourne "" si valide, sinon la clé du message d'erreur.
ValidatePcmRanking(ranking) {
    if (!(ranking is Array) || ranking.Length != 6)
        return "msg_rank_all"
    seen := Map()
    for id in ranking {
        if (id = "")
            return "msg_rank_all"
        if seen.Has(id)
            return "msg_rank_unique"
        seen[id] := true
    }
    return ""
}

; Stocke le classement d'une question dans la session.
; ranks = tableau de 6 answer_id, index 1 = rang 1 (me définit le plus).
VdaSessionRecordRanking(session, questionId, ranks) {
    session.rankings.Push({ question_id: questionId, ranks: ranks })
    if (session.current_index < session.questions.Length)
        session.current_index += 1
    else
        session.completed := true
}

; Additionne les points par clé PCM interne selon les classements.
; minIdx/maxIdx filtrent par numéro de question (0/0 = toutes).
ComputePcmRankingScores(session, minIdx := 0, maxIdx := 0) {
    totals := Map()
    for key in GetSoulPcmKeys()
        totals[key] := 0
    qById := Map()
    for q in session.questions
        qById[q.id] := q
    for r in session.rankings {
        if (minIdx > 0) {
            n := VdaQuestionIndexFromId(r.question_id)
            if (n < minIdx || n > maxIdx)
                continue
        }
        if !qById.Has(r.question_id)
            continue
        q := qById[r.question_id]
        ansById := Map()
        for ans in q.answers
            ansById[ans.id] := ans
        loop 6 {
            rank := A_Index
            if (rank > r.ranks.Length)
                break
            aid := r.ranks[rank]
            if !ansById.Has(aid)
                continue
            key := ansById[aid].pcm_key
            if totals.Has(key)
                totals[key] += (7 - rank)
        }
    }
    return totals
}

; Numéro de question depuis l'id (vda_pcm_07 → 7), 0 si format inconnu.
VdaQuestionIndexFromId(qid) {
    if RegExMatch(qid, "^vda_pcm_(\d+)$", &m)
        return Integer(m[1])
    return 0
}

; ── Mode court : séparation Base / Phase (internes, jamais affichés) ──────────
; Q1-Q12 = Base probable — max 12 x 6 = 72 points par clé.
ComputeVdaBaseScores(session) {
    return ComputePcmRankingScores(session, 1, 12)
}

; Q13-Q20 = Phase actuelle probable — max 8 x 6 = 48 points par clé.
ComputeVdaPhaseScores(session) {
    return ComputePcmRankingScores(session, 13, 20)
}

; Pourcentages internes : base → maxTotal 72, phase → maxTotal 48.
ComputeVdaPercents(scores, maxTotal) {
    percents := Map()
    for key, val in scores
        percents[key] := Round(val / maxTotal * 100)
    return percents
}

; Sauvegarde l'état de session VDA dans vda_state.ini (même logique que soul_state).
SaveVdaSessionState() {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "" || SOUL_SESSION = "")
        return
    if (SOUL_SESSION.active_path != "prima_vda")
        return
    dir := PROFILES_DIR "\" CURRENT_PROFILE_ID "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := VdaStatePath(CURRENT_PROFILE_ID)
    if FileExist(file)
        try FileDelete(file)
    IniWrite(SOUL_SESSION.completed ? "0" : "1", file, "session", "active")
    IniWrite("prima_vda", file, "session", "path")
    IniWrite(SOUL_SESSION.current_index, file, "session", "current_index")
    IniWrite(SOUL_SESSION.completed ? "1" : "0", file, "session", "completed")
    IniWrite("0.1", file, "session", "version")
    ids := ""
    for q in SOUL_SESSION.questions
        ids .= (ids = "" ? "" : ",") . q.id
    IniWrite(ids, file, "questions", "ids")
    for r in SOUL_SESSION.rankings {
        line := ""
        for aid in r.ranks
            line .= (line = "" ? "" : ",") . aid
        IniWrite(line, file, "rankings", r.question_id)
    }
    WriteLog("vda_session_saved", CURRENT_PROFILE_ID " | index " SOUL_SESSION.current_index)
}

; Reprise de session VDA depuis vda_state.ini (jamais de plantage).
TryResumeVdaSession(profileId) {
    global SOUL_SESSION
    file := VdaStatePath(profileId)
    if !FileExist(file)
        return false
    try {
        active := IniRead(file, "session", "active", "0")
        completed := IniRead(file, "session", "completed", "1")
        path := IniRead(file, "session", "path", "")
        if !(active = "1" && completed = "0" && path = "prima_vda")
            return false
        idxStr := IniRead(file, "session", "current_index", "")
        if !RegExMatch(idxStr, "^\d+$")
            throw Error("bad current_index")
        currentIndex := Integer(idxStr)
        idsStr := IniRead(file, "questions", "ids", "")
        if (idsStr = "")
            throw Error("no question ids")
        ids := StrSplit(idsStr, ",", " ")
        bankById := Map()
        for q in GetSoulQuestionsForPath("prima_vda")
            bankById[q.id] := q
        questions := []
        for id in ids {
            if !bankById.Has(id)
                throw Error("unknown question id " id)
            q := bankById[id]
            questions.Push({
                id: q.id, path: q.path, context: q.context, category: q.category,
                signal_type: (q.HasOwnProp("signal_type") ? q.signal_type : ""),
                prompt: q.prompt, max_choices: q.max_choices,
                answers: ShuffleAnswers(q)
            })
        }
        if (currentIndex < 1 || currentIndex > questions.Length)
            throw Error("current_index out of range")
        rankings := []
        loop currentIndex - 1 {
            qid := ids[A_Index]
            val := IniRead(file, "rankings", qid, "")
            parts := StrSplit(val, ",", " ")
            if (val = "" || parts.Length != 6)
                throw Error("missing ranking for " qid)
            rankings.Push({ question_id: qid, ranks: parts })
        }
        SOUL_SESSION := {
            active_path: "prima_vda",
            questions: questions,
            current_index: currentIndex,
            answers: [],
            rankings: rankings,
            completed: false
        }
        WriteLog("vda_session_resumed", profileId " | index " currentIndex)
        return true
    } catch as e {
        WriteLog("vda_resume_failed", profileId " | " e.Message)
        return false
    }
}

; Sauvegarde les totaux internes VDA dans vda_results.ini (jamais affichés).
; baseScores / phaseScores : Maps optionnelles (mode court Q1-12 / Q13-20).
SaveVdaTestResult(profileId, totals, baseScores := "", phaseScores := "") {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := VdaResultsPath(profileId)
    IniWrite("1", file, "prima_vda", "completed")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm"), file, "prima_vda", "last_date")
    IniWrite("0.1", file, "prima_vda", "version")
    for key in GetSoulPcmKeys()
        IniWrite(totals.Has(key) ? totals[key] : 0, file, "scores", key)
    if (baseScores != "") {
        for key in GetSoulPcmKeys()
            IniWrite(baseScores.Has(key) ? baseScores[key] : 0, file, "base", key)
    }
    if (phaseScores != "") {
        for key in GetSoulPcmKeys()
            IniWrite(phaseScores.Has(key) ? phaseScores[key] : 0, file, "phase", key)
    }
    WriteLog("vda_result_saved", profileId)
}

; ── PRIMA Shadow Test — moteur choix 1-2 ──────────────────────────────────────
; Q1-Q10 = axes symboliques internes ; Q11-Q15 = émotion principale.
; Choix : 1 minimum, 2 maximum. priorité 1 = +2, priorité 2 = +1.
; Clés internes uniquement, jamais affichées.

ShadowStatePath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\shadow_state.ini"
}

ShadowResultsPath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\shadow_results.ini"
}

GetShadowAxisKeys() {
    return ["orgueil", "envie", "colere", "paresse", "avarice", "gourmandise", "luxure"]
}

GetShadowEmotionKeys() {
    return ["peur", "tristesse", "colere", "honte", "joie"]
}

; Numéro de question depuis l'id (shadow_07 → 7), 0 si format inconnu.
ShadowQuestionIndexFromId(qid) {
    if RegExMatch(qid, "^shadow_(\d+)$", &m)
        return Integer(m[1])
    return 0
}

; Session Shadow : questions et réponses mélangées (BuildSoulQuestionRun).
BuildShadowQuestionRun(count) {
    session := BuildSoulQuestionRun("prima_shadow", count)
    if (session = "")
        return ""
    WriteLog("shadow_answers_shuffled", "prima_shadow | " session.questions.Length)
    return session
}

; Vérifie les choix : tableau de 1 à 2 answer_id distincts.
; Retourne "" si valide, sinon la clé du message d'erreur.
ValidateShadowChoices(choices) {
    if (!(choices is Array) || choices.Length < 1)
        return "msg_shadow_min"
    if (choices.Length > 2)
        return "msg_shadow_max"
    if (choices.Length = 2 && choices[1] = choices[2])
        return "msg_shadow_max"
    for id in choices {
        if (id = "")
            return "msg_shadow_min"
    }
    return ""
}

; Scoring par answer_id : priorité 1 = +2, priorité 2 = +1 (choix unique = +2).
; Q1-Q10 → totaux axes ; Q11-Q15 → totaux émotions.
ComputeShadowScores(session) {
    axes := Map()
    for key in GetShadowAxisKeys()
        axes[key] := 0
    emotions := Map()
    for key in GetShadowEmotionKeys()
        emotions[key] := 0
    qById := Map()
    for q in session.questions
        qById[q.id] := q
    for a in session.answers {
        if !qById.Has(a.question_id)
            continue
        q := qById[a.question_id]
        n := ShadowQuestionIndexFromId(a.question_id)
        for ans in q.answers {
            mult := 0
            if (ans.id = a.selected_1)
                mult := 2
            else if (a.selected_2 != "" && ans.id = a.selected_2)
                mult := 1
            if (mult = 0)
                continue
            key := ans.shadow_key
            if (n >= 1 && n <= 10) {
                if axes.Has(key)
                    axes[key] += mult
            } else {
                if emotions.Has(key)
                    emotions[key] += mult
            }
        }
    }
    return { axes: axes, emotions: emotions }
}

; État de session Shadow (ordre des questions + choix par priorité).
SaveShadowSessionState() {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "" || SOUL_SESSION = "")
        return
    if (SOUL_SESSION.active_path != "prima_shadow")
        return
    dir := PROFILES_DIR "\" CURRENT_PROFILE_ID "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := ShadowStatePath(CURRENT_PROFILE_ID)
    if FileExist(file)
        try FileDelete(file)
    IniWrite(SOUL_SESSION.completed ? "0" : "1", file, "session", "active")
    IniWrite("prima_shadow", file, "session", "path")
    IniWrite(SOUL_SESSION.current_index, file, "session", "current_index")
    IniWrite(SOUL_SESSION.completed ? "1" : "0", file, "session", "completed")
    IniWrite("0.1", file, "session", "version")
    ids := ""
    for q in SOUL_SESSION.questions
        ids .= (ids = "" ? "" : ",") . q.id
    IniWrite(ids, file, "questions", "ids")
    for a in SOUL_SESSION.answers {
        line := a.selected_1
        if (a.selected_2 != "")
            line .= "," a.selected_2
        IniWrite(line, file, "answers", a.question_id)
    }
    WriteLog("shadow_session_saved", CURRENT_PROFILE_ID " | index " SOUL_SESSION.current_index)
}

; Reprise de session Shadow depuis shadow_state.ini (jamais de plantage).
TryResumeShadowSession(profileId) {
    global SOUL_SESSION
    file := ShadowStatePath(profileId)
    if !FileExist(file)
        return false
    try {
        active := IniRead(file, "session", "active", "0")
        completed := IniRead(file, "session", "completed", "1")
        path := IniRead(file, "session", "path", "")
        if !(active = "1" && completed = "0" && path = "prima_shadow")
            return false
        idxStr := IniRead(file, "session", "current_index", "")
        if !RegExMatch(idxStr, "^\d+$")
            throw Error("bad current_index")
        currentIndex := Integer(idxStr)
        idsStr := IniRead(file, "questions", "ids", "")
        if (idsStr = "")
            throw Error("no question ids")
        ids := StrSplit(idsStr, ",", " ")
        bankById := Map()
        for q in GetSoulQuestionsForPath("prima_shadow")
            bankById[q.id] := q
        questions := []
        for id in ids {
            if !bankById.Has(id)
                throw Error("unknown question id " id)
            q := bankById[id]
            questions.Push({
                id: q.id, path: q.path, context: q.context, category: q.category,
                signal_type: (q.HasOwnProp("signal_type") ? q.signal_type : ""),
                prompt: q.prompt, max_choices: q.max_choices,
                answers: ShuffleAnswers(q)
            })
        }
        if (currentIndex < 1 || currentIndex > questions.Length)
            throw Error("current_index out of range")
        answers := []
        loop currentIndex - 1 {
            qid := ids[A_Index]
            val := IniRead(file, "answers", qid, "")
            parts := StrSplit(val, ",", " ")
            if (val = "" || parts.Length < 1)
                throw Error("missing answer for " qid)
            answers.Push({
                question_id: qid,
                selected_1: parts[1],
                selected_2: (parts.Length >= 2 ? parts[2] : "")
            })
        }
        SOUL_SESSION := {
            active_path: "prima_shadow",
            questions: questions,
            current_index: currentIndex,
            answers: answers,
            completed: false
        }
        WriteLog("shadow_session_resumed", profileId " | index " currentIndex)
        return true
    } catch as e {
        WriteLog("shadow_resume_failed", profileId " | " e.Message)
        return false
    }
}

; Résultat Shadow : totaux internes axes + émotion (jamais affichés).
SaveShadowTestResult(profileId, scores) {
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := ShadowResultsPath(profileId)
    IniWrite("1", file, "prima_shadow", "completed")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm"), file, "prima_shadow", "last_date")
    IniWrite("0.1", file, "prima_shadow", "version")
    for key in GetShadowAxisKeys()
        IniWrite(scores.axes.Has(key) ? scores.axes[key] : 0, file, "axes", key)
    for key in GetShadowEmotionKeys()
        IniWrite(scores.emotions.Has(key) ? scores.emotions[key] : 0, file, "emotion", key)
    WriteLog("shadow_result_saved", profileId)
}

; ── PRIMA Soul Test — sauvegarde / reprise de session ─────────────────────────
SoulStatePath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\soul_state.ini"
}

; Écrit l'état complet de la session en cours dans soul_state.ini.
; Conserve l'ordre exact des questions tirées et l'ordre des réponses
; (premier id = priorité 1, deuxième id = priorité 2).
SaveSoulSessionState() {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "" || SOUL_SESSION = "")
        return
    if (SOUL_SESSION.active_path != "prima_soul")
        return
    dir := PROFILES_DIR "\" CURRENT_PROFILE_ID "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := SoulStatePath(CURRENT_PROFILE_ID)
    if FileExist(file)
        try FileDelete(file)
    IniWrite(SOUL_SESSION.completed ? "0" : "1", file, "session", "active")
    IniWrite("prima_soul", file, "session", "path")
    IniWrite(SOUL_SESSION.current_index, file, "session", "current_index")
    IniWrite(SOUL_SESSION.completed ? "1" : "0", file, "session", "completed")
    IniWrite("0.1", file, "session", "version")
    ids := ""
    for q in SOUL_SESSION.questions
        ids .= (ids = "" ? "" : ",") . q.id
    IniWrite(ids, file, "questions", "ids")
    for a in SOUL_SESSION.answers {
        line := a.selected_1
        if (a.selected_2 != "")
            line .= "," a.selected_2
        IniWrite(line, file, "answers", a.question_id)
    }
    WriteLog("soul_session_saved", CURRENT_PROFILE_ID " | index " SOUL_SESSION.current_index)
}

; Tente de reconstruire SOUL_SESSION depuis soul_state.ini.
; Retourne true si la reprise est prête, false sinon (jamais de plantage).
TryResumeSoulSession(profileId) {
    global SOUL_SESSION
    file := SoulStatePath(profileId)
    if !FileExist(file)
        return false
    try {
        active := IniRead(file, "session", "active", "0")
        completed := IniRead(file, "session", "completed", "1")
        path := IniRead(file, "session", "path", "")
        if !(active = "1" && completed = "0" && path = "prima_soul")
            return false
        idxStr := IniRead(file, "session", "current_index", "")
        if !RegExMatch(idxStr, "^\d+$")
            throw Error("bad current_index")
        currentIndex := Integer(idxStr)
        idsStr := IniRead(file, "questions", "ids", "")
        if (idsStr = "")
            throw Error("no question ids")
        ids := StrSplit(idsStr, ",", " ")
        bankById := Map()
        for q in GetSoulQuestionsForPath("prima_soul")
            bankById[q.id] := q
        questions := []
        for id in ids {
            if !bankById.Has(id)
                throw Error("unknown question id " id)
            q := bankById[id]
            questions.Push({
                id: q.id, path: q.path, context: q.context, category: q.category,
                signal_type: (q.HasOwnProp("signal_type") ? q.signal_type : ""),
                prompt: q.prompt, max_choices: q.max_choices,
                answers: ShuffleAnswers(q)
            })
        }
        if (currentIndex < 1 || currentIndex > questions.Length)
            throw Error("current_index out of range")
        answers := []
        loop currentIndex - 1 {
            qid := ids[A_Index]
            val := IniRead(file, "answers", qid, "")
            parts := StrSplit(val, ",", " ")
            if (val = "" || parts.Length < 1)
                throw Error("missing answer for " qid)
            answers.Push({
                question_id: qid,
                selected_1: parts[1],
                selected_2: (parts.Length >= 2 ? parts[2] : "")
            })
        }
        SOUL_SESSION := {
            active_path: "prima_soul",
            questions: questions,
            current_index: currentIndex,
            answers: answers,
            completed: false
        }
        WriteLog("soul_session_resumed", profileId " | index " currentIndex)
        return true
    } catch as e {
        WriteLog("soul_resume_failed", profileId " | " e.Message)
        return false
    }
}

LoadDomainGoals(profileId, code) {
    file := GoalsIniPath(profileId)
    return {
        short: IniRead(file, code, "short", ""),
        medium: IniRead(file, code, "medium", ""),
        long: IniRead(file, code, "long", "")
    }
}

SaveDomainGoals(profileId, code, short, medium, long) {
    file := GoalsIniPath(profileId)
    IniWrite(Trim(short), file, code, "short")
    IniWrite(Trim(medium), file, code, "medium")
    IniWrite(Trim(long), file, code, "long")
}

DomainHasGoals(data) {
    return (Trim(data.short) != "" || Trim(data.medium) != "" || Trim(data.long) != "")
}

CountConfiguredDomains(profileId) {
    count := 0
    for code in GetDomainCodes() {
        if DomainHasGoals(LoadDomainGoals(profileId, code))
            count++
    }
    return count
}

HasAnyGoals(profileId) {
    return CountConfiguredDomains(profileId) > 0
}

GetDomainsWithGoals(profileId) {
    domains := []
    for code in GetDomainCodes() {
        if DomainHasGoals(LoadDomainGoals(profileId, code))
            domains.Push(code)
    }
    return domains
}

GetGoalsForDomain(profileId, code) {
    goals := []
    data := LoadDomainGoals(profileId, code)
    if (Trim(data.short) != "")
        goals.Push({ duration: "short", durationLabel: T("dur_short"), title: Trim(data.short) })
    if (Trim(data.medium) != "")
        goals.Push({ duration: "medium", durationLabel: T("dur_medium"), title: Trim(data.medium) })
    if (Trim(data.long) != "")
        goals.Push({ duration: "long", durationLabel: T("dur_long"), title: Trim(data.long) })
    return goals
}

ChooseInList(ddl, labels, value) {
    if (value = "") {
        ddl.Choose(1)
        return
    }
    loop labels.Length {
        if (labels[A_Index] = value) {
            ddl.Choose(A_Index)
            return
        }
    }
    ddl.Choose(1)
}

SaveReview(mood, moodCode, energy, energyCode, whatDid, whatImprove, freeNote, reviewDomain := "", goalTitle := "", goalDuration := "") {
    global REVIEWS_DIR, CURRENT_PROFILE_ID, CURRENT_LANG
    EnsureDirectories()
    dateStr := FormatTime(, "yyyy-MM-dd")
    timestamp := FormatTime(, "yyyy-MM-dd HH:mm:ss")
    file := REVIEWS_DIR "\" dateStr "_" CURRENT_PROFILE_ID "_review.txt"
    content :=
        "date=" timestamp "`n"
        . "profile_id=" CURRENT_PROFILE_ID "`n"
        . "language=" CURRENT_LANG "`n"
        . "mood=" SanitizeReviewField(mood) "`n"
        . "mood_code=" moodCode "`n"
        . "energy=" SanitizeReviewField(energy) "`n"
        . "energy_code=" energyCode "`n"
        . "review_domain=" SanitizeReviewField(reviewDomain) "`n"
        . "what_i_did=" SanitizeReviewField(whatDid) "`n"
        . "what_i_did_goal_title=" SanitizeReviewField(goalTitle) "`n"
        . "what_i_did_goal_duration=" SanitizeReviewField(goalDuration) "`n"
        . "what_i_improve=" SanitizeReviewField(whatImprove) "`n"
        . "free_note=" SanitizeReviewField(freeNote) "`n"
    if FileExist(file)
        FileDelete(file)
    FileAppend(content, file, "UTF-8")
}

T(key, p*) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "profile_title":       s := "Profile"
            case "profile_none":        s := "No local profile"
            case "profile_select":      s := "Select a local profile"
            case "btn_create_profile":  s := "Create profile"
            case "login_title":         s := "Profile login"
            case "create_password":     s := "Password"
            case "create_password_confirm": s := "Confirm password"
            case "msg_empty_password":  s := "Please enter a password."
            case "msg_password_mismatch": s := "Passwords do not match."
            case "msg_wrong_password":  s := "Incorrect password."
            case "msg_password_hash_error": s := "Unable to save password securely. Please try again."
            case "btn_continue":        s := "Continue"
            case "btn_archive":         s := "Archive profile"
            case "btn_archives":        s := "Archives"
            case "archives_title":      s := "Archives"
            case "archives_select":     s := "Select an archived folder"
            case "archives_none":        s := "No archives."
            case "btn_delete_archive":  s := "Delete permanently"
            case "msg_select_archive_delete": s := "Please select an archive to delete."
            case "msg_archive_delete_confirm1": s := "Do you really want to delete this archive?`n`n{}"
            case "msg_archive_delete_confirm2": s := "Permanent deletion. This action cannot be undone. Confirm?"
            case "msg_archive_delete_failed": s := "Failed to delete archive."
            case "msg_active_archive_delete": s := "Cannot delete an archive linked to the active profile."
            case "btn_quit":            s := "Quit"
            case "btn_back":            s := "Back"
            case "btn_save":            s := "Save"
            case "btn_create":          s := "Create"
            case "review_title":        s := "Daily Review"
            case "review_mood":         s := "Mood"
            case "review_energy":       s := "Energy"
            case "review_did":          s := "What I did"
            case "review_improve":      s := "What I improve"
            case "review_note":         s := "Free note"
            case "goals_title":         s := "Goals"
            case "goal_domain":         s := "Domain"
            case "dur_short":           s := "Short term"
            case "dur_medium":          s := "Mid term"
            case "dur_long":            s := "Long term"
            case "dur_short_hint":      s := "~3 months max"
            case "dur_medium_hint":     s := "~6 months to 1 year"
            case "dur_long_hint":       s := "~2 to 5 years"
            case "btn_goals":           s := "Goals"
            case "personal_base_title": s := "Personal Base"
            case "base_kit_prima":      s := "PRIMA Kit"
            case "kit_title":           s := "Kit PRIMA"
            case "kit_body":            s := "Local PRIMA base verification."
            case "kit_ai_label":        s := "Selected AI"
            case "kit_ai_other":        s := "Other"
            case "kit_checks_label":    s := "Local checks"
            case "kit_check_root":      s := "PRIMA root folder"
            case "kit_check_prima_app": s := "PrimaApp.ahk"
            case "kit_check_autohotkey": s := "AutoHotkey available"
            case "kit_check_launcher":  s := "Local AHK launcher"
            case "kit_check_shortcut":  s := "PRIMA App shortcut"
            case "msg_autohotkey_missing": s := "AutoHotkey is missing. Open the official download page?"
            case "msg_autohotkey_not_found_shortcut": s := "AutoHotkey not found. Launch PRIMA with launch_prima.ahk or install AutoHotkey v2."
            case "kit_check_profiles":  s := "profiles folder"
            case "kit_check_logs":      s := "logs folder"
            case "kit_check_reviews":   s := "reviews folder"
            case "kit_check_profiles_ini": s := "profiles.ini file"
            case "status_ok":           s := "OK"
            case "status_missing":      s := "Missing"
            case "btn_kit_verify":      s := "Check"
            case "btn_kit_create":      s := "Create missing"
            case "msg_kit_saved":       s := "PRIMA Kit saved."
            case "msg_kit_save_error":  s := "Error while saving."
            case "base_infos_perso":    s := "Personal info"
            case "base_prima_soul":     s := "PRIMA Soul"
            case "prima_soul_intro_title": s := "PRIMA Soul"
            case "prima_soul_intro_body":  s := "Adapt your PRIMA experience without labeling yourself."
            case "prima_soul_intro_sub":   s := "Choose what helps you most today. You can change these choices later."
            case "prima_soul_guide":       s := "The system guides, it does not confine."
            case "soul_status_available":  s := "Available"
            case "soul_status_done":       s := "Completed"
            case "soul_status_locked":     s := "Locked"
            case "soul_status_ready":      s := "Ready"
            case "soul_reading_wait":      s := "Available after all 3 tests"
            case "soul_cycle_complete_status": s := "✅ PRIMA Soul cycle completed"
            case "soul_cycle_complete_hint":   s := "You can now generate your reading, choose your PRIMA architecture, or redo the tests."
            case "prima_soul_complete_title":  s := "PRIMA Soul"
            case "msg_test_done_use_reading":  s := "Use Generate my reading or Redo the tests."
            case "prima_soul_no_diag":     s := "PRIMA Soul does not make any diagnosis."
            case "prima_soul_completed":   s := "PRIMA Soul minimal completed."
            case "soul_tone":              s := "Preferred tone"
            case "soul_rhythm":            s := "Support rhythm"
            case "soul_energy":            s := "Current energy"
            case "soul_need":              s := "Main need today"
            case "soul_rest":              s := "Rest mode"
            case "btn_soul_save_goals":    s := "Save and continue to Goals"
            case "vda_line1":              s := "Observe your reactions in simple situations."
            case "vda_line2":              s := "You can choose what feels most like you."
            case "vda_line3":              s := "The result will suggest tendencies to check against your own experience."
            case "vda_count":              s := "15 short situations."
            case "pcm_line1":              s := "Explore how you move forward, react and communicate."
            case "pcm_line2":              s := "The result will offer a simple reading, without labels."
            case "pcm_line3":              s := "You can adjust this later."
            case "pcm_count":              s := "10 situations maximum."
            case "shadow_line1":           s := "This module is coming later."
            case "shadow_line2":           s := "It will explore what takes too much space when you are under pressure."
            case "shadow_line3":           s := "No judgment, no fixed truth."
            case "soul_settings_title":    s := "PRIMA Soul Settings"
            case "soul_settings_later":    s := "PRIMA Soul settings coming soon."
            case "soul_settings_dev_hint": s := "Developer options for this profile."
            case "btn_reset_soul_cycle":   s := "Reset PRIMA Soul cycle"
            case "btn_redo_tests":         s := "Redo the tests"
            case "msg_redo_tests_confirm": s := "You can redo the tests if this reading doesn't fit you.`n`nCurrent results will be archived before starting again.`n`nContinue?"
            case "msg_redo_tests_done":    s := "Cycle reset. You can redo the tests."
            case "msg_redo_tests_archive_failed": s := "Unable to archive previous results. Reset cancelled."
            case "msg_reset_soul_cycle_confirm": s := "This will archive Soul/VDA/Shadow results for this profile and allow redoing the tests. Continue?"
            case "msg_reset_soul_cycle_done":    s := "PRIMA Soul cycle reset. You can retake the tests."
            case "msg_reset_soul_cycle_failed":  s := "Reset failed. Your current files were not removed."
            case "btn_soul_settings":      s := "Settings"
            case "msg_run_preparing":      s := "Journey in preparation."
            case "msg_pick_at_least_one":  s := "Choose at least 1 answer."
            case "msg_pick_only_two":      s := "Choose at most 2 answers."
            case "soul_pick_hint":         s := "Pick 1 to 2 answers."
            case "vda_test_title":         s := "PRIMA VDA Test"
            case "soul_test_title":        s := "PRIMA Soul Test"
            case "vda_later_1":            s := "This test is coming later."
            case "vda_later_2":            s := "It will explore how you communicate, move forward and react."
            case "vda_intro_1":            s := "This test explores how you communicate, move forward and react."
            case "vda_intro_2":            s := "20 situations will be offered."
            case "msg_rank_all":           s := "Rank all 6 answers."
            case "msg_rank_unique":        s := "Each place must be used only once."
            case "vda_rank_hint_top":      s := "1 = most like you"
            case "vda_rank_hint_bottom":   s := "6 = least like you"
            case "btn_vda_test_done":      s := "PRIMA VDA Test completed"
            case "vda_done_reading":       s := "Your reading will be available once the three tests are completed."
            case "shadow_test_title":      s := "PRIMA Shadow Test"
            case "shadow_intro_1":         s := "This test explores your deep reactions, your inner tensions and the emotion that comes back most often."
            case "shadow_intro_2":         s := "This is not a label. It is a reading lead."
            case "shadow_pick_hint":       s := "Pick 1 to 2 answers."
            case "msg_shadow_min":         s := "Pick at least 1 answer."
            case "msg_shadow_max":         s := "Pick 2 answers maximum."
            case "btn_shadow_test_done":   s := "PRIMA Shadow Test completed"
            case "msg_test_locked_cycle":  s := "It will reopen once the full cycle is completed."
            case "btn_generate_reading":   s := "Generate my reading"
            case "msg_reading_preparing":  s := "Reading in preparation."
            case "reading_hub_title":      s := "Your PRIMA reading"
            case "reading_hub_1":          s := "This reading is not a fixed truth."
            case "reading_hub_2":          s := "It gathers your answers to suggest leads about behavior, needs and communication."
            case "btn_result_soul":        s := "PRIMA Soul result"
            case "btn_result_vda":         s := "PRIMA VDA result"
            case "btn_result_shadow":      s := "PRIMA Shadow result"
            case "btn_save_reading":       s := "Save"
            case "btn_restart_cycle":      s := "Restart the cycle later"
            case "btn_choose_universe":    s := "Choose my universe"
            case "btn_create_plan":        s := "Create my PRIMA plan"
            case "msg_reading_saved":      s := "Reading saved."
            case "msg_cycle_reset_later":  s := "Cycle reset planned later."
            case "msg_universe_later":     s := "Universe choice planned later."
            case "msg_plan_later":         s := "PRIMA plan planned later."
            case "sec_suggest":            s := "1. What your answers suggest"
            case "sec_nourish":            s := "2. What can nourish you"
            case "sec_pressure":           s := "3. Under pressure"
            case "sec_comm":               s := "4. Communication / regulation"
            case "lbl_dominant":           s := "Dominant tendency"
            case "lbl_secondary":          s := "Secondary tendency"
            case "lbl_stable_probable":    s := "Probable stable functioning"
            case "lbl_influence_secondary": s := "Probable secondary influence"
            case "lbl_energy_probable":    s := "Probable current energy"
            case "lbl_tension_dom":        s := "Dominant inner tension"
            case "lbl_tension_sec":        s := "Secondary tension"
            case "lbl_emotion_main":       s := "Probable main emotion"
            case "uni_choice_1":           s := "Three leads are offered to you."
            case "uni_choice_2":           s := "Browse them, then choose what resonates most."
            case "uni_role_main":          s := "Main universe"
            case "uni_role_bridge":        s := "Bridge universe"
            case "uni_role_secondary":     s := "Secondary universe"
            case "uni_why_main":           s := "Main lead: it aligns most directly with your Soul and VDA results."
            case "uni_why_bridge":         s := "Bridge lead: it connects your dominant universe to another inner tone."
            case "uni_why_secondary":      s := "Secondary lead: a complementary nuance to explore if it speaks to you."
            case "choice_piste_of":        s := "Lead {} / {}"
            case "choice_why_label":       s := "Why this lead may fit you"
            case "btn_prev_piste":         s := "← Previous"
            case "btn_next_piste":         s := "Next →"
            case "btn_pick_piste":         s := "Choose this lead"
            case "terr_role_main":         s := "Main territory"
            case "terr_role_bridge":       s := "Bridge territory"
            case "terr_role_secondary":    s := "Secondary territory"
            case "scroll_hint":            s := "Scroll to see more"
            case "terr_choice_title":      s := "Choose my territory"
            case "terr_choice_1":          s := "Three leads are offered to you."
            case "terr_choice_2":          s := "Browse them, then choose what resonates most."
            case "terr_why_main":          s := "Main lead: it reflects the life zone most active for you right now."
            case "terr_why_bridge":        s := "Bridge lead: it links your universe to a complementary territory."
            case "terr_why_secondary":     s := "Secondary lead: an additional angle to consider if it resonates."
            case "btn_pick":               s := "Choose"
            case "identity_saved_title":   s := "PRIMA architecture saved"
            case "identity_saved_1":       s := "Your choice will serve as a symbolic base for the rest of PRIMA App."
            case "identity_saved_2":       s := "This architecture can evolve with your future cycles."
            case "identity_arch_label":    s := "Architecture:"
            case "btn_back_reading":       s := "Back to my reading"
            case "btn_back_prima_home":    s := "Back to PRIMA home"
            case "vda_question_of":        s := "Question {} / {}"
            case "btn_next":               s := "Next"
            case "msg_quit_run":           s := "Leave the current journey?"
            case "msg_finish_or_quit":     s := "Finish the journey or quit the app."
            case "btn_soul_test_done":     s := "PRIMA Soul Test completed"
            case "msg_test_locked_1":      s := "Test already completed."
            case "msg_test_locked_2":      s := "It will reopen once PRIMA VDA, PRIMA Shadow, the results and the universe choice are completed."
            case "vda_done_1":             s := "Journey complete."
            case "vda_done_2":             s := "The full result will be added in a next step."
            case "btn_back_soul":          s := "Back to PRIMA Soul"
            case "result_line1":           s := "Your answers seem to show a possible lead around {}."
            case "result_line2":           s := "This is not an identity. It is a working lead."
            case "result_line3":           s := "A second theme also seems present: {}."
            case "btn_read":               s := "I have read"
            case "btn_start":           s := "Start"
            case "msg_module_later":    s := "Module planned later."
            case "review_domain":       s := "Domain"
            case "review_no_goals":     s := "Add a goal in Personal setup first."
            case "review_no_domain_goals": s := "No goal defined for this domain."
            case "create_title":        s := "New profile"
            case "create_security_title": s := "Profile security"
            case "create_name":         s := "Profile name"
            case "create_lang":         s := "Language"
            case "create_mode":         s := "Profile mode"
            case "mode_client":         s := "Client"
            case "mode_creator":        s := "Creator"
            case "create_code":         s := "Creator code"
            case "msg_wrong_code":      s := "Incorrect code."
            case "privacy_title":       s := "Privacy"
            case "privacy_body":        s := "PRIMA App is local-first.`n`nNo forced cloud.`nNo telemetry.`nNo microphone.`nNo screen capture.`nNo external API."
            case "btn_accept":          s := "I accept"
            case "btn_review":          s := "Review"
            case "btn_proof":           s := "Proof"
            case "btn_settings":        s := "Settings"
            case "settings_title":      s := "Settings"
            case "start_title":         s := "Launch"
            case "start_welcome":       s := "Welcome to PRIMA"
            case "start_profile":       s := "Profile: {}"
            case "btn_launch":          s := "Launch PRIMA"
            case "home_title":          s := "Welcome to PRIMA"
            case "home_active":         s := "Active profile: {}"
            case "home_version":        s := "Version {}"
            case "creator_home_title":  s := "Creator Home"
            case "creator_home_body":   s := "Private PRIMA creator space."
            case "btn_creator_personalization": s := "Personalization"
            case "btn_creator_goal":  s := "Goal"
            case "btn_creator_soul_test": s := "PRIMA Soul Test"
            case "btn_creator_vda_test": s := "PRIMA VDA Test"
            case "btn_creator_shadow_test": s := "PRIMA Shadow Test"
            case "msg_creator_module_later": s := "Creator module planned later."
            case "btn_onboarding":      s := "Personal setup"
            case "btn_change_profile":  s := "Change profile"
            case "onboarding_body":     s := "PRIMA helps you move forward step by step. For now, this version helps you build your base, track your profile, and prepare your personal space."
            case "msg_select_profile":  s := "Please select a profile."
            case "msg_select_archive":  s := "Please select a profile to archive."
            case "msg_active_archive":  s := "This profile is active. Switch profile or log out before archiving it."
            case "msg_archive_confirm": s := "Archive profile « {} » ?`n`nThe profile will be moved to archive/.`nNo permanent deletion."
            case "msg_empty_name":      s := "Please enter a profile name."
            case "msg_no_active":       s := "Error: no active profile."
            case "msg_goals_max_domains": s := "Maximum 5 domains with goals in V0.1."
            case "confirm_close":       s := "Close PRIMA App?"
            case "confirm_quit":        s := "Quit PRIMA App?"
            case "confirm_saved":       s := "Your local data is saved."
            case "confirm_missing":     s := "Warning: active profile not found on disk."
            case "pause_on":            s := "PRIMA App is paused.`n`nCtrl+Alt+Shift+X to resume."
            case "pause_off":           s := "PRIMA App resumed."
            default:                    return key
        }
    } else {
        switch key {
            case "profile_title":       s := "Profil"
            case "profile_none":        s := "Aucun profil local"
            case "profile_select":      s := "Sélectionnez un profil local"
            case "btn_create_profile":  s := "Créer un profil"
            case "login_title":         s := "Connexion profil"
            case "create_password":     s := "Mot de passe"
            case "create_password_confirm": s := "Confirmation mot de passe"
            case "msg_empty_password":  s := "Veuillez entrer un mot de passe."
            case "msg_password_mismatch": s := "Les mots de passe ne correspondent pas."
            case "msg_wrong_password":  s := "Mot de passe incorrect."
            case "msg_password_hash_error": s := "Impossible d'enregistrer le mot de passe. Réessayez."
            case "btn_continue":        s := "Continuer"
            case "btn_archive":         s := "Archiver profil"
            case "btn_archives":        s := "Archives"
            case "archives_title":      s := "Archives"
            case "archives_select":     s := "Sélectionnez une archive"
            case "archives_none":        s := "Aucune archive."
            case "btn_delete_archive":  s := "Supprimer définitivement"
            case "msg_select_archive_delete": s := "Veuillez sélectionner une archive à supprimer."
            case "msg_archive_delete_confirm1": s := "Voulez-vous vraiment supprimer cette archive ?`n`n{}"
            case "msg_archive_delete_confirm2": s := "Suppression définitive. Cette action est irréversible. Confirmer ?"
            case "msg_archive_delete_failed": s := "Échec de la suppression de l'archive."
            case "msg_active_archive_delete": s := "Impossible de supprimer une archive liée au profil actif."
            case "btn_quit":            s := "Quitter"
            case "btn_back":            s := "Retour"
            case "btn_save":            s := "Enregistrer"
            case "btn_create":          s := "Créer"
            case "review_title":        s := "Revue du jour"
            case "review_mood":         s := "Humeur"
            case "review_energy":       s := "Énergie"
            case "review_did":          s := "Ce que j'ai fait"
            case "review_improve":      s := "Ce que j'améliore"
            case "review_note":         s := "Note libre"
            case "goals_title":         s := "Objectifs"
            case "goal_domain":         s := "Domaine"
            case "dur_short":           s := "Court terme"
            case "dur_medium":          s := "Moyen terme"
            case "dur_long":            s := "Long terme"
            case "dur_short_hint":      s := "~3 mois max"
            case "dur_medium_hint":     s := "~6 mois à 1 an"
            case "dur_long_hint":       s := "~2 à 5 ans"
            case "btn_goals":           s := "Objectifs"
            case "personal_base_title": s := "Base personnelle"
            case "base_kit_prima":      s := "Kit PRIMA"
            case "kit_title":           s := "Kit PRIMA"
            case "kit_body":            s := "Vérification de la base locale PRIMA."
            case "kit_ai_label":        s := "IA choisie"
            case "kit_ai_other":        s := "Autre"
            case "kit_checks_label":    s := "Vérifications locales"
            case "kit_check_root":      s := "Dossier racine PRIMA"
            case "kit_check_prima_app": s := "PrimaApp.ahk"
            case "kit_check_autohotkey": s := "AutoHotkey disponible"
            case "kit_check_launcher":  s := "Launcher AHK local"
            case "kit_check_shortcut":  s := "Raccourci PRIMA App"
            case "msg_autohotkey_missing": s := "AutoHotkey est manquant. Voulez-vous ouvrir la page officielle de téléchargement ?"
            case "msg_autohotkey_not_found_shortcut": s := "AutoHotkey est introuvable. Lancez PRIMA avec launch_prima.ahk ou installez AutoHotkey v2."
            case "kit_check_profiles":  s := "Dossier profiles"
            case "kit_check_logs":      s := "Dossier logs"
            case "kit_check_reviews":   s := "Dossier reviews"
            case "kit_check_profiles_ini": s := "Fichier profiles.ini"
            case "status_ok":           s := "OK"
            case "status_missing":      s := "Manquant"
            case "btn_kit_verify":      s := "Vérifier"
            case "btn_kit_create":      s := "Créer ce qui manque"
            case "msg_kit_saved":       s := "Kit PRIMA enregistré."
            case "msg_kit_save_error":  s := "Erreur lors de l'enregistrement."
            case "base_infos_perso":    s := "Infos perso"
            case "base_prima_soul":     s := "PRIMA Soul"
            case "prima_soul_intro_title": s := "PRIMA Soul"
            case "prima_soul_intro_body":  s := "Adapte ton expérience PRIMA sans te coller d'étiquette."
            case "prima_soul_intro_sub":   s := "Choisis ce qui t'aide le plus aujourd'hui. Tu pourras modifier ces choix plus tard."
            case "prima_soul_guide":       s := "Le système guide, il n'enferme pas."
            case "soul_status_available":  s := "Disponible"
            case "soul_status_done":       s := "Terminé"
            case "soul_status_locked":     s := "Verrouillé"
            case "soul_status_ready":      s := "Prêt"
            case "soul_reading_wait":      s := "Disponible après les 3 tests"
            case "soul_cycle_complete_status": s := "✅ Cycle PRIMA Soul terminé"
            case "soul_cycle_complete_hint":   s := "Tu peux maintenant générer ta lecture, choisir ton architecture PRIMA ou refaire les tests."
            case "prima_soul_complete_title":  s := "PRIMA Soul"
            case "msg_test_done_use_reading":  s := "Utilise Générer ma lecture ou Refaire les tests."
            case "prima_soul_no_diag":     s := "PRIMA Soul ne fait pas de diagnostic."
            case "prima_soul_completed":   s := "PRIMA Soul minimal complété."
            case "soul_tone":              s := "Ton préféré"
            case "soul_rhythm":            s := "Rythme d'accompagnement"
            case "soul_energy":            s := "Énergie du moment"
            case "soul_need":              s := "Besoin principal aujourd'hui"
            case "soul_rest":              s := "Mode repos"
            case "btn_soul_save_goals":    s := "Enregistrer et continuer vers Objectifs"
            case "vda_line1":              s := "Observe tes réactions dans des situations simples."
            case "vda_line2":              s := "Tu pourras choisir ce qui te ressemble le plus."
            case "vda_line3":              s := "Le résultat proposera des tendances à vérifier avec ton vécu."
            case "vda_count":              s := "15 situations courtes."
            case "pcm_line1":              s := "Explore ta manière d'avancer, de réagir et de communiquer."
            case "pcm_line2":              s := "Le résultat proposera une lecture simple, sans étiquette."
            case "pcm_line3":              s := "Tu pourras ajuster ça plus tard."
            case "pcm_count":              s := "10 situations maximum."
            case "shadow_line1":           s := "Ce module arrivera plus tard."
            case "shadow_line2":           s := "Il explorera ce qui prend trop de place quand tu es sous pression."
            case "shadow_line3":           s := "Sans jugement, sans vérité fixe."
            case "soul_settings_title":    s := "Réglages PRIMA Soul"
            case "soul_settings_later":    s := "Réglages PRIMA Soul à venir."
            case "soul_settings_dev_hint": s := "Options développeur pour ce profil."
            case "btn_reset_soul_cycle":   s := "Réinitialiser cycle PRIMA Soul"
            case "btn_redo_tests":         s := "Refaire les tests"
            case "msg_redo_tests_confirm": s := "Tu peux refaire les tests si cette lecture ne te correspond pas.`n`nLes résultats actuels seront archivés avant de recommencer.`n`nContinuer ?"
            case "msg_redo_tests_done":    s := "Cycle réinitialisé. Tu peux refaire les tests."
            case "msg_redo_tests_archive_failed": s := "Impossible d'archiver les anciens résultats. Réinitialisation annulée."
            case "msg_reset_soul_cycle_confirm": s := "Cette action va archiver les résultats Soul/VDA/Shadow de ce profil et permettre de refaire les tests. Continuer ?"
            case "msg_reset_soul_cycle_done":    s := "Cycle PRIMA Soul réinitialisé. Tu peux refaire les tests."
            case "msg_reset_soul_cycle_failed":  s := "Échec de la réinitialisation. Tes fichiers actuels n'ont pas été supprimés."
            case "btn_soul_settings":      s := "Réglages"
            case "msg_run_preparing":      s := "Parcours en préparation."
            case "msg_pick_at_least_one":  s := "Choisis au moins 1 réponse."
            case "msg_pick_only_two":      s := "Choisis maximum 2 réponses."
            case "soul_pick_hint":         s := "Choisis 1 à 2 réponses."
            case "vda_test_title":         s := "PRIMA VDA Test"
            case "soul_test_title":        s := "PRIMA Soul Test"
            case "vda_later_1":            s := "Ce test arrivera plus tard."
            case "vda_later_2":            s := "Il explorera ta manière de communiquer, d'avancer et de réagir."
            case "vda_intro_1":            s := "Ce test explore ta manière de communiquer, d'avancer et de réagir."
            case "vda_intro_2":            s := "20 situations seront proposées."
            case "msg_rank_all":           s := "Classe les 6 réponses."
            case "msg_rank_unique":        s := "Chaque place doit être utilisée une seule fois."
            case "vda_rank_hint_top":      s := "1 = te ressemble le plus"
            case "vda_rank_hint_bottom":   s := "6 = te ressemble le moins"
            case "btn_vda_test_done":      s := "PRIMA VDA Test terminé"
            case "vda_done_reading":       s := "Ta lecture sera disponible quand les trois tests seront terminés."
            case "shadow_test_title":      s := "PRIMA Shadow Test"
            case "shadow_intro_1":         s := "Ce test explore tes réactions profondes, tes tensions intérieures et l'émotion qui revient le plus souvent."
            case "shadow_intro_2":         s := "Ce n'est pas une étiquette. C'est une piste de lecture."
            case "shadow_pick_hint":       s := "Choisis 1 à 2 réponses."
            case "msg_shadow_min":         s := "Choisis au moins 1 réponse."
            case "msg_shadow_max":         s := "Choisis maximum 2 réponses."
            case "btn_shadow_test_done":   s := "PRIMA Shadow Test terminé"
            case "msg_test_locked_cycle":  s := "Il sera réouvert quand le cycle complet sera terminé."
            case "btn_generate_reading":   s := "Générer ma lecture"
            case "msg_reading_preparing":  s := "Lecture en préparation."
            case "reading_hub_title":      s := "Ta lecture PRIMA"
            case "reading_hub_1":          s := "Cette lecture n'est pas une vérité fixe."
            case "reading_hub_2":          s := "Elle rassemble tes réponses pour proposer des pistes de comportement, de besoin et de communication."
            case "btn_result_soul":        s := "Résultat PRIMA Soul"
            case "btn_result_vda":         s := "Résultat PRIMA VDA"
            case "btn_result_shadow":      s := "Résultat PRIMA Shadow"
            case "btn_save_reading":       s := "Sauvegarder"
            case "btn_restart_cycle":      s := "Recommencer le cycle plus tard"
            case "btn_choose_universe":    s := "Choisir mon univers"
            case "btn_create_plan":        s := "Créer mon plan PRIMA"
            case "msg_reading_saved":      s := "Lecture sauvegardée."
            case "msg_cycle_reset_later":  s := "Réinitialisation du cycle prévue plus tard."
            case "msg_universe_later":     s := "Choix d'univers prévu plus tard."
            case "msg_plan_later":         s := "Plan PRIMA prévu plus tard."
            case "sec_suggest":            s := "1. Ce que tes réponses suggèrent"
            case "sec_nourish":            s := "2. Ce qui peut te nourrir"
            case "sec_pressure":           s := "3. Sous pression"
            case "sec_comm":               s := "4. Moyen de communication / régulation"
            case "lbl_dominant":           s := "Tendance dominante"
            case "lbl_secondary":          s := "Tendance secondaire"
            case "lbl_stable_probable":    s := "Fonctionnement stable probable"
            case "lbl_influence_secondary": s := "Influence secondaire probable"
            case "lbl_energy_probable":    s := "Énergie actuelle probable"
            case "lbl_tension_dom":        s := "Tension intérieure dominante"
            case "lbl_tension_sec":        s := "Tension secondaire"
            case "lbl_emotion_main":       s := "Émotion principale probable"
            case "uni_choice_1":           s := "3 pistes te sont proposées."
            case "uni_choice_2":           s := "Parcours-les puis choisis celle qui résonne le plus."
            case "uni_role_main":          s := "Univers principal"
            case "uni_role_bridge":        s := "Univers pont"
            case "uni_role_secondary":     s := "Univers secondaire"
            case "uni_why_main":           s := "Piste principale : elle correspond le plus directement à tes résultats Soul et VDA."
            case "uni_why_bridge":         s := "Piste pont : elle relie ton univers dominant à une autre tonalité intérieure."
            case "uni_why_secondary":      s := "Piste secondaire : une nuance complémentaire à explorer si elle te parle."
            case "choice_piste_of":        s := "Piste {} / {}"
            case "choice_why_label":       s := "Pourquoi cette piste peut correspondre"
            case "btn_prev_piste":         s := "← Précédent"
            case "btn_next_piste":         s := "Suivant →"
            case "btn_pick_piste":         s := "Choisir cette piste"
            case "terr_role_main":         s := "Territoire principal"
            case "terr_role_bridge":       s := "Territoire pont"
            case "terr_role_secondary":    s := "Territoire secondaire"
            case "scroll_hint":            s := "Fais défiler pour voir la suite"
            case "terr_choice_title":      s := "Choisir mon territoire"
            case "terr_choice_1":          s := "3 pistes te sont proposées."
            case "terr_choice_2":          s := "Parcours-les puis choisis celle qui résonne le plus."
            case "terr_why_main":          s := "Piste principale : elle reflète la zone de vie la plus active pour toi maintenant."
            case "terr_why_bridge":        s := "Piste pont : elle relie ton univers à un territoire complémentaire."
            case "terr_why_secondary":     s := "Piste secondaire : un angle supplémentaire à considérer s'il résonne."
            case "btn_pick":               s := "Choisir"
            case "identity_saved_title":   s := "Architecture PRIMA sauvegardée"
            case "identity_saved_1":       s := "Ton choix servira de base symbolique pour la suite de PRIMA App."
            case "identity_saved_2":       s := "Cette architecture peut évoluer avec tes futurs cycles."
            case "identity_arch_label":    s := "Architecture :"
            case "btn_back_reading":       s := "Retour à ma lecture"
            case "btn_back_prima_home":    s := "Retour accueil PRIMA"
            case "vda_question_of":        s := "Question {} / {}"
            case "btn_next":               s := "Suivant"
            case "msg_quit_run":           s := "Quitter le parcours en cours ?"
            case "msg_finish_or_quit":     s := "Termine le parcours ou quitte l'application."
            case "btn_soul_test_done":     s := "PRIMA Soul Test terminé"
            case "msg_test_locked_1":      s := "Test déjà terminé."
            case "msg_test_locked_2":      s := "Il sera réouvert quand PRIMA VDA, PRIMA Shadow, les résultats et le choix d'univers seront terminés."
            case "vda_done_1":             s := "Parcours terminé."
            case "vda_done_2":             s := "Le résultat complet sera ajouté dans une prochaine étape."
            case "btn_back_soul":          s := "Retour PRIMA Soul"
            case "result_line1":           s := "Tes réponses semblent montrer une piste possible autour de {}."
            case "result_line2":           s := "Ce n'est pas une identité. C'est une piste de travail."
            case "result_line3":           s := "Un deuxième thème semble aussi présent : {}."
            case "btn_read":               s := "J'ai lu"
            case "btn_start":           s := "Débuter"
            case "msg_module_later":    s := "Module prévu plus tard."
            case "review_domain":       s := "Domaine"
            case "review_no_goals":     s := "Ajoutez d'abord un objectif dans Paramétrage perso."
            case "review_no_domain_goals": s := "Aucun objectif défini pour ce domaine."
            case "create_title":        s := "Nouveau profil"
            case "create_security_title": s := "Sécurité profil"
            case "create_name":         s := "Nom du profil"
            case "create_lang":         s := "Langue"
            case "create_mode":         s := "Mode du profil"
            case "mode_client":         s := "Client"
            case "mode_creator":        s := "Créateur"
            case "create_code":         s := "Code créateur"
            case "msg_wrong_code":      s := "Code incorrect."
            case "privacy_title":       s := "Confidentialité"
            case "privacy_body":        s := "PRIMA App est local-first.`n`nAucun cloud forcé.`nAucune télémétrie.`nAucun micro.`nAucune capture.`nAucune API externe."
            case "btn_accept":          s := "J'accepte"
            case "btn_review":          s := "Revue"
            case "btn_proof":           s := "Preuve"
            case "btn_settings":        s := "Réglages"
            case "settings_title":      s := "Réglages"
            case "start_title":         s := "Lancement"
            case "start_welcome":       s := "Bienvenue dans PRIMA"
            case "start_profile":       s := "Profil : {}"
            case "btn_launch":          s := "Lancer PRIMA"
            case "home_title":          s := "Bienvenue dans PRIMA"
            case "home_active":         s := "Profil actif : {}"
            case "home_version":        s := "Version {}"
            case "creator_home_title":  s := "Creator Home"
            case "creator_home_body":   s := "Espace créateur privé PRIMA."
            case "btn_creator_personalization": s := "Personnalisation"
            case "btn_creator_goal":  s := "Objectif"
            case "btn_creator_soul_test": s := "PRIMA Soul Test"
            case "btn_creator_vda_test": s := "PRIMA VDA Test"
            case "btn_creator_shadow_test": s := "PRIMA Shadow Test"
            case "msg_creator_module_later": s := "Module créateur prévu plus tard."
            case "btn_onboarding":      s := "Paramétrage perso"
            case "btn_change_profile":  s := "Changer de profil"
            case "onboarding_body":     s := "PRIMA t'aide à avancer étape par étape. Pour l'instant, cette version sert à poser ta base, suivre ton profil et préparer ton espace personnel."
            case "msg_select_profile":  s := "Veuillez sélectionner un profil."
            case "msg_select_archive":  s := "Veuillez sélectionner un profil à archiver."
            case "msg_active_archive":  s := "Ce profil est actif. Déconnectez-vous ou choisissez un autre profil avant de l'archiver."
            case "msg_archive_confirm": s := "Archiver le profil « {} » ?`n`nLe profil sera déplacé vers archive/.`nAucune suppression définitive."
            case "msg_empty_name":      s := "Veuillez entrer un nom de profil."
            case "msg_no_active":       s := "Erreur : aucun profil actif."
            case "msg_goals_max_domains": s := "Maximum 5 domaines avec objectifs en V0.1."
            case "confirm_close":       s := "Fermer PRIMA App ?"
            case "confirm_quit":        s := "Quitter PRIMA App ?"
            case "confirm_saved":       s := "Vos données locales sont enregistrées."
            case "confirm_missing":     s := "Attention : le profil actif est introuvable sur disque."
            case "pause_on":            s := "PRIMA App est en pause.`n`nCtrl+Alt+Shift+X pour reprendre."
            case "pause_off":           s := "PRIMA App reprend."
            default:                    return key
        }
    }
    return p.Length ? Format(s, p*) : s
}

; ── Icônes UI PRIMA (affichage uniquement — jamais logs / sauvegarde / moteur) ─
PrimaLabelWithIcon(key, label) {
    icon := PrimaIcon(key)
    return (icon != "") ? icon "  " label : label
}

; Traduction + icône pour l'interface uniquement.
TIcon(key, p*) {
    return PrimaLabelWithIcon(key, T(key, p*))
}

PrimaIcon(key) {
    icon := PrimaMainMenuIcon(key)
    if (icon != "")
        return icon
    icon := PrimaSoulHubIcon(key)
    if (icon != "")
        return icon
    icon := PrimaResultSectionIcon(key)
    if (icon != "")
        return icon
    icon := PrimaStateIcon(key)
    if (icon != "")
        return icon
    icon := PrimaUniverseIcon(key)
    if (icon != "")
        return icon
    icon := PrimaTerritoryIcon(key)
    if (icon != "")
        return icon
    icon := SoulPublicIcon(key)
    if (icon != "")
        return icon
    icon := VdaPublicIcon(key)
    if (icon != "")
        return icon
    icon := ShadowPublicIcon(key)
    if (icon != "")
        return icon
    icon := ShadowEmotionIcon(key)
    if (icon != "")
        return icon
    return ""
}

PrimaMainMenuIcon(key) {
    switch key {
        case "home_title", "btn_launch":          return "🏠"
        case "profile_title":                     return "👤"
        case "btn_create_profile", "btn_create":  return "➕"
        case "create_password", "login_title":    return "🔐"
        case "base_kit_prima", "kit_title":       return "🎒"
        case "goals_title", "btn_goals", "btn_creator_goal": return "🎯"
        case "review_title", "btn_review":        return "📝"
        case "base_prima_soul", "prima_soul_intro_title": return "🧭"
        case "prima_soul_complete_title":         return "🎯"
        case "btn_settings", "btn_soul_settings", "settings_title": return "⚙️"
        case "btn_quit":                          return "🚪"
        case "btn_back", "btn_back_reading", "btn_back_prima_home": return "←"
        case "btn_save", "btn_save_reading":      return "💾"
        case "btn_archive":                       return "🗑️"
        case "btn_archives", "archives_title":   return "📦"
        case "btn_delete_archive":              return "❌"
        case "btn_continue":                      return "➡️"
        case "btn_next":                          return "➡️"
        case "btn_pick", "btn_pick_piste", "btn_accept", "btn_read": return "✅"
        case "btn_change_profile":                return "👤"
        case "start_title":                       return "🏠"
        case "privacy_title":                     return "🔐"
        case "create_title":                      return "➕"
        case "create_security_title":             return "🔐"
        case "btn_kit_verify":                    return "ℹ️"
        case "btn_kit_create":                    return "➕"
        case "btn_back_soul":                     return "←"
    }
    return ""
}

PrimaSoulHubIcon(key) {
    switch key {
        case "soul_test_soul", "soul_test_title", "btn_result_soul", "btn_creator_soul_test", "btn_soul_test_done": return "🪞"
        case "soul_test_vda", "vda_test_title", "btn_result_vda", "btn_creator_vda_test", "btn_vda_test_done": return "🧠"
        case "soul_test_shadow", "shadow_test_title", "btn_result_shadow", "btn_creator_shadow_test", "btn_shadow_test_done": return "🌘"
        case "btn_generate_reading", "reading_hub_title": return "✨"
        case "btn_choose_universe", "uni_choice_title": return "🌌"
        case "btn_create_plan":                   return "🛠️"
        case "btn_restart_cycle", "btn_reset_soul_cycle", "btn_redo_tests": return "🔄"
        case "terr_choice_title":                 return "🧭"
        case "identity_saved_title":              return "✅"
        case "identity_arch_label":               return "🌌"
    }
    return ""
}

PrimaResultSectionIcon(key) {
    switch key {
        case "sec_suggest":                       return "🔎"
        case "sec_nourish":                       return "🌱"
        case "sec_pressure":                      return "⚡"
        case "sec_comm":                          return "🗣️"
        case "lbl_dominant", "lbl_stable_probable", "lbl_tension_dom", "lbl_energy_probable": return "⭐"
        case "lbl_secondary", "lbl_influence_secondary", "lbl_tension_sec": return "✨"
        case "lbl_emotion_main":                  return "💫"
        case "gauge":                             return "📊"
    }
    return ""
}

PrimaStateIcon(key) {
    switch key {
        case "test_available", "btn_start":       return "▶️"
        case "test_done":                         return "✅"
        case "test_locked":                       return "🔒"
        case "msg_reading_preparing":             return "🕯️"
        case "warning":                           return "⚠️"
        case "info":                              return "ℹ️"
        case "no_result":                         return "📭"
        case "vda_question_of":                   return "❓"
        case "msg_rank_all", "shadow_pick_hint", "soul_pick_hint", "reading_hub_1": return "ℹ️"
    }
    return ""
}

PrimaUniverseIcon(key) {
    switch key {
        case "passe":      return "🕰️"
        case "futur":      return "🚀"
        case "ville":      return "🏙️"
        case "ocean":      return "🌊"
        case "desert":     return "🏜️"
        case "labyrinthe": return "🧩"
        case "jardin":     return "🌿"
    }
    return ""
}

PrimaTerritoryIcon(key) {
    switch key {
        case "lien":       return "🤝"
        case "choix":      return "🧭"
        case "regard":     return "👁️"
        case "controle":   return "🛡️"
        case "silence":    return "🌙"
        case "desir":      return "🔥"
        case "changement": return "🌪️"
    }
    return ""
}

; Icônes noms publics Soul (clé interne → emoji, jamais affichée).
SoulPublicIcon(key) {
    switch key {
        case "rejet":       return "📍"
        case "abandon":     return "🤝"
        case "humiliation": return "🌱"
        case "trahison":    return "🛡️"
        case "injustice":   return "⚖️"
    }
    return ""
}

VdaPublicIcon(key) {
    switch key {
        case "analyseur":   return "🧱"
        case "perseverant": return "🧭"
        case "empathique":  return "🤝"
        case "imagineur":   return "🌌"
        case "energiseur":  return "⚡"
        case "promoteur":   return "🚀"
    }
    return ""
}

ShadowPublicIcon(key) {
    switch key {
        case "orgueil":     return "👑"
        case "envie":       return "👁️"
        case "colere":      return "⚡"
        case "paresse":     return "🌫️"
        case "avarice":     return "🛡️"
        case "gourmandise": return "🍯"
        case "luxure":      return "🔥"
    }
    return ""
}

ShadowEmotionIcon(key) {
    switch key {
        case "peur":      return "⚠️"
        case "tristesse": return "🌧️"
        case "colere":    return "🔥"
        case "honte":     return "🫥"
        case "joie":      return "✨"
    }
    return ""
}

PrimaUniverseDisplayNameWithIcon(key) {
    return PrimaLabelWithIcon(key, PrimaUniverseName(key))
}

PrimaTerritoryDisplayNameWithIcon(key) {
    return PrimaLabelWithIcon(key, PrimaTerritoryName(key))
}

SoulReadingNameWithIcon(key) {
    return PrimaLabelWithIcon(key, SoulReadingName(key))
}

VdaReadingNameWithIcon(key) {
    return PrimaLabelWithIcon(key, VdaReadingName(key))
}

ShadowReadingNameWithIcon(key) {
    return PrimaLabelWithIcon(key, ShadowReadingName(key))
}

ShadowEmotionNameWithIcon(key) {
    return PrimaLabelWithIcon(key, ShadowEmotionName(key))
}

; Préfixe priorité choix 1-2 (Soul / Shadow).
PrimaPriorityPrefix(priority) {
    switch priority {
        case 1: return "① — "
        case 2: return "② — "
    }
    return priority " — "
}

; Préfixe rang VDA 1-6.
PrimaRankPrefix(rank) {
    return rank " — "
}

; ── UI helpers (grille PRIMA) ───────────────────────────────────────────────────
AddSpacer(g, h := "") {
    global GAP_MD
    if (h = "")
        h := GAP_MD
    g.Add("Text", "h" h " Background" CLR_BG, "")
}

AddTitle(g, text, size := 24) {
    global CONTENT_W, TITLE_H, CLR_BG, CLR_ACCENT
    g.SetFont("s" size " Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "w" CONTENT_W " h" TITLE_H " Center Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddSubtitle(g, text) {
    global CONTENT_W, TEXT_H, CLR_BG, CLR_SUBTEXT
    g.SetFont("s11 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "w" CONTENT_W " h" TEXT_H " Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddFormTitle(g, text) {
    global FORM_FIELD_W, CLR_BG, CLR_ACCENT, CLR_TEXT
    g.SetFont("s14 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "w" FORM_FIELD_W " h22 Center Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddFormLabel(g, text) {
    global FORM_FIELD_W, CLR_BG, CLR_SUBTEXT, CLR_TEXT
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "w" FORM_FIELD_W " h16 Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddFormBodyText(g, text) {
    global FORM_FIELD_W, CLR_BG, CLR_TEXT
    g.SetFont("s10 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "w" FORM_FIELD_W " Center Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddFormGap(g, h := 3) {
    global CLR_BG
    g.Add("Text", "h" h " Background" CLR_BG, "")
}

AddFormButton(g, label, action) {
    global FORM_BTN_W, FORM_BTN_H
    btn := g.Add("Button", "w" FORM_BTN_W " h" FORM_BTN_H " Center", label)
    btn.OnEvent("Click", action)
    return btn
}

AddFormNavBackQuit(g, backAction, includeQuit := true) {
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("btn_back"), backAction)
    if (includeQuit) {
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    }
}

AddCreateLabel(g, text) {
    AddFormLabel(g, text)
}

AddCreateGap(g, h := 3) {
    AddFormGap(g, h)
}

AddBodyText(g, text, w := "") {
    global CONTENT_W, CLR_BG, CLR_TEXT
    if (w = "")
        w := CONTENT_W
    g.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "w" w " Background" CLR_BG, text)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddCardRule(g) {
    global CONTENT_W, CLR_PANEL
    g.Add("Text", "w" CONTENT_W " h1 Background" CLR_PANEL, "")
}

; Carte de choix : titre + description + bouton Choisir (même géométrie partout).
AddChoiceCard(g, title, desc, pickAction) {
    global GAP_LG, GAP_SM, GAP_Y, CARD_H, CARD_W, CLR_BG, CLR_PANEL
    AddSpacer(g, GAP_LG)
    AddCardRule(g)
    AddSpacer(g, GAP_Y)
    AddSubtitle(g, title)
    AddSpacer(g, GAP_SM)
    AddBodyText(g, desc)
    AddSpacer(g, GAP_Y)
    AddButton(g, TIcon("btn_pick"), pickAction)
    AddSpacer(g, GAP_SM)
}

; En-tête fixe écran choix Univers / Territoire.
AddChoiceScreenHeader(g, title, introLine1, introLine2 := "") {
    global MARGIN_X, CONTENT_W, CHOICE_TITLE_Y, CHOICE_INTRO_Y, CHOICE_INTRO_H
    global CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT
    g.SetFont("s20 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" CHOICE_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG, title)
    intro := introLine1
    if (introLine2 != "")
        intro .= "`n" introLine2
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" CHOICE_INTRO_Y " w" CONTENT_W " h" CHOICE_INTRO_H " Center +0x2000 Background" CLR_BG, intro)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

; Carte compacte à position absolue (icône+titre, description, Choisir dans la carte).
AddFixedChoiceCard(g, row, roleLabel, title, desc, pickAction) {
    global CHOICE_CARD_X, CHOICE_CARD_W, CHOICE_CARD_H, CHOICE_CARD_GAP, CHOICE_CARD_START_Y
    global CHOICE_PICK_W, BUTTON_H, CLR_PANEL, CLR_SUBTEXT, CLR_TEXT, CLR_ACCENT
    y := CHOICE_CARD_START_Y + (row - 1) * (CHOICE_CARD_H + CHOICE_CARD_GAP)
    x := CHOICE_CARD_X
    w := CHOICE_CARD_W
    h := CHOICE_CARD_H
    g.Add("Text", "x" x " y" y " w" w " h" h " Background" CLR_PANEL, "")
    g.SetFont("s9 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 8) " w" (w - 32) " h18 BackgroundTrans", roleLabel)
    g.SetFont("s12 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 28) " w" (w - CHOICE_PICK_W - 40) " h24 BackgroundTrans", title)
    g.SetFont("s10 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 52) " w" (w - CHOICE_PICK_W - 40) " h44 +0x2000 BackgroundTrans", desc)
    pickX := x + w - CHOICE_PICK_W - 16
    pickY := y + h - BUTTON_H - 12
    btn := g.Add("Button", "x" pickX " y" pickY " w" CHOICE_PICK_W " h" BUTTON_H " Center", TIcon("btn_pick"))
    btn.OnEvent("Click", pickAction)
}

; Pied écran choix : Retour (fixe y=650).
AddChoiceNavBack(g, backAction) {
    global MARGIN_X, CONTENT_W, CHOICE_NAV_Y, TEST_NAV_BTN_W, BUTTON_H
    x := MARGIN_X + (CONTENT_W - TEST_NAV_BTN_W) // 2
    btnBack := g.Add("Button", "x" x " y" CHOICE_NAV_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_back"))
    btnBack.OnEvent("Click", backAction)
}

; Carte paginée (1 piste visible) : titre, description, pourquoi, bouton Choisir.
AddPagedChoiceCard(g, title, desc, whyText, pickAction) {
    global CHOICE_CARD_X, CHOICE_CARD_W, PAGED_CHOICE_CARD_Y, PAGED_CHOICE_CARD_H
    global CHOICE_PICK_W, BUTTON_H_BIG, CLR_PANEL, CLR_SUBTEXT, CLR_TEXT, CLR_ACCENT
    x := CHOICE_CARD_X
    y := PAGED_CHOICE_CARD_Y
    w := CHOICE_CARD_W
    h := PAGED_CHOICE_CARD_H
    innerW := w - 32
    g.Add("Text", "x" x " y" y " w" w " h" h " Background" CLR_PANEL, "")
    g.SetFont("s16 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 20) " w" innerW " h28 BackgroundTrans", title)
    g.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 54) " w" innerW " h88 +0x2000 BackgroundTrans", desc)
    g.SetFont("s10 Bold c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 148) " w" innerW " h18 BackgroundTrans", T("choice_why_label"))
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" (x + 16) " y" (y + 168) " w" innerW " h56 +0x2000 BackgroundTrans", whyText)
    pickX := x + (w - CHOICE_PICK_W) // 2
    pickY := y + h - BUTTON_H_BIG - 16
    btn := g.Add("Button", "x" pickX " y" pickY " w" CHOICE_PICK_W " h" BUTTON_H_BIG " Center", TIcon("btn_pick_piste"))
    btn.OnEvent("Click", pickAction)
}

; Navigation paginée : Précédent | Choisir cette piste | Suivant.
AddPagedChoiceNavRow(g, page, total, onPrev, onPick, onNext) {
    global MARGIN_X, CONTENT_W, PAGED_CHOICE_NAV_Y, PAGED_CHOICE_NAV_BTN_W, PAGED_CHOICE_PICK_W
    global BUTTON_H, BUTTON_H_BIG
    gap := 16
    totalW := 2 * PAGED_CHOICE_NAV_BTN_W + PAGED_CHOICE_PICK_W + 2 * gap
    startX := MARGIN_X + (CONTENT_W - totalW) // 2
    btnPrev := g.Add("Button", "x" startX " y" PAGED_CHOICE_NAV_Y " w" PAGED_CHOICE_NAV_BTN_W " h" BUTTON_H " Center"
        , T("btn_prev_piste"))
    btnPrev.OnEvent("Click", onPrev)
    btnPrev.Enabled := (page > 1)
    xPick := startX + PAGED_CHOICE_NAV_BTN_W + gap
    btnPick := g.Add("Button", "x" xPick " y" PAGED_CHOICE_NAV_Y " w" PAGED_CHOICE_PICK_W " h" BUTTON_H_BIG " Center"
        , TIcon("btn_pick_piste"))
    btnPick.OnEvent("Click", onPick)
    xNext := xPick + PAGED_CHOICE_PICK_W + gap
    btnNext := g.Add("Button", "x" xNext " y" PAGED_CHOICE_NAV_Y " w" PAGED_CHOICE_NAV_BTN_W " h" BUTTON_H " Center"
        , T("btn_next_piste"))
    btnNext.OnEvent("Click", onNext)
    btnNext.Enabled := (page < total)
}

AddButton(g, label, action, w := "", h := "") {
    global BUTTON_W, BUTTON_H
    if (w = "")
        w := BUTTON_W
    if (h = "")
        h := BUTTON_H
    btn := g.Add("Button", "w" w " h" h " Center", label)
    btn.OnEvent("Click", action)
    return btn
}

AddBigButton(g, label, action) {
    global BUTTON_W, BUTTON_H_BIG
    btn := g.Add("Button", "w" BUTTON_W " h" BUTTON_H_BIG " Center", label)
    btn.SetFont("s12 Bold")
    btn.OnEvent("Click", action)
    return btn
}

; Hauteur réponse selon longueur du texte (wrapping multi-ligne).
AnswerButtonHeight(text, maxH := 64) {
    global ANSWER_H, ANSWER_H_LG
    charsPerLine := 88
    lines := Max(1, Ceil(StrLen(text) / charsPerLine))
    if (lines <= 1)
        h := ANSWER_H
    else if (lines = 2)
        h := ANSWER_H_LG
    else
        h := ANSWER_H_LG + (lines - 2) * 20
    return Min(h, maxH)
}

; Bouton réponse test : largeur grille, multi-ligne, hauteur auto.
AddAnswerButton(g, text, handler, w := "") {
    global ANSWER_W
    if (w = "")
        w := ANSWER_W
    h := AnswerButtonHeight(text)
    btn := g.Add("Button", "w" w " h" h " +0x2000", text)
    btn.OnEvent("Click", handler)
    return btn
}

; Abscisse centrée pour la colonne réponses test (820 px).
TestAnswerX() {
    global MARGIN_X, CONTENT_W, TEST_ANSWER_W
    return MARGIN_X + (CONTENT_W - TEST_ANSWER_W) // 2
}

; En-tête fixe écran question : titre · compteur · prompt · consigne · séparateur.
AddTestQuestionHeader(g, title, countText, promptText, hintText := "") {
    global MARGIN_X, CONTENT_W, TEST_TITLE_Y, TEST_COUNT_Y, TEST_PROMPT_Y, TEST_PROMPT_H
    global TEST_HINT_Y, TEST_HINT_H, TEST_RULE_Y, TEST_ANSWER_W
    global CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT, CLR_PANEL
    ax := TestAnswerX()
    g.SetFont("s20 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" TEST_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG, title)
    g.SetFont("s11 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" TEST_COUNT_Y " w" CONTENT_W " h22 Center Background" CLR_BG, countText)
    g.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "x" ax " y" TEST_PROMPT_Y " w" TEST_ANSWER_W " h" TEST_PROMPT_H " +0x2000 Background" CLR_BG, promptText)
    if (hintText != "") {
        g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
        g.Add("Text", "x" ax " y" TEST_HINT_Y " w" TEST_ANSWER_W " h" TEST_HINT_H " Background" CLR_BG, hintText)
        g.Add("Text", "x" ax " y" TEST_RULE_Y " w" TEST_ANSWER_W " h1 Background" CLR_PANEL, "")
    }
    g.SetFont("s11 c" CLR_TEXT, "Segoe UI")
}

; Hauteurs + nav adaptative : nav_y = min(WINDOW_H - 110, answers_end + 28).
ComputeTestAnswerLayout(texts) {
    global TEST_ANSWERS_Y, GAP_TEST_ANSWER, TEST_ANSWER_H_DEF, TEST_ANSWER_MAX_H, ANSWER_H
    global TEST_NAV_GAP_AFTER, TEST_NAV_MAX_Y, WINDOW_H
    n := texts.Length
    if (n = 0)
        return { heights: [], navY: TEST_NAV_MAX_Y, answersEnd: TEST_ANSWERS_Y }
    navCap := Min(TEST_NAV_MAX_Y, WINDOW_H - 110)
    avail := navCap - TEST_NAV_GAP_AFTER - TEST_ANSWERS_Y
    heights := []
    for t in texts {
        h := AnswerButtonHeight(t, TEST_ANSWER_MAX_H)
        if (h <= ANSWER_H + 2 && StrLen(t) <= 90)
            h := TEST_ANSWER_H_DEF
        heights.Push(h)
    }
    total := 0
    for h in heights
        total += h
    total += (n - 1) * GAP_TEST_ANSWER
    if (total > avail) {
        cap := Max(38, Min(TEST_ANSWER_MAX_H, Floor((avail - (n - 1) * GAP_TEST_ANSWER) / n)))
        heights := []
        for t in texts {
            h := AnswerButtonHeight(t, cap)
            if (h < cap && StrLen(t) <= 90)
                h := cap
            heights.Push(h)
        }
        total := 0
        for h in heights
            total += h
        total += (n - 1) * GAP_TEST_ANSWER
    }
    answersEnd := TEST_ANSWERS_Y + total
    navY := Min(navCap, answersEnd + TEST_NAV_GAP_AFTER)
    return { heights: heights, navY: navY, answersEnd: answersEnd }
}

; Style visuel réponse sélectionnée / non sélectionnée (UI uniquement).
ApplyTestAnswerPickStyle(btn, prefix, answerText, selected) {
    global CLR_TEXT, CLR_ACCENT
    btn.Text := prefix answerText
    if (selected)
        btn.SetFont("s11 Bold c" CLR_ACCENT, "Segoe UI")
    else
        btn.SetFont("s11 c" CLR_TEXT, "Segoe UI")
}

; Pile de réponses centrée (820 px) à y=245+.
AddTestAnswerButtons(g, texts, clickHandler) {
    global TEST_ANSWERS_Y, GAP_TEST_ANSWER, TEST_ANSWER_W, CLR_TEXT
    layout := ComputeTestAnswerLayout(texts)
    btns := []
    y := TEST_ANSWERS_Y
    ax := TestAnswerX()
    for i, h in layout.heights {
        btn := g.Add("Button", "x" ax " y" y " w" TEST_ANSWER_W " h" h " +0x2000", "  " texts[i])
        btn.SetFont("s11 c" CLR_TEXT, "Segoe UI")
        btn.OnEvent("Click", clickHandler.Bind(i))
        btns.Push(btn)
        y += h + GAP_TEST_ANSWER
    }
    btns.navY := layout.navY
    return btns
}

; Navigation test : Suivant | Quitter — y adaptatif selon contenu.
AddFixedTestNav(g, nextAction, navY := "") {
    global MARGIN_X, CONTENT_W, TEST_NAV_BTN_W, TEST_NAV_GAP, TEST_NAV_MAX_Y, BUTTON_H
    if (navY = "")
        navY := TEST_NAV_MAX_Y
    totalW := 2 * TEST_NAV_BTN_W + TEST_NAV_GAP
    startX := MARGIN_X + (CONTENT_W - totalW) // 2
    btnNext := g.Add("Button", "x" startX " y" navY " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_next"))
    btnNext.OnEvent("Click", nextAction)
    xQuit := startX + TEST_NAV_BTN_W + TEST_NAV_GAP
    btnQuit := g.Add("Button", "x" xQuit " y" navY " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_quit"))
    btnQuit.OnEvent("Click", (*) => ConfirmExit("quit"))
}

AddDisabledButton(g, label, w := "", h := "") {
    global BUTTON_W, BUTTON_H
    if (w = "")
        w := BUTTON_W
    if (h = "")
        h := BUTTON_H
    btn := g.Add("Button", "w" w " h" h " Center", label)
    btn.Enabled := false
    return btn
}

; En-tête d'écran : titre + texte(s) d'introduction.
AddScreenHeader(g, title, introLines*) {
    global GAP_SM, GAP_LG
    AddTitle(g, title, 20)
    AddSpacer(g, GAP_SM)
    for line in introLines
        AddBodyText(g, line)
    AddSpacer(g, GAP_LG)
}

; Navigation bas d'écran : Retour puis Quitter (ou actions custom).
AddNavBackQuit(g, backAction, quitAction := "") {
    global GAP_XL, GAP_Y
    AddSpacer(g, GAP_XL)
    AddButton(g, TIcon("btn_back"), backAction)
    if (quitAction != "") {
        AddSpacer(g, GAP_Y)
        AddButton(g, TIcon("btn_quit"), quitAction)
    }
}

; Navigation test : Suivant puis Quitter.
AddTestNav(g, nextAction) {
    global GAP_LG, GAP_Y
    AddSpacer(g, GAP_LG)
    AddButton(g, TIcon("btn_next"), nextAction)
    AddSpacer(g, GAP_Y)
    AddButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
}

; Section résultat : sous-titre + contenu (lignes vides ignorées).
AddResultSection(g, sectionKey, bodyLines*) {
    global GAP_LG, GAP_SM
    AddSpacer(g, GAP_LG)
    AddSubtitle(g, TIcon(sectionKey))
    AddSpacer(g, GAP_SM)
    for line in bodyLines {
        if (line != "")
            AddBodyText(g, line)
    }
}

HomeChangeProfile(*) {
    global CURRENT_PROFILE_ID, CURRENT_DISPLAY_NAME, PENDING_PROFILE_ID
    CURRENT_PROFILE_ID := ""
    CURRENT_DISPLAY_NAME := ""
    PENDING_PROFILE_ID := ""
    SetTimer(DeferredRenderProfile, -1)
}

DeferredRenderProfile(*) {
    SetTimer(DeferredRenderProfile, 0)
    RenderScreen("profile")
}

HomeOpenOnboarding(*) {
    SetTimer(DeferredRenderOnboarding, -1)
}

DeferredRenderOnboarding(*) {
    SetTimer(DeferredRenderOnboarding, 0)
    RenderScreen("onboarding")
}

HomeOpenSettings(*) {
    SetTimer(DeferredRenderSettings, -1)
}

DeferredRenderSettings(*) {
    SetTimer(DeferredRenderSettings, 0)
    RenderScreen("settings")
}

HomeOpenReview(*) {
    global REVIEW_BACK_SCREEN
    REVIEW_BACK_SCREEN := "home"
    SetTimer(DeferredRenderReview, -1)
}

CreatorOpenReview(*) {
    global REVIEW_BACK_SCREEN
    REVIEW_BACK_SCREEN := "creator_home"
    SetTimer(DeferredRenderReview, -1)
}

CreatorOpenSoul(*) {
    global PRIMA_SOUL_BACK
    PRIMA_SOUL_BACK := "creator_home"
    SetTimer(DeferredRenderPrimaSoulIntro, -1)
}

DeferredRenderCreatorSoul(*) {
    global PRIMA_SOUL_BACK
    SetTimer(DeferredRenderCreatorSoul, 0)
    PRIMA_SOUL_BACK := "creator_home"
    RenderScreen("prima_soul_intro")
}

CreatorOpenGoals(*) {
    global CURRENT_PROFILE_ID, GOALS_BACK_SCREEN
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        return
    }
    GOALS_BACK_SCREEN := "creator_home"
    RenderScreen("onboarding_goals")
}

DeferredRenderReview(*) {
    SetTimer(DeferredRenderReview, 0)
    RenderScreen("review")
}

HomeOpenPrimaSoulIntro(*) {
    global PRIMA_SOUL_BACK
    PRIMA_SOUL_BACK := "home"
    SetTimer(DeferredRenderPrimaSoulIntro, -1)
}

PersonalBaseOpenPrimaSoulIntro(*) {
    global PRIMA_SOUL_BACK
    PRIMA_SOUL_BACK := "personal_base"
    SetTimer(DeferredRenderPrimaSoulIntro, -1)
}

DeferredRenderPrimaSoulIntro(*) {
    SetTimer(DeferredRenderPrimaSoulIntro, 0)
    RenderScreen("prima_soul_intro")
}

PrimaSoulBackToHome(*) {
    SetTimer(DeferredPrimaSoulBackHome, -1)
}

DeferredPrimaSoulBackHome(*) {
    global PRIMA_SOUL_BACK
    SetTimer(DeferredPrimaSoulBackHome, 0)
    RenderScreen(PRIMA_SOUL_BACK)
}

OpenCreateProfile(*) {
    global DRAFT_LANG, DRAFT_NAME, DRAFT_MODE, DRAFT_PASSWORD, DRAFT_PASSWORD_CONFIRM, CURRENT_LANG
    DRAFT_LANG := CURRENT_LANG
    DRAFT_NAME := ""
    DRAFT_MODE := "client"
    DRAFT_PASSWORD := ""
    DRAFT_PASSWORD_CONFIRM := ""
    CURRENT_LANG := DRAFT_LANG
    RenderScreen("create")
}

TrySaveCreateDrafts() {
    global NAME_INPUT, DRAFT_NAME
    try DRAFT_NAME := NAME_INPUT.Value
}

TrySaveCreateSecurityDrafts() {
    global PASSWORD_INPUT, PASSWORD_CONFIRM_INPUT
    global DRAFT_PASSWORD, DRAFT_PASSWORD_CONFIRM
    try DRAFT_PASSWORD := PASSWORD_INPUT.Value
    try DRAFT_PASSWORD_CONFIRM := PASSWORD_CONFIRM_INPUT.Value
}

CreateLangChange(*) {
    global LANG_CHOICE, DRAFT_LANG, CURRENT_LANG, MODE_CHOICE, DRAFT_MODE
    TrySaveCreateDrafts()
    DRAFT_MODE := (MODE_CHOICE.Value = 2) ? "creator" : "client"
    DRAFT_LANG := (LANG_CHOICE.Text = "English") ? "en" : "fr"
    CURRENT_LANG := DRAFT_LANG
    RenderScreen("create")
}

CreateModeChange(*) {
    TrySaveCreateDrafts()
    global MODE_CHOICE, DRAFT_MODE
    DRAFT_MODE := (MODE_CHOICE.Value = 2) ? "creator" : "client"
    RenderScreen("create")
}

CreateProfileContinue(*) {
    global NAME_INPUT, LANG_CHOICE, MODE_CHOICE
    global DRAFT_NAME, DRAFT_LANG, DRAFT_MODE, CURRENT_LANG
    name := Trim(NAME_INPUT.Value)
    if (name = "") {
        MsgBox(T("msg_empty_name"), APP_TITLE, "Icon!")
        return
    }
    DRAFT_NAME := name
    DRAFT_LANG := (LANG_CHOICE.Text = "English") ? "en" : "fr"
    DRAFT_MODE := (MODE_CHOICE.Value = 2) ? "creator" : "client"
    CURRENT_LANG := DRAFT_LANG
    RenderScreen("create_security")
}

BackFromCreateSecurity(*) {
    TrySaveCreateSecurityDrafts()
    RenderScreen("create")
}

BackFromCreate(*) {
    RestoreSessionLanguage()
    RenderScreen("profile")
}

; ── Écrans ────────────────────────────────────────────────────────────────────
BuildProfile() {
    ids := GetProfileIds()
    global FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    g := NewFormGui()
    AddFormTitle(g, TIcon("profile_title"))

    if (ids.Length = 0) {
        AddFormGap(g, 8)
        AddFormBodyText(g, T("profile_none"))
        AddFormGap(g, 10)
        AddFormButton(g, TIcon("btn_create_profile"), OpenCreateProfile)
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_archives"), (*) => RenderScreen("archives"))
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    } else {
        AddFormGap(g, 6)
        AddFormBodyText(g, T("profile_select"))
        AddFormGap(g, 4)
        global PROFILE_LIST, PROFILE_IDS
        PROFILE_IDS := ids
        names := []
        for id in ids {
            name := IniRead(PROFILES_DIR "\" id "\profile.ini", "Profile", "display_name", id)
            names.Push(name)
        }
        PROFILE_LIST := g.Add("ListBox", "w" FORM_FIELD_W " h80 Background" CLR_PANEL " c" CLR_TEXT, names)
        if (names.Length > 0) {
            PROFILE_LIST.Choose(1)
            PROFILE_LIST.OnEvent("DoubleClick", ProfileContinue)
        }
        AddFormGap(g, 8)
        AddFormButton(g, TIcon("btn_continue"), ProfileContinue)
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_archive"), ProfileArchive)
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_create_profile"), OpenCreateProfile)
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_archives"), (*) => RenderScreen("archives"))
        AddFormGap(g, 4)
        AddFormButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    }

    ShowFormGui()
}

BuildArchives() {
    global ARCHIVE_LIST, ARCHIVE_FOLDER_NAMES, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    folderNames := GetArchiveFolderNames()
    g := NewFormGui()
    AddFormTitle(g, TIcon("archives_title"))
    WriteLog("archive_screen_opened")

    if (folderNames.Length = 0) {
        AddFormGap(g, 8)
        AddFormBodyText(g, T("archives_none"))
        AddFormGap(g, 10)
        AddFormNavBackQuit(g, (*) => RenderScreen("profile"))
    } else {
        AddFormGap(g, 6)
        AddFormBodyText(g, T("archives_select"))
        AddFormGap(g, 4)
        ARCHIVE_FOLDER_NAMES := folderNames
        displayLines := []
        for name in folderNames
            displayLines.Push(FormatArchiveListEntry(name))
        ARCHIVE_LIST := g.Add("ListBox", "w" FORM_FIELD_W " h100 Background" CLR_PANEL " c" CLR_TEXT, displayLines)
        AddFormGap(g, 8)
        AddFormButton(g, TIcon("btn_delete_archive"), ArchiveDeletePermanently)
        AddFormNavBackQuit(g, (*) => RenderScreen("profile"))
    }

    ShowFormGui()
}

ProfileArchive(*) {
    global PROFILE_LIST, PROFILE_IDS, CURRENT_PROFILE_ID
    idx := GetProfileListIndex()
    if (idx = 0) {
        MsgBox(T("msg_select_archive"), APP_TITLE, "Icon!")
        return
    }
    profileId := PROFILE_IDS[idx]
    if (CURRENT_PROFILE_ID != "" && profileId = CURRENT_PROFILE_ID) {
        MsgBox(T("msg_active_archive"), APP_TITLE, "Icon!")
        return
    }
    displayName := IniRead(PROFILES_DIR "\" profileId "\profile.ini", "Profile", "display_name", profileId)
    result := MsgBox(T("msg_archive_confirm", displayName), APP_TITLE, "YesNo Icon?")
    if (result != "Yes")
        return
    ArchiveProfile(profileId)
    RenderScreen("profile")
}

; Index ListBox profil (1-based) ; repli sur le seul profil si rien n'est sélectionné.
GetProfileListIndex() {
    global PROFILE_LIST, PROFILE_IDS
    idx := 0
    if IsObject(PROFILE_LIST)
        idx := PROFILE_LIST.Value
    if (idx = 0 && PROFILE_IDS.Length = 1)
        idx := 1
    return idx
}

ProfileContinue(*) {
    global PROFILE_LIST, PROFILE_IDS, PENDING_PROFILE_ID, CURRENT_LANG
    WriteLog("profile_continue_clicked", PROFILE_IDS.Length)
    idx := GetProfileListIndex()
    if (idx = 0) {
        WriteLog("profile_selection_empty", "continue")
        MsgBox(T("msg_select_profile"), APP_TITLE, "Icon!")
        return
    }
    if (idx < 1 || idx > PROFILE_IDS.Length) {
        WriteLog("profile_selection_invalid", idx)
        MsgBox(T("msg_select_profile"), APP_TITLE, "Icon!")
        return
    }
    profileId := PROFILE_IDS[idx]
    PENDING_PROFILE_ID := profileId
    CURRENT_LANG := GetProfileLanguage(profileId)
    WriteLog("profile_selected", profileId)
    RenderScreen("profile_login")
}

BuildProfileLogin() {
    global PENDING_PROFILE_ID, LOGIN_PASSWORD_INPUT, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    if (PENDING_PROFILE_ID = "") {
        RenderScreen("profile")
        return
    }
    displayName := IniRead(PROFILES_DIR "\" PENDING_PROFILE_ID "\profile.ini", "Profile", "display_name", PENDING_PROFILE_ID)
    g := NewFormGui()
    AddFormTitle(g, TIcon("login_title"))
    AddFormGap(g, 6)
    AddFormBodyText(g, T("start_profile", displayName))
    AddFormGap(g, 6)
    AddFormLabel(g, T("create_password"))
    LOGIN_PASSWORD_INPUT := g.Add("Edit", "w" FORM_FIELD_W " h22 Password Background" CLR_PANEL " c" CLR_TEXT, "")
    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_continue"), ProfileLoginSubmit)
    AddFormNavBackQuit(g, (*) => RenderScreen("profile"))
    try LOGIN_PASSWORD_INPUT.Focus()
    ShowFormGui()
}

ProfileLoginSubmit(*) {
    global PENDING_PROFILE_ID, LOGIN_PASSWORD_INPUT
    if (PENDING_PROFILE_ID = "") {
        RenderScreen("profile")
        return
    }
    password := Trim(LOGIN_PASSWORD_INPUT.Value)
    if (password = "") {
        MsgBox(T("msg_empty_password"), APP_TITLE, "Icon!")
        return
    }
    if VerifyProfilePassword(PENDING_PROFILE_ID, password) {
        profileId := PENDING_PROFILE_ID
        PENDING_PROFILE_ID := ""
        RouteAfterProfileLogin(profileId)
        return
    }
    WriteLog("profile_login_failed", PENDING_PROFILE_ID)
    WriteProfileLog(PENDING_PROFILE_ID, "profile_login_failed")
    MsgBox(T("msg_wrong_password"), APP_TITLE, "Icon!")
}

BuildCreateProfile() {
    global DRAFT_NAME, DRAFT_LANG, DRAFT_MODE
    global FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    g := NewFormGui()
    AddFormTitle(g, TIcon("create_title"))

    AddFormGap(g, 6)
    AddFormLabel(g, T("create_name"))
    global NAME_INPUT
    NAME_INPUT := g.Add("Edit", "w" FORM_FIELD_W " h22 Background" CLR_PANEL " c" CLR_TEXT, DRAFT_NAME)

    AddFormGap(g, 4)
    AddFormLabel(g, T("create_lang"))
    global LANG_CHOICE
    LANG_CHOICE := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, ["Français", "English"])
    LANG_CHOICE.Choose(DRAFT_LANG = "en" ? 2 : 1)
    LANG_CHOICE.OnEvent("Change", CreateLangChange)

    AddFormGap(g, 4)
    AddFormLabel(g, T("create_mode"))
    global MODE_CHOICE
    MODE_CHOICE := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, [T("mode_client"), T("mode_creator")])
    MODE_CHOICE.Choose(DRAFT_MODE = "creator" ? 2 : 1)
    MODE_CHOICE.OnEvent("Change", CreateModeChange)

    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_continue"), CreateProfileContinue)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_back"), BackFromCreate)

    ShowFormGui()
}

BuildCreateProfileSecurity() {
    global DRAFT_MODE, DRAFT_PASSWORD, DRAFT_PASSWORD_CONFIRM
    global FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    g := NewFormGui()
    AddFormTitle(g, TIcon("create_security_title"))

    AddFormGap(g, 6)
    if (DRAFT_MODE = "creator") {
        AddFormLabel(g, T("create_code"))
        global CREATOR_CODE_INPUT
        CREATOR_CODE_INPUT := g.Add("Edit", "w" FORM_FIELD_W " h22 Password Background" CLR_PANEL " c" CLR_TEXT, "")
        AddFormGap(g, 4)
    }

    AddFormLabel(g, T("create_password"))
    global PASSWORD_INPUT
    PASSWORD_INPUT := g.Add("Edit", "w" FORM_FIELD_W " h22 Password Background" CLR_PANEL " c" CLR_TEXT, DRAFT_PASSWORD)

    AddFormGap(g, 4)
    AddFormLabel(g, T("create_password_confirm"))
    global PASSWORD_CONFIRM_INPUT
    PASSWORD_CONFIRM_INPUT := g.Add("Edit", "w" FORM_FIELD_W " h22 Password Background" CLR_PANEL " c" CLR_TEXT, DRAFT_PASSWORD_CONFIRM)

    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_create"), CreateProfileSubmit)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_back"), BackFromCreateSecurity)

    ShowFormGui()
}

CreateProfileSubmit(*) {
    global DRAFT_NAME, DRAFT_LANG, DRAFT_MODE
    global CREATOR_CODE_INPUT, CREATOR_CODE, PASSWORD_INPUT, PASSWORD_CONFIRM_INPUT
    name := Trim(DRAFT_NAME)
    if (name = "") {
        MsgBox(T("msg_empty_name"), APP_TITLE, "Icon!")
        RenderScreen("create")
        return
    }
    password := Trim(PASSWORD_INPUT.Value)
    confirm := Trim(PASSWORD_CONFIRM_INPUT.Value)
    if (password = "") {
        MsgBox(T("msg_empty_password"), APP_TITLE, "Icon!")
        return
    }
    if (password !== confirm) {
        MsgBox(T("msg_password_mismatch"), APP_TITLE, "Icon!")
        return
    }
    lang := DRAFT_LANG
    mode := DRAFT_MODE
    if (mode = "creator") {
        if (Trim(CREATOR_CODE_INPUT.Value) !== CREATOR_CODE) {
            MsgBox(T("msg_wrong_code"), APP_TITLE, "Icon!")
            return
        }
    }
    profileId := CreateProfile(name, lang, mode)
    if !SetProfilePassword(profileId, password) {
        MsgBox(T("msg_password_hash_error"), APP_TITLE, "Icon!")
        return
    }
    if (mode = "creator")
        RenderScreen("creator_home")
    else
        RenderScreen("privacy")
}

BuildPrivacy() {
    g := NewFormGui()
    AddFormTitle(g, TIcon("privacy_title"))
    AddFormGap(g, 6)
    AddFormBodyText(g, T("privacy_body"))
    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_accept"), PrivacyAccept)
    AddFormNavBackQuit(g, (*) => RenderScreen("profile"))
    ShowFormGui()
}

PrivacyAccept(*) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        RenderScreen("profile")
        return
    }
    IniWrite("yes", PROFILES_DIR "\" CURRENT_PROFILE_ID "\consent.ini", "Consent", "privacy_accepted")
    WriteLog("privacy_accepted", CURRENT_PROFILE_ID)
    WriteProfileLog(CURRENT_PROFILE_ID, "privacy_accepted")
    RenderScreen("start_here")
}

BuildStartHere() {
    global CURRENT_DISPLAY_NAME
    g := NewFormGui()
    AddFormTitle(g, TIcon("start_title"))
    AddFormGap(g, 6)
    AddFormBodyText(g, T("start_welcome"))
    AddFormGap(g, 4)
    AddFormBodyText(g, T("start_profile", CURRENT_DISPLAY_NAME))
    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_launch"), StartHereLaunch)
    AddFormNavBackQuit(g, (*) => RenderScreen("profile"))
    ShowFormGui()
}

StartHereLaunch(*) {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        RenderScreen("profile")
        return
    }
    IniWrite("yes", PROFILES_DIR "\" CURRENT_PROFILE_ID "\state.ini", "State", "onboarding_completed")
    WriteLog("onboarding_completed", CURRENT_PROFILE_ID)
    WriteProfileLog(CURRENT_PROFILE_ID, "onboarding_completed")
    RenderScreen("home")
}

BuildKitPrima() {
    global CURRENT_PROFILE_ID, KIT_AI_DDL, KIT_STATUS_TEXT, KIT_LAST_CHECKS, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    if (CURRENT_PROFILE_ID = "")
        return
    g := NewFormGui()
    AddFormTitle(g, TIcon("kit_title"))
    AddFormGap(g, 4)
    AddFormBodyText(g, T("kit_body"))
    AddFormGap(g, 6)
    AddFormLabel(g, T("kit_ai_label"))
    KIT_AI_DDL := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, GetKitAiLabels())
    KIT_AI_DDL.Choose(KitAiIndexForValue(LoadKitSelectedAi(CURRENT_PROFILE_ID)))
    AddFormGap(g, 6)
    AddFormLabel(g, T("kit_checks_label"))
    KIT_LAST_CHECKS := RunKitChecks()
    KIT_STATUS_TEXT := g.Add("Edit", "w" FORM_FIELD_W " h92 ReadOnly Multi Background" CLR_PANEL " c" CLR_TEXT, FormatKitStatusText(KIT_LAST_CHECKS))
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("btn_kit_verify"), KitVerify)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_kit_create"), KitCreateMissing)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_save"), KitSave)
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("btn_back"), KitBack)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    WriteLog("kit_opened", CURRENT_PROFILE_ID)
    ShowFormGui()
}

BuildHome() {
    global CURRENT_DISPLAY_NAME, APP_VERSION, CURRENT_PROFILE_ID
    g := NewFormGui()
    AddFormTitle(g, TIcon("home_title"))
    AddFormGap(g, 4)
    AddFormBodyText(g, T("home_active", CURRENT_DISPLAY_NAME))
    AddFormBodyText(g, T("home_version", APP_VERSION))
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("base_kit_prima"), OpenKitFromHome)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("base_prima_soul"), HomeOpenPrimaSoulIntro)
    AddFormGap(g, 4)
    AddFormButton(g, T("btn_proof"), ShowModuleLater)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_review"), HomeOpenReview)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_settings"), HomeOpenSettings)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_change_profile"), HomeChangeProfile)
    WriteLog("app_home_opened", CURRENT_PROFILE_ID)
    ShowFormGui()
}

BuildCreatorHome() {
    global CURRENT_PROFILE_ID
    g := NewFormGui()
    AddFormTitle(g, T("creator_home_title"))
    AddFormGap(g, 4)
    AddFormBodyText(g, T("creator_home_body"))
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("base_kit_prima"), OpenKitFromCreator)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("base_prima_soul"), CreatorOpenSoul)
    AddFormGap(g, 4)
    AddFormButton(g, T("btn_creator_personalization"), ShowCreatorModuleLater)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_creator_goal"), CreatorOpenGoals)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_review"), CreatorOpenReview)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_change_profile"), HomeChangeProfile)
    WriteLog("creator_home_opened", CURRENT_PROFILE_ID)
    ShowFormGui()
}

BuildCreatorSoul() {
    global PRIMA_SOUL_BACK
    PRIMA_SOUL_BACK := "creator_home"
    RenderScreen("prima_soul_intro")
}

GoalsDomainChange(*) {
    global GOALS_DOMAIN_DDL, GOALS_DOMAIN_IDX, GOAL_SHORT, GOAL_MEDIUM, GOAL_LONG, CURRENT_PROFILE_ID
    prevCode := GetDomainCodes()[GOALS_DOMAIN_IDX]
    SaveDomainGoals(CURRENT_PROFILE_ID, prevCode, GOAL_SHORT.Value, GOAL_MEDIUM.Value, GOAL_LONG.Value)
    GOALS_DOMAIN_IDX := GOALS_DOMAIN_DDL.Value
    RenderScreen("onboarding_goals")
}

OnboardingDomainSave(*) {
    global CURRENT_PROFILE_ID, GOALS_DOMAIN_DDL, GOAL_SHORT, GOAL_MEDIUM, GOAL_LONG, GOALS_DOMAIN_IDX
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        return
    }
    code := GetDomainCodes()[GOALS_DOMAIN_IDX]
    data := LoadDomainGoals(CURRENT_PROFILE_ID, code)
    wasConfigured := DomainHasGoals(data)
    newData := { short: GOAL_SHORT.Value, medium: GOAL_MEDIUM.Value, long: GOAL_LONG.Value }
    if (!wasConfigured && DomainHasGoals(newData) && CountConfiguredDomains(CURRENT_PROFILE_ID) >= 5) {
        MsgBox(T("msg_goals_max_domains"), APP_TITLE, "Icon!")
        return
    }
    SaveDomainGoals(CURRENT_PROFILE_ID, code, GOAL_SHORT.Value, GOAL_MEDIUM.Value, GOAL_LONG.Value)
}

ShowModuleLater(*) {
    MsgBox(T("msg_module_later"), APP_TITLE, "Icon!")
}

; ── Hub PRIMA Soul — grille 2×2 (position absolue, tient dans 1050×760) ────────
SoulHubGridX(col) {
    global MARGIN_X, CONTENT_W, SOUL_HUB_CARD_W, SOUL_HUB_GAP
    gridW := 2 * SOUL_HUB_CARD_W + SOUL_HUB_GAP
    startX := MARGIN_X + (CONTENT_W - gridW) // 2
    return startX + (col - 1) * (SOUL_HUB_CARD_W + SOUL_HUB_GAP)
}

SoulHubGridY(row) {
    global SOUL_HUB_GRID_Y, SOUL_HUB_CARD_H, SOUL_HUB_GAP
    return SOUL_HUB_GRID_Y + (row - 1) * (SOUL_HUB_CARD_H + SOUL_HUB_GAP)
}

AddSoulHubHeader(g, title, intro) {
    global MARGIN_X, CONTENT_W, SOUL_HUB_TITLE_Y, SOUL_HUB_INTRO_Y, CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT
    g.SetFont("s22 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" SOUL_HUB_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG, title)
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" SOUL_HUB_INTRO_Y " w" CONTENT_W " h44 Center +0x2000 Background" CLR_BG, intro)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

; Carte hub : titre (icône) + statut court, clic sur toute la carte.
AddSoulHubCard(g, col, row, title, status, action, enabled := true) {
    global SOUL_HUB_CARD_W, SOUL_HUB_CARD_H
    x := SoulHubGridX(col)
    y := SoulHubGridY(row)
    if (Trim(title) = "")
        title := "—"
    label := (Trim(status) != "") ? title "`n" status : title
    btn := g.Add("Button", "x" x " y" y " w" SOUL_HUB_CARD_W " h" SOUL_HUB_CARD_H " +0x2000 Center", label)
    btn.SetFont("s11")
    if (action != "")
        btn.OnEvent("Click", action)
    if (!enabled)
        btn.Enabled := false
    return btn
}

; Bouton pleine largeur hub (2 colonnes) — ex. reset cycle.
AddSoulHubWideButton(g, row, label, action) {
    global SOUL_HUB_CARD_W, SOUL_HUB_GAP, SOUL_HUB_CARD_H
    x := SoulHubGridX(1)
    y := SoulHubGridY(row)
    w := 2 * SOUL_HUB_CARD_W + SOUL_HUB_GAP
    if (Trim(label) = "")
        label := "—"
    btn := g.Add("Button", "x" x " y" y " w" w " h" SOUL_HUB_CARD_H " Center", label)
    btn.SetFont("s11")
    btn.OnEvent("Click", action)
    return btn
}

; Carte hub à y absolu (hub cycle terminé).
AddSoulHubCardAt(g, col, y, title, status, action) {
    global SOUL_HUB_CARD_W, SOUL_HUB_CARD_H
    x := SoulHubGridX(col)
    if (Trim(title) = "")
        title := "—"
    label := (Trim(status) != "") ? title "`n" status : title
    btn := g.Add("Button", "x" x " y" y " w" SOUL_HUB_CARD_W " h" SOUL_HUB_CARD_H " +0x2000 Center", label)
    btn.SetFont("s11")
    if (action != "")
        btn.OnEvent("Click", action)
    return btn
}

; Bouton pleine largeur à y absolu.
AddSoulHubWideButtonAt(g, y, label, action) {
    global SOUL_HUB_CARD_W, SOUL_HUB_GAP, SOUL_HUB_CARD_H
    x := SoulHubGridX(1)
    w := 2 * SOUL_HUB_CARD_W + SOUL_HUB_GAP
    if (Trim(label) = "")
        label := "—"
    btn := g.Add("Button", "x" x " y" y " w" w " h" SOUL_HUB_CARD_H " Center", label)
    btn.SetFont("s11")
    btn.OnEvent("Click", action)
    return btn
}

; En-tête écran lancement test (positions fixes).
AddLaunchScreenHeader(g, title, introLine1, introLine2 := "") {
    global MARGIN_X, CONTENT_W, LAUNCH_TITLE_Y, LAUNCH_INTRO_Y, LAUNCH_INTRO_H
    global CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT
    g.SetFont("s20 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" LAUNCH_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG, title)
    intro := introLine1
    if (introLine2 != "")
        intro .= "`n" introLine2
    g.SetFont("s11 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" LAUNCH_INTRO_Y " w" CONTENT_W " h" LAUNCH_INTRO_H " Center +0x2000 Background" CLR_BG, intro)
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

; Action principale écran lancement (Débuter / Test terminé).
AddLaunchMainAction(g, label, action, enabled := true) {
    global MARGIN_X, CONTENT_W, LAUNCH_ACTION_Y, LAUNCH_ACTION_W, LAUNCH_ACTION_H
    x := MARGIN_X + (CONTENT_W - LAUNCH_ACTION_W) // 2
    if (Trim(label) = "")
        label := "—"
    btn := g.Add("Button", "x" x " y" LAUNCH_ACTION_Y " w" LAUNCH_ACTION_W " h" LAUNCH_ACTION_H " Center", label)
    btn.SetFont("s12")
    if (action != "")
        btn.OnEvent("Click", action)
    if (!enabled)
        btn.Enabled := false
    return btn
}

; Pied lancement test : Retour | Quitter (fixe y=650).
AddLaunchFooter(g, backAction) {
    global MARGIN_X, CONTENT_W, LAUNCH_NAV_Y, TEST_NAV_BTN_W, TEST_NAV_GAP, BUTTON_H
    totalW := 2 * TEST_NAV_BTN_W + TEST_NAV_GAP
    startX := MARGIN_X + (CONTENT_W - totalW) // 2
    btnBack := g.Add("Button", "x" startX " y" LAUNCH_NAV_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_back"))
    btnBack.OnEvent("Click", backAction)
    xQuit := startX + TEST_NAV_BTN_W + TEST_NAV_GAP
    btnQuit := g.Add("Button", "x" xQuit " y" LAUNCH_NAV_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_quit"))
    btnQuit.OnEvent("Click", (*) => ConfirmExit("quit"))
}

ShowTestAlreadyDone(*) {
    MsgBox(SoulTestDoneMessage(), APP_TITLE, "Iconi")
}

ShowReadingNotReady(*) {
    MsgBox(T("soul_reading_wait"), APP_TITLE, "Iconi")
}

; Message clic test terminé — adapté si le cycle est déjà complet.
SoulTestDoneMessage() {
    global CURRENT_PROFILE_ID
    msg := T("msg_test_locked_1")
    if (CURRENT_PROFILE_ID != "" && IsPrimaSoulCycleComplete(CURRENT_PROFILE_ID))
        return msg "`n`n" T("msg_test_done_use_reading")
    return msg "`n`n" T("msg_test_locked_2")
}

; Pied hub cycle terminé : Retour · Quitter (2 boutons).
AddSoulHubFooterBackQuit(g, backAction) {
    global SOUL_HUB_FOOTER_Y, TEST_NAV_BTN_W, TEST_NAV_GAP, BUTTON_H, MARGIN_X, CONTENT_W
    totalW := 2 * TEST_NAV_BTN_W + TEST_NAV_GAP
    startX := MARGIN_X + (CONTENT_W - totalW) // 2
    btnBack := g.Add("Button", "x" startX " y" SOUL_HUB_FOOTER_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_back"))
    btnBack.OnEvent("Click", backAction)
    xQuit := startX + TEST_NAV_BTN_W + TEST_NAV_GAP
    btnQuit := g.Add("Button", "x" xQuit " y" SOUL_HUB_FOOTER_Y " w" TEST_NAV_BTN_W " h" BUTTON_H " Center", TIcon("btn_quit"))
    btnQuit.OnEvent("Click", (*) => ConfirmExit("quit"))
}

; Pied de page compact : Retour · Réglages · Quitter (3 boutons alignés).
AddSoulHubFooter(g, backAction) {
    global SOUL_HUB_FOOTER_Y, SOUL_HUB_FOOTER_BTN_W, SOUL_HUB_GAP, BUTTON_H, MARGIN_X, CONTENT_W
    gridW := 3 * SOUL_HUB_FOOTER_BTN_W + 2 * SOUL_HUB_GAP
    startX := MARGIN_X + (CONTENT_W - gridW) // 2
    xBack := startX
    xSet := startX + SOUL_HUB_FOOTER_BTN_W + SOUL_HUB_GAP
    xQuit := startX + 2 * (SOUL_HUB_FOOTER_BTN_W + SOUL_HUB_GAP)
    btnBack := g.Add("Button", "x" xBack " y" SOUL_HUB_FOOTER_Y " w" SOUL_HUB_FOOTER_BTN_W " h" BUTTON_H " Center", TIcon("btn_back"))
    btnBack.OnEvent("Click", backAction)
    btnSet := g.Add("Button", "x" xSet " y" SOUL_HUB_FOOTER_Y " w" SOUL_HUB_FOOTER_BTN_W " h" BUTTON_H " Center", TIcon("btn_soul_settings"))
    btnSet.OnEvent("Click", (*) => RenderScreen("prima_soul_settings"))
    btnQuit := g.Add("Button", "x" xQuit " y" SOUL_HUB_FOOTER_Y " w" SOUL_HUB_FOOTER_BTN_W " h" BUTTON_H " Center", TIcon("btn_quit"))
    btnQuit.OnEvent("Click", (*) => ConfirmExit("quit"))
}

; ── Hub lecture PRIMA — grille 2×4 (position absolue, tient dans 1050×760) ─────
ReadingHubGridX(col) {
    global MARGIN_X, CONTENT_W, READING_HUB_BTN_W, READING_HUB_GAP_X
    gridW := 2 * READING_HUB_BTN_W + READING_HUB_GAP_X
    startX := MARGIN_X + (CONTENT_W - gridW) // 2
    return startX + (col - 1) * (READING_HUB_BTN_W + READING_HUB_GAP_X)
}

ReadingHubGridY(row) {
    global READING_HUB_GRID_Y, READING_HUB_BTN_H, READING_HUB_GAP_Y
    return READING_HUB_GRID_Y + (row - 1) * (READING_HUB_BTN_H + READING_HUB_GAP_Y)
}

AddReadingHubHeader(g, title, introLine1, introLine2 := "") {
    global MARGIN_X, CONTENT_W, READING_HUB_TITLE_Y, READING_HUB_INTRO_Y, READING_HUB_INTRO_H
    global READING_HUB_BTN_W, READING_HUB_GAP_X, READING_HUB_GRID_Y
    global CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT, CLR_PANEL
    g.SetFont("s20 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" READING_HUB_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG, title)
    intro := introLine1
    if (introLine2 != "")
        intro .= "`n" introLine2
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" READING_HUB_INTRO_Y " w" CONTENT_W " h" READING_HUB_INTRO_H " Center +0x2000 Background" CLR_BG, intro)
    ax := ReadingHubGridX(1)
    gridW := 2 * READING_HUB_BTN_W + READING_HUB_GAP_X
    g.Add("Text", "x" ax " y" (READING_HUB_GRID_Y - 10) " w" gridW " h1 Background" CLR_PANEL, "")
    g.SetFont("s12 c" CLR_TEXT, "Segoe UI")
}

AddReadingHubButton(g, col, row, label, action) {
    global READING_HUB_BTN_W, READING_HUB_BTN_H
    x := ReadingHubGridX(col)
    y := ReadingHubGridY(row)
    btn := g.Add("Button", "x" x " y" y " w" READING_HUB_BTN_W " h" READING_HUB_BTN_H " Center", label)
    btn.OnEvent("Click", action)
    return btn
}

; Écran fin de test simple — pas de résultat détaillé (lecture via hub global).
BuildPrimaTestDoneScreen(titleKey) {
    global MARGIN_X, CONTENT_W, BUTTON_H, CLR_BG, CLR_ACCENT, CLR_TEXT, CLR_SUBTEXT, CLR_PANEL
    g := NewGui()
    cardW := 680
    cardX := MARGIN_X + (CONTENT_W - cardW) // 2
    cardY := 130
    g.Add("Text", "x" cardX " y" cardY " w" cardW " h200 Background" CLR_PANEL, "")
    g.SetFont("s20 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" cardX " y" (cardY + 24) " w" cardW " h36 Center BackgroundTrans", TIcon(titleKey))
    g.SetFont("s13 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "x" cardX " y" (cardY + 68) " w" cardW " h28 Center BackgroundTrans", T("vda_done_1"))
    g.SetFont("s11 c" CLR_TEXT, "Segoe UI")
    g.Add("Text", "x" (cardX + 36) " y" (cardY + 100) " w" (cardW - 72) " h48 Center +0x2000 BackgroundTrans", T("vda_done_reading"))
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" cardX " y" (cardY + 156) " w" cardW " h22 Center BackgroundTrans", T("prima_soul_guide"))
    btnW := 320
    btnX := MARGIN_X + (CONTENT_W - btnW) // 2
    btnY := cardY + 230
    btnBack := g.Add("Button", "x" btnX " y" btnY " w" btnW " h" BUTTON_H " Center", TIcon("btn_back_soul"))
    btnBack.OnEvent("Click", (*) => RenderScreen("prima_soul_intro"))
    btnQuit := g.Add("Button", "x" btnX " y" (btnY + BUTTON_H + 10) " w" btnW " h" BUTTON_H " Center", TIcon("btn_quit"))
    btnQuit.OnEvent("Click", (*) => ConfirmExit("quit"))
    ShowScreen()
}

ShowCreatorModuleLater(*) {
    MsgBox(T("msg_creator_module_later"), APP_TITLE, "Icon!")
}

; ── PRIMA Soul — hub (1050×760) ───────────────────────────────────────────────
BuildPrimaSoulIntro() {
    global CURRENT_PROFILE_ID
    cycleComplete := (CURRENT_PROFILE_ID != "" && IsPrimaSoulCycleComplete(CURRENT_PROFILE_ID))
    WriteLog("soul_hub_mode", CURRENT_PROFILE_ID " | " (cycleComplete ? "complete" : "in_progress"))
    if (cycleComplete)
        BuildPrimaSoulIntroComplete()
    else
        BuildPrimaSoulIntroInProgress()
}

; Hub cycle terminé : actions de suite (lecture, univers, reset).
BuildPrimaSoulIntroComplete() {
    global CURRENT_PROFILE_ID, MARGIN_X, CONTENT_W, CLR_BG, CLR_ACCENT, CLR_SUBTEXT, CLR_TEXT
    global SOUL_HUB_COMPLETE_GRID_Y, SOUL_HUB_CARD_H, SOUL_HUB_GAP, SOUL_HUB_TESTS_STATUS_Y
    g := NewGui()
    g.SetFont("s22 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" SOUL_HUB_TITLE_Y " w" CONTENT_W " h36 Center Background" CLR_BG
        , TIcon("prima_soul_complete_title"))
    g.SetFont("s12 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y88 w" CONTENT_W " h28 Center Background" CLR_BG, T("soul_cycle_complete_status"))
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y118 w" CONTENT_W " h40 Center +0x2000 Background" CLR_BG, T("soul_cycle_complete_hint"))
    yActions := SOUL_HUB_COMPLETE_GRID_Y
    yReset := yActions + SOUL_HUB_CARD_H + SOUL_HUB_GAP
    AddSoulHubCardAt(g, 1, yActions, TIcon("btn_generate_reading"), T("soul_status_ready"), OpenSoulReadingHub)
    AddSoulHubCardAt(g, 2, yActions, TIcon("btn_choose_universe"), "", OpenPrimaUniverseChoice)
    AddSoulHubWideButtonAt(g, yReset, TIcon("btn_redo_tests"), SoulRedoTestsClicked)
    g.SetFont("s10 c" CLR_SUBTEXT, "Segoe UI")
    ty := SOUL_HUB_TESTS_STATUS_Y
    g.Add("Text", "x" MARGIN_X " y" ty " w" CONTENT_W " h22 Center Background" CLR_BG, TIcon("btn_soul_test_done"))
    g.Add("Text", "x" MARGIN_X " y" (ty + 24) " w" CONTENT_W " h22 Center Background" CLR_BG, TIcon("btn_vda_test_done"))
    g.Add("Text", "x" MARGIN_X " y" (ty + 48) " w" CONTENT_W " h22 Center Background" CLR_BG, TIcon("btn_shadow_test_done"))
    AddSoulHubFooterBackQuit(g, PrimaSoulBackToHome)
    WriteLog("soul_global_reading_available", CURRENT_PROFILE_ID)
    ShowScreen()
}

; Hub en cours : grille 2×2 tests + lecture + reset partiel.
BuildPrimaSoulIntroInProgress() {
    global CURRENT_PROFILE_ID
    g := NewGui()
    AddSoulHubHeader(g, TIcon("prima_soul_intro_title"), T("prima_soul_guide"))
    soulDone := (CURRENT_PROFILE_ID != "" && IsSoulTestCompleted(CURRENT_PROFILE_ID, "prima_soul"))
    vdaDone := (CURRENT_PROFILE_ID != "" && IsSoulTestCompleted(CURRENT_PROFILE_ID, "prima_vda"))
    shadowDone := (CURRENT_PROFILE_ID != "" && IsSoulTestCompleted(CURRENT_PROFILE_ID, "prima_shadow"))
    allDone := soulDone && vdaDone && shadowDone
    anyDone := soulDone || vdaDone || shadowDone
    if (allDone) {
        BuildPrimaSoulIntroComplete()
        return
    }
    if (soulDone) {
        AddSoulHubCard(g, 1, 1, TIcon("btn_soul_test_done"), T("soul_status_done"), ShowTestAlreadyDone)
    } else {
        AddSoulHubCard(g, 1, 1, PrimaLabelWithIcon("soul_test_soul", "PRIMA Soul")
            , T("soul_status_available"), OpenSoulTestFromHub)
    }
    if (vdaDone) {
        AddSoulHubCard(g, 2, 1, TIcon("btn_vda_test_done"), T("soul_status_done"), ShowTestAlreadyDone)
    } else {
        AddSoulHubCard(g, 2, 1, PrimaLabelWithIcon("soul_test_vda", "PRIMA VDA")
            , T("soul_status_available"), OpenVdaFromSoulHub)
    }
    if (shadowDone) {
        AddSoulHubCard(g, 1, 2, TIcon("btn_shadow_test_done"), T("soul_status_done"), ShowTestAlreadyDone)
    } else {
        AddSoulHubCard(g, 1, 2, PrimaLabelWithIcon("soul_test_shadow", "PRIMA Shadow")
            , T("soul_status_available"), (*) => RenderScreen("prima_soul_shadow"))
    }
    AddSoulHubCard(g, 2, 2, TIcon("btn_generate_reading"), T("soul_reading_wait"), ShowReadingNotReady)
    if (anyDone)
        AddSoulHubWideButton(g, 3, TIcon("btn_redo_tests"), SoulRedoTestsClicked)
    AddSoulHubFooter(g, PrimaSoulBackToHome)
    ShowScreen()
}

; ── Lancement des tests ───────────────────────────────────────────────────────
; Clic sur un test verrouillé : message sobre, pas de relance.
ShowSoulTestLocked(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_test_click_locked", CURRENT_PROFILE_ID)
    MsgBox(SoulTestDoneMessage(), APP_TITLE, "Icon!")
}

; PRIMA Soul Test = test 15 situations (banque prima_soul).
; Verrou technique : aucun lancement, aucune nouvelle session, aucune écriture
; de soul_state.ini / soul_results.ini si le test est verrouillé.
StartSoulTestRun(*) {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (!CanStartSoulTest("prima_soul")) {
        WriteLog("soul_test_start_blocked", CURRENT_PROFILE_ID " | prima_soul")
        ShowSoulTestLocked()
        return
    }
    session := BuildSoulQuestionRun("prima_soul", 15)
    if (session = "") {
        MsgBox(T("msg_run_preparing"), APP_TITLE, "Icon!")
        return
    }
    SOUL_SESSION := session
    WriteLog("soul_run_started", "prima_soul | 15")
    WriteLog("soul_answers_shuffled", "prima_soul | " session.questions.Length)
    SaveSoulSessionState()
    RenderScreen("prima_soul_question")
}

; Clic sur un test VDA verrouillé.
ShowVdaTestLocked(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_test_click_locked", CURRENT_PROFILE_ID " | prima_vda")
    MsgBox(SoulTestDoneMessage(), APP_TITLE, "Icon!")
}

; PRIMA VDA Test : lance le test de classement (20 questions).
StartSoulVdaRun(*) {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (!CanStartSoulTest("prima_vda")) {
        WriteLog("soul_test_start_blocked", CURRENT_PROFILE_ID " | prima_vda")
        ShowVdaTestLocked()
        return
    }
    session := BuildVdaQuestionRun(20)
    if (session = "") {
        MsgBox(T("msg_run_preparing"), APP_TITLE, "Icon!")
        return
    }
    SOUL_SESSION := session
    WriteLog("vda_test_started", "prima_vda | 20")
    SaveVdaSessionState()
    RenderScreen("prima_vda_rank")
}

; ── PRIMA VDA — lecteur de classement (6 réponses, rangs 1 à 6) ───────────────
global VDARANK_PICKS := []
global VDARANK_ANSWER_BTNS := []

BuildPrimaVdaRankQuestion() {
    global SOUL_SESSION, VDARANK_PICKS, VDARANK_ANSWER_BTNS
    if (SOUL_SESSION = "" || SOUL_SESSION.active_path != "prima_vda" || SOUL_SESSION.completed) {
        RenderScreen("prima_soul_intro")
        return
    }
    q := SOUL_SESSION.questions[SOUL_SESSION.current_index]
    VDARANK_PICKS := []
    VDARANK_ANSWER_BTNS := []
    g := NewGui()
    rankHint := TIcon("msg_rank_all") " — " T("vda_rank_hint_top") " · " T("vda_rank_hint_bottom")
    AddTestQuestionHeader(g, TIcon("vda_test_title")
        , TIcon("vda_question_of", SOUL_SESSION.current_index, SOUL_SESSION.questions.Length)
        , q.prompt, rankHint)
    texts := []
    for a in q.answers
        texts.Push(a.text)
    VDARANK_ANSWER_BTNS := AddTestAnswerButtons(g, texts, VdaRankAnswerClick)
    AddFixedTestNav(g, VdaRankNextQuestion, VDARANK_ANSWER_BTNS.navY)
    ShowScreen()
}

; Clic = assigne le prochain rang disponible ; re-clic = retire le rang
; et l'ordre restant est recalculé proprement.
VdaRankAnswerClick(idx, *) {
    global VDARANK_PICKS
    pos := 0
    for i, v in VDARANK_PICKS {
        if (v = idx)
            pos := i
    }
    if (pos) {
        VDARANK_PICKS.RemoveAt(pos)
    } else {
        if (VDARANK_PICKS.Length >= 6)
            return
        VDARANK_PICKS.Push(idx)
    }
    VdaRankRefreshLabels()
}

VdaRankRefreshLabels() {
    global VDARANK_PICKS, VDARANK_ANSWER_BTNS, SOUL_SESSION
    q := SOUL_SESSION.questions[SOUL_SESSION.current_index]
    for i, btn in VDARANK_ANSWER_BTNS {
        prefix := ""
        selected := false
        for p, v in VDARANK_PICKS {
            if (v = i) {
                prefix := PrimaRankPrefix(p)
                selected := true
            }
        }
        ApplyTestAnswerPickStyle(btn, prefix, q.answers[i].text, selected)
    }
}

VdaRankNextQuestion(*) {
    global SOUL_SESSION, VDARANK_PICKS, CURRENT_PROFILE_ID
    if (SOUL_SESSION = "" || SOUL_SESSION.completed) {
        RenderScreen("prima_soul_intro")
        return
    }
    q := SOUL_SESSION.questions[SOUL_SESSION.current_index]
    ranks := []
    for v in VDARANK_PICKS
        ranks.Push(q.answers[v].id)
    errKey := ValidatePcmRanking(ranks)
    if (errKey != "") {
        MsgBox(T(errKey), APP_TITLE, "Icon!")
        return
    }
    VdaSessionRecordRanking(SOUL_SESSION, q.id, ranks)
    WriteLog("vda_question_ranked", q.id)
    SaveVdaSessionState()
    if (SOUL_SESSION.completed) {
        WriteLog("vda_test_completed", CURRENT_PROFILE_ID " | " SOUL_SESSION.rankings.Length)
        if (CURRENT_PROFILE_ID != "") {
            MarkSoulTestCompleted(CURRENT_PROFILE_ID, "prima_vda")
            WriteLog("vda_test_locked", CURRENT_PROFILE_ID)
            totals := ComputePcmRankingScores(SOUL_SESSION)
            baseScores := ComputeVdaBaseScores(SOUL_SESSION)
            phaseScores := ComputeVdaPhaseScores(SOUL_SESSION)
            SaveVdaTestResult(CURRENT_PROFILE_ID, totals, baseScores, phaseScores)
        }
        RenderScreen("prima_vda_rank_done")
    } else {
        RenderScreen("prima_vda_rank")
    }
}

; Fin VDA : pas de résultat détaillé immédiat.
BuildPrimaVdaRankDone() {
    BuildPrimaTestDoneScreen("vda_test_title")
}

OpenSoulTestFromHub(*) {
    global SOUL_TEST_BACK_SCREEN
    SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
    RenderScreen("prima_soul_test")
}

CreatorOpenSoulTest(*) {
    global SOUL_TEST_BACK_SCREEN
    SOUL_TEST_BACK_SCREEN := "prima_soul_intro"
    RenderScreen("prima_soul_test")
}

OpenVdaFromSoulHub(*) {
    global VDA_BACK_SCREEN
    VDA_BACK_SCREEN := "prima_soul_intro"
    RenderScreen("prima_soul_vda")
}

CreatorOpenVdaTest(*) {
    global VDA_BACK_SCREEN
    VDA_BACK_SCREEN := "prima_soul_intro"
    RenderScreen("prima_soul_vda")
}

; Écran de lancement PRIMA Soul Test (test 15 situations).
BuildPrimaSoulTest() {
    global CURRENT_PROFILE_ID, SOUL_TEST_BACK_SCREEN
    g := NewGui()
    done := (CURRENT_PROFILE_ID != "" && IsSoulTestCompleted(CURRENT_PROFILE_ID, "prima_soul"))
    AddLaunchScreenHeader(g, TIcon("soul_test_title"), T("vda_count"), T("vda_line1"))
    if (done)
        AddLaunchMainAction(g, TIcon("btn_soul_test_done"), ShowTestAlreadyDone)
    else
        AddLaunchMainAction(g, TIcon("btn_start"), StartSoulTestRun)
    AddLaunchFooter(g, (*) => RenderScreen(SOUL_TEST_BACK_SCREEN))
    ShowScreen()
}

; Écran de lancement PRIMA VDA Test.
BuildPrimaSoulVda() {
    global CURRENT_PROFILE_ID, VDA_BACK_SCREEN
    g := NewGui()
    done := (CURRENT_PROFILE_ID != "" && IsSoulTestCompleted(CURRENT_PROFILE_ID, "prima_vda"))
    AddLaunchScreenHeader(g, TIcon("vda_test_title"), T("vda_intro_1"), T("vda_intro_2"))
    if (done)
        AddLaunchMainAction(g, TIcon("btn_vda_test_done"), ShowTestAlreadyDone)
    else
        AddLaunchMainAction(g, TIcon("btn_start"), StartSoulVdaRun)
    AddLaunchFooter(g, (*) => RenderScreen(VDA_BACK_SCREEN))
    ShowScreen()
}

; Écran de lancement PRIMA Shadow Test.
BuildPrimaSoulShadow() {
    global CURRENT_PROFILE_ID
    g := NewGui()
    done := (CURRENT_PROFILE_ID != "" && IsSoulTestCompleted(CURRENT_PROFILE_ID, "prima_shadow"))
    AddLaunchScreenHeader(g, TIcon("shadow_test_title"), T("shadow_intro_1"), T("shadow_intro_2"))
    if (done)
        AddLaunchMainAction(g, TIcon("btn_shadow_test_done"), ShowTestAlreadyDone)
    else
        AddLaunchMainAction(g, TIcon("btn_start"), StartShadowTestRun)
    AddLaunchFooter(g, (*) => RenderScreen("prima_soul_intro"))
    ShowScreen()
}

; Clic sur un test Shadow verrouillé.
ShowShadowTestLocked(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_test_click_locked", CURRENT_PROFILE_ID " | prima_shadow")
    MsgBox(SoulTestDoneMessage(), APP_TITLE, "Icon!")
}

StartShadowTestRun(*) {
    global SOUL_SESSION, CURRENT_PROFILE_ID
    if (!CanStartSoulTest("prima_shadow")) {
        WriteLog("soul_test_start_blocked", CURRENT_PROFILE_ID " | prima_shadow")
        ShowShadowTestLocked()
        return
    }
    session := BuildShadowQuestionRun(15)
    if (session = "") {
        MsgBox(T("msg_run_preparing"), APP_TITLE, "Icon!")
        return
    }
    SOUL_SESSION := session
    WriteLog("shadow_test_started", "prima_shadow | 15")
    SaveShadowSessionState()
    RenderScreen("prima_shadow_question")
}

; ── PRIMA Shadow — lecteur de questions (choix 1-2) ───────────────────────────
global SHADOW_PICKS := []
global SHADOW_ANSWER_BTNS := []

BuildPrimaShadowQuestion() {
    global SOUL_SESSION, SHADOW_PICKS, SHADOW_ANSWER_BTNS
    if (SOUL_SESSION = "" || SOUL_SESSION.active_path != "prima_shadow" || SOUL_SESSION.completed) {
        RenderScreen("prima_soul_intro")
        return
    }
    q := SOUL_SESSION.questions[SOUL_SESSION.current_index]
    SHADOW_PICKS := []
    SHADOW_ANSWER_BTNS := []
    g := NewGui()
    AddTestQuestionHeader(g, TIcon("shadow_test_title")
        , TIcon("vda_question_of", SOUL_SESSION.current_index, SOUL_SESSION.questions.Length)
        , q.prompt, TIcon("shadow_pick_hint"))
    texts := []
    for a in q.answers
        texts.Push(a.text)
    SHADOW_ANSWER_BTNS := AddTestAnswerButtons(g, texts, ShadowAnswerClick)
    AddFixedTestNav(g, ShadowNextQuestion, SHADOW_ANSWER_BTNS.navY)
    ShowScreen()
}

; Premier clic = priorité 1 (+2), deuxième clic = priorité 2 (+1).
; Re-cliquer une réponse choisie la retire.
ShadowAnswerClick(idx, *) {
    global SHADOW_PICKS
    pos := 0
    for i, v in SHADOW_PICKS {
        if (v = idx)
            pos := i
    }
    if (pos) {
        SHADOW_PICKS.RemoveAt(pos)
    } else {
        if (SHADOW_PICKS.Length >= 2) {
            MsgBox(T("msg_shadow_max"), APP_TITLE, "Icon!")
            return
        }
        SHADOW_PICKS.Push(idx)
    }
    ShadowRefreshAnswerLabels()
}

ShadowRefreshAnswerLabels() {
    global SHADOW_PICKS, SHADOW_ANSWER_BTNS, SOUL_SESSION
    q := SOUL_SESSION.questions[SOUL_SESSION.current_index]
    for i, btn in SHADOW_ANSWER_BTNS {
        prefix := ""
        selected := false
        for p, v in SHADOW_PICKS {
            if (v = i) {
                prefix := PrimaPriorityPrefix(p)
                selected := true
            }
        }
        ApplyTestAnswerPickStyle(btn, prefix, q.answers[i].text, selected)
    }
}

ShadowNextQuestion(*) {
    global SOUL_SESSION, SHADOW_PICKS, CURRENT_PROFILE_ID
    if (SOUL_SESSION = "" || SOUL_SESSION.completed) {
        RenderScreen("prima_soul_intro")
        return
    }
    q := SOUL_SESSION.questions[SOUL_SESSION.current_index]
    choices := []
    for v in SHADOW_PICKS
        choices.Push(q.answers[v].id)
    errKey := ValidateShadowChoices(choices)
    if (errKey != "") {
        MsgBox(T(errKey), APP_TITLE, "Icon!")
        return
    }
    selected1 := choices[1]
    selected2 := (choices.Length >= 2) ? choices[2] : ""
    SoulSessionRecordAnswer(SOUL_SESSION, q.id, selected1, selected2)
    SaveShadowSessionState()
    if (SOUL_SESSION.completed) {
        WriteLog("shadow_test_completed", CURRENT_PROFILE_ID " | " SOUL_SESSION.answers.Length)
        if (CURRENT_PROFILE_ID != "") {
            MarkSoulTestCompleted(CURRENT_PROFILE_ID, "prima_shadow")
            WriteLog("shadow_test_locked", CURRENT_PROFILE_ID)
            scores := ComputeShadowScores(SOUL_SESSION)
            SaveShadowTestResult(CURRENT_PROFILE_ID, scores)
        }
        RenderScreen("prima_shadow_done")
    } else {
        RenderScreen("prima_shadow_question")
    }
}

; Fin Shadow : pas de résultat détaillé immédiat.
BuildPrimaShadowDone() {
    BuildPrimaTestDoneScreen("shadow_test_title")
}

; ── Lecture globale PRIMA — hub résultats + écrans détail ─────────────────────
; Tout est formulé en pistes ("tes réponses suggèrent…"), jamais en vérité.
; Les clés internes (blessures, PCM, axes Shadow) ne sont jamais affichées :
; seuls les noms publics neutres apparaissent.

OpenSoulReadingHub(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_global_reading_opened", CURRENT_PROFILE_ID)
    RenderScreen("soul_reading_hub")
}

OpenPrimaUniverseChoice(*) {
    global CURRENT_PROFILE_ID, UNIVERSE_BACK_SCREEN, PRIMA_UNI_PAGE
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    PRIMA_UNI_PAGE := 1
    UNIVERSE_BACK_SCREEN := "prima_soul_intro"
    WriteLog("soul_universe_choice_from_hub", CURRENT_PROFILE_ID)
    RenderScreen("prima_universe_choice")
}

BuildSoulReadingHub() {
    global CURRENT_PROFILE_ID, MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    g := NewGui()
    AddScrollPageHeader(g, TIcon("reading_hub_title"), T("reading_hub_1"), T("reading_hub_2"))
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, SCROLL_VIEWPORT_H)
    AddReadingHubButtonScroll(cg, 1, 1, TIcon("btn_result_soul"), (*) => RenderScreen("soul_reading_soul"))
    AddReadingHubButtonScroll(cg, 2, 1, TIcon("btn_result_vda"), (*) => RenderScreen("soul_reading_vda"))
    AddReadingHubButtonScroll(cg, 1, 2, TIcon("btn_result_shadow"), (*) => RenderScreen("soul_reading_shadow"))
    AddReadingHubButtonScroll(cg, 2, 2, TIcon("btn_choose_universe"), SoulReadingUniverseClicked)
    AddReadingHubButtonScroll(cg, 1, 3, TIcon("btn_save_reading"), SoulReadingSaveClicked)
    AddReadingHubButtonScroll(cg, 2, 3, TIcon("btn_create_plan"), SoulReadingPlanClicked)
    AddReadingHubButtonScroll(cg, 1, 4, TIcon("btn_redo_tests"), SoulRedoTestsClicked)
    AddReadingHubButtonScroll(cg, 2, 4, TIcon("btn_back"), (*) => RenderScreen("prima_soul_intro"))
    ShowScreen()
}

; Boutons préparés : messages seulement, aucune action concrète pour l'instant.
SoulReadingSaveClicked(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_reading_saved_clicked", CURRENT_PROFILE_ID)
    MsgBox(T("msg_reading_saved"), APP_TITLE, "Iconi")
}

SoulReadingUniverseClicked(*) {
    global CURRENT_PROFILE_ID, UNIVERSE_BACK_SCREEN, PRIMA_UNI_PAGE
    WriteLog("soul_universe_choice_clicked", CURRENT_PROFILE_ID)
    PRIMA_UNI_PAGE := 1
    UNIVERSE_BACK_SCREEN := "soul_reading_hub"
    RenderScreen("prima_universe_choice")
}

SoulReadingPlanClicked(*) {
    global CURRENT_PROFILE_ID
    WriteLog("soul_plan_clicked", CURRENT_PROFILE_ID)
    MsgBox(T("msg_plan_later"), APP_TITLE, "Iconi")
}

; ── Helpers lecture : scores INI, top 2, jauge ─────────────────────────────────

; Lit une section de scores entiers depuis un fichier résultats.
ReadIniScoreMap(file, section, keys) {
    m := Map()
    for key in keys {
        v := IniRead(file, section, key, "0")
        m[key] := (v ~= "^\d+$") ? Integer(v) : 0
    }
    return m
}

; Renvoie les deux clés les plus fortes d'une Map de scores.
TopTwoScoreKeys(m, keys) {
    main := "", second := ""
    for key in keys {
        if (main = "" || m[key] > m[main])
            main := key
    }
    for key in keys {
        if (key = main)
            continue
        if (second = "" || m[key] > m[second])
            second := key
    }
    return { main: main, second: second }
}

; Jauge visuelle simple sur 5 blocs à partir d'un pourcentage 0-100.
SoulGaugeText(pct) {
    filled := Round(pct / 20)
    if (filled < 0)
        filled := 0
    if (filled > 5)
        filled := 5
    bar := ""
    loop 5
        bar .= (A_Index <= filled) ? "■" : "□"
    return bar
}

; ── Mapping public Soul (jamais les mots internes) ─────────────────────────────
SoulReadingName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "place"
            case "abandon":     return "bond"
            case "humiliation": return "personal need"
            case "trahison":    return "trust"
            case "injustice":   return "fairness"
        }
    } else {
        switch key {
            case "rejet":       return "place"
            case "abandon":     return "lien"
            case "humiliation": return "besoin personnel"
            case "trahison":    return "confiance"
            case "injustice":   return "justesse"
        }
    }
    return ""
}

; Besoin probable (section "Ce qui peut te nourrir").
SoulReadingNeed(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "Your answers suggest a need to feel welcome as you are."
            case "abandon":     return "Your answers suggest a need for a stable bond and presence."
            case "humiliation": return "Your answers suggest a need to express your needs without shame."
            case "trahison":    return "Your answers suggest a need for reliability and trust."
            case "injustice":   return "Your answers suggest a need for fairness and balance."
        }
    } else {
        switch key {
            case "rejet":       return "Tes réponses suggèrent un besoin de te sentir accueilli tel que tu es."
            case "abandon":     return "Tes réponses suggèrent un besoin de lien stable et de présence."
            case "humiliation": return "Tes réponses suggèrent un besoin d'exprimer tes besoins sans honte."
            case "trahison":    return "Tes réponses suggèrent un besoin de fiabilité et de confiance."
            case "injustice":   return "Tes réponses suggèrent un besoin de justesse et d'équilibre."
        }
    }
    return ""
}

; Comportement possible (formulation prudente).
SoulReadingBehavior(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "A possible lead: stepping back when you doubt being welcome."
            case "abandon":     return "A possible lead: seeking reassurance when the bond feels fragile."
            case "humiliation": return "A possible lead: taking too much on yourself so as not to bother."
            case "trahison":    return "A possible lead: checking or keeping control when doubt sets in."
            case "injustice":   return "A possible lead: aiming for perfect before feeling."
        }
    } else {
        switch key {
            case "rejet":       return "Une piste possible : te mettre en retrait quand tu doutes d'être bienvenu."
            case "abandon":     return "Une piste possible : chercher à être rassuré quand le lien semble fragile."
            case "humiliation": return "Une piste possible : prendre trop sur toi pour ne pas déranger."
            case "trahison":    return "Une piste possible : vérifier ou garder le contrôle quand le doute s'installe."
            case "injustice":   return "Une piste possible : viser le parfait avant de ressentir."
        }
    }
    return ""
}

; Sous pression (jamais de diagnostic).
SoulReadingPressure(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "rejet":       return "Under pressure, you may withdraw or isolate more than needed."
            case "abandon":     return "Under pressure, you may hold on to the bond or wait for a sign."
            case "humiliation": return "Under pressure, you may forget yourself and carry for others."
            case "trahison":    return "Under pressure, you may close up or want to control everything."
            case "injustice":   return "Under pressure, you may become cold, hard or very demanding."
        }
    } else {
        switch key {
            case "rejet":       return "Sous pression, tu peux te mettre à l'écart ou t'isoler plus que nécessaire."
            case "abandon":     return "Sous pression, tu peux t'accrocher au lien ou attendre un signe."
            case "humiliation": return "Sous pression, tu peux t'oublier et porter à la place des autres."
            case "trahison":    return "Sous pression, tu peux te fermer ou vouloir tout contrôler."
            case "injustice":   return "Sous pression, tu peux devenir froid, dur ou très exigeant."
        }
    }
    return ""
}

; ── Mapping public VDA (jamais de clé PCM, jamais "base/phase" en vérité) ──────
VdaReadingName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "structure"
            case "perseverant": return "meaning"
            case "empathique":  return "human bond"
            case "imagineur":   return "inner space"
            case "energiseur":  return "living energy"
            case "promoteur":   return "direct action"
        }
    } else {
        switch key {
            case "analyseur":   return "structure"
            case "perseverant": return "sens"
            case "empathique":  return "lien humain"
            case "imagineur":   return "espace intérieur"
            case "energiseur":  return "énergie vivante"
            case "promoteur":   return "action directe"
        }
    }
    return ""
}

; Besoin psychologique probable.
VdaReadingNeed(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "Your answers suggest a need for recognition of your work and clear time frames."
            case "perseverant": return "Your answers suggest a need for your convictions and commitment to be respected."
            case "empathique":  return "Your answers suggest a need to be welcomed as a person, with warmth."
            case "imagineur":   return "Your answers suggest a need for calm, space and clear instructions."
            case "energiseur":  return "Your answers suggest a need for playful contact and lightness."
            case "promoteur":   return "Your answers suggest a need for action, challenge and quick results."
        }
    } else {
        switch key {
            case "analyseur":   return "Tes réponses suggèrent un besoin que ton travail soit reconnu et que le temps soit structuré."
            case "perseverant": return "Tes réponses suggèrent un besoin que tes convictions et ton engagement soient respectés."
            case "empathique":  return "Tes réponses suggèrent un besoin d'être accueilli en tant que personne, avec chaleur."
            case "imagineur":   return "Tes réponses suggèrent un besoin de calme, d'espace et de consignes claires."
            case "energiseur":  return "Tes réponses suggèrent un besoin de contacts ludiques et de légèreté."
            case "promoteur":   return "Tes réponses suggèrent un besoin d'action, de défis et de résultats rapides."
        }
    }
    return ""
}

; Moyen de communication conseillé (piste, pas règle).
VdaReadingComm(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "A possible lead: clear, factual and structured exchanges."
            case "perseverant": return "A possible lead: sincere exchanges that respect your values."
            case "empathique":  return "A possible lead: warm, personal exchanges."
            case "imagineur":   return "A possible lead: simple requests, one thing at a time, without pressure."
            case "energiseur":  return "A possible lead: lively, spontaneous exchanges with humor."
            case "promoteur":   return "A possible lead: direct, short, action-oriented exchanges."
        }
    } else {
        switch key {
            case "analyseur":   return "Une piste possible : des échanges clairs, factuels et structurés."
            case "perseverant": return "Une piste possible : des échanges sincères qui respectent tes valeurs."
            case "empathique":  return "Une piste possible : des échanges chaleureux et personnels."
            case "imagineur":   return "Une piste possible : des demandes simples, une chose à la fois, sans pression."
            case "energiseur":  return "Une piste possible : des échanges vivants, spontanés, avec de l'humour."
            case "promoteur":   return "Une piste possible : des échanges directs, courts, orientés action."
        }
    }
    return ""
}

; Environnement qui peut nourrir.
VdaReadingEnv(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "An ordered setting where work is recognized can nourish you."
            case "perseverant": return "An environment consistent with your values can nourish you."
            case "empathique":  return "A warm, welcoming environment can nourish you."
            case "imagineur":   return "A calm space with time for yourself can nourish you."
            case "energiseur":  return "A stimulating, creative environment can nourish you."
            case "promoteur":   return "Movement, challenges and room to act can nourish you."
        }
    } else {
        switch key {
            case "analyseur":   return "Un cadre ordonné où le travail est reconnu peut te nourrir."
            case "perseverant": return "Un environnement cohérent avec tes valeurs peut te nourrir."
            case "empathique":  return "Un environnement chaleureux et accueillant peut te nourrir."
            case "imagineur":   return "Un espace calme avec du temps pour toi peut te nourrir."
            case "energiseur":  return "Un environnement stimulant et créatif peut te nourrir."
            case "promoteur":   return "Du mouvement, des défis et de la place pour agir peuvent te nourrir."
        }
    }
    return ""
}

; Sous pression (piste possible, jamais certitude).
VdaReadingPressure(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "analyseur":   return "Under pressure, you may over-control, over-detail or exhaust yourself in perfection."
            case "perseverant": return "Under pressure, you may judge, stiffen or want to convince at all costs."
            case "empathique":  return "Under pressure, you may over-adapt and forget yourself to be accepted."
            case "imagineur":   return "Under pressure, you may withdraw, disappear or postpone decisions."
            case "energiseur":  return "Under pressure, you may complain, provoke or shift the blame."
            case "promoteur":   return "Under pressure, you may force things, take risks or bend the frame."
        }
    } else {
        switch key {
            case "analyseur":   return "Sous pression, tu peux sur-contrôler, sur-détailler ou t'épuiser dans le parfait."
            case "perseverant": return "Sous pression, tu peux juger, te raidir ou vouloir convaincre à tout prix."
            case "empathique":  return "Sous pression, tu peux trop t'adapter et t'oublier pour être accepté."
            case "imagineur":   return "Sous pression, tu peux te couper, disparaître ou repousser les décisions."
            case "energiseur":  return "Sous pression, tu peux râler, provoquer ou rejeter la faute."
            case "promoteur":   return "Sous pression, tu peux forcer, prendre des risques ou contourner le cadre."
        }
    }
    return ""
}

; ── Mapping public Shadow (jamais péché, défaut, diagnostic, score brut) ───────
ShadowReadingName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "orgueil":     return "need for worth"
            case "envie":       return "comparison"
            case "colere":      return "tension"
            case "paresse":     return "avoidance"
            case "avarice":     return "control"
            case "gourmandise": return "compensation"
            case "luxure":      return "intensity"
        }
    } else {
        switch key {
            case "orgueil":     return "besoin de valeur"
            case "envie":       return "comparaison"
            case "colere":      return "tension"
            case "paresse":     return "évitement"
            case "avarice":     return "contrôle"
            case "gourmandise": return "compensation"
            case "luxure":      return "intensité"
        }
    }
    return ""
}

; Besoin caché probable.
ShadowReadingHiddenNeed(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "orgueil":     return "This may indicate a hidden need to be valued without having to prove it."
            case "envie":       return "This may indicate a hidden need to feel your own path has worth, without comparison."
            case "colere":      return "This may indicate a hidden need for your limits to be heard earlier."
            case "paresse":     return "This may indicate a hidden need for safety before effort, step by step."
            case "avarice":     return "This may indicate a hidden need for stability before letting go."
            case "gourmandise": return "This may indicate a hidden need for real comfort rather than quick fixes."
            case "luxure":      return "This may indicate a hidden need for living intensity without danger."
        }
    } else {
        switch key {
            case "orgueil":     return "Cela peut indiquer un besoin caché d'être reconnu à ta juste valeur sans devoir le prouver."
            case "envie":       return "Cela peut indiquer un besoin caché de sentir que ta route a de la valeur, sans comparaison."
            case "colere":      return "Cela peut indiquer un besoin caché que tes limites soient entendues plus tôt."
            case "paresse":     return "Cela peut indiquer un besoin caché de sécurité avant l'effort, pas à pas."
            case "avarice":     return "Cela peut indiquer un besoin caché de stabilité avant de lâcher du lest."
            case "gourmandise": return "Cela peut indiquer un besoin caché de réconfort réel plutôt que de compensations rapides."
            case "luxure":      return "Cela peut indiquer un besoin caché d'intensité vivante sans te mettre en danger."
        }
    }
    return ""
}

; Sous pression (piste possible).
ShadowReadingPressure(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "orgueil":     return "Under pressure, you may want to prove and carry everything alone."
            case "envie":       return "Under pressure, you may compare yourself and put yourself down."
            case "colere":      return "Under pressure, you may react too fast and too strong."
            case "paresse":     return "Under pressure, you may avoid, postpone or cut yourself off."
            case "avarice":     return "Under pressure, you may hold back, control or close up."
            case "gourmandise": return "Under pressure, you may compensate with quick pleasures."
            case "luxure":      return "Under pressure, you may seek thrill at the wrong moment."
        }
    } else {
        switch key {
            case "orgueil":     return "Sous pression, tu peux vouloir prouver et tout porter seul."
            case "envie":       return "Sous pression, tu peux te comparer et te dévaloriser."
            case "colere":      return "Sous pression, tu peux réagir trop vite et trop fort."
            case "paresse":     return "Sous pression, tu peux éviter, repousser ou te couper."
            case "avarice":     return "Sous pression, tu peux retenir, contrôler ou te fermer."
            case "gourmandise": return "Sous pression, tu peux compenser par des plaisirs rapides."
            case "luxure":      return "Sous pression, tu peux chercher le frisson au mauvais moment."
        }
    }
    return ""
}

; Piste de régulation douce.
ShadowReadingRegulation(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "orgueil":     return "A gentle lead: note one real success without showing it to anyone."
            case "envie":       return "A gentle lead: turn one comparison into one concrete action for yourself."
            case "colere":      return "A gentle lead: name the tension as soon as it rises, before it overflows."
            case "paresse":     return "A gentle lead: cut the next step into one tiny step."
            case "avarice":     return "A gentle lead: give or delegate one small thing today."
            case "gourmandise": return "A gentle lead: offer yourself one real chosen comfort, not an automatic one."
            case "luxure":      return "A gentle lead: choose a healthy intensity - sport, creation, a framed challenge."
        }
    } else {
        switch key {
            case "orgueil":     return "Piste douce : note une réussite réelle sans la montrer à personne."
            case "envie":       return "Piste douce : transforme une comparaison en une action concrète pour toi."
            case "colere":      return "Piste douce : nomme la tension dès qu'elle monte, avant qu'elle déborde."
            case "paresse":     return "Piste douce : découpe la prochaine étape en un pas minuscule."
            case "avarice":     return "Piste douce : donne ou délègue une petite chose aujourd'hui."
            case "gourmandise": return "Piste douce : offre-toi un vrai moment de réconfort choisi, pas automatique."
            case "luxure":      return "Piste douce : choisis une intensité saine — sport, création, défi cadré."
        }
    }
    return ""
}

; Émotion publique (libellés simples uniquement).
ShadowEmotionName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "peur":      return "fear"
            case "tristesse": return "sadness"
            case "colere":    return "anger"
            case "honte":     return "shame"
            case "joie":      return "joy"
        }
    } else {
        switch key {
            case "peur":      return "peur"
            case "tristesse": return "tristesse"
            case "colere":    return "colère"
            case "honte":     return "honte"
            case "joie":      return "joie"
        }
    }
    return ""
}

; ── Écran détail : Résultat PRIMA Soul ─────────────────────────────────────────
; Pas de scores stockés pour Soul : affichage dominant / secondaire uniquement.
BuildSoulReadingSoul() {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    file := SoulResultsPath(CURRENT_PROFILE_ID)
    mainKey := IniRead(file, "latest", "main_tendency", "")
    secondKey := IniRead(file, "latest", "secondary_tendency", "")
    if (mainKey = "" || SoulReadingName(mainKey) = "") {
        RenderScreen("soul_reading_hub")
        return
    }
    WriteLog("soul_result_detail_opened", CURRENT_PROFILE_ID)
    global MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H
    g := NewGui()
    AddScrollPageHeader(g, TIcon("btn_result_soul"), TIcon("reading_hub_1"))
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, SCROLL_VIEWPORT_H)
    contentY := 8
    contentY := AddScrollResultSection(cg, contentY, "sec_suggest"
        , TIcon("lbl_dominant") " : " SoulReadingNameWithIcon(mainKey)
        , (secondKey != "" && SoulReadingName(secondKey) != "") ? TIcon("lbl_secondary") " : " SoulReadingNameWithIcon(secondKey) : ""
        , SoulReadingBehavior(mainKey))
    contentY := AddScrollResultSection(cg, contentY, "sec_nourish", SoulReadingNeed(mainKey))
    contentY := AddScrollResultSection(cg, contentY, "sec_pressure", SoulReadingPressure(mainKey))
    contentY := AddScrollResultSection(cg, contentY, "sec_comm", GetSoulTendencyAction(mainKey))
    AddScrollPageFooterBack(g, (*) => RenderScreen("soul_reading_hub"))
    ShowScreen()
}

; ── Écran détail : Résultat PRIMA VDA ──────────────────────────────────────────
; "Fonctionnement stable probable" (Q1-12) / "Énergie actuelle probable" (Q13-20).
; Pourcentages calculés sur le maximum possible de la section, jamais de score brut.
BuildSoulReadingVda() {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    file := VdaResultsPath(CURRENT_PROFILE_ID)
    if (IniRead(file, "prima_vda", "completed", "0") != "1") {
        RenderScreen("soul_reading_hub")
        return
    }
    keys := GetSoulPcmKeys()
    base := ReadIniScoreMap(file, "base", keys)
    phase := ReadIniScoreMap(file, "phase", keys)
    baseSum := 0
    for , v in base
        baseSum += v
    if (baseSum = 0) {
        ; Compatibilité : anciens résultats sans section [base] → totaux globaux.
        base := ReadIniScoreMap(file, "scores", keys)
        baseSum := 0
        for , v in base
            baseSum += v
    }
    if (baseSum = 0) {
        RenderScreen("soul_reading_hub")
        return
    }
    phaseSum := 0
    for , v in phase
        phaseSum += v
    top := TopTwoScoreKeys(base, keys)
    ; Chaque question distribue 21 points : max par clé = somme * 6 / 21.
    baseMax := baseSum * 6 / 21
    mainPct := Round(base[top.main] * 100 / baseMax)
    secPct := Round(base[top.second] * 100 / baseMax)
    WriteLog("vda_result_detail_opened", CURRENT_PROFILE_ID)
    global MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H
    g := NewGui()
    AddScrollPageHeader(g, TIcon("btn_result_vda"), TIcon("reading_hub_1"))
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, SCROLL_VIEWPORT_H)
    contentY := 8
    suggestLines := [
        TIcon("lbl_stable_probable") " : " VdaReadingNameWithIcon(top.main) "  (" mainPct "%)  " PrimaLabelWithIcon("gauge", SoulGaugeText(mainPct)),
        TIcon("lbl_influence_secondary") " : " VdaReadingNameWithIcon(top.second) "  (" secPct "%)"
    ]
    if (phaseSum > 0) {
        phaseTop := TopTwoScoreKeys(phase, keys)
        phaseMax := phaseSum * 6 / 21
        phasePct := Round(phase[phaseTop.main] * 100 / phaseMax)
        suggestLines.Push(TIcon("lbl_energy_probable") " : " VdaReadingNameWithIcon(phaseTop.main) "  (" phasePct "%)  " PrimaLabelWithIcon("gauge", SoulGaugeText(phasePct)))
    }
    contentY := AddScrollResultSection(cg, contentY, "sec_suggest", suggestLines*)
    contentY := AddScrollResultSection(cg, contentY, "sec_nourish", VdaReadingNeed(top.main), VdaReadingEnv(top.main))
    contentY := AddScrollResultSection(cg, contentY, "sec_pressure", VdaReadingPressure(top.main))
    contentY := AddScrollResultSection(cg, contentY, "sec_comm", VdaReadingComm(top.main))
    AddScrollPageFooterBack(g, (*) => RenderScreen("soul_reading_hub"))
    ShowScreen()
}

; ── Écran détail : Résultat PRIMA Shadow ───────────────────────────────────────
; Pourcentages discrets = part relative des points, jamais de score brut.
BuildSoulReadingShadow() {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    file := ShadowResultsPath(CURRENT_PROFILE_ID)
    if (IniRead(file, "prima_shadow", "completed", "0") != "1") {
        RenderScreen("soul_reading_hub")
        return
    }
    axisKeys := GetShadowAxisKeys()
    axes := ReadIniScoreMap(file, "axes", axisKeys)
    axSum := 0
    for , v in axes
        axSum += v
    if (axSum = 0) {
        RenderScreen("soul_reading_hub")
        return
    }
    top := TopTwoScoreKeys(axes, axisKeys)
    mainPct := Round(axes[top.main] * 100 / axSum)
    secPct := Round(axes[top.second] * 100 / axSum)
    emoKeys := GetShadowEmotionKeys()
    emotions := ReadIniScoreMap(file, "emotion", emoKeys)
    emoSum := 0
    for , v in emotions
        emoSum += v
    emoTop := TopTwoScoreKeys(emotions, emoKeys)
    WriteLog("shadow_result_detail_opened", CURRENT_PROFILE_ID)
    global MARGIN_X, CONTENT_W, SCROLL_VIEWPORT_Y, SCROLL_VIEWPORT_H
    g := NewGui()
    AddScrollPageHeader(g, TIcon("btn_result_shadow"), TIcon("reading_hub_1"))
    cg := CreateScrollableContentArea(g, MARGIN_X, SCROLL_VIEWPORT_Y, CONTENT_W, SCROLL_VIEWPORT_H)
    contentY := 8
    suggestShadow := [
        TIcon("lbl_tension_dom") " : " ShadowReadingNameWithIcon(top.main) "  (" mainPct "%)  " PrimaLabelWithIcon("gauge", SoulGaugeText(mainPct)),
        TIcon("lbl_tension_sec") " : " ShadowReadingNameWithIcon(top.second) "  (" secPct "%)"
    ]
    if (emoSum > 0)
        suggestShadow.Push(TIcon("lbl_emotion_main") " : " ShadowEmotionNameWithIcon(emoTop.main))
    contentY := AddScrollResultSection(cg, contentY, "sec_suggest", suggestShadow*)
    contentY := AddScrollResultSection(cg, contentY, "sec_nourish", ShadowReadingHiddenNeed(top.main))
    contentY := AddScrollResultSection(cg, contentY, "sec_pressure", ShadowReadingPressure(top.main))
    contentY := AddScrollResultSection(cg, contentY, "sec_comm", ShadowReadingRegulation(top.main))
    AddScrollPageFooterBack(g, (*) => RenderScreen("soul_reading_hub"))
    ShowScreen()
}

; ── PRIMA Univers + Territoire — Master Architecture v2 ───────────────────────
; Visible : 7 Univers × 7 Territoires = 49 architectures PRIMA.
; Moteur caché : Base VDA × blessure principale (30) et Phase VDA × blessure
; secondaire (30) = 900 combinaisons internes. Aucune clé interne affichée :
; ni PCM, ni blessure, ni diagnostic. Tout est proposé en pistes.

global PRIMA_SELECTED_UNIVERSE := ""
global PRIMA_SELECTED_TERRITORY := ""
global PRIMA_UNI_SUGGESTED := ""
global PRIMA_TERR_SUGGESTED := ""
global PRIMA_UNI_PAGE := 1
global PRIMA_TERR_PAGE := 1

GetPrimaUniverseKeys() {
    return ["passe", "futur", "ville", "ocean", "desert", "labyrinthe", "jardin"]
}

GetPrimaTerritoryKeys() {
    return ["lien", "choix", "regard", "controle", "silence", "desir", "changement"]
}

; Noms publics des univers (seuls libellés affichés).
PrimaUniverseName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "passe":      return "Universe of the Past"
            case "futur":      return "Universe of the Future"
            case "ville":      return "Universe of the City"
            case "ocean":      return "Universe of the Ocean"
            case "desert":     return "Universe of the Desert"
            case "labyrinthe": return "Universe of the Labyrinth"
            case "jardin":     return "Universe of the Garden"
        }
    } else {
        switch key {
            case "passe":      return "Univers du Passé"
            case "futur":      return "Univers du Futur"
            case "ville":      return "Univers de la Ville"
            case "ocean":      return "Univers de l'Océan"
            case "desert":     return "Univers du Désert"
            case "labyrinthe": return "Univers du Labyrinthe"
            case "jardin":     return "Univers du Jardin"
        }
    }
    return ""
}

; Descriptions courtes des univers ("cet univers peut représenter…").
PrimaUniverseDesc(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "passe":      return "An inner setting tied to memory, old traces and what still asks to be understood."
            case "futur":      return "An inner setting turned toward building, anticipating and the need to master what comes next."
            case "ville":      return "A social, lively inner setting where place, gaze and adaptation take a lot of space."
            case "ocean":      return "A deep, sensitive inner setting crossed by emotions, bonds and intuition."
            case "desert":     return "A silent, protective inner setting where space and distance let you breathe."
            case "labyrinthe": return "A complex, mental inner setting that seeks to understand, secure and find the right path."
            case "jardin":     return "An inner setting of repair, gentleness and gradual rebuilding."
        }
    } else {
        switch key {
            case "passe":      return "Un décor intérieur lié à la mémoire, aux traces anciennes et à ce qui demande encore à être compris."
            case "futur":      return "Un décor intérieur tourné vers la construction, l'anticipation et le besoin de maîtriser la suite."
            case "ville":      return "Un décor intérieur social, vivant, où la place, le regard et l'adaptation prennent beaucoup d'espace."
            case "ocean":      return "Un décor intérieur profond, sensible, traversé par les émotions, le lien et l'intuition."
            case "desert":     return "Un décor intérieur silencieux, protecteur, où l'espace et la distance permettent de respirer."
            case "labyrinthe": return "Un décor intérieur complexe, mental, qui cherche à comprendre, sécuriser et trouver le bon chemin."
            case "jardin":     return "Un décor intérieur de réparation, de douceur et de reconstruction progressive."
        }
    }
    return ""
}

; Noms publics des territoires.
PrimaTerritoryName(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "lien":       return "Territory of the Bond"
            case "choix":      return "Territory of Choice"
            case "regard":     return "Territory of the Gaze"
            case "controle":   return "Territory of Control"
            case "silence":    return "Territory of Silence"
            case "desir":      return "Territory of Desire"
            case "changement": return "Territory of Change"
        }
    } else {
        switch key {
            case "lien":       return "Territoire du Lien"
            case "choix":      return "Territoire du Choix"
            case "regard":     return "Territoire du Regard"
            case "controle":   return "Territoire du Contrôle"
            case "silence":    return "Territoire du Silence"
            case "desir":      return "Territoire du Désir"
            case "changement": return "Territoire du Changement"
        }
    }
    return ""
}

; Descriptions courtes des territoires.
PrimaTerritoryDesc(key) {
    global CURRENT_LANG
    if (CURRENT_LANG = "en") {
        switch key {
            case "lien":       return "A current zone centered on presence, attachment and relational safety."
            case "choix":      return "A current zone of decision, direction and responsibility."
            case "regard":     return "A current zone tied to image, judgment and social place."
            case "controle":   return "A current zone of structure, checking, trust and mastery."
            case "silence":    return "A current zone of withdrawal, rest, distance and inner protection."
            case "desir":      return "A current zone around wanting, pleasure, the body and the right to want."
            case "changement": return "A current zone of transition, rupture, movement and starting over."
        }
    } else {
        switch key {
            case "lien":       return "Une zone actuelle centrée sur la présence, l'attachement et la sécurité relationnelle."
            case "choix":      return "Une zone actuelle de décision, de direction et de responsabilité."
            case "regard":     return "Une zone actuelle liée à l'image, au jugement et à la place sociale."
            case "controle":   return "Une zone actuelle de structure, de vérification, de confiance et de maîtrise."
            case "silence":    return "Une zone actuelle de retrait, de repos, de distance et de protection intérieure."
            case "desir":      return "Une zone actuelle autour de l'envie, du plaisir, du corps et du droit de vouloir."
            case "changement": return "Une zone actuelle de transition, de rupture, de mouvement et de recommencement."
        }
    }
    return ""
}

; ── Moteur Univers / Territoire V0.1 (interne, jamais affiché) ─────────────────

; Univers fin = clé VDA (base) × blessure Soul. Règles beta puis fallback blessure.
MapPrimaUniverse(pcmKey, soulKey) {
    switch pcmKey {
        case "empathique":
            if (soulKey = "abandon" || soulKey = "rejet")
                return "ocean"
            if (soulKey = "humiliation")
                return "jardin"
        case "analyseur":
            if (soulKey = "injustice")
                return "labyrinthe"
            if (soulKey = "trahison")
                return "futur"
        case "perseverant":
            if (soulKey = "injustice" || soulKey = "trahison")
                return "labyrinthe"
        case "imagineur":
            if (soulKey = "rejet" || soulKey = "abandon")
                return "desert"
        case "energiseur":
            if (soulKey = "rejet" || soulKey = "humiliation")
                return "ville"
        case "promoteur":
            if (soulKey = "trahison" || soulKey = "injustice")
                return "futur"
    }
    switch soulKey {
        case "abandon":     return "ocean"
        case "rejet":       return "desert"
        case "humiliation": return "jardin"
        case "trahison":    return "futur"
        case "injustice":   return "labyrinthe"
    }
    return ""
}

; Pont entre deux univers identiques (table fixe).
PrimaUniverseBridge(key) {
    switch key {
        case "ocean":      return "jardin"
        case "jardin":     return "ocean"
        case "labyrinthe": return "futur"
        case "futur":      return "ville"
        case "ville":      return "labyrinthe"
        case "desert":     return "passe"
        case "passe":      return "ocean"
    }
    return ""
}

; Territoire fin = clé VDA (phase) × blessure secondaire Soul.
MapPrimaTerritory(pcmKey, soulKey) {
    switch pcmKey {
        case "empathique":
            if (soulKey = "abandon" || soulKey = "rejet")
                return "lien"
        case "analyseur":
            if (soulKey = "injustice" || soulKey = "trahison")
                return "controle"
        case "perseverant":
            if (soulKey = "injustice" || soulKey = "trahison")
                return "regard"
        case "imagineur":
            if (soulKey = "rejet" || soulKey = "abandon")
                return "silence"
        case "energiseur":
            if (soulKey = "rejet" || soulKey = "humiliation")
                return "regard"
        case "promoteur":
            if (soulKey = "trahison" || soulKey = "injustice")
                return "choix"
    }
    ; Toute phase + humiliation forte → désir.
    if (soulKey = "humiliation")
        return "desir"
    switch soulKey {
        case "abandon":   return "lien"
        case "rejet":     return "silence"
        case "trahison":  return "controle"
        case "injustice": return "regard"
    }
    return ""
}

; Pont territoire selon l'univers choisi.
PrimaTerritoryForUniverse(universeKey) {
    switch universeKey {
        case "ocean":      return "lien"
        case "passe":      return "lien"
        case "futur":      return "choix"
        case "ville":      return "regard"
        case "desert":     return "silence"
        case "labyrinthe": return "controle"
        case "jardin":     return "changement"
    }
    return "lien"
}

; Garantit exactement 3 clés distinctes (ordre conservé, complète via canon puis fallback).
EnsureExactlyThreePrimaKeys(list, canonKeys, fallbackKeys) {
    out := []
    for k in list {
        if (k = "")
            continue
        found := false
        for o in out {
            if (o = k)
                found := true
        }
        if !found
            out.Push(k)
    }
    for k in canonKeys {
        if (out.Length >= 3)
            break
        found := false
        for o in out {
            if (o = k)
                found := true
        }
        if !found
            out.Push(k)
    }
    for k in fallbackKeys {
        if (out.Length >= 3)
            break
        found := false
        for o in out {
            if (o = k)
                found := true
        }
        if !found
            out.Push(k)
    }
    result := []
    loop Min(3, out.Length)
        result.Push(out[A_Index])
    return result
}

; Alias historique.
DedupePrimaKeys(list, allKeys) {
    return EnsureExactlyThreePrimaKeys(list, allKeys, allKeys)
}

; Somme des valeurs d'une Map de scores.
PrimaScoreSum(m) {
    total := 0
    for , v in m
        total += v
    return total
}

; Propose 3 univers : principal, pont, secondaire. Fallback si calcul impossible.
ComputeSuggestedPrimaUniverses(profileId) {
    canon := GetPrimaUniverseKeys()
    fallback := ["ocean", "labyrinthe", "jardin"]
    if (profileId = "")
        return EnsureExactlyThreePrimaKeys([], canon, fallback)
    soulFile := SoulResultsPath(profileId)
    soulMain := IniRead(soulFile, "latest", "main_tendency", "")
    soulSecond := IniRead(soulFile, "latest", "secondary_tendency", "")
    if (soulSecond = "")
        soulSecond := soulMain
    keys := GetSoulPcmKeys()
    vdaFile := VdaResultsPath(profileId)
    base := ReadIniScoreMap(vdaFile, "base", keys)
    if (PrimaScoreSum(base) = 0)
        base := ReadIniScoreMap(vdaFile, "scores", keys)
    if (soulMain = "" || PrimaScoreSum(base) = 0)
        return EnsureExactlyThreePrimaKeys([], canon, fallback)
    top := TopTwoScoreKeys(base, keys)
    mainUni := MapPrimaUniverse(top.main, soulMain)
    secUni := MapPrimaUniverse(top.second, soulSecond)
    if (mainUni = "" || secUni = "")
        return EnsureExactlyThreePrimaKeys([], canon, fallback)
    bridge := PrimaUniverseBridge(mainUni)
    if (bridge = "")
        bridge := fallback[2]
    return EnsureExactlyThreePrimaKeys([mainUni, bridge, secUni], canon, fallback)
}

; Propose 3 territoires : principal, pont avec l'univers choisi, secondaire.
ComputeSuggestedPrimaTerritories(profileId, selectedUniverse) {
    canon := GetPrimaTerritoryKeys()
    fallback := ["lien", "controle", "changement"]
    bridge := PrimaTerritoryForUniverse(selectedUniverse)
    if (profileId = "" || selectedUniverse = "")
        return EnsureExactlyThreePrimaKeys([bridge], canon, fallback)
    soulFile := SoulResultsPath(profileId)
    soulSecond := IniRead(soulFile, "latest", "secondary_tendency", "")
    if (soulSecond = "")
        soulSecond := IniRead(soulFile, "latest", "main_tendency", "")
    keys := GetSoulPcmKeys()
    phase := ReadIniScoreMap(VdaResultsPath(profileId), "phase", keys)
    if (soulSecond = "" || PrimaScoreSum(phase) = 0)
        return EnsureExactlyThreePrimaKeys([bridge], canon, fallback)
    top := TopTwoScoreKeys(phase, keys)
    t1 := MapPrimaTerritory(top.main, soulSecond)
    t3 := MapPrimaTerritory(top.second, soulSecond)
    if (t1 = "" || t3 = "")
        return EnsureExactlyThreePrimaKeys([bridge], canon, fallback)
    return EnsureExactlyThreePrimaKeys([t1, bridge, t3], canon, fallback)
}

; ── Sauvegarde prima_identity.ini ──────────────────────────────────────────────
PrimaIdentityPath(profileId) {
    return PROFILES_DIR "\" profileId "\soul\prima_identity.ini"
}

JoinPrimaKeys(arr) {
    if !IsObject(arr)
        return ""
    s := ""
    for k in arr
        s .= (s = "" ? "" : ",") k
    return s
}

SavePrimaIdentity(profileId, universe, territory) {
    global PRIMA_UNI_SUGGESTED, PRIMA_TERR_SUGGESTED
    if (profileId = "" || universe = "" || territory = "")
        return
    dir := PROFILES_DIR "\" profileId "\soul"
    if !DirExist(dir)
        DirCreate(dir)
    file := PrimaIdentityPath(profileId)
    label := PrimaUniverseName(universe) " / " PrimaTerritoryName(territory)
    IniWrite(universe, file, "identity", "selected_universe")
    IniWrite(territory, file, "identity", "selected_territory")
    IniWrite(label, file, "identity", "architecture_label")
    IniWrite(FormatTime(, "yyyy-MM-dd HH:mm"), file, "identity", "date")
    IniWrite("0.1", file, "identity", "version")
    IniWrite("49", file, "engine", "visible_total")
    IniWrite("900", file, "engine", "hidden_total")
    IniWrite("calculated_and_confirmed", file, "engine", "universe_source")
    IniWrite("calculated_and_confirmed", file, "engine", "territory_source")
    IniWrite(JoinPrimaKeys(PRIMA_UNI_SUGGESTED), file, "suggestions", "universes")
    IniWrite(JoinPrimaKeys(PRIMA_TERR_SUGGESTED), file, "suggestions", "territories")
    WriteLog("prima_identity_saved", profileId " | " universe "/" territory)
}

; ── Écran choix Univers ────────────────────────────────────────────────────────
BuildPrimaUniverseChoice() {
    BuildPrimaPagedChoiceScreen("universe")
}

UniversePrevPage(*) {
    global PRIMA_UNI_PAGE
    if (PRIMA_UNI_PAGE > 1) {
        PRIMA_UNI_PAGE -= 1
        RenderScreen("prima_universe_choice")
    }
}

UniverseNextPage(*) {
    global PRIMA_UNI_PAGE
    if (PRIMA_UNI_PAGE < 3) {
        PRIMA_UNI_PAGE += 1
        RenderScreen("prima_universe_choice")
    }
}

UniverseChoiceBack(backScreen, *) {
    RenderScreen(backScreen)
}

SelectPrimaUniverse(key, *) {
    global CURRENT_PROFILE_ID, PRIMA_SELECTED_UNIVERSE, PRIMA_TERR_PAGE
    PRIMA_SELECTED_UNIVERSE := key
    PRIMA_TERR_PAGE := 1
    WriteLog("prima_universe_selected", CURRENT_PROFILE_ID " | " key)
    RenderScreen("prima_territory_choice")
}

; ── Écran choix Territoire ─────────────────────────────────────────────────────
BuildPrimaTerritoryChoice() {
    BuildPrimaPagedChoiceScreen("territory")
}

TerritoryPrevPage(*) {
    global PRIMA_TERR_PAGE
    if (PRIMA_TERR_PAGE > 1) {
        PRIMA_TERR_PAGE -= 1
        RenderScreen("prima_territory_choice")
    }
}

TerritoryNextPage(*) {
    global PRIMA_TERR_PAGE
    if (PRIMA_TERR_PAGE < 3) {
        PRIMA_TERR_PAGE += 1
        RenderScreen("prima_territory_choice")
    }
}

TerritoryChoiceBack(*) {
    global PRIMA_UNI_PAGE
    PRIMA_UNI_PAGE := 1
    RenderScreen("prima_universe_choice")
}

BuildPrimaPagedChoiceScreen(mode) {
    global CURRENT_PROFILE_ID, PRIMA_UNI_SUGGESTED, PRIMA_TERR_SUGGESTED
    global PRIMA_UNI_PAGE, PRIMA_TERR_PAGE, PRIMA_SELECTED_UNIVERSE, UNIVERSE_BACK_SCREEN
    global MARGIN_X, CONTENT_W, PAGED_CHOICE_PAGE_Y, CLR_BG, CLR_ACCENT

    total := 3
    if (mode = "universe") {
        if (CURRENT_PROFILE_ID = "") {
            RenderScreen("prima_soul_intro")
            return
        }
        PRIMA_UNI_SUGGESTED := ComputeSuggestedPrimaUniverses(CURRENT_PROFILE_ID)
        WriteLog("prima_universe_suggestions", JoinPrimaKeys(PRIMA_UNI_SUGGESTED))
        WriteLog("prima_universe_choice_opened", CURRENT_PROFILE_ID)
        page := Max(1, Min(total, PRIMA_UNI_PAGE))
        PRIMA_UNI_PAGE := page
        roles := ["uni_role_main", "uni_role_bridge", "uni_role_secondary"]
        whyKeys := ["uni_why_main", "uni_why_bridge", "uni_why_secondary"]
        key := PRIMA_UNI_SUGGESTED[page]
        screenTitle := TIcon("btn_choose_universe")
        guide1 := T("uni_choice_1")
        guide2 := T("uni_choice_2")
        cardTitle := PrimaUniverseDisplayNameWithIcon(key)
        cardDesc := PrimaUniverseDesc(key)
        onPick := SelectPrimaUniverse.Bind(key)
        onPrev := UniversePrevPage
        onNext := UniverseNextPage
        backScreen := (UNIVERSE_BACK_SCREEN != "") ? UNIVERSE_BACK_SCREEN : "soul_reading_hub"
        onBack := UniverseChoiceBack.Bind(backScreen)
    } else {
        if (CURRENT_PROFILE_ID = "" || PRIMA_SELECTED_UNIVERSE = "") {
            RenderScreen("soul_reading_hub")
            return
        }
        PRIMA_TERR_SUGGESTED := ComputeSuggestedPrimaTerritories(CURRENT_PROFILE_ID, PRIMA_SELECTED_UNIVERSE)
        WriteLog("prima_territory_suggestions", JoinPrimaKeys(PRIMA_TERR_SUGGESTED))
        WriteLog("prima_territory_choice_opened", CURRENT_PROFILE_ID)
        page := Max(1, Min(total, PRIMA_TERR_PAGE))
        PRIMA_TERR_PAGE := page
        roles := ["terr_role_main", "terr_role_bridge", "terr_role_secondary"]
        whyKeys := ["terr_why_main", "terr_why_bridge", "terr_why_secondary"]
        key := PRIMA_TERR_SUGGESTED[page]
        screenTitle := TIcon("terr_choice_title")
        guide1 := T("terr_choice_1")
        guide2 := T("terr_choice_2")
        cardTitle := PrimaTerritoryDisplayNameWithIcon(key)
        cardDesc := PrimaTerritoryDesc(key)
        onPick := SelectPrimaTerritory.Bind(key)
        onPrev := TerritoryPrevPage
        onNext := TerritoryNextPage
        onBack := TerritoryChoiceBack
    }

    g := NewGui()
    AddChoiceScreenHeader(g, screenTitle, guide1, guide2)
    g.SetFont("s12 Bold c" CLR_ACCENT, "Segoe UI")
    g.Add("Text", "x" MARGIN_X " y" PAGED_CHOICE_PAGE_Y " w" CONTENT_W " h24 Center Background" CLR_BG
        , T("choice_piste_of", page, total) " — " T(roles[page]))
    AddPagedChoiceCard(g, cardTitle, cardDesc, T(whyKeys[page]), onPick)
    AddPagedChoiceNavRow(g, page, total, onPrev, onPick, onNext)
    AddChoiceNavBack(g, onBack)
    ShowScreen()
}

SelectPrimaTerritory(key, *) {
    global CURRENT_PROFILE_ID, PRIMA_SELECTED_UNIVERSE, PRIMA_SELECTED_TERRITORY
    PRIMA_SELECTED_TERRITORY := key
    WriteLog("prima_territory_selected", CURRENT_PROFILE_ID " | " key)
    SavePrimaIdentity(CURRENT_PROFILE_ID, PRIMA_SELECTED_UNIVERSE, key)
    RenderScreen("prima_identity_saved")
}

; ── Écran confirmation architecture ────────────────────────────────────────────
BuildPrimaIdentitySaved() {
    global PRIMA_SELECTED_UNIVERSE, PRIMA_SELECTED_TERRITORY
    if (PRIMA_SELECTED_UNIVERSE = "" || PRIMA_SELECTED_TERRITORY = "") {
        RenderScreen("soul_reading_hub")
        return
    }
    g := NewGui()
    AddScreenHeader(g, TIcon("identity_saved_title"), T("identity_saved_1"), T("identity_saved_2"))
    AddSubtitle(g, TIcon("identity_arch_label"))
    AddSpacer(g, GAP_SM)
    AddBodyText(g, PrimaUniverseDisplayNameWithIcon(PRIMA_SELECTED_UNIVERSE) " / " PrimaTerritoryDisplayNameWithIcon(PRIMA_SELECTED_TERRITORY))
    AddSpacer(g, GAP_LG)
    AddButton(g, TIcon("btn_back_reading"), (*) => RenderScreen("soul_reading_hub"))
    AddSpacer(g, GAP_Y)
    AddButton(g, TIcon("btn_back_prima_home"), (*) => RenderScreen("prima_soul_intro"))
    AddSpacer(g, GAP_Y)
    AddButton(g, TIcon("btn_redo_tests"), SoulRedoTestsClicked)
    ShowScreen()
}

BuildPrimaSoulSettings() {
    global CURRENT_PROFILE_ID
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("prima_soul_intro")
        return
    }
    g := NewGui()
    AddScreenHeader(g, TIcon("soul_settings_title"), T("soul_settings_dev_hint"))
    AddSpacer(g, GAP_LG)
    AddButton(g, TIcon("btn_redo_tests"), SoulRedoTestsClicked)
    AddNavBackQuit(g, (*) => RenderScreen("prima_soul_intro"), (*) => ConfirmExit("quit"))
    ShowScreen()
}

; ── PRIMA Soul — lecteur de questions (5 réponses, choix 1 à 2) ───────────────
global SOUL_PICKS := []
global SOUL_ANSWER_BTNS := []

BuildPrimaSoulQuestion() {
    global SOUL_SESSION, SOUL_PICKS, SOUL_ANSWER_BTNS
    if (SOUL_SESSION = "" || SOUL_SESSION.active_path != "prima_soul" || SOUL_SESSION.completed) {
        RenderScreen(SOUL_TEST_BACK_SCREEN)
        return
    }
    q := SOUL_SESSION.questions[SOUL_SESSION.current_index]
    SOUL_PICKS := []
    SOUL_ANSWER_BTNS := []
    g := NewGui()
    AddTestQuestionHeader(g, TIcon("soul_test_title")
        , TIcon("vda_question_of", SOUL_SESSION.current_index, SOUL_SESSION.questions.Length)
        , q.prompt, TIcon("soul_pick_hint"))
    texts := []
    for a in q.answers
        texts.Push(a.text)
    SOUL_ANSWER_BTNS := AddTestAnswerButtons(g, texts, SoulAnswerClick)
    AddFixedTestNav(g, SoulNextQuestion, SOUL_ANSWER_BTNS.navY)
    ShowScreen()
}

; Pendant un test actif, aucun retour au hub n'est autorisé.
SoulBackFromQuestion(*) {
    MsgBox(T("msg_finish_or_quit"), APP_TITLE, "Icon!")
}

; Premier clic = priorité 1, deuxième clic = priorité 2.
; Re-cliquer une réponse choisie la retire (l'autre remonte en priorité 1).
SoulAnswerClick(idx, *) {
    global SOUL_PICKS
    pos := 0
    for i, v in SOUL_PICKS {
        if (v = idx)
            pos := i
    }
    if (pos) {
        SOUL_PICKS.RemoveAt(pos)
    } else {
        if (SOUL_PICKS.Length >= 2) {
            MsgBox(T("msg_pick_only_two"), APP_TITLE, "Icon!")
            return
        }
        SOUL_PICKS.Push(idx)
    }
    SoulRefreshAnswerLabels()
}

SoulRefreshAnswerLabels() {
    global SOUL_PICKS, SOUL_ANSWER_BTNS, SOUL_SESSION
    q := SOUL_SESSION.questions[SOUL_SESSION.current_index]
    for i, btn in SOUL_ANSWER_BTNS {
        prefix := ""
        selected := false
        for p, v in SOUL_PICKS {
            if (v = i) {
                prefix := PrimaPriorityPrefix(p)
                selected := true
            }
        }
        ApplyTestAnswerPickStyle(btn, prefix, q.answers[i].text, selected)
    }
}

SoulNextQuestion(*) {
    global SOUL_SESSION, SOUL_PICKS
    if (SOUL_SESSION = "" || SOUL_SESSION.completed) {
        RenderScreen(SOUL_TEST_BACK_SCREEN)
        return
    }
    if (SOUL_PICKS.Length < 1) {
        MsgBox(T("msg_pick_at_least_one"), APP_TITLE, "Icon!")
        return
    }
    q := SOUL_SESSION.questions[SOUL_SESSION.current_index]
    selected1 := q.answers[SOUL_PICKS[1]].id
    selected2 := (SOUL_PICKS.Length >= 2) ? q.answers[SOUL_PICKS[2]].id : ""
    SoulSessionRecordAnswer(SOUL_SESSION, q.id, selected1, selected2)
    SaveSoulSessionState()
    if (SOUL_SESSION.completed) {
        WriteLog("soul_run_completed", "prima_soul | " SOUL_SESSION.answers.Length)
        if (CURRENT_PROFILE_ID != "") {
            MarkSoulTestCompleted(CURRENT_PROFILE_ID, "prima_soul")
            result := ComputeSoulMainTendencies(SOUL_SESSION)
            WriteLog("soul_result_built", CURRENT_PROFILE_ID)
            SaveSoulTestResult(CURRENT_PROFILE_ID, result.main, result.second)
        }
        RenderScreen("prima_soul_done")
    } else {
        RenderScreen("prima_soul_question")
    }
}

; Fin Soul : pas de résultat détaillé immédiat.
BuildPrimaSoulDone() {
    BuildPrimaTestDoneScreen("soul_test_title")
}

BuildPrimaVdaDone() {
    BuildPrimaTestDoneScreen("vda_test_title")
}

SoulChooseByCode(ddl, codes, savedCode) {
    if (savedCode != "") {
        loop codes.Length {
            if (codes[A_Index] = savedCode) {
                ddl.Choose(A_Index)
                return
            }
        }
    }
    ddl.Choose(1)
}

AddSoulChoice(g, key, savedCode) {
    AddSubtitle(g, T("soul_" key))
    AddSpacer(g, 3)
    ddl := g.Add("DropDownList", "w880 Background" CLR_PANEL " c" CLR_TEXT, GetSoulChoiceLabels(key))
    SoulChooseByCode(ddl, GetSoulChoiceCodes()[key], savedCode)
    return ddl
}

BuildPrimaSoulChoices() {
    global CURRENT_PROFILE_ID
    global SOUL_TONE, SOUL_RHYTHM, SOUL_ENERGY, SOUL_NEED, SOUL_REST
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        RenderScreen("profile")
        return
    }
    g := NewGui()
    AddTitle(g, T("prima_soul_intro_title"), 20)
    AddSpacer(g, 4)
    AddSubtitle(g, T("prima_soul_guide"))
    AddSpacer(g, 8)
    SOUL_TONE := AddSoulChoice(g, "tone", LoadSoulChoice(CURRENT_PROFILE_ID, "tone"))
    AddSpacer(g, 6)
    SOUL_RHYTHM := AddSoulChoice(g, "rhythm", LoadSoulChoice(CURRENT_PROFILE_ID, "rhythm"))
    AddSpacer(g, 6)
    SOUL_ENERGY := AddSoulChoice(g, "energy", LoadSoulChoice(CURRENT_PROFILE_ID, "energy"))
    AddSpacer(g, 6)
    SOUL_NEED := AddSoulChoice(g, "need", LoadSoulChoice(CURRENT_PROFILE_ID, "need"))
    AddSpacer(g, 6)
    SOUL_REST := AddSoulChoice(g, "rest", LoadSoulChoice(CURRENT_PROFILE_ID, "rest"))
    AddSpacer(g, 10)
    AddButton(g, TIcon("btn_soul_save_goals"), PrimaSoulSave)
    AddSpacer(g, 4)
    AddButton(g, TIcon("btn_back"), (*) => RenderScreen("prima_soul_intro"))
    AddSpacer(g, 4)
    AddButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    ShowScreen()
}

PrimaSoulSave(*) {
    global CURRENT_PROFILE_ID, SOUL_TONE, SOUL_RHYTHM, SOUL_ENERGY, SOUL_NEED, SOUL_REST
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        RenderScreen("profile")
        return
    }
    codes := GetSoulChoiceCodes()
    tone := codes["tone"][SOUL_TONE.Value ? SOUL_TONE.Value : 1]
    rhythm := codes["rhythm"][SOUL_RHYTHM.Value ? SOUL_RHYTHM.Value : 1]
    energy := codes["energy"][SOUL_ENERGY.Value ? SOUL_ENERGY.Value : 1]
    need := codes["need"][SOUL_NEED.Value ? SOUL_NEED.Value : 1]
    rest := codes["rest"][SOUL_REST.Value ? SOUL_REST.Value : 1]
    SaveSoulChoices(CURRENT_PROFILE_ID, tone, rhythm, energy, need, rest)
    WriteLog("prima_soul_saved", CURRENT_PROFILE_ID)
    WriteProfileLog(CURRENT_PROFILE_ID, "prima_soul_saved")
    RenderScreen("onboarding_goals")
}

BuildOnboarding() {
    g := NewFormGui()
    AddFormTitle(g, TIcon("btn_onboarding"))
    AddFormGap(g, 6)
    AddFormBodyText(g, T("onboarding_body"))
    AddFormGap(g, 12)
    AddFormButton(g, TIcon("btn_continue"), (*) => RenderScreen("personal_base"))
    AddFormNavBackQuit(g, (*) => RenderScreen("home"))
    ShowFormGui()
}

BuildPersonalBase() {
    g := NewFormGui()
    AddFormTitle(g, T("personal_base_title"))
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("base_kit_prima"), ShowModuleLater)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("base_prima_soul"), PersonalBaseOpenPrimaSoulIntro)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_goals"), OpenGoalsFromPersonalBase)
    AddFormGap(g, 4)
    AddFormButton(g, T("btn_proof"), ShowModuleLater)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_review"), HomeOpenReview)
    AddFormNavBackQuit(g, (*) => RenderScreen("onboarding"))
    ShowFormGui()
}

BuildOnboardingGoals() {
    global CURRENT_PROFILE_ID, GOALS_DOMAIN_IDX, GOALS_DOMAIN_DDL, GOAL_SHORT, GOAL_MEDIUM, GOAL_LONG, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    if (CURRENT_PROFILE_ID = "")
        return
    if (GOALS_DOMAIN_IDX < 1)
        GOALS_DOMAIN_IDX := 1
    code := GetDomainCodes()[GOALS_DOMAIN_IDX]
    data := LoadDomainGoals(CURRENT_PROFILE_ID, code)
    g := NewFormGui()
    AddFormTitle(g, TIcon("goals_title"))
    AddFormGap(g, 4)
    AddFormLabel(g, T("goal_domain"))
    GOALS_DOMAIN_DDL := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, GetDomainLabels())
    GOALS_DOMAIN_DDL.Choose(GOALS_DOMAIN_IDX)
    GOALS_DOMAIN_DDL.OnEvent("Change", GoalsDomainChange)
    AddFormGap(g, 4)
    AddFormLabel(g, T("dur_short") . " — " T("dur_short_hint"))
    GOAL_SHORT := g.Add("Edit", "w" FORM_FIELD_W " h22 Background" CLR_PANEL " c" CLR_TEXT, data.short)
    AddFormGap(g, 3)
    AddFormLabel(g, T("dur_medium") . " — " T("dur_medium_hint"))
    GOAL_MEDIUM := g.Add("Edit", "w" FORM_FIELD_W " h22 Background" CLR_PANEL " c" CLR_TEXT, data.medium)
    AddFormGap(g, 3)
    AddFormLabel(g, T("dur_long") . " — " T("dur_long_hint"))
    GOAL_LONG := g.Add("Edit", "w" FORM_FIELD_W " h22 Background" CLR_PANEL " c" CLR_TEXT, data.long)
    AddFormGap(g, 10)
    AddFormButton(g, TIcon("btn_save"), OnboardingDomainSave)
    AddFormNavBackQuit(g, GoalsBack)
    ShowFormGui()
}

OpenGoalsFromPersonalBase(*) {
    global GOALS_BACK_SCREEN
    GOALS_BACK_SCREEN := "personal_base"
    RenderScreen("onboarding_goals")
}

GoalsBack(*) {
    global GOALS_BACK_SCREEN
    RenderScreen(GOALS_BACK_SCREEN)
}

ReviewBack(*) {
    global REVIEW_BACK_SCREEN
    RenderScreen(REVIEW_BACK_SCREEN)
}

BuildReviewBlocked() {
    g := NewFormGui()
    AddFormTitle(g, TIcon("review_title"))
    AddFormGap(g, 8)
    AddFormBodyText(g, PrimaLabelWithIcon("no_result", T("review_no_goals")))
    AddFormNavBackQuit(g, ReviewBack)
    ShowFormGui()
}

ReviewDomainChange(*) {
    global REVIEW_DOMAIN, REVIEW_SELECTED_DOMAIN_IDX
    REVIEW_SELECTED_DOMAIN_IDX := REVIEW_DOMAIN.Value
    RenderScreen("review")
}

BuildReview() {
    global CURRENT_PROFILE_ID, REVIEW_SELECTED_DOMAIN_IDX, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    domainsWithGoals := GetDomainsWithGoals(CURRENT_PROFILE_ID)
    if (domainsWithGoals.Length = 0) {
        BuildReviewBlocked()
        return
    }
    if (REVIEW_SELECTED_DOMAIN_IDX > domainsWithGoals.Length)
        REVIEW_SELECTED_DOMAIN_IDX := 1
    selectedCode := domainsWithGoals[REVIEW_SELECTED_DOMAIN_IDX]
    domainGoals := GetGoalsForDomain(CURRENT_PROFILE_ID, selectedCode)

    g := NewFormGui()
    AddFormTitle(g, TIcon("review_title"))
    AddFormGap(g, 4)
    AddFormLabel(g, T("review_mood"))
    global REVIEW_MOOD
    REVIEW_MOOD := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, GetMoodLabels())
    REVIEW_MOOD.Choose(1)
    AddFormGap(g, 3)
    AddFormLabel(g, T("review_energy"))
    global REVIEW_ENERGY
    REVIEW_ENERGY := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, GetEnergyLabels())
    REVIEW_ENERGY.Choose(1)
    AddFormGap(g, 3)
    AddFormLabel(g, T("review_domain"))
    global REVIEW_DOMAIN, REVIEW_DOMAIN_GOALS
    domainLabels := []
    for code in domainsWithGoals
        domainLabels.Push(GetDomainLabelForCode(code))
    REVIEW_DOMAIN := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, domainLabels)
    REVIEW_DOMAIN.Choose(REVIEW_SELECTED_DOMAIN_IDX)
    REVIEW_DOMAIN.OnEvent("Change", ReviewDomainChange)
    AddFormGap(g, 3)
    AddFormLabel(g, T("review_did"))
    global REVIEW_DID
    REVIEW_DOMAIN_GOALS := domainGoals
    if (domainGoals.Length = 0) {
        REVIEW_DID := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, [T("review_no_domain_goals")])
        REVIEW_DID.Choose(1)
    } else {
        didLabels := []
        for goal in domainGoals
            didLabels.Push(goal.durationLabel . " — " . goal.title)
        REVIEW_DID := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, didLabels)
        REVIEW_DID.Choose(1)
    }
    AddFormGap(g, 3)
    AddFormLabel(g, T("review_improve"))
    global REVIEW_IMPROVE
    REVIEW_IMPROVE := g.Add("Edit", "w" FORM_FIELD_W " h22 Multi Background" CLR_PANEL " c" CLR_TEXT, "")
    AddFormGap(g, 3)
    AddFormLabel(g, T("review_note"))
    global REVIEW_NOTE
    REVIEW_NOTE := g.Add("Edit", "w" FORM_FIELD_W " h22 Multi Background" CLR_PANEL " c" CLR_TEXT, "")
    AddFormGap(g, 8)
    AddFormButton(g, TIcon("btn_save"), ReviewSave)
    AddFormNavBackQuit(g, ReviewBack)
    ShowFormGui()
}

ReviewSave(*) {
    global CURRENT_PROFILE_ID, REVIEW_MOOD, REVIEW_ENERGY, REVIEW_DID, REVIEW_IMPROVE, REVIEW_NOTE
    global REVIEW_DOMAIN, REVIEW_SELECTED_DOMAIN_IDX, REVIEW_DOMAIN_GOALS
    if (CURRENT_PROFILE_ID = "") {
        MsgBox(T("msg_no_active"), APP_TITLE, "Icon!")
        RenderScreen("home")
        return
    }
    moodIdx := REVIEW_MOOD.Value
    energyIdx := REVIEW_ENERGY.Value
    moodLabels := GetMoodLabels()
    moodCodes := GetMoodCodes()
    energyLabels := GetEnergyLabels()
    energyCodes := GetEnergyCodes()
    moodLabel := moodIdx ? moodLabels[moodIdx] : ""
    moodCode := moodIdx ? moodCodes[moodIdx] : ""
    energyLabel := energyIdx ? energyLabels[energyIdx] : ""
    energyCode := energyIdx ? energyCodes[energyIdx] : ""
    domainsWithGoals := GetDomainsWithGoals(CURRENT_PROFILE_ID)
    reviewDomain := ""
    whatDid := ""
    goalTitle := ""
    goalDuration := ""
    if (domainsWithGoals.Length > 0 && REVIEW_DOMAIN_GOALS.Length > 0) {
        selectedCode := domainsWithGoals[REVIEW_SELECTED_DOMAIN_IDX]
        reviewDomain := GetDomainLabelForCode(selectedCode)
        didIdx := REVIEW_DID.Value
        if (didIdx > 0) {
            goal := REVIEW_DOMAIN_GOALS[didIdx]
            whatDid := goal.title
            goalTitle := goal.title
            goalDuration := goal.duration
        }
    }
    SaveReview(moodLabel, moodCode, energyLabel, energyCode, whatDid, REVIEW_IMPROVE.Value, REVIEW_NOTE.Value, reviewDomain, goalTitle, goalDuration)
    WriteLog("review_saved", CURRENT_PROFILE_ID)
}

BuildSettings() {
    global CURRENT_PROFILE_ID, CURRENT_LANG, FORM_FIELD_W, CLR_PANEL, CLR_TEXT
    g := NewFormGui()
    AddFormTitle(g, TIcon("settings_title"))
    AddFormGap(g, 6)
    AddFormLabel(g, T("create_lang"))
    global SETTINGS_LANG
    SETTINGS_LANG := g.Add("DropDownList", "w" FORM_FIELD_W " Background" CLR_PANEL " c" CLR_TEXT, ["Français", "English"])
    SETTINGS_LANG.Choose(CURRENT_LANG = "en" ? 2 : 1)
    SETTINGS_LANG.OnEvent("Change", SettingsLangChange)
    AddFormNavBackQuit(g, (*) => RenderScreen("home"), false)
    AddFormGap(g, 4)
    AddFormButton(g, TIcon("btn_quit"), (*) => ConfirmExit("quit"))
    ShowFormGui()
}

SettingsLangChange(*) {
    global SETTINGS_LANG, CURRENT_PROFILE_ID, CURRENT_LANG
    if (CURRENT_PROFILE_ID = "") {
        RenderScreen("home")
        return
    }
    lang := (SETTINGS_LANG.Text = "English") ? "en" : "fr"
    SaveProfileLanguage(CURRENT_PROFILE_ID, lang)
    CURRENT_LANG := lang
    RenderScreen("settings")
}

; ── Hotkeys ───────────────────────────────────────────────────────────────────
PauseApp() {
    global IS_PAUSED
    IS_PAUSED := !IS_PAUSED
    if (IS_PAUSED)
        MsgBox(T("pause_on"), APP_TITLE, "Icon!")
    else
        MsgBox(T("pause_off"), APP_TITLE, "Icon!")
    WriteLog(IS_PAUSED ? "app_paused" : "app_resumed")
}

EmergencyExit() {
    SaveSoulSessionState()
    SaveVdaSessionState()
    SaveShadowSessionState()
    WriteLog("app_emergency_exit")
    CloseCurrentWindow()
    ExitApp()
}
