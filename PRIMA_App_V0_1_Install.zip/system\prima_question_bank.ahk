#Requires AutoHotkey v2.0
; PRIMA question bank — BuildPrimaQuestionBank()
; Compatible scoring: prima_soul (rank 5), prima_vda (rank 6), prima_shadow tension (rank 7) + emotion (rank 5)

PrimaBankSoulAnswers(texts, axes) {
    answers := []
    loop texts.Length {
        i := A_Index
        answers.Push({ id: "a" i, text: texts[i], scores: Map(axes[i], 1) })
    }
    return answers
}

PrimaBankVdaAnswers(texts, keys) {
    answers := []
    loop texts.Length {
        i := A_Index
        answers.Push({ id: "a" i, text: texts[i], pcm_key: keys[i] })
    }
    return answers
}

PrimaBankShadowTensionAnswers(texts, keys) {
    answers := []
    loop texts.Length {
        i := A_Index
        answers.Push({ id: "a" i, text: texts[i], shadow_key: keys[i] })
    }
    return answers
}

PrimaBankShadowEmotionAnswers(texts, keys) {
    answers := []
    loop texts.Length {
        i := A_Index
        answers.Push({ id: "a" i, text: texts[i], shadow_key: keys[i] })
    }
    return answers
}

BuildPrimaQuestionBank() {
    bank := []
    soulAxes := ["rejet", "abandon", "humiliation", "trahison", "injustice"]
    vdaKeys := ["analyseur", "perseverant", "empathique", "imagineur", "energiseur", "promoteur"]
    shadowTenKeys := ["orgueil", "envie", "colere", "paresse", "avarice", "gourmandise", "luxure"]
    shadowEmoKeys := ["peur", "tristesse", "colere", "honte", "joie"]

    ; ── SOUL — 20 questions (4 par axe), rank 5 ──
    bank.Push({
        id: "Q-SOUL-REJET-01", path: "prima_soul", test_type: "soul", primary_axis: "rejet",
        environment: "famille", target: "cousin", trigger: "coupe_la_parole",
        context: "famille", category: "cousin", signal_type: "interaction",
        prompt: "Au dîner de famille, ton cousin coupe la parole quand tu expliques ton projet. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me tais et j'attends qu'on me laisse une place.", "Je cherche un regard complice pour ne pas rester seul.", "Je rougis et j'ai honte de continuer.", "Je me méfie de ce qu'il cache derrière ça.", "Je trouve injuste qu'on m'impose ce silence."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-REJET-02", path: "prima_soul", test_type: "soul", primary_axis: "rejet",
        environment: "travail", target: "equipe", trigger: "dejeuner_sans_invitation",
        context: "travail", category: "equipe", signal_type: "contexte",
        prompt: "Au bureau, ton équipe part déjeuner ensemble sans t'avoir prévenu. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me dis que je ne fais pas vraiment partie du groupe.", "Je vérifie si quelqu'un va revenir vers moi.", "Je fais comme si ça ne me touchait pas pour ne pas paraître needy.", "Je me demande qui a décidé de m'exclure.", "Je trouve ça injuste si tout le monde n'est pas traité pareil."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-REJET-03", path: "prima_soul", test_type: "soul", primary_axis: "rejet",
        environment: "amitie", target: "amis_proches", trigger: "conversation_sans_toi",
        context: "amitie", category: "amis_proches", signal_type: "perception",
        prompt: "En soirée chez des amis proches, la conversation enchaîne comme si tu n'étais pas là. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me replie et j'attends qu'on m'inclue.", "Je cherche un signe qu'on pense encore à moi.", "Je me sens ridicule de vouloir parler.", "Je me demande si quelqu'un parle de moi ailleurs.", "Je trouve injuste d'être ignoré alors que je suis là."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-REJET-04", path: "prima_soul", test_type: "soul", primary_axis: "rejet",
        environment: "numerique", target: "groupe_messagerie", trigger: "message_sans_reponse",
        context: "numerique", category: "groupe_messagerie", signal_type: "repetition",
        prompt: "Dans un groupe de messagerie actif, personne ne répond à ton message alors que les autres échangent. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me dis que je dérange et je me retire.", "J'envoie un autre signe pour qu'on me voie.", "J'ai honte d'avoir écrit.", "Je me demande si on me cache quelque chose.", "Je trouve injuste qu'on réponde aux autres et pas à moi."],
            soulAxes)
    })

    bank.Push({
        id: "Q-SOUL-ABANDON-01", path: "prima_soul", test_type: "soul", primary_axis: "abandon",
        environment: "amour", target: "partenaire", trigger: "depart_sans_nouvelles",
        context: "amour", category: "partenaire", signal_type: "emotion",
        prompt: "Ton partenaire part une semaine en voyage et ne t'envoie aucune nouvelle le premier jour. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me ferme pour ne pas le/la harceler.", "J'ai peur qu'il/elle m'oublie déjà.", "Je me sens bête d'attendre un signe.", "Je me demande s'il/elle cache quelque chose.", "Je trouve injuste qu'il/elle ne pense pas à me rassurer."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-ABANDON-02", path: "prima_soul", test_type: "soul", primary_axis: "abandon",
        environment: "famille", target: "mere", trigger: "appel_promise_non_tenu",
        context: "famille", category: "mere", signal_type: "besoin",
        prompt: "Ta mère promet de t'appeler le soir et la soirée passe sans nouvelles. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me dis que je ne suis pas sa priorité.", "Je reste disponible au téléphone en espérant qu'elle appelle.", "Je me sens enfant à attendre ainsi.", "Je me demande si elle évite un sujet.", "Je trouve injuste qu'elle ne tienne pas sa promesse."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-ABANDON-03", path: "prima_soul", test_type: "soul", primary_axis: "abandon",
        environment: "travail", target: "collegue", trigger: "aide_promise_disparue",
        context: "travail", category: "collegue", signal_type: "comportement",
        prompt: "Un collègue t'avait promis de t'aider sur un dossier urgent et disparaît toute la journée. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me débrouille seul sans le relancer.", "Je cherche quelqu'un d'autre pour ne pas rester seul face au dossier.", "Je me sens naïf d'avoir compté sur lui.", "Je me demande s'il m'a menti exprès.", "Je trouve injuste de porter seul ce qu'on avait partagé."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-ABANDON-04", path: "prima_soul", test_type: "soul", primary_axis: "abandon",
        environment: "amitie", target: "ami_proche", trigger: "annulation_derniere_minute",
        context: "amitie", category: "ami_proche", signal_type: "repetition",
        prompt: "Un ami proche annule un rendez-vous important à la dernière minute sans proposer de date. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je coupe court et je ne montre rien.", "J'ai besoin qu'il me dise qu'on se reverra vite.", "Je me sens bête d'avoir compté dessus.", "Je me demande s'il préfère quelqu'un d'autre.", "Je trouve injuste qu'il ne compense pas son annulation."],
            soulAxes)
    })

    bank.Push({
        id: "Q-SOUL-HUMIL-01", path: "prima_soul", test_type: "soul", primary_axis: "humiliation",
        environment: "travail", target: "chef", trigger: "correction_publique",
        context: "travail", category: "chef", signal_type: "interaction",
        prompt: "En réunion, ton chef corrige ton travail devant toute l'équipe. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je voudrais disparaître de la salle.", "J'ai besoin qu'un collègue me soutienne après.", "Je rougis et j'ai honte de mon erreur.", "Je me méfie de ses intentions en me corrigeant ainsi.", "Je trouve injuste d'être exposé plutôt que guidé en privé."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-HUMIL-02", path: "prima_soul", test_type: "soul", primary_axis: "humiliation",
        environment: "famille", target: "proche", trigger: "moquerie_expression",
        context: "famille", category: "proche", signal_type: "emotion",
        prompt: "À table en famille, quelqu'un rit ouvertement de ta façon de t'exprimer. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me tais pour ne plus attirer l'attention.", "Je cherche un regard qui me rassure.", "Je me sens ridicule et petit.", "Je me demande s'ils se moquent aussi quand je pars.", "Je trouve injuste qu'on me rabaisse devant les autres."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-HUMIL-03", path: "prima_soul", test_type: "soul", primary_axis: "humiliation",
        environment: "famille", target: "enfant", trigger: "contradiction_publique",
        context: "famille", category: "enfant", signal_type: "comportement",
        prompt: "Ton enfant te contredit fermement devant des invités sur un sujet personnel. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me replie pour ne pas envenimer.", "J'ai besoin qu'un proche prenne ma défense.", "Je me sens humilié en tant que parent.", "Je me demande s'il le fait exprès pour me nuire.", "Je trouve injuste d'être attaqué devant tout le monde."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-HUMIL-04", path: "prima_soul", test_type: "soul", primary_axis: "humiliation",
        environment: "travail", target: "collegue", trigger: "erreur_visible",
        context: "travail", category: "collegue", signal_type: "perception",
        prompt: "Un collègue signale une erreur visible sur ta présentation devant le client. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me contracte et je me fais tout petit.", "Je cherche un allié dans la salle.", "J'ai honte de mon travail.", "Je me demande s'il l'a fait pour briller.", "Je trouve injuste qu'il m'expose au lieu de m'aider."],
            soulAxes)
    })

    bank.Push({
        id: "Q-SOUL-TRAH-01", path: "prima_soul", test_type: "soul", primary_axis: "trahison",
        environment: "amitie", target: "confident", trigger: "secret_revele",
        context: "amitie", category: "confident", signal_type: "interaction",
        prompt: "Un proche répète un secret que tu lui avais confié en toute confiance. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me coupe du groupe pour me protéger.", "J'ai besoin de savoir si le lien peut tenir.", "Je me sens bête d'avoir parlé.", "Je ne veux plus faire confiance à personne ici.", "Je trouve injuste qu'on ne respecte pas ce qu'on m'avait promis."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-TRAH-02", path: "prima_soul", test_type: "soul", primary_axis: "trahison",
        environment: "travail", target: "associe", trigger: "accord_sans_consultation",
        context: "travail", category: "associe", signal_type: "comportement",
        prompt: "Ton associé conclut un accord important sans te consulter. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me retire du fil de décision.", "J'ai besoin qu'il me dise que je compte encore.", "Je me sens diminué publiquement.", "Je ne lui fais plus confiance sur les prochains dossiers.", "Je trouve injuste qu'il décide seul de notre engagement."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-TRAH-03", path: "prima_soul", test_type: "soul", primary_axis: "trahison",
        environment: "amitie", target: "ami", trigger: "parole_en_absence",
        context: "amitie", category: "ami", signal_type: "perception",
        prompt: "Tu apprends qu'un ami a parlé de toi en ton absence avec des détails que tu n'aurais pas partagés. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me mets à distance sans confrontation.", "J'ai besoin qu'il me rassure sur notre lien.", "Je me sens exposé et ridicule.", "Je vérifie tout ce qu'il pourrait encore dire.", "Je trouve injuste qu'il use de ma confiance ainsi."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-TRAH-04", path: "prima_soul", test_type: "soul", primary_axis: "trahison",
        environment: "travail", target: "collaborateur", trigger: "travail_modifie_sans_avis",
        context: "travail", category: "collaborateur", signal_type: "repetition",
        prompt: "Quelqu'un de confiance modifie ton travail sans te prévenir et le présente comme sien. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me retire et je laisse faire.", "J'ai besoin d'un témoin qui connaît la vérité.", "Je me sens humilié dans mon métier.", "Je ne lui confierai plus rien d'important.", "Je trouve injuste qu'il s'approprie ce que j'ai produit."],
            soulAxes)
    })

    bank.Push({
        id: "Q-SOUL-INJUST-01", path: "prima_soul", test_type: "soul", primary_axis: "injustice",
        environment: "travail", target: "collegue", trigger: "promotion_inmeritee",
        context: "travail", category: "collegue", signal_type: "contexte",
        prompt: "Au travail, un collègue clairement moins impliqué que toi reçoit la promotion. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me replie et j'en parle à personne.", "J'ai besoin qu'un supérieur reconnaisse mon travail.", "Je me sens diminué et ridicule.", "Je me demande qui a trahi ma contribution.", "Je crie injustice intérieurement."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-INJUST-02", path: "prima_soul", test_type: "soul", primary_axis: "injustice",
        environment: "famille", target: "frere", trigger: "punition_inegale",
        context: "famille", category: "frere", signal_type: "repetition",
        prompt: "En famille, ton frère échappe à une punition que tu as reçue pour la même faute. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me ferme et j'accepte en silence.", "J'ai besoin qu'un parent me prenne enfin au sérieux.", "Je me sens humilié d'être traité différemment.", "Je me méfie des promesses qu'on me fait.", "Je réagis vivement parce que ce n'est pas juste."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-INJUST-03", path: "prima_soul", test_type: "soul", primary_axis: "injustice",
        environment: "travail", target: "equipe", trigger: "faute_imputee",
        context: "travail", category: "equipe", signal_type: "interaction",
        prompt: "On te reproche en réunion une erreur commise par quelqu'un d'autre de l'équipe. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me tais pour ne pas créer de conflit.", "Je cherche un allié qui connaît la vérité.", "J'ai honte d'être montré du doigt.", "Je me demande qui m'a trahi.", "Je réagis parce que ce n'est pas juste."],
            soulAxes)
    })
    bank.Push({
        id: "Q-SOUL-INJUST-04", path: "prima_soul", test_type: "soul", primary_axis: "injustice",
        environment: "famille", target: "proches", trigger: "regles_differentes",
        context: "famille", category: "proches", signal_type: "comportement",
        prompt: "Les règles changent pour toi mais pas pour les autres membres de la famille. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankSoulAnswers(
            ["Je me coupe pour éviter le conflit.", "J'ai besoin qu'on me dise que je compte pareil.", "Je me sens rabaissé par ce double standard.", "Je ne fais plus confiance aux décisions prises.", "Je conteste parce que ce n'est pas équitable."],
            soulAxes)
    })

    ; ── VDA — 24 questions (4 par type PCM), rank 6 ──
    ; Base (12)
    bank.Push({
        id: "Q-VDA-ANAL-01", path: "prima_vda", test_type: "vda", primary_axis: "analyseur", vda_section: "base",
        environment: "travail", target: "nouveau_projet", trigger: "demarrage_equipe",
        context: "travail", category: "nouveau_projet", signal_type: "environnement",
        prompt: "Tu intègres une nouvelle équipe sur un projet complexe. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Comprendre vite les règles, les étapes et qui fait quoi.", "Savoir que le projet a du sens et des standards clairs.", "Sentir une ambiance humaine où l'on m'explique les choses.", "Avoir le temps d'observer avant d'être sollicité.", "Sentir de l'énergie et des échanges spontanés.", "Voir des objectifs concrets à atteindre rapidement."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-ANAL-02", path: "prima_vda", test_type: "vda", primary_axis: "analyseur", vda_section: "base",
        environment: "quotidien", target: "organisation", trigger: "semaine_chargee",
        context: "quotidien", category: "organisation", signal_type: "besoin",
        prompt: "Ta semaine est surchargée et tout arrive en même temps. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Mettre de l'ordre, prioriser et structurer.", "Garder le cap sur ce qui compte vraiment.", "Ne pas perdre le contact humain en courant.", "Prendre du recul avant de m'engager partout.", "Garder du mouvement et de la légèreté.", "Choisir ce qui rapporte le plus vite."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-PER-01", path: "prima_vda", test_type: "vda", primary_axis: "perseverant", vda_section: "base",
        environment: "travail", target: "mission", trigger: "doute_valeurs",
        context: "travail", category: "mission", signal_type: "force",
        prompt: "On te propose une mission lucrative mais en décalage avec ce que tu défends. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Analyser les risques et les faits avant de décider.", "Refuser si ça contredit mes convictions.", "Vérifier l'impact humain sur les personnes touchées.", "Prendre du temps seul pour clarifier.", "Tester si on peut l'ajuster avec humour et créativité.", "Saisir l'opportunité si le gain est net."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-PER-02", path: "prima_vda", test_type: "vda", primary_axis: "perseverant", vda_section: "base",
        environment: "famille", target: "proches", trigger: "desaccord_principe",
        context: "famille", category: "proches", signal_type: "interaction",
        prompt: "Tes proches prennent une décision qui heurte un principe important pour toi. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Demander des explications précises sur leurs choix.", "Tenir bon sur ce qui me semble juste.", "Essayer de préserver le lien malgré le désaccord.", "Me retirer un moment pour ne pas exploser.", "Détendre l'atmosphère pour rouvrir le dialogue.", "Proposer une solution rapide pour trancher."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-EMP-01", path: "prima_vda", test_type: "vda", primary_axis: "empathique", vda_section: "base",
        environment: "amitie", target: "ami", trigger: "detresse_silencieuse",
        context: "amitie", category: "ami", signal_type: "perception",
        prompt: "Un ami proche semble ailleurs depuis plusieurs jours sans rien dire. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Chercher des indices concrets sur ce qui se passe.", "Me demander si j'ai respecté mes engagements envers lui.", "M'approcher avec douceur pour qu'il se sente en sécurité.", "Lui laisser de l'espace tout en restant disponible.", "L'inviter à faire quelque chose de léger ensemble.", "Lui proposer une sortie ou une action pour le relancer."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-EMP-02", path: "prima_vda", test_type: "vda", primary_axis: "empathique", vda_section: "base",
        environment: "travail", target: "equipe", trigger: "tension_collective",
        context: "travail", category: "equipe", signal_type: "communication",
        prompt: "L'équipe est tendue après une mauvaise nouvelle commune. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Clarifier les faits pour éviter les rumeurs.", "Rappeler ce qui est juste et acceptable pour tous.", "Prendre soin de chacun avant de parler stratégie.", "Laisser retomber la pression avant d'en parler.", "Remonter le moral avec de l'énergie positive.", "Proposer un plan d'action immédiat."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-IMA-01", path: "prima_vda", test_type: "vda", primary_axis: "imagineur", vda_section: "base",
        environment: "travail", target: "open_space", trigger: "bruit_constant",
        context: "travail", category: "open_space", signal_type: "environnement",
        prompt: "Tu dois produire un travail de fond dans un open space bruyant toute la journée. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Organiser mon espace et mes outils pour limiter le chaos.", "Refuser de travailler dans des conditions qui trahissent mes standards.", "Chercher un coin calme où l'on me laisse tranquille.", "Me retirer mentalement jusqu'à retrouver ma concentration.", "Transformer le bruit en énergie créative.", "Aller vite pour finir et sortir de là."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-IMA-02", path: "prima_vda", test_type: "vda", primary_axis: "imagineur", vda_section: "base",
        environment: "quotidien", target: "soi", trigger: "sollicitation_continue",
        context: "quotidien", category: "soi", signal_type: "besoin",
        prompt: "On te sollicite sans interruption depuis le matin. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Prioriser et cadre les demandes une par une.", "Protéger ce qui compte vraiment pour moi.", "Répondre aux autres sans me perdre.", "Couper le flux pour respirer seul.", "Enchaîner avec légèreté pour ne pas alourdir.", "Régler le plus urgent et avancer."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-ENR-01", path: "prima_vda", test_type: "vda", primary_axis: "energiseur", vda_section: "base",
        environment: "amitie", target: "soiree", trigger: "ambiance_plate",
        context: "amitie", category: "soiree", signal_type: "interaction",
        prompt: "La soirée traîne et l'ambiance retombe chez des amis. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Proposer un jeu ou une activité structurée.", "Rappeler pourquoi on est là ensemble.", "M'occuper de celui qui semble isolé.", "Laisser la soirée suivre son cours sans forcer.", "Relancer avec humour et spontanéité.", "Sortir quelque chose de plus intense ou inédit."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-ENR-02", path: "prima_vda", test_type: "vda", primary_axis: "energiseur", vda_section: "base",
        environment: "travail", target: "reunion", trigger: "lenteur_collective",
        context: "travail", category: "reunion", signal_type: "communication",
        prompt: "Une réunion importante s'enlise sur des détails sans avancer. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Reformuler l'ordre du jour pour clarifier.", "Rappeler l'objectif et ce qui est non négociable.", "Sentir si le groupe a besoin d'être entendu.", "Proposer une pause pour laisser digérer.", "Relancer avec une idée surprenante.", "Pousser pour décider maintenant."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-PRO-01", path: "prima_vda", test_type: "vda", primary_axis: "promoteur", vda_section: "base",
        environment: "travail", target: "opportunite", trigger: "decision_rapide",
        context: "travail", category: "opportunite", signal_type: "force",
        prompt: "Une opportunité intéressante exige une réponse avant ce soir. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Vérifier les chiffres et les contraintes avant de signer.", "M'assurer que ça respecte mes lignes rouges.", "Consulter une personne de confiance.", "Prendre une nuit de réflexion si possible.", "Tester l'eau avec une proposition audacieuse.", "Saisir le créneau avant que ça parte ailleurs."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-PRO-02", path: "prima_vda", test_type: "vda", primary_axis: "promoteur", vda_section: "base",
        environment: "quotidien", target: "projet_personnel", trigger: "peur_rater",
        context: "quotidien", category: "projet_personnel", signal_type: "stress",
        prompt: "Tu hésites à lancer un projet personnel qui te tient à cœur. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Préparer un plan réaliste avant de commencer.", "M'assurer que ça correspond à qui je suis.", "Partager l'idée avec quelqu'un qui me soutient.", "Rêver et affiner seul avant d'agir.", "Commencer par une version fun et légère.", "Foncer sur une première action visible."],
            vdaKeys)
    })

    ; Phase (12)
    bank.Push({
        id: "Q-VDA-ANAL-03", path: "prima_vda", test_type: "vda", primary_axis: "analyseur", vda_section: "phase",
        environment: "travail", target: "chef", trigger: "critique_imprevue",
        context: "travail", category: "chef", signal_type: "stress",
        prompt: "Sous pression, ton chef te reproche un oubli devant d'autres personnes. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Corriger avec précision et reprendre le contrôle des faits.", "Me raidir sur ce qui est juste ou injuste dans sa façon de faire.", "Avoir mal au ton utilisé plus qu'au fond.", "Me fermer et traiter le reste plus tard seul.", "Répondre vivement pour défendre ma réputation.", "Contre-attaquer en proposant une solution immédiate."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-ANAL-04", path: "prima_vda", test_type: "vda", primary_axis: "analyseur", vda_section: "phase",
        environment: "quotidien", target: "imprevu", trigger: "plan_bouscule",
        context: "quotidien", category: "imprevu", signal_type: "phase",
        prompt: "Un imprévu majeur bouleverse ton planning de la journée. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Recalculer tout méthodiquement.", "Me demander si j'accepte ce décalage avec mes valeurs.", "Chercher qui peut m'aider à tenir.", "Me retirer un instant pour reprendre pied.", "Improviser avec énergie.", "Prendre la décision la plus rapide possible."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-PER-03", path: "prima_vda", test_type: "vda", primary_axis: "perseverant", vda_section: "phase",
        environment: "travail", target: "direction", trigger: "consigne_ambigue",
        context: "travail", category: "direction", signal_type: "phase",
        prompt: "La direction envoie une consigne floue qui contredit ce qui avait été annoncé. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Demander par écrit une clarification précise.", "Refuser intérieurement tant que ce n'est pas cohérent.", "Vérifier l'impact sur l'équipe avant d'obéir.", "Attendre de voir comment ça se stabilise.", "En rire pour détendre l'atmosphère.", "Appliquer la version la plus avantageuse tout de suite."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-PER-04", path: "prima_vda", test_type: "vda", primary_axis: "perseverant", vda_section: "phase",
        environment: "famille", target: "proches", trigger: "compromis_force",
        context: "famille", category: "proches", signal_type: "stress",
        prompt: "On te pousse à faire un compromis familial que tu trouves profondément injuste. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Lister calmement les faits qui posent problème.", "Tenir ta position coûte que coûte.", "Essayer de préserver la paix sans trahir tout le monde.", "Te retirer de la discussion.", "Détourner avec humour pour éviter l'explosion.", "Trancher vite pour en finir."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-EMP-03", path: "prima_vda", test_type: "vda", primary_axis: "empathique", vda_section: "phase",
        environment: "amour", target: "partenaire", trigger: "distance_soudaine",
        context: "amour", category: "partenaire", signal_type: "phase",
        prompt: "Ton partenaire devient distant sans explication après une période proche. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Analyser les changements concrets dans son comportement.", "Me demander si j'ai trahi une promesse implicite.", "Lui dire que j'ai peur de le/la perdre.", "Me replier en attendant qu'il/elle revienne.", "Proposer une sortie légère pour recréer du lien.", "Confronter directement pour savoir où on en est."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-EMP-04", path: "prima_vda", test_type: "vda", primary_axis: "empathique", vda_section: "phase",
        environment: "travail", target: "collegue", trigger: "erreur_publiee",
        context: "travail", category: "collegue", signal_type: "phase",
        prompt: "Un collègue commet une erreur visible et se referme immédiatement. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Corriger les faits pour limiter les dégâts.", "Rappeler les règles que tout le monde doit respecter.", "Aller vers lui pour qu'il ne se sente pas seul.", "Le laisser digérer avant d'en parler.", "Détendre l'ambiance pour qu'il respire.", "Prendre le relais pour que le dossier avance."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-IMA-03", path: "prima_vda", test_type: "vda", primary_axis: "imagineur", vda_section: "phase",
        environment: "travail", target: "reunion", trigger: "sollicitation_immediate",
        context: "travail", category: "reunion", signal_type: "phase",
        prompt: "En pleine réunion tendue, on te demande ton avis sans t'avoir laissé préparer. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Demander une minute pour structurer ma réponse.", "Répondre selon mes principes même sous pression.", "Parler d'abord de l'impact humain.", "Dire que j'ai besoin de réfléchir hors réunion.", "Répondre avec spontanéité pour débloquer.", "Donner une réponse tranchée pour avancer."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-IMA-04", path: "prima_vda", test_type: "vda", primary_axis: "imagineur", vda_section: "phase",
        environment: "quotidien", target: "soi", trigger: "surcharge_emotionnelle",
        context: "quotidien", category: "soi", signal_type: "phase",
        prompt: "Tu sens la surcharge monter après une journée dense en interactions. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Lister ce qui reste à faire demain.", "Me demander si j'ai dépassé mes limites justes.", "Appeler quelqu'un qui me comprend.", "Couper les écrans et me isoler.", "Sortir ou bouger pour évacuer.", "Finir une dernière tâche pour clore la journée."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-ENR-03", path: "prima_vda", test_type: "vda", primary_axis: "energiseur", vda_section: "phase",
        environment: "travail", target: "equipe", trigger: "mauvaise_nouvelle",
        context: "travail", category: "equipe", signal_type: "phase",
        prompt: "L'équipe apprend qu'un objectif important est compromis. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Analyser ce qui a failli et ce qu'il reste.", "Dénoncer ce qui n'était pas acceptable.", "Prendre soin de ceux qui sont secoués.", "Me retirer pour digérer seul.", "Relancer le groupe avec une énergie nouvelle.", "Proposer un pari ou un défi pour rebondir."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-ENR-04", path: "prima_vda", test_type: "vda", primary_axis: "energiseur", vda_section: "phase",
        environment: "famille", target: "proches", trigger: "conflit_ouvert",
        context: "famille", category: "proches", signal_type: "phase",
        prompt: "Un conflit familial éclate ouvertement pendant un repas. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Recadrer les faits pour stopper les dérives.", "Rappeler ce qui devrait être respecté.", "Apaiser celui qui souffre le plus.", "Me taire et attendre que ça retombe.", "Détourner avec humour ou une anecdote.", "Trancher fort pour couper court."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-PRO-03", path: "prima_vda", test_type: "vda", primary_axis: "promoteur", vda_section: "phase",
        environment: "travail", target: "client", trigger: "deadline_impossible",
        context: "travail", category: "client", signal_type: "phase",
        prompt: "Un client exige une livraison impossible dans les délais annoncés. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "high", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Recalculer ce qui est faisable avec rigueur.", "Refuser ce qui trahit nos engagements.", "Expliquer l'impact sur l'équipe.", "Gagner du temps pour repenser l'approche.", "Proposer une variante créative immédiate.", "Accepter le défi et foncer."],
            vdaKeys)
    })
    bank.Push({
        id: "Q-VDA-PRO-04", path: "prima_vda", test_type: "vda", primary_axis: "promoteur", vda_section: "phase",
        environment: "quotidien", target: "decision", trigger: "peur_regret",
        context: "quotidien", category: "decision", signal_type: "phase",
        prompt: "Tu dois choisir entre sécurité et un saut risqué qui t'attire. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 6,
        answers: PrimaBankVdaAnswers(
            ["Comparer scénarios et conséquences.", "Vérifier si le risque contredit mes valeurs.", "Demander conseil à quelqu'un de proche.", "Rêver du meilleur scénario avant de trancher.", "Tester une petite version du saut.", "Foncer avant de me parler out."],
            vdaKeys)
    })

    ; ── SHADOW tension — 14 questions (2 par axe), rank 7 ──
    bank.Push({
        id: "Q-SHADOW-TEN-ORG-01", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "orgueil",
        environment: "travail", target: "equipe", trigger: "merite_non_reconnu",
        context: "travail", category: "equipe", signal_type: "stress",
        prompt: "En réunion, ton idée est ignorée puis reprise par quelqu'un d'autre sans mention de ta part. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je montre que je savais déjà et que je suis au niveau.", "Je regarde qui est valorisé à ma place.", "Je sens la colère monter vite.", "Je me désengage et laisse faire.", "Je retiens mon énergie pour ne plus donner gratuitement.", "Je compense en faisant autre chose de plaisant.", "Je cherche une victoire ailleurs pour me sentir puissant."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-ORG-02", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "orgueil",
        environment: "famille", target: "proches", trigger: "critique_publique",
        context: "famille", category: "proches", signal_type: "interaction",
        prompt: "Un proche te corrige devant d'autres personnes sur un sujet que tu maîtrises. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je rétablis ma compétence immédiatement.", "Je compare avec ce qu'on reconnaît chez les autres.", "J'explose intérieurement.", "Je me ferme et j'abandonne le sujet.", "Je garde mes preuves pour moi désormais.", "Je passe à autre chose de plus agréable.", "Je dramatise pour reprendre le contrôle."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-ENV-01", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "envie",
        environment: "numerique", target: "reseau_social", trigger: "reussite_autrui",
        context: "numerique", category: "reseau_social", signal_type: "perception",
        prompt: "Tu vois la réussite d'un pair affichée partout en ligne alors que tu stagnes. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je me persuade que je vaux mieux qu'on ne le voit.", "Je calcule ce qu'il a que je n'ai pas.", "Je m'agace contre la situation.", "Je scroll sans agir.", "Je protège ce que j'ai déjà.", "Je me console avec un plaisir rapide.", "Je fantasme une montée en puissance immédiate."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-ENV-02", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "envie",
        environment: "travail", target: "collegue", trigger: "avantage_injuste",
        context: "travail", category: "collegue", signal_type: "contexte",
        prompt: "Un collègue obtient un avantage visible sans effort apparent de ton point de vue. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je prouve ma supériorité ailleurs.", "Je pense sans cesse à ce qu'il a reçu.", "Je rumine avec irritation.", "Je baisse les bras sur ce dossier.", "Je retiens mon aide et mon temps.", "Je me récompense autrement.", "Je cherche un raccourci plus excitant."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-COL-01", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "colere",
        environment: "travail", target: "client", trigger: "retard_repete",
        context: "travail", category: "client", signal_type: "interaction",
        prompt: "Un client te fait attendre une heure puis minimise ton temps. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je montre que je ne me laisse pas marcher dessus.", "Je pense à d'autres clients mieux traités.", "Je réponds sèchement sur-le-champ.", "Je repousse la suite à plus tard.", "Je facture chaque minute désormais.", "Je me calme avec un petit plaisir.", "Je cherche une confrontation nette."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-COL-02", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "colere",
        environment: "famille", target: "proche", trigger: "promesse_non_tenue",
        context: "famille", category: "proche", signal_type: "repetition",
        prompt: "Un proche oublie encore une promesse simple qui comptait pour toi. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je le mets face à sa responsabilité.", "Je pense à ceux qui reçoivent plus de lui.", "Je lâche prise en parlant sec.", "Je n'insiste plus.", "Je garde mes efforts pour moi.", "Je m'apaise autrement.", "Je provoque une scène pour qu'il réagisse."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-PAR-01", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "paresse",
        environment: "travail", target: "tache", trigger: "travail_repetitif",
        context: "travail", category: "tache", signal_type: "comportement",
        prompt: "Une tâche importante mais répétitive traîne depuis des jours sur ton bureau. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je la refais parfaitement pour prouver que je peux.", "Je pense à d'autres projets plus stimulants.", "Je m'irrite contre moi-même.", "Je repousse encore une fois.", "Je ne donne que le strict minimum.", "Je me distrais avec autre chose d'agréable.", "Je cherche une montée d'adrénaline pour me lancer."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-PAR-02", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "paresse",
        environment: "quotidien", target: "corvee", trigger: "effort_evite",
        context: "quotidien", category: "corvee", signal_type: "besoin",
        prompt: "Une corvée nécessaire te pèse alors que tu sais qu'elle ne peut pas attendre. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je la fais impeccablement pour ne pas être jugé.", "Je pense à ceux qui semblent s'en sortir sans.", "Je m'énerve intérieurement.", "Je la repousse au dernier moment.", "Je fais le minimum vital.", "Je m'offre d'abord un réconfort.", "Je cherche une échappatoire plus intense."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-AVA-01", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "avarice",
        environment: "famille", target: "proches", trigger: "demande_financiere",
        context: "famille", category: "proches", signal_type: "interaction",
        prompt: "Un proche te demande de l'aide financière sans garantie de remboursement. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je montre que je gère mieux que lui.", "Je pense à ce qu'il dépense ailleurs.", "Je réponds avec dureté.", "Je repousse la discussion.", "Je serre ce que j'ai encore plus fort.", "Je compense mon malaise par un achat.", "Je cherche un deal qui me profite."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-AVA-02", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "avarice",
        environment: "travail", target: "equipe", trigger: "partage_ressources",
        context: "travail", category: "equipe", signal_type: "comportement",
        prompt: "On te demande de partager une ressource rare que tu as mis du temps à obtenir. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je montre que j'ai su la mériter.", "Je regarde qui en profite sans effort.", "Je m'agace de devoir céder.", "Je reporte le partage.", "Je garde l'essentiel pour moi.", "Je me récompense pour ce que j'ai donné.", "Je négocie un retour immédiat."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-GOU-01", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "gourmandise",
        environment: "quotidien", target: "soi", trigger: "journee_difficile",
        context: "quotidien", category: "soi", signal_type: "emotion",
        prompt: "Après une journée difficile, tu rentres épuisé sans avoir mangé correctement. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je me prouve que je tiens quand même.", "Je pense à ceux qui ont eu une journée plus légère.", "Je m'énerve contre tout.", "Je m'effondre devant un écran.", "Je garde mes réserves pour demain.", "Je m'envoie un réconfort immédiat.", "Je cherche une sensation forte pour oublier."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-GOU-02", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "gourmandise",
        environment: "amitie", target: "soiree", trigger: "tentation_exces",
        context: "amitie", category: "soiree", signal_type: "comportement",
        prompt: "En soirée, tout est disponible en abondance alors que tu avais prévu modération. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je montre que je maîtrise ma réputation.", "Je regarde ce que les autres se permettent.", "Je m'irrite si on me commente.", "Je laisse faire sans choisir.", "Je limite ce que je donne aux autres.", "Je profite sans compter.", "Je cherche l'excès qui me réveille."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-LUX-01", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "luxure",
        environment: "amour", target: "partenaire", trigger: "distance_physique",
        context: "amour", category: "partenaire", signal_type: "besoin",
        prompt: "Ton partenaire est distant physiquement depuis plusieurs semaines sans explication claire. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je montre que je n'ai pas besoin de lui/elle.", "Je pense à d'autres couples plus fusionnels.", "Je réagis avec dureté.", "Je me retire dans l'indifférence.", "Je protège mon cœur et mon corps.", "Je compense avec d'autres plaisirs.", "Je cherche l'intensité ailleurs."],
            shadowTenKeys)
    })
    bank.Push({
        id: "Q-SHADOW-TEN-LUX-02", path: "prima_shadow", test_type: "shadow", shadow_kind: "tension", primary_axis: "luxure",
        environment: "quotidien", target: "soi", trigger: "ennui_profond",
        context: "quotidien", category: "soi", signal_type: "repetition",
        prompt: "Une période de routine te laisse insatisfait malgré une vie stable en apparence. Sur le moment, avant de réfléchir, qu'est-ce qui te ressemble le plus ?",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 7,
        answers: PrimaBankShadowTensionAnswers(
            ["Je prouve que je vaux plus que cette routine.", "Je compare ma vie à des vies plus vibrantes.", "Je m'agace facilement.", "Je m'engourdis et j'attends.", "Je retiens mes envies et mes ressources.", "Je multiplie les petits plaisirs.", "Je fantasme un choc ou une aventure."],
            shadowTenKeys)
    })

    ; ── SHADOW emotion — 5 questions (rank 5 émotions) ──
    bank.Push({
        id: "Q-SHADOW-EMO-01", path: "prima_shadow", test_type: "shadow", shadow_kind: "emotion", primary_axis: "peur",
        environment: "quotidien", target: "matin", trigger: "reveil_lourd",
        context: "quotidien", category: "matin", signal_type: "emotion",
        prompt: "Tu te réveilles avec une boule au ventre avant une journée importante. Classe du plus au moins présent sur le moment.",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 5,
        answers: PrimaBankShadowEmotionAnswers(
            ["La peur que quelque chose dérape.", "Une tristesse diffuse sans cause nette.", "Une colère prête à sortir.", "La honte d'être jugé.", "Une joie fragile malgré tout."],
            shadowEmoKeys)
    })
    bank.Push({
        id: "Q-SHADOW-EMO-02", path: "prima_shadow", test_type: "shadow", shadow_kind: "emotion", primary_axis: "tristesse",
        environment: "amour", target: "partenaire", trigger: "apres_dispute",
        context: "amour", category: "partenaire", signal_type: "emotion",
        prompt: "Juste après une dispute avec ton partenaire, quelles émotions dominent ? Classe du plus au moins présent.",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankShadowEmotionAnswers(
            ["La peur que le lien se fissure.", "Une tristesse qui s'installe.", "Une colère qui tourne.", "La honte de ce que j'ai dit.", "Un soulagement d'avoir parlé."],
            shadowEmoKeys)
    })
    bank.Push({
        id: "Q-SHADOW-EMO-03", path: "prima_shadow", test_type: "shadow", shadow_kind: "emotion", primary_axis: "colere",
        environment: "travail", target: "reunion", trigger: "avant_expose",
        context: "travail", category: "reunion", signal_type: "emotion",
        prompt: "Dix minutes avant un exposé devant des personnes qui te jugent, quelles émotions montent ? Classe du plus au moins présent.",
        active: 1, language: "fr", weight: "normal", intensity: "medium", max_choices: 5,
        answers: PrimaBankShadowEmotionAnswers(
            ["La peur de rater.", "Une lassitude d'avance.", "Une colère contre la pression.", "La honte d'être exposé.", "Une excitation qui monte."],
            shadowEmoKeys)
    })
    bank.Push({
        id: "Q-SHADOW-EMO-04", path: "prima_shadow", test_type: "shadow", shadow_kind: "emotion", primary_axis: "honte",
        environment: "famille", target: "souvenirs", trigger: "reviviscence_passe",
        context: "famille", category: "souvenirs", signal_type: "emotion",
        prompt: "En repensant à un moment gênant de ton passé familial, quelles émotions reviennent ? Classe du plus au moins présent.",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 5,
        answers: PrimaBankShadowEmotionAnswers(
            ["La peur que ça se répète.", "Une nostalgie qui serre.", "Une colère contre ce qui s'est passé.", "La honte de ce moment.", "Une gratitude pour ce qui a aussi été beau."],
            shadowEmoKeys)
    })
    bank.Push({
        id: "Q-SHADOW-EMO-05", path: "prima_shadow", test_type: "shadow", shadow_kind: "emotion", primary_axis: "joie",
        environment: "quotidien", target: "semaine", trigger: "bilan_emotionnel",
        context: "quotidien", category: "semaine", signal_type: "emotion",
        prompt: "En faisant le bilan de ta semaine, quelles émotions reviennent le plus souvent ? Classe du plus au moins présent.",
        active: 1, language: "fr", weight: "normal", intensity: "low", max_choices: 5,
        answers: PrimaBankShadowEmotionAnswers(
            ["L'inquiétude persistante.", "Un fond de tristesse.", "Une irritabilité facile.", "Le doute sur ma valeur.", "Des éclats de joie simple."],
            shadowEmoKeys)
    })

    return bank
}
