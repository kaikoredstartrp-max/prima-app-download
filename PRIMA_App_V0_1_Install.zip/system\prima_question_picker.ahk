#Requires AutoHotkey v2.0
; PRIMA question picker - balanced sets + stable seeded shuffle (V0.1 surgical bank)

PrimaQuestionBankVersion() {
    return "v0.1_surgical"
}

PrimaTestTypeFromPath(path) {
    switch path {
        case "prima_soul": return "soul"
        case "prima_vda": return "vda"
        case "prima_shadow": return "shadow"
    }
    return ""
}

PrimaQuestionIsActive(q) {
    if (q.HasOwnProp("active") && !q.active)
        return false
    return true
}

PrimaHashSeed(seed) {
    h := 0
    for c in StrSplit(seed, "")
        h := Mod(h * 31 + Ord(c), 2147483647)
    return h = 0 ? 1 : h
}

PrimaSeededRandom(&state, min, max) {
    state := Mod(state * 48271, 2147483647)
    return min + Mod(state, max - min + 1)
}

PrimaShuffleArraySeeded(arr, seed) {
    if !(arr is Array) || arr.Length < 2
        return arr
    state := PrimaHashSeed(seed)
    i := arr.Length
    while (i > 1) {
        j := PrimaSeededRandom(&state, 1, i)
        tmp := arr[i]
        arr[i] := arr[j]
        arr[j] := tmp
        i--
    }
    return arr
}

PrimaShuffleAnswersSeeded(q, seed) {
    shuffled := []
    for a in q.answers
        shuffled.Push(a)
    return PrimaShuffleArraySeeded(shuffled, seed "_ans")
}

PrimaQuestionSessionIndex(session, qid) {
    if !(session.HasOwnProp("questions"))
        return 0
    loop session.questions.Length {
        if (session.questions[A_Index].id = qid) {
            q := session.questions[A_Index]
            if (q.HasOwnProp("session_index"))
                return q.session_index
            return A_Index
        }
    }
    if RegExMatch(qid, "^vda_pcm_(\d+)$", &m)
        return Integer(m[1])
    if RegExMatch(qid, "^shadow_(\d+)$", &m)
        return Integer(m[1])
    return 0
}

PrimaActivePoolForTestType(testType) {
    pool := []
    for q in GetSoulQuestionBank() {
        if (q.HasOwnProp("test_type") && q.test_type = testType && PrimaQuestionIsActive(q))
            pool.Push(q)
    }
    return pool
}

PrimaMakeQuestionSeed(profileId, testType) {
    pid := profileId != "" ? profileId : "anon"
    return pid "_" testType "_" FormatTime(, "yyyyMMddHHmmss") "_" Random(100000, 999999)
}

PrimaOrderQuestionIdsAvoidRepeats(ids, poolById, seed) {
    if (ids.Length < 2)
        return { ids: ids, repeat_warning: false }
    remaining := []
    for id in ids
        remaining.Push(poolById[id])
    ordered := []
    state := PrimaHashSeed(seed "_ord")
    lastEnv := ""
    lastTarget := ""
    repeatWarning := false
    while (remaining.Length > 0) {
        bestIdx := 0
        bestScore := -1
        for i, q in remaining {
            score := 0
            if (lastEnv != "" && q.environment = lastEnv)
                score -= 2
            if (lastTarget != "" && q.target = lastTarget)
                score -= 2
            if (q.HasOwnProp("intensity") && q.intensity = "high")
                score -= 1
            score += PrimaSeededRandom(&state, 0, 9)
            if (bestIdx = 0 || score > bestScore) {
                bestScore := score
                bestIdx := i
            }
        }
        q := remaining.RemoveAt(bestIdx)
        ordered.Push(q.id)
        if (lastEnv != "" && q.environment = lastEnv)
            repeatWarning := true
        if (lastTarget != "" && q.target = lastTarget)
            repeatWarning := true
        lastEnv := q.environment
        lastTarget := q.target
    }
    return { ids: ordered, repeat_warning: repeatWarning }
}

PickSoulQuestionIds(pool, seed) {
    axes := GetSoulVdaKeys()
    perAxis := 3
    picked := []
    for ax in axes {
        candidates := []
        for q in pool {
            if (q.primary_axis = ax)
                candidates.Push(q)
        }
        shuffled := candidates.Clone()
        PrimaShuffleArraySeeded(shuffled, seed "_soul_" ax)
        n := 0
        for q in shuffled {
            if (n >= perAxis)
                break
            picked.Push(q)
            n++
        }
    }
    byId := Map()
    ids := []
    for q in picked {
        ids.Push(q.id)
        byId[q.id] := q
    }
    return PrimaOrderQuestionIdsAvoidRepeats(ids, byId, seed)
}

PickVdaSectionIds(sectionPool, keys, seed, total, minPerType) {
    picked := []
    typeCount := Map()
    for k in keys
        typeCount[k] := 0
    shuffled := sectionPool.Clone()
    PrimaShuffleArraySeeded(shuffled, seed)
    for q in shuffled {
        if (picked.Length >= total)
            break
        picked.Push(q)
        if typeCount.Has(q.primary_axis)
            typeCount[q.primary_axis]++
    }
    for k in keys {
        while (typeCount[k] < minPerType && picked.Length < total) {
            found := false
            for q in shuffled {
                if (q.primary_axis != k)
                    continue
                already := false
                for p in picked {
                    if (p.id = q.id) {
                        already := true
                        break
                    }
                }
                if (already)
                    continue
                picked.Push(q)
                typeCount[k]++
                found := true
                break
            }
            if !found
                break
        }
    }
    while (picked.Length < total) {
        added := false
        for q in shuffled {
            already := false
            for p in picked {
                if (p.id = q.id) {
                    already := true
                    break
                }
            }
            if (already)
                continue
            picked.Push(q)
            added := true
            if (picked.Length >= total)
                break
        }
        if !added
            break
    }
    ids := []
    for q in picked
        ids.Push(q.id)
    return { ids: ids, repeat_warning: false }
}

PickVdaQuestionIds(pool, seed) {
    basePool := []
    phasePool := []
    for q in pool {
        if (q.HasOwnProp("vda_section") && q.vda_section = "phase")
            phasePool.Push(q)
        else
            basePool.Push(q)
    }
    keys := GetSoulPcmKeys()
    pickBase := PickVdaSectionIds(basePool, keys, seed "_vda_base", 12, 2)
    pickPhase := PickVdaSectionIds(phasePool, keys, seed "_vda_phase", 8, 2)
    ids := []
    for id in pickBase.ids
        ids.Push(id)
    for id in pickPhase.ids
        ids.Push(id)
    byId := Map()
    for q in pool
        byId[q.id] := q
    ord := PrimaOrderQuestionIdsAvoidRepeats(ids, byId, seed)
    ord.repeat_warning := ord.repeat_warning || pickBase.repeat_warning || pickPhase.repeat_warning
    return ord
}

PickShadowQuestionIds(pool, seed) {
    tenPool := []
    emoPool := []
    for q in pool {
        if (q.HasOwnProp("shadow_kind") && q.shadow_kind = "emotion")
            emoPool.Push(q)
        else
            tenPool.Push(q)
    }
    tenKeys := GetShadowAxisKeys()
    pickedTen := []
    shuffledTen := tenPool.Clone()
    PrimaShuffleArraySeeded(shuffledTen, seed "_sh_t")
    for k in tenKeys {
        for q in shuffledTen {
            if (q.primary_axis != k)
                continue
            pickedTen.Push(q)
            break
        }
    }
    while (pickedTen.Length < 10) {
        added := false
        for q in shuffledTen {
            dup := false
            for p in pickedTen {
                if (p.id = q.id) {
                    dup := true
                    break
                }
            }
            if (dup)
                continue
            pickedTen.Push(q)
            added := true
            if (pickedTen.Length >= 10)
                break
        }
        if !added
            break
    }
    shuffledEmo := emoPool.Clone()
    PrimaShuffleArraySeeded(shuffledEmo, seed "_sh_e")
    pickedEmo := []
    for q in shuffledEmo {
        pickedEmo.Push(q)
        if (pickedEmo.Length >= 5)
            break
    }
    ids := []
    for q in pickedTen
        ids.Push(q.id)
    for q in pickedEmo
        ids.Push(q.id)
    byId := Map()
    for q in pool
        byId[q.id] := q
    ord := PrimaOrderQuestionIdsAvoidRepeats(ids, byId, seed "_sh_ord")
    tensionIds := []
    emotionIds := []
    for id in ord.ids {
        if (byId[id].shadow_kind = "emotion")
            emotionIds.Push(id)
        else
            tensionIds.Push(id)
    }
    finalIds := []
    for id in tensionIds
        finalIds.Push(id)
    for id in emotionIds
        finalIds.Push(id)
    return { ids: finalIds, repeat_warning: ord.repeat_warning }
}

BuildQuestionSet(testType, profileId := "", seed := "") {
    path := ""
    switch testType {
        case "soul": path := "prima_soul"
        case "vda": path := "prima_vda"
        case "shadow": path := "prima_shadow"
        default: return ""
    }
    expected := testType = "soul" ? 15 : testType = "vda" ? 20 : 15
    if (seed = "")
        seed := PrimaMakeQuestionSeed(profileId, testType)
    pool := PrimaActivePoolForTestType(testType)
    if (pool.Length < expected)
        return ""
    pickResult := testType = "soul" ? PickSoulQuestionIds(pool, seed)
        : testType = "vda" ? PickVdaQuestionIds(pool, seed)
        : PickShadowQuestionIds(pool, seed)
    if (pickResult.ids.Length != expected)
        return ""
    bankById := Map()
    for q in pool
        bankById[q.id] := q
    questions := []
    for i, id in pickResult.ids {
        if !bankById.Has(id)
            return ""
        q := bankById[id]
        ansSeed := seed "_q" i
        orderedAnswers := PrimaShuffleAnswersSeeded(q, ansSeed)
        answerOrder := ""
        for a in orderedAnswers
            answerOrder .= (answerOrder = "" ? "" : ",") . a.id
        questions.Push({
            id: q.id, path: q.path,
            context: q.HasOwnProp("environment") ? q.environment : q.context,
            category: q.HasOwnProp("target") ? q.target : q.category,
            signal_type: (q.HasOwnProp("signal_type") ? q.signal_type : ""),
            prompt: q.prompt, max_choices: q.max_choices,
            answers: orderedAnswers,
            session_index: i,
            answer_order: answerOrder
        })
    }
    return {
        active_path: path,
        test_type: testType,
        question_seed: seed,
        bank_version: PrimaQuestionBankVersion(),
        questions: questions,
        current_index: 1,
        answers: [],
        rankings: [],
        completed: false,
        pick_repeat_warning: pickResult.HasOwnProp("repeat_warning") ? pickResult.repeat_warning : false
    }
}

PrimaRestoreAnswerOrder(q, orderStr) {
    parts := StrSplit(orderStr, ",", " ")
    byId := Map()
    for a in q.answers
        byId[a.id] := a
    ordered := []
    for id in parts {
        if byId.Has(id)
            ordered.Push(byId[id])
    }
    for a in q.answers {
        found := false
        for o in ordered {
            if (o.id = a.id) {
                found := true
                break
            }
        }
        if !found
            ordered.Push(a)
    }
    return ordered
}

PrimaSessionQuestionFromBank(q, answerOrderStr := "") {
    answers := answerOrderStr != "" ? PrimaRestoreAnswerOrder(q, answerOrderStr) : ShuffleAnswers(q)
    return {
        id: q.id, path: q.path,
        context: q.HasOwnProp("environment") ? q.environment : q.context,
        category: q.HasOwnProp("target") ? q.target : q.category,
        signal_type: (q.HasOwnProp("signal_type") ? q.signal_type : ""),
        prompt: q.prompt, max_choices: q.max_choices,
        answers: answers,
        answer_order: answerOrderStr
    }
}

PrimaWriteSessionQuestionMeta(file, session) {
    IniWrite(session.question_seed, file, "session", "question_seed")
    IniWrite(session.bank_version, file, "session", "bank_version")
    if (session.HasOwnProp("pick_repeat_warning") && session.pick_repeat_warning)
        IniWrite("1", file, "session", "question_pick_repeat_warning")
    else
        IniWrite("0", file, "session", "question_pick_repeat_warning")
    for q in session.questions {
        ord := q.HasOwnProp("answer_order") ? q.answer_order : ""
        if (ord = "") {
            for a in q.answers
                ord .= (ord = "" ? "" : ",") . a.id
        }
        IniWrite(ord, file, "answer_order", q.id)
    }
}

PrimaRebuildSessionQuestions(path, ids, file) {
    bankById := Map()
    for q in GetSoulQuestionsForPath(path)
        bankById[q.id] := q
    questions := []
    for i, id in ids {
        if !bankById.Has(id)
            throw Error("unknown question id " id)
        q := bankById[id]
        orderStr := IniRead(file, "answer_order", id, "")
        sq := PrimaSessionQuestionFromBank(q, orderStr)
        sq.session_index := i
        questions.Push(sq)
    }
    return questions
}

TestGuidanceHint(path, currentIndex) {
    if (currentIndex != 1)
        return ""
    switch path {
        case "prima_soul": return T("soul_test_guidance")
        case "prima_vda": return T("vda_test_guidance")
        case "prima_shadow": return T("shadow_test_guidance")
    }
    return ""
}
