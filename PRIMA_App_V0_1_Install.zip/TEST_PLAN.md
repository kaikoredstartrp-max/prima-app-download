# Plan de test — PRIMA App V0.1

## Prérequis

- AutoHotkey v2 installé
- Workspace propre (pas de profils existants)

## Tests manuels

### 1. Lancement sans profil
- [ ] Lancer `PrimaApp.ahk`
- [ ] Vérifier écran Boot (titre « PRIMA App V0.1 », logo PRIMA visible)
- [ ] Vérifier transition vers Profile
- [ ] Vérifier message « Aucun profil local »
- [ ] Vérifier boutons « Créer un profil » et « Quitter »

### 2. Création profil k1000
- [ ] Cliquer « Créer un profil »
- [ ] Entrer `k1000`, cliquer « Créer »
- [ ] Vérifier création dans `profiles/` :
  - `profiles.ini`
  - `<profile_id>/profile.ini`
  - `<profile_id>/consent.ini`
  - `<profile_id>/state.ini`
  - `<profile_id>/logs/`
- [ ] Vérifier log `profile_created` dans `logs/`

### 3. Privacy
- [ ] Vérifier texte confidentialité local-first
- [ ] Cliquer « J'accepte »
- [ ] Vérifier `privacy_accepted=yes` dans `consent.ini`
- [ ] Vérifier log `privacy_accepted`
- [ ] Vérifier ouverture START_HERE

### 4. START_HERE
- [ ] Vérifier « Bienvenue dans PRIMA »
- [ ] Vérifier nom profil affiché (k1000)
- [ ] Cliquer « Lancer PRIMA »
- [ ] Vérifier `onboarding_completed=yes` dans `state.ini`
- [ ] Vérifier log `onboarding_completed`
- [ ] Vérifier ouverture Home

### 5. Home
- [ ] Vérifier titre « Bienvenue dans PRIMA »
- [ ] Vérifier profil actif affiché
- [ ] Vérifier version V0.1
- [ ] Vérifier Review, Proof, Settings **désactivés**
- [ ] Vérifier Quitter **actif**
- [ ] Vérifier log `app_home_opened`

### 6. Relance directe Home
- [ ] Fermer l'app (Quitter)
- [ ] Relancer `PrimaApp.ahk`
- [ ] Vérifier Boot puis **Home direct** (pas Profile/Privacy/START_HERE)

### 7. Quitter depuis chaque écran
- [ ] Sans profil : Quitter depuis Profile → app fermée, log `app_closed`
- [ ] Avec profil incomplet : Quitter depuis chaque écran
- [ ] Depuis Home : Quitter → log `app_closed`

### 8. Hotkeys
- [ ] `Ctrl+Alt+Shift+X` → message pause, log `app_paused`
- [ ] `Ctrl+Alt+Shift+X` à nouveau → message reprise, log `app_resumed`
- [ ] `Ctrl+Alt+Shift+Q` → fermeture immédiate, log `app_emergency_exit`

### 9. Git — profiles/ non stagé
- [ ] `git init` si nécessaire
- [ ] `git add .`
- [ ] `git status` → `profiles/*` (sauf `.gitkeep`) **non stagé**
- [ ] `logs/*` (sauf `.gitkeep`) **non stagé**

### 10. Absence réseau / API / cloud / télémétrie
- [ ] Inspecter `PrimaApp.ahk` : aucun `Http`, `URL`, `WinHttp`, socket
- [ ] Aucune dépendance externe dans le projet
- [ ] Aucun appel réseau au runtime (moniteur réseau optionnel)

## Retour

| Test | Résultat | Notes |
|------|----------|-------|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
| 7 | | |
| 8 | | |
| 9 | | |
| 10 | | |
