# PRIMA App V0.1 — Clean Spine Architecture

## Vue d'ensemble

PRIMA App V0.1 est une application locale Windows en AutoHotkey v2.
Objectif unique : poser la fondation (spine) du flux utilisateur.

## Flux principal

```mermaid
flowchart LR
    Boot --> Profile
    Profile -->|nouveau profil| Privacy
    Profile -->|profil existant incomplet| Privacy
    Profile -->|profil existant incomplet| StartHere
    Profile -->|profil complété| Home
    Privacy --> StartHere
    StartHere --> Home
    Boot -->|relance, profil complété| Home
```

## Écrans

| Écran | Rôle | Transitions |
|-------|------|-------------|
| Boot | Splash PRIMA (1,2 s) | → Profile ou Home |
| Profile | Sélection / création profil | → Privacy, Home, Quit |
| Create Profile | Saisie nom | → Privacy |
| Privacy | Consentement local-first | → START_HERE, Retour Profile |
| START_HERE | Onboarding | → Home, Retour Profile |
| Home | Hub principal V0.1 | Quit |

## Stockage

```
profiles/
├── profiles.ini          # Index [Index] Profile1, Profile2...
├── app_state.ini         # last_profile_id
└── <profile_id>/
    ├── profile.ini       # profile_id, display_name, created_at, last_used_at
    ├── consent.ini       # privacy_accepted
    ├── state.ini         # onboarding_completed
    └── logs/             # logs par profil

logs/
└── YYYY-MM-DD_prima.log  # logs application
```

## Logs événements

| Événement | Déclencheur |
|-----------|-------------|
| `app_started` | Lancement |
| `profile_created` | Création profil |
| `profile_selected` | Continuer sur profil existant |
| `privacy_accepted` | J'accepte |
| `onboarding_completed` | Lancer PRIMA |
| `app_home_opened` | Affichage Home |
| `app_closed` | Quitter normal |
| `app_paused` / `app_resumed` | Hotkey X |
| `app_emergency_exit` | Hotkey Q |

## Contraintes V0.1

- Une seule fenêtre à la fois
- UI sombre, lisible
- Review, Proof, Settings visibles mais désactivés
- Pas de fonctionnalité réseau

## Évolution future (hors V0.1)

- Review, Proof, Settings (activation)
- Intégration documents `_drive_reference/`
- Modules système (`system/guide`, `system/review`, `system/proof`)
