PRIMA App V0.1 - Installation
=============================

1. Installez AutoHotkey v2 : https://www.autohotkey.com/
2. Extrayez ce dossier.
3. Lancez launch_prima.ahk
4. Creez votre profil et choisissez un mot de passe local.

Local-first : vos donnees restent sur votre PC.
Aucun profil ni mot de passe n'est inclus dans ce package.

Version : QA hardened PRIMA Soul (2026-06-12)