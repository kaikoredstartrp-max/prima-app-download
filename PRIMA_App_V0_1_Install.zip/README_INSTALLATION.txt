PRIMA App V0.1 - Installation locale
=====================================

Ce package contient une copie propre de PRIMA App, sans profils,
logs ou donnees personnelles. Tout fonctionne en local sur votre PC.


1. Installer AutoHotkey v2 (si absent)
--------------------------------------
PRIMA App necessite AutoHotkey version 2.

  - Telechargez AutoHotkey v2 sur : https://www.autohotkey.com/
  - Installez la version 2 (pas la v1).
  - Redemarrez PRIMA apres l installation si besoin.


2. Lancer PRIMA App
-------------------
Extrayez ce dossier ou vous voulez (par ex. Bureau ou Documents).

  - Double-cliquez sur launch_prima.ahk, ou
  - Double-cliquez sur PRIMA App.lnk si le raccourci est present.

Le raccourci PRIMA App.lnk peut etre cree ou repare depuis
Kit PRIMA une fois AutoHotkey v2 installe.


3. Creer un profil
------------------
Au premier lancement, l ecran Profil s affiche.

  - Cliquez sur Creer profil.
  - Entrez un nom d affichage.
  - Choisissez Client ou Createur selon votre usage.
  - Choisissez la langue (Francais ou English).


4. Choisir un mot de passe
---------------------------
Chaque profil est protege par un mot de passe local.

  - Definissez un mot de passe lors de la creation.
  - Confirmez-le.
  - Conservez-le : il n y a pas de recuperation cloud.


5. Verifier l installation avec Kit PRIMA
-----------------------------------------
Une fois connecte, ouvrez Kit PRIMA depuis l accueil.

  - Cliquez sur Verifier pour controler dossiers et fichiers.
  - Utilisez Creer ce qui manque si des elements sont absents.
  - Enregistrez si besoin.

Kit PRIMA confirme que votre installation locale est prete.


6. Fonctionnement local-first
-----------------------------
  - Vos donnees restent sur votre machine (dossiers profiles/, logs/, reviews/).
  - Aucune synchronisation cloud automatique.
  - Vous gardez le controle de vos fichiers.


7. Aucun compte cloud / API requis
------------------------------------
  - Pas de compte a creer.
  - Pas de cle API obligatoire pour utiliser PRIMA App V0.1.
  - L application fonctionne hors ligne apres installation.


Structure du dossier
--------------------
  PrimaApp.ahk          - Application principale
  launch_prima.ahk      - Lanceur local
  PRIMA App.lnk         - Raccourci Windows (si present)
  profiles/             - Profils utilisateur (vide au depart)
  logs/                 - Journaux locaux
  reviews/              - Revues exportees


PRIMA App V0.1 - local-first, sans publication en ligne.