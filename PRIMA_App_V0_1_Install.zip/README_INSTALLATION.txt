PRIMA App V0.1 - Installation locale
=====================================

1. Installez AutoHotkey v2 : https://www.autohotkey.com/
2. Lancez launch_prima.ahk ou PRIMA App.lnk
3. Creez un profil et un mot de passe
4. Verifiez avec Kit PRIMA

Local-first. Aucune donnee personnelle incluse.