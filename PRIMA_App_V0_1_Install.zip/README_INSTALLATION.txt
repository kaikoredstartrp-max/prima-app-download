﻿PRIMA App V0.1 — Installation
=============================

PRIMA App V0.1 — Stable

Contenu :
- Kit PRIMA V0.1
- PRIMA Soul minimal
- Soul / VDA / Shadow
- Questions chirurgicales
- Reprise test
- Rester connecté
- Ranking corrigé
- Choix Univers
- Choix Territoire
- Choix Race / Forme symbolique
- Forces/faiblesses cohérentes par territoire
- Identité PRIMA verrouillée par profil

Important :
Pour cette version, créez un profil neuf.
Les anciens profils de test peuvent contenir des états corrompus.

Installation :
1. Extrayez ce dossier où vous voulez sur votre PC Windows.
2. Installez AutoHotkey v2 : https://www.autohotkey.com/
3. Lancez launch_prima.ahk (double-clic).
4. Créez un profil neuf et un mot de passe local.
5. Utilisez Kit PRIMA pour vérifier l'installation.
