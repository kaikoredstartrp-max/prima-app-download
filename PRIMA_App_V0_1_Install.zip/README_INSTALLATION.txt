﻿PRIMA App V0.1 — Installation
=============================

1. Extrayez ce dossier où vous voulez sur votre PC Windows.
2. Installez AutoHotkey v2 : https://www.autohotkey.com/
3. Lancez launch_prima.ahk (double-clic).
4. Créez un profil et un mot de passe local.
5. Utilisez Kit PRIMA pour vérifier l'installation.

Version : QA hardened 2026-06-12 (hotfix packaging)
