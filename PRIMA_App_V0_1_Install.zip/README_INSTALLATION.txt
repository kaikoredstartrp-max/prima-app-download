﻿PRIMA App V0.1 - Installation locale
=====================================

1. Installez AutoHotkey v2 : https://www.autohotkey.com/
2. Lancez launch_prima.ahk
3. Creez un profil (2 etapes) et un mot de passe
4. Verifiez avec Kit PRIMA

Local-first. Aucune donnee personnelle incluse.
