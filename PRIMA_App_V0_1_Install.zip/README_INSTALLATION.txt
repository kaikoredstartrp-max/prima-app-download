PRIMA App V0.1 - Installez AutoHotkey v2, lancez launch_prima.ahk, creez un profil.
