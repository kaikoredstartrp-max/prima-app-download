﻿PRIMA App V0.1 — Installation locale
=====================================

Ce package contient une copie propre de PRIMA App, sans profils,
logs ou données personnelles. Tout fonctionne en local sur votre PC.


1. Installer AutoHotkey v2 (si absent)
--------------------------------------
PRIMA App nécessite AutoHotkey version 2.

  • Téléchargez AutoHotkey v2 sur : https://www.autohotkey.com/
  • Installez la version 2 (pas la v1).
  • Redémarrez PRIMA après l’installation si besoin.


2. Lancer PRIMA App
-------------------
Extrayez ce dossier où vous voulez (par ex. Bureau ou Documents).

  • Double-cliquez sur « launch_prima.ahk », ou
  • Double-cliquez sur « PRIMA App.lnk » si le raccourci est présent.

Le raccourci « PRIMA App.lnk » peut aussi être créé plus tard depuis
Kit PRIMA une fois AutoHotkey v2 installé.


3. Créer un profil
------------------
Au premier lancement, l’écran Profil s’affiche.

  • Cliquez sur « Créer profil ».
  • Entrez un nom d’affichage.
  • Choisissez Client ou Créateur selon votre usage.
  • Choisissez la langue (Français ou English).


4. Choisir un mot de passe
---------------------------
Chaque profil est protégé par un mot de passe local.

  • Définissez un mot de passe lors de la création.
  • Confirmez-le.
  • Conservez-le : il n’y a pas de récupération cloud.


5. Vérifier l’installation avec Kit PRIMA
-----------------------------------------
Une fois connecté, ouvrez « Kit PRIMA » depuis l’accueil.

  • Cliquez sur « Vérifier » pour contrôler dossiers et fichiers.
  • Utilisez « Créer ce qui manque » si des éléments sont absents.
  • Enregistrez si besoin.

Kit PRIMA confirme que votre installation locale est prête.


6. Fonctionnement local-first
-----------------------------
  • Vos données restent sur votre machine (dossiers profiles/, logs/, reviews/).
  • Aucune synchronisation cloud automatique.
  • Vous gardez le contrôle de vos fichiers.


7. Aucun compte cloud / API requis
------------------------------------
  • Pas de compte à créer.
  • Pas de clé API obligatoire pour utiliser PRIMA App V0.1.
  • L’application fonctionne hors ligne après installation.


Structure du dossier
--------------------
  PrimaApp.ahk          — Application principale
  launch_prima.ahk      — Lanceur local
  PRIMA App.lnk         — Raccourci Windows (si présent)
  profiles/             — Profils utilisateur (vide au départ)
  logs/                 — Journaux locaux
  reviews/              — Revues exportées


PRIMA App V0.1 — local-first, sans publication en ligne.
