﻿PRIMA App V0.1 — Installation
=============================

Version stable PRIMA App V0.1

Contenu :
- Kit PRIMA V0.1
- PRIMA Soul minimal
- Soul / VDA / Shadow
- Reprise test
- Rester connecté
- Ranking corrigé
- Questions chirurgicales
- Choix Univers
- Choix Territoire
- Choix Race / Forme symbolique
- Identité PRIMA verrouillée par profil

Important :
Cette version doit être testée avec un profil neuf.
Les anciens profils de test peuvent contenir des états corrompus.

Installation :
1. Extrayez ce dossier où vous voulez sur votre PC Windows.
2. Installez AutoHotkey v2 : https://www.autohotkey.com/
3. Lancez launch_prima.ahk (double-clic).
4. Créez un profil neuf et un mot de passe local.
5. Utilisez Kit PRIMA pour vérifier l'installation.
