# system/guide

Espace réservé aux guides PRIMA intégrés dans l'application.

## V0.1

Non implémenté. Le bouton **Settings** sur Home est visible mais désactivé.

## Référence

Documents officiels attendus (voir `_drive_reference/REQUIRED_DOCS.md`) :

- PRIMA Guide V1 Commun
