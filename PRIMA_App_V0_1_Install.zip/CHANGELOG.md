# Changelog — PRIMA App

## V0.1 — Clean Spine Foundation (2026-06-09)

### Ajouté
- Application locale AutoHotkey v2 (`PrimaApp.ahk`)
- Flux complet : Boot → Profile → Privacy → START_HERE → Home
- Gestion des profils locaux (`profiles/`)
- Écran de confidentialité local-first
- Logs locaux (`logs/`)
- Hotkeys pause (`Ctrl+Alt+Shift+X`) et fermeture d'urgence (`Ctrl+Alt+Shift+Q`)
- Relance directe vers Home si profil complété
- Documentation système et protocole de test
- Référence Drive (`_drive_reference/`)

### Règles
- Aucun cloud, réseau, API, télémétrie, micro, capture écran
- Données locales uniquement
- Profils ignorés par Git
