# PRIMA App V0.1

Application locale Windows — **Clean Spine Foundation**.

## Prérequis

- Windows 10/11
- [AutoHotkey v2](https://www.autohotkey.com/) installé

## Lancement

Double-cliquer sur `PrimaApp.ahk` ou exécuter :

```
AutoHotkey64.exe PrimaApp.ahk
```

## Flux

```
Boot → Profile → Privacy → START_HERE → Home
```

- **Boot** : écran d'accueil PRIMA (1,2 s)
- **Profile** : sélection ou création de profil local
- **Privacy** : acceptation confidentialité local-first
- **START_HERE** : onboarding profil
- **Home** : écran principal (Review, Proof, Settings désactivés en V0.1)

Si un profil complété existe, relance directe vers **Home**.

## Hotkeys

| Raccourci | Action |
|-----------|--------|
| `Ctrl+Alt+Shift+X` | Pause / reprise + message |
| `Ctrl+Alt+Shift+Q` | Fermeture d'urgence |

## Données locales

| Chemin | Contenu |
|--------|---------|
| `profiles/profiles.ini` | Index des profils |
| `profiles/<id>/profile.ini` | Métadonnées profil |
| `profiles/<id>/consent.ini` | Acceptation confidentialité |
| `profiles/<id>/state.ini` | État onboarding |
| `profiles/<id>/logs/` | Logs par profil |
| `logs/` | Logs application |

## Règles non négociables

- Pas de cloud, réseau, API, télémétrie
- Pas de micro, capture écran, Discord
- Pas de web app, React, Next.js, SaaS
- AutoHotkey v2 uniquement
- Données locales uniquement
- **ArcOS est legacy — non utilisé**

## Documentation

- `TEST_PLAN.md` — plan de test manuel
- `SECURITY_NOTES.md` — notes sécurité
- `system/` — architecture et protocoles
- `_drive_reference/` — exports documents PRIMA (non privé)
